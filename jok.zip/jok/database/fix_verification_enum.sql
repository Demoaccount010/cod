-- Migration: Ensure all verification_status enum values exist
-- Run this in Supabase SQL Editor

-- If verification_status is a PostgreSQL ENUM type, add missing values:
DO $$
BEGIN
    -- Check if the type exists first
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'verification_status') THEN
        -- Add all values that might be missing
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'pending'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'queued'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'sent'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'delivered'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'read'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'confirmed'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'cancelled'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'failed'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'expired'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'no_reply'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'phone_missing'; EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TYPE verification_status ADD VALUE IF NOT EXISTS 'not_required'; EXCEPTION WHEN duplicate_object THEN NULL; END;
    END IF;
END $$;

-- If the column is VARCHAR instead of ENUM, no migration needed (any string is valid).
-- To check, run: SELECT data_type, udt_name FROM information_schema.columns WHERE table_name = 'orders' AND column_name = 'verification_status';

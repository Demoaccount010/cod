-- ═══════════════════════════════════════════════════════════════════════
-- Worker Activity & Per-Day Hours Migration
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════════════

-- 1. Add last_activity_at to users table
--    Tracks when a worker last did real work (accept chat, send reply, verify call)
--    Used by the auto-offline scheduler to detect truly inactive workers.
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;

-- 2. Add duration_seconds to worker_duty_logs table
--    Stores how many seconds this particular session/break lasted.
--    Populated on clock_out, break_start, and auto_offline events.
--    Allows per-day duty hours to be computed by summing duration_seconds.
ALTER TABLE worker_duty_logs ADD COLUMN IF NOT EXISTS duration_seconds bigint DEFAULT 0;

-- 3. Also update the action check constraint to include 'auto_offline'
--    (so auto-offline events from the scheduler are stored cleanly)
ALTER TABLE worker_duty_logs DROP CONSTRAINT IF EXISTS worker_duty_logs_action_check;
ALTER TABLE worker_duty_logs ADD CONSTRAINT worker_duty_logs_action_check
    CHECK (action IN ('clock_in', 'clock_out', 'break_start', 'break_end', 'auto_offline'));

-- Done!

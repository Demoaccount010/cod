-- Database migration part 2 - Additional tables and features

-- WhatsApp integration tables
CREATE TABLE whatsapp_accounts (
    id SERIAL PRIMARY KEY,
    merchant_id INTEGER REFERENCES merchants(id),
    whatsapp_business_account_id VARCHAR(255) UNIQUE NOT NULL,
    access_token VARCHAR(500),
    phone_number_id VARCHAR(255),
    phone_number VARCHAR(20),
    is_verified BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- WhatsApp messages table
CREATE TABLE whatsapp_messages (
    id SERIAL PRIMARY KEY,
    merchant_id INTEGER REFERENCES merchants(id),
    customer_id INTEGER REFERENCES customers(id),
    whatsapp_message_id VARCHAR(255) UNIQUE,
    message_type VARCHAR(50), -- text, image, document, etc
    message_content TEXT,
    direction VARCHAR(20), -- incoming/outgoing
    status VARCHAR(50), -- sent, delivered, read, failed
    external_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Subscriptions table
CREATE TABLE subscriptions (
    id SERIAL PRIMARY KEY,
    merchant_id INTEGER REFERENCES merchants(id),
    plan_type VARCHAR(100), -- free, starter, professional, enterprise
    monthly_price DECIMAL(10,2),
    max_messages INTEGER,
    max_stores INTEGER,
    max_templates INTEGER,
    is_active BOOLEAN DEFAULT true,
    start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    renewal_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Billing records table
CREATE TABLE billing_records (
    id SERIAL PRIMARY KEY,
    subscription_id INTEGER REFERENCES subscriptions(id),
    merchant_id INTEGER REFERENCES merchants(id),
    amount DECIMAL(10,2),
    period_start DATE,
    period_end DATE,
    status VARCHAR(50), -- pending, paid, overdue
    invoice_number VARCHAR(50),
    due_date DATE,
    paid_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verification documents table
CREATE TABLE verification_documents (
    id SERIAL PRIMARY KEY,
    merchant_id INTEGER REFERENCES merchants(id),
    document_type VARCHAR(100), -- cnic, ntn, bank_statement
    document_url VARCHAR(500),
    status VARCHAR(50), -- pending, approved, rejected
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Support tickets table
CREATE TABLE support_tickets (
    id SERIAL PRIMARY KEY,
    merchant_id INTEGER REFERENCES merchants(id),
    title VARCHAR(255),
    description TEXT,
    category VARCHAR(100),
    priority VARCHAR(50), -- low, medium, high, urgent
    status VARCHAR(50), -- open, in_progress, resolved, closed
    assigned_to INTEGER REFERENCES admins(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Support ticket replies table
CREATE TABLE ticket_replies (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER REFERENCES support_tickets(id),
    responder_id INTEGER,
    reply_text TEXT,
    attachments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create additional indexes
CREATE INDEX idx_whatsapp_merchant ON whatsapp_accounts(merchant_id);
CREATE INDEX idx_subscription_merchant ON subscriptions(merchant_id);
CREATE INDEX idx_billing_merchant ON billing_records(merchant_id);
CREATE INDEX idx_support_status ON support_tickets(status);
CREATE INDEX idx_whatsapp_messages_merchant ON whatsapp_messages(merchant_id);

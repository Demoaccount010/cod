-- ═══════════════════════════════════════════════════════════════
-- Migration: Remove Twilio & Plivo from admin_settings
-- ═══════════════════════════════════════════════════════════════
-- Run this in Supabase SQL Editor to clean up Twilio/Plivo columns

-- Remove Twilio columns from admin_settings
ALTER TABLE admin_settings DROP COLUMN IF EXISTS twilio_account_sid;
ALTER TABLE admin_settings DROP COLUMN IF EXISTS twilio_auth_token;
ALTER TABLE admin_settings DROP COLUMN IF EXISTS twilio_from_number;
ALTER TABLE admin_settings DROP COLUMN IF EXISTS twilio_enabled;

-- Remove Plivo columns from admin_settings
ALTER TABLE admin_settings DROP COLUMN IF EXISTS plivo_auth_id;
ALTER TABLE admin_settings DROP COLUMN IF EXISTS plivo_auth_token;
ALTER TABLE admin_settings DROP COLUMN IF EXISTS plivo_from_number;

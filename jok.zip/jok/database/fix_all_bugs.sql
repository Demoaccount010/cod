-- ═══════════════════════════════════════════════════════════════════════
-- CODVerify System Audit Fix Migration
-- Run this in Supabase SQL Editor
-- Fixes all critical schema bugs found during system audit
-- ═══════════════════════════════════════════════════════════════════════

-- ── FIX 1: Add 'claimed' to order_verifications.call_status CHECK ──────
-- The backend uses call_status='claimed' to mark orders taken by workers,
-- but the DB CHECK constraint only allows: pending, answered, not_picked, cancel, callback
-- This causes a DB error whenever a worker claims or admin assigns an order.

ALTER TABLE order_verifications
  DROP CONSTRAINT IF EXISTS order_verifications_call_status_check;

ALTER TABLE order_verifications
  ADD CONSTRAINT order_verifications_call_status_check
  CHECK (call_status IN ('pending', 'answered', 'not_picked', 'cancel', 'callback', 'claimed'));


-- ── FIX 2: Add 'system' to chat_messages.sender_type CHECK ─────────────
-- The backend inserts sender_type='system' when a worker accepts or resolves
-- a session ("✅ Agent joined" / "✅ Conversation resolved"), but the CHECK
-- constraint only allows: visitor, ai, worker — causing a DB constraint error.

ALTER TABLE chat_messages
  DROP CONSTRAINT IF EXISTS chat_messages_sender_type_check;

ALTER TABLE chat_messages
  ADD CONSTRAINT chat_messages_sender_type_check
  CHECK (sender_type IN ('visitor', 'ai', 'worker', 'system'));


-- ── FIX 3: Add 'auto_offline' to worker_duty_logs.action CHECK ─────────
-- The heartbeat stale-detection code inserts action='auto_offline' when a
-- worker's connection drops, but no CHECK constraint exists on this column —
-- added here for correctness and future safety.

ALTER TABLE worker_duty_logs
  DROP CONSTRAINT IF EXISTS worker_duty_logs_action_check;

ALTER TABLE worker_duty_logs
  ADD CONSTRAINT worker_duty_logs_action_check
  CHECK (action IN ('clock_in', 'clock_out', 'break_start', 'break_end', 'auto_offline'));


-- ── FIX 4: Ensure last_heartbeat column exists on users table ──────────
-- Confirmed this already exists in DB (verified via schema query),
-- but adding IF NOT EXISTS for safety in case of fresh deploys.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS last_heartbeat TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_users_last_heartbeat ON users(last_heartbeat);


-- ── FIX 5: Add missing setting_label and setting_group to admin_settings ─
-- The billing/pricing upsert in admin/billing.py inserts these two columns
-- but they don't exist in the DB → INSERT silently fails when creating new
-- per-order rate settings (e.g. per_order_rate_inr, per_order_rate_usd).

ALTER TABLE admin_settings
  ADD COLUMN IF NOT EXISTS setting_label TEXT,
  ADD COLUMN IF NOT EXISTS setting_group TEXT;

CREATE INDEX IF NOT EXISTS idx_admin_settings_group ON admin_settings(setting_group);


-- ── FIX 6: Add widget_theme column to merchant_chatbot_config ───────────
-- The chatbot settings page now supports light/dark theme switching.
-- This column stores the merchant's preferred widget theme.

ALTER TABLE merchant_chatbot_config
  ADD COLUMN IF NOT EXISTS widget_theme TEXT DEFAULT 'dark';


-- ── Verification ────────────────────────────────────────────────────────
SELECT 'All schema fixes applied successfully!' AS result;

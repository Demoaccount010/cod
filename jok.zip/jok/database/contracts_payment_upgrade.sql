-- ============================================================
-- Contract Payment System Upgrade
-- Adds: payment_type, auto_payment, EMI calculation, blacklist tracking
-- Run in Supabase SQL Editor
-- ============================================================

-- 1. Add new columns to contracts table
ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    payment_type TEXT NOT NULL DEFAULT 'one_time' 
    CHECK (payment_type IN ('one_time', 'emi', 'monthly_recurring'));

ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    auto_payment_enabled BOOLEAN DEFAULT true;

ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    emi_start_date TIMESTAMPTZ;  -- When EMI deductions start

ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    emi_schedule JSONB DEFAULT '[]';  -- Array of {month, amount, due_date, paid_date, status}

ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    payment_gateway TEXT DEFAULT 'razorpay';

ALTER TABLE contracts ADD COLUMN IF NOT EXISTS
    razorpay_subscription_id TEXT;  -- For recurring payments

-- 2. Drop and recreate contract_blacklist table (separate from merchant_blacklist which is for phone blacklisting)
DROP TABLE IF EXISTS contract_blacklist CASCADE;

CREATE TABLE contract_blacklist (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    notes TEXT,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_contract_blacklist_merchant ON contract_blacklist(merchant_id);
CREATE INDEX idx_contract_blacklist_created ON contract_blacklist(created_at);

-- 3. Drop and recreate payment failures table
DROP TABLE IF EXISTS payment_failures CASCADE;

CREATE TABLE payment_failures (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    contract_id UUID REFERENCES contracts(id) ON DELETE SET NULL,
    razorpay_payment_id TEXT,
    amount DECIMAL(12,2),
    failure_reason TEXT,
    retry_count INT DEFAULT 0,
    next_retry_at TIMESTAMPTZ,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'retried', 'blacklisted')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_payment_failures_merchant ON payment_failures(merchant_id);
CREATE INDEX idx_payment_failures_status ON payment_failures(status);

-- 4. Add blacklist_status to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS
    blacklist_status TEXT DEFAULT 'active' CHECK (blacklist_status IN ('active', 'blacklisted'));

ALTER TABLE users ADD COLUMN IF NOT EXISTS
    blacklist_reason TEXT;

ALTER TABLE users ADD COLUMN IF NOT EXISTS
    blacklist_date TIMESTAMPTZ;

-- 5. Enable RLS and add policies
ALTER TABLE contract_blacklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_failures ENABLE ROW LEVEL SECURITY;

-- Allow service role and backend to access all data
CREATE POLICY "allow_service_role_contract_blacklist" ON contract_blacklist
    FOR ALL USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');

CREATE POLICY "allow_service_role_payment_failures" ON payment_failures
    FOR ALL USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');

-- =====================================================================
-- Wallet System Migration
-- Run this in Supabase SQL Editor
-- =====================================================================

-- 1. Merchant Wallets table
CREATE TABLE IF NOT EXISTS merchant_wallets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    balance DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total_credited DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total_debited DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    low_balance_alert_sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT merchant_wallets_user_id_unique UNIQUE (user_id)
);

-- 2. Wallet Transactions table (full audit log)
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    wallet_id UUID REFERENCES merchant_wallets(id) ON DELETE SET NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('credit', 'debit')),
    amount DECIMAL(10, 4) NOT NULL,
    balance_before DECIMAL(12, 2),
    balance_after DECIMAL(12, 2),
    service_key VARCHAR(80),
    -- e.g. 'whatsapp_cod_verification' | 'call_verification' | 'manual_credit' | 'contract_credit'
    description TEXT,
    reference_id VARCHAR(150),
    -- order_id, contract_id, etc.
    contract_id UUID REFERENCES contracts(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Indexes for fast lookups
CREATE INDEX IF NOT EXISTS idx_merchant_wallets_user_id ON merchant_wallets (user_id);

CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id ON wallet_transactions (user_id);

CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at ON wallet_transactions (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_wallet_transactions_service_key ON wallet_transactions (service_key);

CREATE INDEX IF NOT EXISTS idx_wallet_transactions_contract_id ON wallet_transactions (contract_id);

-- 4. Auto-update updated_at on merchant_wallets
CREATE OR REPLACE FUNCTION update_wallet_updated_at ()
    RETURNS TRIGGER
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_wallet_updated_at ON merchant_wallets;

CREATE TRIGGER trg_wallet_updated_at
    BEFORE UPDATE ON merchant_wallets
    FOR EACH ROW
    EXECUTE FUNCTION update_wallet_updated_at ();

-- 5. Row Level Security (RLS) — merchants see only their own wallet
ALTER TABLE merchant_wallets ENABLE ROW LEVEL SECURITY;

ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Merchants: read own wallet
CREATE POLICY "merchant_wallet_select" ON merchant_wallets
    FOR SELECT USING (auth.uid () = user_id);

-- Merchants: read own transactions
CREATE POLICY "merchant_wallet_txn_select" ON wallet_transactions
    FOR SELECT USING (auth.uid () = user_id);

-- Service role (backend) can do everything
CREATE POLICY "service_role_wallet_all" ON merchant_wallets
    FOR ALL USING (auth.role () = 'service_role');

CREATE POLICY "service_role_txn_all" ON wallet_transactions
    FOR ALL USING (auth.role () = 'service_role');

-- 6. Check: contracts table me wallet_credit_amount column add karo agar nahi hai
ALTER TABLE contracts
    ADD COLUMN IF NOT EXISTS wallet_credit_amount DECIMAL(12, 2) DEFAULT 0.00;

-- Done!
SELECT
    'Wallet system migration completed successfully' AS status;

-- ============================================================
-- Careers / Jobs Table
-- Run this in Supabase SQL editor
-- ============================================================

CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Core
    title TEXT NOT NULL,
    department TEXT NOT NULL,
    location TEXT NOT NULL,
    job_type TEXT NOT NULL DEFAULT 'Full-time',         -- Full-time|Part-time|Remote|Contract
    experience_level TEXT NOT NULL DEFAULT 'Mid-level', -- Fresher|Junior|Mid-level|Senior|Lead
    slots INTEGER NOT NULL DEFAULT 1,                   -- Number of openings

    -- Salary
    salary_min INTEGER,
    salary_max INTEGER,
    salary_currency TEXT DEFAULT 'INR',
    salary_disclosed BOOLEAN DEFAULT TRUE,

    -- Rich content (HTML allowed)
    description TEXT NOT NULL,
    requirements TEXT,
    benefits TEXT,
    how_to_apply TEXT,
    application_email TEXT,
    application_url TEXT,

    -- Dates
    start_date DATE,
    end_date DATE,    -- Job auto-deactivates after this date (scheduler)

    -- Flags
    is_active BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,

    -- Meta
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Index for public listing query performance
CREATE INDEX IF NOT EXISTS idx_jobs_active ON jobs(is_active, end_date);
CREATE INDEX IF NOT EXISTS idx_jobs_department ON jobs(department);

-- RLS (disable for service key access, or enable with appropriate policies)
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read active jobs (public careers page)
CREATE POLICY "Public can read active jobs" ON jobs
    FOR SELECT USING (is_active = TRUE);

-- Only authenticated admins can write
CREATE POLICY "Admins can manage jobs" ON jobs
    FOR ALL USING (TRUE)
    WITH CHECK (TRUE);

-- ============================================================
-- Done! Now deploy backend and run the migrations above.
-- ============================================================

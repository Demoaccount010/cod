-- ============================================================
-- FIX: Restore merchant_blacklist for customer phone blacklisting
-- + Create contract_blacklist for auto-payment merchant blacklisting
--
-- Run this NOW in Supabase SQL Editor to fix the 500 error.
-- ============================================================

-- Step 1: Rename the broken merchant_blacklist (has merchant_id) to contract_blacklist
ALTER TABLE merchant_blacklist RENAME TO contract_blacklist;

-- Step 2: Recreate merchant_blacklist for customer phone blacklisting
CREATE TABLE IF NOT EXISTS merchant_blacklist (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,  -- the merchant
    phone_number_hash TEXT NOT NULL,
    phone_last_four   TEXT,
    reason      TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_merchant_blacklist_user_id
    ON merchant_blacklist(user_id);

CREATE INDEX IF NOT EXISTS idx_merchant_blacklist_phone_hash
    ON merchant_blacklist(user_id, phone_number_hash);

-- Step 3: RLS for merchant_blacklist
ALTER TABLE merchant_blacklist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_service_role_merchant_blacklist" ON merchant_blacklist
    FOR ALL USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');

-- Step 4: RLS for contract_blacklist (already exists from previous migration)
ALTER TABLE contract_blacklist ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE tablename = 'contract_blacklist'
          AND policyname = 'allow_service_role_contract_blacklist'
    ) THEN
        CREATE POLICY "allow_service_role_contract_blacklist" ON contract_blacklist
            FOR ALL USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');
    END IF;
END $$;

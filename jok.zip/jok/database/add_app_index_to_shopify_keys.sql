-- ─────────────────────────────────────────────────────────────────────────────
-- Migration: Add app_index to shopify_install_keys
-- Purpose  : Makes Shopify plugin fully stateless — server restart safe
-- Run this : Supabase Dashboard → SQL Editor → Paste → Run
-- Date     : 2026-03-16
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Add the column (safe — uses IF NOT EXISTS, no data loss)
ALTER TABLE shopify_install_keys
  ADD COLUMN IF NOT EXISTS app_index INTEGER DEFAULT 0;

-- 2. Backfill existing rows (all existing shops → app[0] which is the default)
UPDATE shopify_install_keys
  SET app_index = 0
  WHERE app_index IS NULL;

-- 3. Add index for faster lookups by shop_domain (if not already present)
CREATE INDEX IF NOT EXISTS idx_shopify_install_keys_shop_domain
  ON shopify_install_keys (shop_domain);

-- Verify
SELECT id, shop_domain, app_index, is_used, created_at
  FROM shopify_install_keys
  ORDER BY created_at DESC
  LIMIT 10;

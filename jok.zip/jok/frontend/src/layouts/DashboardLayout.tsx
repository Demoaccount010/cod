import { useState, useEffect, useRef, useCallback } from 'react';
import { Outlet, NavLink, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { merchantApi, workerApi } from '../api';
import { motion, AnimatePresence } from 'framer-motion';
import {
    LayoutDashboard, ShoppingCart, Store, Settings, FileText,
    Users, Wallet, HelpCircle, Bell, LogOut, Menu, ChevronDown,
    MessageSquare, Shield, BarChart3, Zap, Sparkles, Star, Mail, Headphones, Phone, Bot, Plug, PhoneCall, Briefcase, Lock
} from 'lucide-react';

const merchantNav = [
    { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/dashboard/orders', icon: ShoppingCart, label: 'Orders' },
    { to: '/dashboard/stores', icon: Store, label: 'Stores' },
    { to: '/dashboard/contract', icon: FileText, label: 'My Contract' },
    { to: '/dashboard/customers', icon: Users, label: 'Customers' },
    { to: '/dashboard/notifications', icon: Bell, label: 'Notifications' },
    { to: '/dashboard/support', icon: HelpCircle, label: 'Support' },
    { to: '/dashboard/chatbot', icon: Bot, label: 'AI Chatbot' },
    { to: '/dashboard/templates', icon: Sparkles, label: 'Templates' },
    { to: '/dashboard/api-keys', icon: Zap, label: 'API Keys' },
    { to: '/dashboard/settings', icon: Settings, label: 'Settings' },
];

const adminNav = [
    { to: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/admin/merchants', icon: Users, label: 'Merchants' },
    { to: '/admin/orders', icon: ShoppingCart, label: 'Orders' },
    { to: '/admin/contracts', icon: FileText, label: 'Contracts' },
    { to: '/admin/billing', icon: Wallet, label: 'Billing' },
    { to: '/admin/staff', icon: Headphones, label: 'Staff Management' },
    { to: '/admin/partners', icon: Shield, label: 'Partners' },
    { to: '/admin/blog', icon: FileText, label: 'Blog' },
    { to: '/admin/jobs', icon: Briefcase, label: 'Job Postings' },
    { to: '/admin/support', icon: HelpCircle, label: 'Support' },
    { to: '/admin/reviews', icon: Star, label: 'Reviews' },
    { to: '/admin/contact-inquiries', icon: Mail, label: 'Contact Inquiries' },
    { to: '/admin/blacklist', icon: Users, label: 'Blacklist' },
    { to: '/admin/settings', icon: Settings, label: 'Settings' },
    { to: '/admin/logs', icon: BarChart3, label: 'Activity Logs' },
    { to: '/admin/health', icon: Zap, label: 'System Health' },
    { to: '/admin/integrations', icon: Plug, label: 'Integrations' },
];

const workerNav = [
    { to: '/worker', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/worker/orders', icon: Phone, label: 'Verify Orders' },
    { to: '/worker/stores', icon: Store, label: 'Stores' },
    { to: '/worker/chat', icon: MessageSquare, label: 'Customer Support' },
    { to: '/worker/api-limits', icon: BarChart3, label: 'API Limits' },
    { to: '/worker/callbacks', icon: PhoneCall, label: 'Callbacks' },
];


export default function DashboardLayout() {
    const { user, logout, isAdmin, isWorker } = useAuth();
    const navigate = useNavigate();
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [profileOpen, setProfileOpen] = useState(false);
    const [unreadCount, setUnreadCount] = useState(0);
    // Worker-specific state
    const [workerDutyStatus, setWorkerDutyStatus] = useState<string>('off_duty');
    const [workerBadges, setWorkerBadges] = useState<{ orders: number; chats: number }>({ orders: 0, chats: 0 });
    const navItems = isAdmin ? adminNav : isWorker ? workerNav : merchantNav;
    const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

    useEffect(() => {
        if (isAdmin || isWorker) return;
        const fetchCount = async () => {
            try {
                const res = await merchantApi.getUnreadCount();
                setUnreadCount(res.data?.data?.count || 0);
            } catch { }
        };
        fetchCount();
        pollRef.current = setInterval(fetchCount, 30000);
        return () => { if (pollRef.current) clearInterval(pollRef.current); };
    }, [isAdmin]);

    // Worker: poll duty status + notification counts every 30s
    const fetchWorkerStatus = useCallback(async () => {
        if (!isWorker) return;
        try {
            const res = await workerApi.getDashboardStats();
            const data = res.data?.data;
            setWorkerDutyStatus(data?.duty?.status || 'off_duty');
            setWorkerBadges({
                orders: Math.max(0, (data?.verification?.total_today || 0) - (data?.verification?.answered || 0) - (data?.verification?.not_picked || 0) - (data?.verification?.cancelled || 0)),
                chats: data?.chats?.waiting || 0,
            });
        } catch { }
    }, [isWorker]);

    useEffect(() => {
        if (!isWorker) return;
        fetchWorkerStatus();
        const interval = setInterval(fetchWorkerStatus, 30000);
        return () => clearInterval(interval);
    }, [isWorker, fetchWorkerStatus]);

    const isOnDuty = workerDutyStatus === 'on_duty';

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    return (
        <div className="flex h-screen bg-[#F8FAFC] overflow-hidden">
            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 z-50 w-64 sm:w-72 md:w-64 transform transition-transform duration-300 lg:relative lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} sidebar-gradient border-r border-white/5 shadow-2xl shadow-black/50 max-h-screen overflow-y-auto`}>
                <div className="flex items-center gap-3 px-6 py-6 border-b border-white/5">
                    <div className="w-10 h-10 rounded-xl premium-gradient flex items-center justify-center shadow-lg shadow-indigo-500/20">
                        <MessageSquare className="w-5.5 h-5.5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-white font-bold text-xl tracking-tight font-['Outfit']">CODVerify</h1>
                        <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                            <p className="text-gray-400 text-[10px] uppercase tracking-[0.1em] font-semibold">{isAdmin ? 'Admin Portal' : isWorker ? 'Agent Portal' : 'Pro Merchant'}</p>
                        </div>
                    </div>
                </div>

                <div className="px-3 py-6 sidebar-scroll overflow-y-auto" style={{ height: 'calc(100vh - 160px)' }}>
                    <p className="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Main Menu</p>
                    <nav className="space-y-1.5">
                        {navItems.map(item => {
                            const isLockedForWorker = isWorker && !isOnDuty && (item.to === '/worker/orders' || item.to === '/worker/chat');
                            const badge = isWorker && !isLockedForWorker
                                ? (item.to === '/worker/orders' ? workerBadges.orders : item.to === '/worker/chat' ? workerBadges.chats : 0)
                                : 0;

                            if (isLockedForWorker) {
                                return (
                                    <button
                                        key={item.to}
                                        onClick={() => {
                                            import('sonner').then(({ toast }) => toast.error('⚠️ Go On Duty first to access this section'));
                                        }}
                                        className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 group text-gray-600 hover:bg-white/5 w-full opacity-60 cursor-not-allowed"
                                    >
                                        <item.icon className="w-4.5 h-4.5" />
                                        <span className="flex-1 text-left">{item.label}</span>
                                        <Lock className="w-3 h-3 text-gray-500" />
                                    </button>
                                );
                            }

                            return (
                                <NavLink key={item.to} to={item.to} end={item.to === '/dashboard' || item.to === '/admin' || item.to === '/worker'}
                                    onClick={() => setSidebarOpen(false)}
                                    className={({ isActive }) =>
                                        `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 group ${isActive ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]' : 'text-gray-400 hover:text-white hover:bg-white/5'
                                        }`
                                    }>
                                    <item.icon className={`w-4.5 h-4.5 transition-transform duration-300 group-hover:scale-110 ${sidebarOpen ? 'text-indigo-400' : ''}`} />
                                    <span className="flex-1">{item.label}</span>
                                    {badge > 0 && (
                                        <span className="min-w-[20px] h-[20px] px-1 bg-red-500 text-white rounded-full text-[9px] font-black flex items-center justify-center animate-bounce">
                                            {badge > 9 ? '9+' : badge}
                                        </span>
                                    )}
                                    {!isWorker && item.label === 'Dashboard' && <Sparkles className="w-3.5 h-3.5 text-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity" />}
                                </NavLink>
                            );
                        })}
                    </nav>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/5 bg-[#0F172A]/80 backdrop-blur-xl">
                    <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-gray-400 hover:text-red-400 hover:bg-red-500/10 w-full transition-all duration-300 group">
                        <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-red-500/20 transition-colors">
                            <LogOut className="w-4 h-4" />
                        </div>
                        <span className="font-semibold">Sign Out</span>
                    </button>
                </div>
            </aside>

            {/* Overlay */}
            <AnimatePresence>
                {sidebarOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
                        onClick={() => setSidebarOpen(false)}
                    />
                )}
            </AnimatePresence>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col min-w-0">
                <header className="glass-card border-b border-gray-200/50 px-4 lg:px-8 py-3.5 flex items-center justify-between sticky top-0 z-30">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-gray-500 hover:text-indigo-600 rounded-xl hover:bg-indigo-50 transition-all">
                            <Menu className="w-6 h-6" />
                        </button>
                        <div className="hidden lg:block">
                            <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-widest">{isAdmin ? 'System Intelligence' : isWorker ? 'Agent Tools' : 'Store Operations'}</h2>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 md:gap-4">


                        <Link to={isAdmin ? '/admin' : '/dashboard/notifications'} className="relative p-2.5 text-gray-500 hover:text-indigo-600 rounded-xl hover:bg-gray-100 transition-all group">
                            <Bell className="w-5.5 h-5.5" />
                            {!isAdmin && unreadCount > 0 && (
                                <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 bg-indigo-600 text-white rounded-full text-[9px] font-black flex items-center justify-center border-2 border-white">
                                    {unreadCount > 9 ? '9+' : unreadCount}
                                </span>
                            )}
                        </Link>

                        <div className="h-8 w-px bg-gray-200 mx-1" />

                        <div className="relative">
                            <button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center gap-3 p-1 rounded-xl hover:bg-gray-50 transition-all">
                                <div className="w-9 h-9 rounded-xl premium-gradient flex items-center justify-center text-white text-sm font-bold shadow-lg shadow-indigo-500/20">
                                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                                </div>
                                <div className="hidden md:block text-left">
                                    <p className="text-sm font-bold text-gray-900 font-['Outfit']">{user?.name}</p>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{user?.company_name || 'Personal Account'}</p>
                                </div>
                                <ChevronDown className={`w-4 h-4 text-gray-400 hidden md:block transition-transform duration-300 ${profileOpen ? 'rotate-180' : ''}`} />
                            </button>

                            <AnimatePresence>
                                {profileOpen && (
                                    <>
                                        <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
                                        <motion.div initial={{ opacity: 0, y: 15, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 15, scale: 0.95 }}
                                            className="absolute right-0 mt-3 w-64 bg-white/90 backdrop-blur-2xl rounded-2xl shadow-2xl border border-gray-100/50 py-3 z-50 overflow-hidden">
                                            <div className="px-4 py-2 border-b border-gray-50 mb-2">
                                                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Account</p>
                                            </div>
                                            <Link to={isAdmin ? '/admin/settings' : isWorker ? '/worker/settings' : '/dashboard/settings'} onClick={() => setProfileOpen(false)}
                                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 hover:text-indigo-600 transition-colors">
                                                <Settings className="w-4 h-4" /> Profile Settings
                                            </Link>
                                            {isAdmin && (
                                                <Link to='/admin/billing' onClick={() => setProfileOpen(false)}
                                                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 hover:text-indigo-600 transition-colors">
                                                    <Wallet className="w-4 h-4" /> Billing
                                                </Link>
                                            )}
                                            <div className="px-2 mt-2">
                                                <button onClick={handleLogout} className="flex items-center gap-3 w-full px-4 py-3 text-sm font-bold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition-all mt-2">
                                                    <LogOut className="w-4 h-4" /> Logout
                                                </button>
                                            </div>
                                        </motion.div>
                                    </>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>
                </header>

                <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-8 bg-[#F8FAFC]">
                    <div className="max-w-7xl mx-auto w-full">
                        <Outlet />
                    </div>
                </main>
            </div>
        </div>
    );
}

import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCountry } from '../contexts/CountryContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
    MessageSquare, Menu, X, Globe, ArrowRight, ShieldCheck,
    Twitter, Github, Linkedin, ChevronDown, Zap, BookOpen, Info, FileText, Link2
} from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

const productLinks = [
    { to: '/features', label: 'All Features', icon: Zap, desc: 'WhatsApp, SMS, Voice & AI Chatbot' },
    { to: '/integrations', label: 'Integrations', icon: Link2, desc: 'Shopify, WooCommerce & Custom API' },
    { to: '/countries', label: 'Countries', icon: Globe, desc: 'India, USA & expanding markets' },
    { to: '/services', label: 'Services', icon: Globe, desc: 'Premium verification & support services' },
];

const resourceLinks = [
    { to: '/docs', label: 'API Docs', icon: BookOpen, desc: 'Integration guides & references' },
    { to: '/blog', label: 'Blog', icon: FileText, desc: 'E-commerce insights & updates' },
    { to: '/faq', label: 'FAQ', icon: Info, desc: 'Common questions answered' },
    { to: '/careers', label: 'Careers', icon: Zap, desc: 'Jobs & career opportunities' },
    { to: '/status', label: 'Status', icon: ShieldCheck, desc: 'System status & uptime' },
    { to: '/changelog', label: 'Changelog', icon: Zap, desc: "What's new in CODVerify" },
];


function DropdownMenu({ label, items }: { label: string; items: typeof productLinks | typeof resourceLinks }) {
    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handler = (e: MouseEvent) => {
            if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    return (
        <div ref={ref} className="relative">
            <button
                onClick={() => setOpen(!open)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all ${open ? 'text-white' : 'text-gray-400 hover:text-white'}`}
            >
                {label}
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${open ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
                {open && (
                    <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.97 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.97 }}
                        transition={{ duration: 0.15 }}
                        className="absolute top-full left-0 mt-3 w-72 bg-[#132F4C] rounded-xl border border-white/10 shadow-2xl shadow-black/30 p-2 z-50 backdrop-blur-xl"
                    >
                        {items.map((item: any) => (
                            <Link
                                key={item.to}
                                to={item.to}
                                onClick={() => setOpen(false)}
                                className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors group"
                            >
                                {item.icon && (
                                    <div className="w-8 h-8 rounded-lg bg-[#635BFF]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#635BFF]/20 transition-colors">
                                        <item.icon className="w-4 h-4 text-[#635BFF]" />
                                    </div>
                                )}
                                <div>
                                    <div className="text-sm font-semibold text-white">{item.label}</div>
                                    {item.desc && <div className="text-xs text-gray-400 mt-0.5">{item.desc}</div>}
                                </div>
                            </Link>
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

export default function PublicLayout() {
    const { user } = useAuth();
    const { info, setManual } = useCountry();
    const location = useLocation();
    const [mobileOpen, setMobileOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 20);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="min-h-screen flex flex-col font-['Inter'] antialiased text-gray-900 bg-[#F6F9FC]">
            {/* ═══ PREMIUM DARK HEADER ═══════════════════════════════════════ */}
            <header className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${scrolled ? 'py-2' : 'py-3'}`}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6">
                    <div className={`flex items-center justify-between px-4 sm:px-6 py-2.5 rounded-2xl border transition-all duration-500 ${scrolled
                        ? 'bg-[#0A2540]/95 backdrop-blur-2xl border-white/[0.06] shadow-[0_8px_32px_rgba(0,0,0,0.4)]'
                        : 'bg-[#0A2540]/60 backdrop-blur-xl border-white/[0.04]'
                        }`}>
                        {/* Logo */}
                        <Link to="/" className="flex items-center gap-2.5 group flex-shrink-0">
                            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#635BFF] to-[#00D4AA] flex items-center justify-center shadow-lg shadow-[#635BFF]/20 group-hover:shadow-[#635BFF]/40 group-hover:scale-110 transition-all duration-300">
                                <MessageSquare className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-lg font-bold tracking-tight text-white">COD<span className="text-[#635BFF]">VERIFY</span></span>
                        </Link>

                        {/* Desktop Nav */}
                        <nav className="hidden lg:flex items-center gap-0.5">
                            <Link to="/" className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${location.pathname === '/' ? 'text-white bg-white/[0.06]' : 'text-gray-400 hover:text-white'}`}>Home</Link>
                            <DropdownMenu label="Product" items={productLinks} />
                            <DropdownMenu label="Resources" items={resourceLinks} />
                            <Link to="/contact" className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${location.pathname === '/contact' ? 'text-white bg-white/[0.06]' : 'text-gray-400 hover:text-white'}`}>Contact</Link>
                        </nav>

                        {/* Right side */}
                        <div className="hidden lg:flex items-center gap-3">
                            {/* Country selector */}
                            {!info.loading && (
                                <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
                                    <span>{info.country === 'IN' ? '🇮🇳' : info.country === 'PH' ? '🇵🇭' : info.country === 'MX' ? '🇲🇽' : info.country === 'GB' ? '🇬🇧' : '🇺🇸'}</span>
                                    <select
                                        value={info.country || 'IN'}
                                        onChange={e => setManual(e.target.value as 'IN' | 'US' | 'PH' | 'MX' | 'GB')}
                                        className="bg-transparent text-xs font-medium text-gray-400 outline-none cursor-pointer hover:text-white transition-colors"
                                    >
                                        <option value="IN">India</option>
                                        <option value="US">USA</option>
                                        <option value="PH">Philippines</option>
                                        <option value="MX">Mexico</option>
                                        <option value="GB">UK</option>
                                    </select>
                                </div>
                            )}
                            {user ? (
                                <Link to={user.role === 'admin' ? '/admin' : '/dashboard'}
                                    className="px-5 py-2 stripe-button text-white rounded-lg text-sm font-semibold">
                                    Dashboard
                                </Link>
                            ) : (
                                <div className="flex items-center gap-3">
                                    <Link to="/login" className="text-sm font-medium text-gray-400 hover:text-white transition-colors">Sign in</Link>
                                    <Link to="/signup" className="group stripe-button text-white rounded-lg px-5 py-2 text-sm font-semibold flex items-center gap-1.5">
                                        Start Free <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                                    </Link>
                                </div>
                            )}
                        </div>

                        {/* Mobile hamburger */}
                        <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden w-10 h-10 flex items-center justify-center text-white bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
                            <AnimatePresence mode="wait">
                                {mobileOpen ? <X key="x" className="w-5 h-5" /> : <Menu key="m" className="w-5 h-5" />}
                            </AnimatePresence>
                        </button>
                    </div>
                </div>

                {/* Mobile Menu */}
                <AnimatePresence>
                    {mobileOpen && (
                        <motion.div
                            initial={{ opacity: 0, y: -15, scale: 0.97 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -15, scale: 0.97 }}
                            transition={{ duration: 0.2 }}
                            className="lg:hidden absolute top-full left-3 right-3 mt-3"
                        >
                            <div className="bg-[#132F4C] rounded-2xl border border-white/10 p-4 shadow-2xl shadow-black/30 backdrop-blur-xl">
                                <div className="space-y-1 mb-4">
                                    {[
                                        { to: '/', label: 'Home' },
                                        { to: '/features', label: 'Features' },
                                        { to: '/countries', label: 'Countries' },
                                        { to: '/services', label: 'Services' },
                                        { to: '/docs', label: 'API Docs' },
                                        { to: '/faq', label: 'FAQ' },
                                        { to: '/blog', label: 'Blog' },
                                        { to: '/careers', label: 'Careers 💼' },
                                        { to: '/about', label: 'About' },
                                        { to: '/contact', label: 'Contact' },
                                    ].map(link => (
                                        <Link key={link.to} to={link.to} onClick={() => setMobileOpen(false)}
                                            className={`block px-4 py-3 rounded-xl text-sm font-medium transition-all ${location.pathname === link.to ? 'bg-[#635BFF]/10 text-[#635BFF]' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
                                            {link.label}
                                        </Link>
                                    ))}
                                </div>
                                <hr className="border-white/5 mb-4" />
                                {!user ? (
                                    <div className="grid grid-cols-2 gap-2">
                                        <Link to="/login" onClick={() => setMobileOpen(false)} className="px-4 py-3 bg-white/5 text-white rounded-xl text-center text-sm font-semibold hover:bg-white/10 transition-all">Sign In</Link>
                                        <Link to="/signup" onClick={() => setMobileOpen(false)} className="px-4 py-3 stripe-button text-white rounded-xl text-center text-sm font-semibold">Start Free</Link>
                                    </div>
                                ) : (
                                    <Link to={user.role === 'admin' ? '/admin' : '/dashboard'} onClick={() => setMobileOpen(false)} className="block px-4 py-3 stripe-button text-white rounded-xl text-center text-sm font-semibold">Dashboard</Link>
                                )}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </header>

            <main className="flex-1">
                <Outlet />
            </main>

            {/* ═══ PREMIUM DARK FOOTER — STRIPE-STYLE ═══════════════════════ */}
            <footer className="bg-[#0A2540] text-white pt-20 sm:pt-28 pb-8 sm:pb-12 overflow-hidden relative">
                {/* Top gradient line */}
                <div className="absolute top-0 left-0 w-full h-px glow-line opacity-40" />

                {/* Background elements */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#635BFF]/5 rounded-full blur-[150px] pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#00D4AA]/5 rounded-full blur-[150px] pointer-events-none" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    {/* CTA Banner inside footer */}
                    <div className="mb-20 bg-gradient-to-r from-[#635BFF]/10 to-[#00D4AA]/10 rounded-2xl border border-white/5 p-8 sm:p-12 flex flex-col lg:flex-row items-center justify-between gap-6">
                        <div>
                            <h3 className="text-2xl sm:text-3xl font-bold text-white font-['Outfit'] tracking-tight mb-2">
                                Ready to eliminate fake orders?
                            </h3>
                            <p className="text-gray-400 text-sm max-w-md">
                                Start verifying COD orders in minutes. No credit card required.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <Link to="/signup" className="group stripe-button text-white rounded-xl px-8 py-3.5 font-semibold text-sm flex items-center gap-2">
                                Start Free <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                            </Link>
                            <Link to="/contact" className="px-8 py-3.5 bg-white/5 text-white rounded-xl font-semibold text-sm border border-white/10 hover:bg-white/10 transition-all">
                                Talk to Sales
                            </Link>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12 mb-16">
                        {/* Brand Column */}
                        <div className="col-span-2">
                            <Link to="/" className="flex items-center gap-2.5 mb-6">
                                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#635BFF] to-[#00D4AA] flex items-center justify-center">
                                    <MessageSquare className="w-4 h-4 text-white" />
                                </div>
                                <span className="text-lg font-bold tracking-tight">COD<span className="text-white/40">VERIFY</span></span>
                            </Link>
                            <p className="text-gray-500 text-sm leading-relaxed mb-6 max-w-xs">
                                AI-powered COD order verification for e-commerce brands worldwide.
                            </p>
                            <div className="flex items-center gap-2 flex-wrap mb-6">
                                {[
                                    { code: 'IN', flag: '🇮🇳' }, { code: 'US', flag: '🇺🇸' },
                                    { code: 'PH', flag: '🇵🇭' }, { code: 'MX', flag: '🇲🇽' }, { code: 'GB', flag: '🇬🇧' },
                                ].map(c => (
                                    <Link key={c.code} to={`/countries?country=${c.code}`}
                                        className="flex items-center gap-1 bg-white/5 hover:bg-white/10 rounded-lg px-2.5 py-1.5 text-xs transition-colors">
                                        {c.flag}
                                    </Link>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                {[Twitter, Github, Linkedin].map((Icon, i) => (
                                    <button key={i} className="w-9 h-9 bg-white/5 rounded-lg flex items-center justify-center hover:bg-[#635BFF] transition-all duration-300 group">
                                        <Icon className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Product */}
                        <div>
                            <h4 className="text-xs font-semibold text-white/30 uppercase tracking-wider mb-5">Product</h4>
                            <div className="space-y-3">
                                {[
                                    { to: '/features', label: 'Features' },
                                    { to: '/services', label: 'Services' },
                                    { to: '/integrations', label: 'Integrations' },
                                    { to: '/countries', label: 'Countries' },
                                    { to: '/changelog', label: 'Changelog' },
                                ].map(l => (
                                    <Link key={l.to} to={l.to} className="block text-sm text-gray-500 hover:text-white transition-colors">{l.label}</Link>
                                ))}
                            </div>
                        </div>

                        {/* Developers */}
                        <div>
                            <h4 className="text-xs font-semibold text-white/30 uppercase tracking-wider mb-5">Developers</h4>
                            <div className="space-y-3">
                                {[
                                    { to: '/docs', label: 'API Docs' },
                                    { to: '/integrations', label: 'Plugins' },
                                    { to: '/status', label: 'System Status' },
                                    { to: '/changelog', label: 'API Changelog' },
                                ].map(l => (
                                    <Link key={l.to} to={l.to} className="block text-sm text-gray-500 hover:text-white transition-colors">{l.label}</Link>
                                ))}
                            </div>
                        </div>

                        {/* Resources */}
                        <div>
                            <h4 className="text-xs font-semibold text-white/30 uppercase tracking-wider mb-5">Resources</h4>
                            <div className="space-y-3">
                                {[
                                    { to: '/blog', label: 'Blog' },
                                    { to: '/faq', label: 'FAQ' },
                                    { to: '/partners', label: 'Partners' },
                                    { to: '/contact', label: 'Contact' },
                                ].map(l => (
                                    <Link key={l.to} to={l.to} className="block text-sm text-gray-500 hover:text-white transition-colors">{l.label}</Link>
                                ))}
                            </div>
                        </div>

                        {/* Company */}
                        <div>
                            <h4 className="text-xs font-semibold text-white/30 uppercase tracking-wider mb-5">Company</h4>
                            <div className="space-y-3">
                                {[
                                    { to: '/about', label: 'About' },
                                    { to: '/careers', label: 'Careers' },
                                    { to: '/terms', label: 'Terms' },
                                    { to: '/privacy', label: 'Privacy' },
                                ].map(l => (
                                    <Link key={l.to} to={l.to} className="block text-sm text-gray-500 hover:text-white transition-colors">{l.label}</Link>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Bottom Bar */}
                    <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-3 text-gray-600">
                            <ShieldCheck className="w-4 h-4 text-[#00D4AA] flex-shrink-0" />
                            <p className="text-xs font-medium">© 2026 CODVerify Technologies · All Rights Reserved</p>
                        </div>
                        <div className="flex flex-wrap gap-6">
                            {[
                                { to: '/terms', label: 'Terms' },
                                { to: '/privacy', label: 'Privacy' },
                                { to: '/status', label: 'Status' },
                            ].map(l => (
                                <Link key={l.to} to={l.to} className="text-xs font-medium text-gray-600 hover:text-[#635BFF] transition-colors">{l.label}</Link>
                            ))}
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
}

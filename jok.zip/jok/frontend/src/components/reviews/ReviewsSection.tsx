import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { publicApi } from '../../api';
import { ChevronLeft, ChevronRight, Star, Quote, Sparkles, Send } from 'lucide-react';

// ─── 20 Demo Reviews (shown when API returns empty) ──────────────────────────
const DEMO_REVIEWS = [
    { id: 'd1', author_name: 'Rahul Sharma', author_company: 'TrendyKart', author_role: 'Founder', rating: 5, title: 'RTO dropped 45% in first month', body: 'CODVerify completely transformed our COD operations. We were losing ₹2L/month on fake orders. Within 30 days, our RTO dropped from 38% to 21%. The WhatsApp verification is seamless — customers love it.', is_featured: true },
    { id: 'd2', author_name: 'Priya Patel', author_company: 'GlamBox India', author_role: 'Operations Head', rating: 5, title: 'Best investment for our D2C brand', body: 'We tried 3 different COD verification services before CODVerify. None came close. The AI chatbot handles 80% of customer queries automatically. Our team now focuses on growth instead of chasing fake orders.' },
    { id: 'd3', author_name: 'Michael Chen', author_company: 'UrbanEdge US', author_role: 'CEO', rating: 5, title: 'SMS verification works flawlessly for US market', body: 'Been using CODVerify for our US store. The SMS + Voice call fallback is incredibly effective. 99% of genuine customers confirm within 2 minutes. Fraudulent orders get filtered out automatically.' },
    { id: 'd4', author_name: 'Ankit Verma', author_company: 'FitGear Pro', author_role: 'Co-Founder', rating: 5, title: 'Saved us from ₹5L loss in first quarter', body: 'We sell fitness equipment via COD. High-ticket items = high RTO risk. CODVerify\'s verification caught 200+ fake orders in Q1 alone. The ROI is insane — literally 50x return on investment.' },
    { id: 'd5', author_name: 'Sarah Johnson', author_company: 'PureGlow Cosmetics', author_role: 'E-commerce Manager', rating: 4, title: 'Great tool, amazing support team', body: 'The verification rates are excellent and the dashboard gives us real-time insights. What impressed me most is their support team — they helped us customize everything during onboarding.' },
    { id: 'd6', author_name: 'Deepak Kumar', author_company: 'ElectroMart', author_role: 'Owner', rating: 5, title: 'WhatsApp verification = game changer for India', body: 'Indian customers respond to WhatsApp like nothing else. Our confirmation rate went from 60% to 94% after switching to CODVerify. The button-based verification is so simple even non-tech-savvy customers can use it.' },
    { id: 'd7', author_name: 'Neha Agarwal', author_company: 'StyleNest', author_role: 'Founder', rating: 5, title: 'Reduced RTO from 42% to 18%', body: 'Fashion D2C brand here. Our RTO was killing our margins. CODVerify brought it down dramatically. The personalized contract plan they offered us was very reasonable and the results speak for themselves.' },
    { id: 'd8', author_name: 'James Wilson', author_company: 'GadgetStop', author_role: 'Operations Director', rating: 5, title: 'Voice call verification is brilliant', body: 'Many of our older customers don\'t check SMS quickly. The auto voice call fallback is genius — it rings them if they don\'t respond to SMS within 5 minutes. Our confirmation rate is now 97%.' },
    { id: 'd9', author_name: 'Kavita Desai', author_company: 'BabyBliss India', author_role: 'Co-Founder', rating: 5, title: 'Zero fake orders since we started', body: 'We sell baby products online. Before CODVerify, we\'d get 15-20 fake orders daily. Now? Zero. The behavioral analysis catches suspicious patterns before orders even reach verification.' },
    { id: 'd10', author_name: 'Arjun Mehta', author_company: 'SpiceRoute', author_role: 'Tech Lead', rating: 4, title: 'API integration was smooth', body: 'We have a custom e-commerce setup. The API documentation was thorough and integration took us only 2 hours. The webhook callbacks are reliable and event tracking is comprehensive.' },
    { id: 'd11', author_name: 'Ritu Singh', author_company: 'HomeCraft Store', author_role: 'Founder', rating: 5, title: 'Customer support is exceptional', body: 'What sets CODVerify apart is their dedicated support. Our account manager responds within minutes and helped us optimize our verification flow. It feels like having an in-house team.' },
    { id: 'd12', author_name: 'Chris Anderson', author_company: 'Peak Athletics', author_role: 'COO', rating: 5, title: 'ROI was visible within the first week', body: 'We were skeptical about yet another verification tool. But the results were immediate — within 7 days we saw a 35% drop in failed deliveries. The analytics dashboard makes it easy to track everything.' },
    { id: 'd13', author_name: 'Pooja Reddy', author_company: 'NaturalGlow', author_role: 'Marketing Head', rating: 5, title: 'Our delivery success rate is now 96%', body: 'Organic skincare brand. COD is 70% of our revenue. CODVerify made sure almost every COD order is genuine. 96% delivery success rate — our logistics partner is amazed.' },
    { id: 'd14', author_name: 'Vikram Joshi', author_company: 'TechBazaar', author_role: 'Founder', rating: 5, title: 'Shopify integration is seamless', body: 'Installed the Shopify plugin, connected our store, and it just works. Every COD order gets verified automatically. No manual intervention needed. This is how SaaS should work.' },
    { id: 'd15', author_name: 'Meera Kapoor', author_company: 'FashionHub', author_role: 'CEO', rating: 4, title: 'Great for scaling COD business', body: 'When we scaled from 100 to 1000 orders/day, CODVerify scaled with us effortlessly. The system handles peak loads during sale events without breaking a sweat.' },
    { id: 'd16', author_name: 'Rajesh Nair', author_company: 'KeralaSpice', author_role: 'Owner', rating: 5, title: 'Hindi + English templates work perfectly', body: 'Our customers speak Hindi and English. The multi-language verification templates are perfect. Customers get messages in their preferred language which increases confirmation rates significantly.' },
    { id: 'd17', author_name: 'Lisa Park', author_company: 'ZenHome USA', author_role: 'VP Operations', rating: 5, title: 'Best COD verification for US market', body: 'Finding a COD verification service that works well in the US was challenging. CODVerify\'s SMS + voice combo is the only solution that gave us over 95% confirmation rates.' },
    { id: 'd18', author_name: 'Suresh Gupta', author_company: 'MediQuick', author_role: 'Director', rating: 5, title: 'AI chatbot handles everything', body: 'The AI chatbot on our website handles customer queries about their orders 24/7. It even processes address changes and quantity updates. Our support ticket volume dropped by 60%.' },
    { id: 'd19', author_name: 'Amanda Foster', author_company: 'PetPlanet', author_role: 'E-commerce Head', rating: 5, title: 'Fraud detection saved us thousands', body: 'CODVerify\'s blacklist system and risk scoring identified a fraud ring that was placing fake orders. Saved us at least $5,000 in the first month. The fraud pattern alerts are invaluable.' },
    { id: 'd20', author_name: 'Karan Malhotra', author_company: 'UrbanWear', author_role: 'Founder', rating: 5, title: 'From 30% RTO to 12% — unbelievable', body: 'Streetwear brand. COD orders were a nightmare with 30% returns. After CODVerify, we\'re at 12%. The personalized contract plan gave us unlimited verifications at a fraction of what we were losing.' },
];

// ─── Star Display ─────────────────────────────────────────────────────────────
function Stars({ count }: { count: number }) {
    return (
        <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`w-4 h-4 ${i < count ? 'fill-amber-400 text-amber-400' : 'fill-gray-200 text-gray-200'}`} />
            ))}
        </div>
    );
}

// ─── Star Rating Input ────────────────────────────────────────────────────────
function StarRating({ value, onChange }: { value: number; onChange: (v: number) => void }) {
    const [hover, setHover] = useState(0);
    return (
        <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map(star => (
                <button key={star} type="button" onClick={() => onChange(star)}
                    onMouseEnter={() => setHover(star)} onMouseLeave={() => setHover(0)}
                    className="transition-transform hover:scale-125 active:scale-95">
                    <Star className={`w-7 h-7 ${(hover || value) >= star
                        ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.4)]'
                        : 'fill-gray-200 text-gray-200'}`}
                    />
                </button>
            ))}
        </div>
    );
}

// ─── Review Card for Carousel ─────────────────────────────────────────────────
function ReviewCard({ review }: { review: any }) {
    const initials = (review.author_name || '?').split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);
    const gradients = [
        'from-indigo-500 to-purple-500', 'from-emerald-500 to-teal-500',
        'from-amber-500 to-orange-500', 'from-rose-500 to-pink-500',
        'from-blue-500 to-cyan-500', 'from-violet-500 to-fuchsia-500'
    ];
    const grad = gradients[review.author_name?.charCodeAt(0) % gradients.length] || gradients[0];

    return (
        <div className="glass-card rounded-[28px] p-7 border border-white/80 shadow-xl hover:shadow-2xl transition-all duration-500 h-full flex flex-col relative overflow-hidden group">
            {/* Decorative quote */}
            <div className="absolute -top-2 -right-2 opacity-[0.04] group-hover:opacity-[0.08] transition-opacity duration-500">
                <Quote className="w-28 h-28 text-indigo-600" />
            </div>

            {/* Featured badge */}
            {review.is_featured && (
                <div className="flex items-center gap-1.5 mb-4">
                    <span className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-[10px] font-bold text-amber-700 uppercase tracking-widest flex items-center gap-1">
                        <Sparkles className="w-3 h-3" /> Featured
                    </span>
                </div>
            )}

            {/* Stars */}
            <div className="mb-4">
                <Stars count={review.rating || 5} />
            </div>

            {/* Title */}
            {review.title && (
                <h3 className="font-bold text-gray-900 text-[15px] leading-snug mb-3 font-['Outfit']">
                    "{review.title}"
                </h3>
            )}

            {/* Body */}
            <p className="text-gray-500 text-sm leading-relaxed flex-1 mb-5 line-clamp-4">
                {review.body}
            </p>

            {/* Author */}
            <div className="flex items-center gap-3 pt-4 border-t border-gray-100/80">
                <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center text-white text-xs font-bold shadow-lg shadow-indigo-500/10`}>
                    {initials}
                </div>
                <div className="min-w-0">
                    <div className="font-bold text-sm text-gray-900 truncate">{review.author_name}</div>
                    <div className="text-[11px] text-gray-400 font-medium truncate">
                        {review.author_role}{review.author_role && review.author_company && ' · '}{review.author_company}
                    </div>
                </div>
            </div>
        </div>
    );
}

// ─── Submit Review Form ───────────────────────────────────────────────────────
function SubmitReviewForm({ onSuccess }: { onSuccess: () => void }) {
    const [form, setForm] = useState({ author_name: '', author_company: '', author_role: '', rating: 5, title: '', body: '' });
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!form.author_name.trim() || !form.body.trim()) { toast.error('Name and review are required'); return; }
        try {
            setSubmitting(true);
            await publicApi.submitReview(form);
            setSubmitted(true);
            onSuccess();
        } catch { toast.error('Failed to submit. Try again.'); }
        finally { setSubmitting(false); }
    };

    if (submitted) return (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
            className="text-center py-16 px-8 glass-card rounded-[32px] border border-emerald-100">
            <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-10 h-10 text-emerald-500" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 font-['Outfit'] mb-2">Thank you! 🎉</h3>
            <p className="text-gray-400 text-sm">Your review has been submitted and will be visible after admin approval.</p>
        </motion.div>
    );

    return (
        <motion.form onSubmit={handleSubmit} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="glass-card rounded-[32px] p-8 sm:p-10 border border-white shadow-xl space-y-6">
            <div>
                <h3 className="text-2xl font-bold text-gray-900 font-['Outfit'] mb-1">Share Your Experience</h3>
                <p className="text-sm text-gray-400">Help others discover CODVerify. Reviews are moderated before publishing.</p>
            </div>

            <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Your Rating *</label>
                <StarRating value={form.rating} onChange={v => setForm(p => ({ ...p, rating: v }))} />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1.5">Your Name *</label>
                    <input required value={form.author_name} onChange={e => setForm(p => ({ ...p, author_name: e.target.value }))}
                        placeholder="Rahul Sharma" className="w-full px-4 py-3 border border-gray-100 rounded-2xl text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all bg-gray-50/50" />
                </div>
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1.5">Company</label>
                    <input value={form.author_company} onChange={e => setForm(p => ({ ...p, author_company: e.target.value }))}
                        placeholder="Your Store" className="w-full px-4 py-3 border border-gray-100 rounded-2xl text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all bg-gray-50/50" />
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1.5">Role</label>
                    <input value={form.author_role} onChange={e => setForm(p => ({ ...p, author_role: e.target.value }))}
                        placeholder="Founder / Operations Head" className="w-full px-4 py-3 border border-gray-100 rounded-2xl text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all bg-gray-50/50" />
                </div>
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1.5">Review Title</label>
                    <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
                        placeholder="COD returns dropped 40%" className="w-full px-4 py-3 border border-gray-100 rounded-2xl text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all bg-gray-50/50" />
                </div>
            </div>

            <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1.5">Your Review *</label>
                <textarea required value={form.body} onChange={e => setForm(p => ({ ...p, body: e.target.value }))}
                    rows={4} placeholder="Tell us about your experience with CODVerify..."
                    className="w-full px-4 py-3 border border-gray-100 rounded-2xl text-sm resize-none focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all bg-gray-50/50" />
            </div>

            <button type="submit" disabled={submitting} id="submit-review-btn"
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-xl shadow-indigo-600/20 active:scale-[0.98]">
                {submitting ? <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : <Send className="w-4 h-4" />}
                {submitting ? 'Submitting...' : 'Submit Your Review'}
            </button>
        </motion.form>
    );
}

// ─── Auto-Sliding Carousel ────────────────────────────────────────────────────
export default function ReviewsSection({ showForm = true }: { showForm?: boolean }) {
    const [reviews, setReviews] = useState<any[]>(DEMO_REVIEWS);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

    const loadReviews = async () => {
        try {
            const res = await publicApi.getReviews();
            const apiReviews = res.data?.data?.reviews || res.data?.data || [];
            if (apiReviews.length > 0) setReviews(apiReviews);
        } catch {
            // Keep DEMO_REVIEWS — already in state
        }
    };

    useEffect(() => { loadReviews(); }, []);

    // How many cards visible at once — responsive
    const getCardsPerView = useCallback(() => {
        if (typeof window === 'undefined') return 3;
        if (window.innerWidth < 640) return 1;
        if (window.innerWidth < 1024) return 2;
        return 3;
    }, []);

    const [cardsPerView, setCardsPerView] = useState(getCardsPerView());

    useEffect(() => {
        const handleResize = () => setCardsPerView(getCardsPerView());
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, [getCardsPerView]);

    const maxIndex = Math.max(0, reviews.length - cardsPerView);

    // Auto-slide every 4 seconds
    useEffect(() => {
        if (isPaused || reviews.length <= cardsPerView) return;
        timerRef.current = setInterval(() => {
            setCurrentIndex(prev => prev >= maxIndex ? 0 : prev + 1);
        }, 4000);
        return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }, [isPaused, maxIndex, reviews.length, cardsPerView]);

    const goTo = (dir: 'prev' | 'next') => {
        if (dir === 'prev') setCurrentIndex(p => p <= 0 ? maxIndex : p - 1);
        else setCurrentIndex(p => p >= maxIndex ? 0 : p + 1);
    };

    // Aggregated stats
    const avgRating = reviews.length > 0 ? (reviews.reduce((s, r) => s + (r.rating || 5), 0) / reviews.length).toFixed(1) : '5.0';

    return (
        <section className="py-20 sm:py-28 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
            {/* Decorative background */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-indigo-50 rounded-full blur-[120px] opacity-40 -mt-48" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                {/* Header */}
                <div className="text-center mb-14 sm:mb-16">
                    <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                        <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-50 border border-amber-200 rounded-full text-amber-700 text-[10px] font-bold uppercase tracking-[0.2em] mb-6">
                            <div className="flex gap-0.5">{[1, 2, 3, 4, 5].map(i => <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />)}</div>
                            <span>{avgRating} Average Rating</span>
                        </div>
                        <h2 className="text-4xl sm:text-5xl font-black text-gray-900 tracking-tighter mb-4 font-['Outfit']">
                            Loved by <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">1,200+</span> Merchants
                        </h2>
                        <p className="text-gray-400 text-lg max-w-xl mx-auto font-medium">
                            Real results from store owners who eliminated RTO and scaled confidently with COD.
                        </p>
                    </motion.div>
                </div>

                {/* Carousel */}
                {reviews.length > 0 ? (
                    <div className="relative"
                        onMouseEnter={() => setIsPaused(true)}
                        onMouseLeave={() => setIsPaused(false)}>

                        {/* Cards Grid — show cardsPerView at a time */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            {reviews.slice(currentIndex, currentIndex + cardsPerView).map((r, i) => (
                                <motion.div key={r.id || `${currentIndex}-${i}`}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 0.08, duration: 0.4 }}
                                >
                                    <ReviewCard review={r} />
                                </motion.div>
                            ))}
                        </div>

                        {/* Navigation Arrows */}
                        <button onClick={() => goTo('prev')}
                            className="absolute left-0 top-1/2 -translate-y-1/2 translate-x-1 sm:-translate-x-5 w-9 h-9 sm:w-12 sm:h-12 bg-white rounded-xl sm:rounded-2xl shadow-xl shadow-gray-900/10 border border-gray-100 flex items-center justify-center hover:bg-indigo-50 hover:border-indigo-200 transition-all z-20 active:scale-90">
                            <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                        </button>
                        <button onClick={() => goTo('next')}
                            className="absolute right-0 top-1/2 -translate-y-1/2 -translate-x-1 sm:translate-x-5 w-9 h-9 sm:w-12 sm:h-12 bg-white rounded-xl sm:rounded-2xl shadow-xl shadow-gray-900/10 border border-gray-100 flex items-center justify-center hover:bg-indigo-50 hover:border-indigo-200 transition-all z-20 active:scale-90">
                            <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                        </button>

                        {/* Dot Indicators */}
                        <div className="flex items-center justify-center gap-1.5 mt-8">
                            {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                                <button key={i} onClick={() => setCurrentIndex(i)}
                                    className={`rounded-full transition-all duration-300 ${currentIndex === i
                                        ? 'w-8 h-2.5 bg-indigo-600 shadow-lg shadow-indigo-500/30'
                                        : 'w-2.5 h-2.5 bg-gray-200 hover:bg-gray-300'}`}
                                />
                            ))}
                        </div>
                    </div>
                ) : null}


                {/* Submit Form */}
                {showForm && (
                    <div className="max-w-2xl mx-auto mt-16">
                        <SubmitReviewForm onSuccess={loadReviews} />
                    </div>
                )}
            </div>
        </section>
    );
}

import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Star } from "lucide-react";
import { useEffect, useState } from "react";
import { TestimonialsColumn, type Testimonial } from "../ui/testimonials-columns-1";
import { publicApi } from "../../api";

// 4 cartoon avatars — cycle through all reviews by index % 4
const CARTOON_AVATARS = [
    "https://api.dicebear.com/9.x/avataaars/svg?seed=CODVerify1&backgroundColor=b6e3f4&radius=50",
    "https://api.dicebear.com/9.x/avataaars/svg?seed=CODVerify2&backgroundColor=ffd5dc&radius=50",
    "https://api.dicebear.com/9.x/avataaars/svg?seed=CODVerify3&backgroundColor=c0aede&radius=50",
    "https://api.dicebear.com/9.x/avataaars/svg?seed=CODVerify4&backgroundColor=d1f4d9&radius=50",
];

const FALLBACK_TESTIMONIALS: Testimonial[] = [
    {
        text: "CODVerify completely transformed our COD operations. We were losing ₹2L/month on fake orders. Within 30 days, our RTO dropped from 38% to 21%. The WhatsApp verification is seamless — customers love it.",
        image: CARTOON_AVATARS[0],
        name: "Rahul Sharma",
        role: "Founder",
        company: "TrendyKart",
        rating: 5,
    },
    {
        text: "We tried 3 different COD verification services before CODVerify. None came close. The AI chatbot handles 80% of customer queries automatically. Our team now focuses on growth instead of chasing fake orders.",
        image: CARTOON_AVATARS[1],
        name: "Priya Patel",
        role: "Operations Head",
        company: "GlamBox India",
        rating: 5,
    },
    {
        text: "Been using CODVerify for our US store. The SMS + Voice call fallback is incredibly effective. 99% of genuine customers confirm within 2 minutes. Fraudulent orders get filtered out automatically.",
        image: CARTOON_AVATARS[2],
        name: "Michael Chen",
        role: "CEO",
        company: "UrbanEdge US",
        rating: 5,
    },
    {
        text: "We sell fitness equipment via COD. High-ticket items mean high RTO risk. CODVerify's verification caught 200+ fake orders in Q1 alone. The ROI is insane — literally 50x return on investment.",
        image: CARTOON_AVATARS[3],
        name: "Ankit Verma",
        role: "Co-Founder",
        company: "FitGear Pro",
        rating: 5,
    },
    {
        text: "The verification rates are excellent and the dashboard gives us real-time insights. What impressed me most is their support team — they helped us customize everything during onboarding.",
        image: CARTOON_AVATARS[0],
        name: "Sarah Johnson",
        role: "E-commerce Manager",
        company: "PureGlow Cosmetics",
        rating: 4,
    },
    {
        text: "Indian customers respond to WhatsApp like nothing else. Our confirmation rate went from 60% to 94% after switching to CODVerify. The button-based verification is so simple — even non-tech-savvy customers use it.",
        image: CARTOON_AVATARS[1],
        name: "Deepak Kumar",
        role: "Owner",
        company: "ElectroMart",
        rating: 5,
    },
    {
        text: "Fashion D2C brand here. Our RTO was killing our margins. CODVerify brought it down from 42% to 18% dramatically. The personalized contract plan was very reasonable and the results speak for themselves.",
        image: CARTOON_AVATARS[2],
        name: "Neha Agarwal",
        role: "Founder",
        company: "StyleNest",
        rating: 5,
    },
    {
        text: "Many of our older customers don't check SMS quickly. The auto voice call fallback is genius — it rings them if they don't respond to SMS within 5 minutes. Our confirmation rate is now 97%.",
        image: CARTOON_AVATARS[3],
        name: "James Wilson",
        role: "Operations Director",
        company: "GadgetStop",
        rating: 5,
    },
    {
        text: "We sell baby products online. Before CODVerify, we'd get 15-20 fake orders daily. Now? Zero. The behavioral analysis catches suspicious patterns before orders even reach verification.",
        image: CARTOON_AVATARS[0],
        name: "Kavita Desai",
        role: "Co-Founder",
        company: "BabyBliss India",
        rating: 5,
    },
];

export default function TestimonialsSection() {
    const [testimonials, setTestimonials] = useState<Testimonial[]>(FALLBACK_TESTIMONIALS);

    useEffect(() => {
        publicApi.getReviews()
            .then((res) => {
                const rows: any[] = res.data?.data ?? res.data?.reviews ?? res.data ?? [];
                if (rows.length > 0) {
                    const mapped: Testimonial[] = rows.map((r: any, idx: number) => ({
                        text: r.body ?? r.text ?? "",
                        image: CARTOON_AVATARS[idx % CARTOON_AVATARS.length],
                        name: r.author_name ?? r.name ?? "Customer",
                        role: r.author_role ?? r.role ?? "",
                        company: r.author_company ?? r.company ?? "",
                        rating: r.rating ?? 5,
                    }));
                    setTestimonials(mapped);
                }
            })
            .catch(() => { /* keep fallback */ });
    }, []);

    const firstColumn = testimonials.slice(0, Math.ceil(testimonials.length / 3));
    const secondColumn = testimonials.slice(Math.ceil(testimonials.length / 3), Math.ceil(testimonials.length * 2 / 3));
    const thirdColumn = testimonials.slice(Math.ceil(testimonials.length * 2 / 3));

    return (
        <section className="relative py-20 sm:py-28 bg-[#0A2540] overflow-hidden">
            {/* Background */}
            <div className="absolute inset-0 grid-pattern-dark opacity-20" />
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            <div className="absolute top-1/3 left-[5%] w-96 h-96 bg-[#635BFF]/10 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-1/4 right-[5%] w-80 h-80 bg-[#00D4AA]/8 rounded-full blur-[100px] pointer-events-none" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">

                {/* Header */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    viewport={{ once: true }}
                    className="flex flex-col items-center text-center max-w-2xl mx-auto mb-14 sm:mb-16"
                >
                    <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-6">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Customer Reviews</span>
                    </div>

                    <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-5 leading-[1.05]">
                        Trusted by{" "}
                        <span className="text-gradient-hero">500+ brands</span>
                        <br />across 5 countries
                    </h2>

                    <p className="text-white/45 text-base sm:text-lg leading-relaxed">
                        From D2C startups to enterprise brands — see how CODVerify is transforming COD operations.
                    </p>

                    {/* Star aggregate */}
                    <div className="flex items-center gap-2 mt-5">
                        <div className="flex gap-0.5">
                            {Array.from({ length: 5 }).map((_, i) => (
                                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                            ))}
                        </div>
                        <span className="text-white font-bold text-sm">4.9</span>
                        <span className="text-white/35 text-sm">/ 5.0 · 500+ reviews</span>
                    </div>
                </motion.div>

                {/* Columns */}
                <div className="flex justify-center gap-5 sm:gap-6 mt-12 [mask-image:linear-gradient(to_bottom,transparent,black_20%,black_80%,transparent)] max-h-[720px] overflow-hidden">
                    <TestimonialsColumn
                        testimonials={firstColumn}
                        duration={18}
                    />
                    <TestimonialsColumn
                        testimonials={secondColumn}
                        className="hidden md:block"
                        duration={22}
                    />
                    <TestimonialsColumn
                        testimonials={thirdColumn}
                        className="hidden lg:block"
                        duration={20}
                    />
                </div>

                {/* CTA */}
                <motion.div
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.2 }}
                    viewport={{ once: true }}
                    className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12"
                >
                    <Link
                        to="/signup"
                        className="stripe-button inline-flex items-center gap-2 px-7 py-3.5 text-white rounded-full font-bold text-sm"
                    >
                        Start Free Trial <ArrowRight className="w-4 h-4" />
                    </Link>
                    <Link
                        to="/reviews"
                        className="inline-flex items-center gap-2 px-7 py-3.5 bg-white/6 hover:bg-white/10 border border-white/12 text-white/70 hover:text-white rounded-full font-bold text-sm transition-all"
                    >
                        Read All Reviews
                    </Link>
                </motion.div>
            </div>
        </section>
    );
}

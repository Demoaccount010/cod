import React from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";

export type Testimonial = {
    text: string;
    image: string;
    name: string;
    role: string;
    company: string;
    rating: number;
};

export const TestimonialsColumn = (props: {
    className?: string;
    testimonials: Testimonial[];
    duration?: number;
}) => {
    return (
        <div className={props.className}>
            <motion.div
                animate={{ translateY: "-50%" }}
                transition={{
                    duration: props.duration || 10,
                    repeat: Infinity,
                    ease: "linear",
                    repeatType: "loop",
                }}
                className="flex flex-col gap-5 pb-5 bg-[#0A2540]"
            >
                {[
                    ...new Array(2).fill(0).map((_, index) => (
                        <React.Fragment key={index}>
                            {props.testimonials.map(({ text, image, name, role, company, rating }, i) => (
                                <div
                                    key={i}
                                    className="p-6 rounded-2xl bg-white/5 border border-white/10 max-w-xs w-full backdrop-blur-sm hover:border-[#635BFF]/30 transition-colors duration-300"
                                >
                                    {/* Stars */}
                                    <div className="flex gap-0.5 mb-3">
                                        {Array.from({ length: 5 }).map((_, si) => (
                                            <Star
                                                key={si}
                                                className={`w-3.5 h-3.5 ${si < rating
                                                    ? "fill-amber-400 text-amber-400"
                                                    : "fill-white/10 text-white/10"
                                                    }`}
                                            />
                                        ))}
                                    </div>

                                    {/* Review text */}
                                    <p className="text-white/65 text-sm leading-relaxed">{text}</p>

                                    {/* Author */}
                                    <div className="flex items-center gap-3 mt-5 pt-4 border-t border-white/8">
                                        <img
                                            width={40}
                                            height={40}
                                            src={image}
                                            alt={name}
                                            className="h-10 w-10 rounded-full object-cover flex-shrink-0 ring-2 ring-[#635BFF]/20 bg-white/10"
                                            onError={(e) => {
                                                (e.currentTarget as HTMLImageElement).src =
                                                    "https://api.dicebear.com/9.x/avataaars/svg?seed=fallback&backgroundColor=b6e3f4&radius=50";
                                            }}
                                        />
                                        <div className="flex flex-col">
                                            <div className="font-semibold text-white text-sm leading-5">{name}</div>
                                            <div className="text-xs text-white/40 leading-5">
                                                {role} · {company}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </React.Fragment>
                    )),
                ]}
            </motion.div>
        </div>
    );
};

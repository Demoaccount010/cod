import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { chatApi } from '../api';
import { MessageSquare, Send, X, User, Bot, Minimize2, ChevronRight } from 'lucide-react';

// ── Scripted FAQ answers (no AI cost) ────────────────────────────
const MENU_OPTIONS = [
    {
        id: 'what',
        label: '🏢 What is CODVerify?',
        answer: 'CODVerify is an intelligent COD (Cash on Delivery) order verification platform. We help e-commerce businesses reduce RTO (Return to Origin) losses by verifying customer orders before shipping — saving you money on failed deliveries.',
    },
    {
        id: 'services',
        label: '⚡ Our Services',
        answer: '• WhatsApp Order Verification (94% response rate)\n• SMS + Voice Call Verification (97% confirmation)\n• AI Customer Support Chatbot\n• Real-time Analytics Dashboard\n• Shopify & WooCommerce Plugins\n• Multi-language Support (Hindi, English & more)',
    },
    {
        id: 'how',
        label: '🔄 How It Works',
        answer: '1️⃣ Customer places COD order on your store\n2️⃣ CODVerify sends WhatsApp/SMS verification\n3️⃣ Customer confirms or cancels\n4️⃣ You get instant update — ship only confirmed orders\n\nResult: Up to 45% reduction in RTO losses!',
    },
    {
        id: 'pricing',
        label: '💰 Pricing',
        answer: 'We offer fully customised pricing based on your order volume — among the most affordable in the market.\n\nApply on our website and our team will set up a personalised plan for your business within 24 hours.',
    },
    {
        id: 'integration',
        label: '🔌 Shopify & WooCommerce',
        answer: 'We integrate seamlessly with:\n• Shopify (1-click install from Shopify App Store)\n• WooCommerce (Plugin available)\n• Custom stores via REST API\n\nSetup takes less than 5 minutes!',
    },
    {
        id: 'contact',
        label: '📧 Contact Us',
        answer: 'Email: support@codverify.tech\nWebsite: codverify.tech/contact\n\nOur team typically responds within 24 hours on business days.',
    },
];

type ChatMode = 'greeting' | 'menu' | 'scripted' | 'ai_chat';

interface Message {
    type: 'bot' | 'user' | 'ai' | 'worker' | 'system';
    text: string;
    time: string;
}

export default function ChatWidget() {
    const [isOpen, setIsOpen] = useState(false);
    const [mode, setMode] = useState<ChatMode>('greeting');
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [sending, setSending] = useState(false);
    const [sessionId, setSessionId] = useState<string | null>(null);
    const [sessionStatus, setSessionStatus] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    // Poll when AI/human chat is active
    useEffect(() => {
        if (!sessionId || mode !== 'ai_chat') return;
        const poll = setInterval(async () => {
            try {
                const r = await chatApi.getMessages(sessionId);
                const apiMsgs = r.data?.data?.messages || [];
                const status = r.data?.data?.session_status || '';
                setSessionStatus(status);
                // Convert API messages to our format
                const converted: Message[] = apiMsgs.map((m: any) => ({
                    type: m.sender_type === 'visitor' ? 'user' as const : m.sender_type as Message['type'],
                    text: m.message,
                    time: new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                }));
                setMessages(converted);
            } catch { }
        }, 3000);
        return () => clearInterval(poll);
    }, [sessionId, mode]);

    const addBotMsg = (text: string) => {
        setMessages(prev => [...prev, { type: 'bot', text, time: now() }]);
    };

    const addUserMsg = (text: string) => {
        setMessages(prev => [...prev, { type: 'user', text, time: now() }]);
    };

    const handleOpen = () => {
        setIsOpen(true);
        if (messages.length === 0) {
            // Greeting
            setTimeout(() => {
                addBotMsg('Hey! 👋 Welcome to CODVerify!\nHow can I help you today?');
                setMode('menu');
            }, 500);
        }
    };

    const handleMenuClick = (option: typeof MENU_OPTIONS[0]) => {
        addUserMsg(option.label);
        setTimeout(() => {
            addBotMsg(option.answer);
            // Show back to menu prompt
            setTimeout(() => {
                setMode('scripted');
            }, 300);
        }, 400);
    };

    const handleBackToMenu = () => {
        addBotMsg('What else would you like to know? 👇');
        setMode('menu');
    };

    const handleConnectAgent = async () => {
        addUserMsg('🤝 Connect with Agent');
        addBotMsg('Sure! Connecting you with our AI assistant...\nYou can ask any question about CODVerify. If you need a human agent, just ask!');
        setMode('ai_chat');

        // Start AI chat session
        try {
            const r = await chatApi.startChat({
                visitor_name: 'Visitor',
                message: 'Hello, I want to know more about CODVerify',
            });
            const data = r.data?.data;
            setSessionId(data?.session_id);
            if (data?.ai_response) {
                setMessages(prev => [...prev, { type: 'ai', text: data.ai_response, time: now() }]);
            }
            setSessionStatus(data?.handoff_requested ? 'waiting_human' : 'ai_active');
        } catch {
            addBotMsg('Oops! Connection failed. Please try again later or email us at support@codverify.tech');
        }
    };

    const handleSendAI = async () => {
        if (!input.trim() || !sessionId) return;
        const msg = input;
        addUserMsg(msg);
        setInput('');
        setSending(true);
        try {
            const r = await chatApi.sendMessage(sessionId, msg);
            const data = r.data?.data;
            if (data?.ai_response) {
                setMessages(prev => [...prev, { type: 'ai', text: data.ai_response, time: now() }]);
            }
            if (data?.status) setSessionStatus(data.status);
        } catch { }
        finally { setSending(false); }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendAI();
        }
    };

    const handleClose = () => {
        setIsOpen(false);
    };

    const handleReset = () => {
        setIsOpen(false);
        setMessages([]);
        setMode('greeting');
        setSessionId(null);
        setSessionStatus('');
    };

    return (
        <>
            {/* Floating Button */}
            <AnimatePresence>
                {!isOpen && (
                    <motion.button
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0 }}
                        onClick={handleOpen}
                        className="fixed bottom-4 right-4 z-50 w-14 h-14 sm:w-[60px] sm:h-[60px] rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-2xl shadow-indigo-500/30 flex items-center justify-center hover:scale-110 transition-transform"
                    >
                        <MessageSquare className="w-6 h-6 sm:w-7 sm:h-7" />
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white animate-pulse" />
                    </motion.button>
                )}
            </AnimatePresence>

            {/* Chat Window — mobile: full width, desktop: 380px */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 40, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 40, scale: 0.9 }}
                        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                        className="fixed z-50 bg-white flex flex-col overflow-hidden
                            bottom-0 right-0 w-full h-[85vh] rounded-t-3xl
                            sm:bottom-4 sm:right-4 sm:w-[370px] sm:h-[500px] sm:rounded-3xl
                            shadow-2xl shadow-black/20 border border-gray-100"
                    >
                        {/* Header */}
                        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-3.5 flex items-center justify-between flex-shrink-0">
                            <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                                    <Bot className="w-4 h-4 text-white" />
                                </div>
                                <div>
                                    <h3 className="text-white font-bold text-sm font-['Outfit']">CODVerify Support</h3>
                                    <p className="text-white/70 text-[10px] font-semibold">
                                        {sessionStatus === 'human_active' ? '🟢 Human agent connected' :
                                            sessionStatus === 'waiting_human' ? '⏳ Connecting to agent...' :
                                                mode === 'ai_chat' ? '🤖 AI Assistant' :
                                                    '💬 Always here to help'}
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-center gap-1">
                                <button onClick={handleClose} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                                    <Minimize2 className="w-4 h-4 text-white/80" />
                                </button>
                                <button onClick={handleReset} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                                    <X className="w-4 h-4 text-white/80" />
                                </button>
                            </div>
                        </div>

                        {/* Messages + Menu Area */}
                        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3 bg-gray-50">
                            {/* Messages */}
                            {messages.map((m, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${m.type === 'system' ? 'justify-center' : m.type === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    {m.type === 'system' ? (
                                        <div className="px-4 py-1.5 bg-amber-50 border border-amber-200 rounded-full text-[11px] font-bold text-amber-700 text-center">
                                            {m.text}
                                        </div>
                                    ) : (
                                        <div className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-[13px] leading-relaxed ${m.type === 'user'
                                            ? 'bg-indigo-600 text-white rounded-br-sm'
                                            : m.type === 'worker'
                                                ? 'bg-emerald-50 text-emerald-900 border border-emerald-100 rounded-bl-sm'
                                                : m.type === 'ai'
                                                    ? 'bg-purple-50 text-purple-900 border border-purple-100 rounded-bl-sm'
                                                    : 'bg-white text-gray-800 border border-gray-100 rounded-bl-sm shadow-sm'
                                            }`}>
                                            {m.type !== 'user' && (
                                                <div className="flex items-center gap-1 mb-0.5">
                                                    {m.type === 'worker' ? <User className="w-3 h-3 text-emerald-500" /> : <Bot className="w-3 h-3 text-indigo-400" />}
                                                    <span className="text-[8px] font-bold opacity-50 uppercase tracking-wider">
                                                        {m.type === 'worker' ? 'Agent' : m.type === 'ai' ? 'AI' : 'CODVerify'}
                                                    </span>
                                                </div>
                                            )}
                                            <p className="whitespace-pre-line">{m.text}</p>
                                            <p className={`text-[8px] mt-1 opacity-30 ${m.type === 'user' ? 'text-right' : ''}`}>{m.time}</p>
                                        </div>
                                    )}
                                </motion.div>
                            ))}

                            {/* Menu Options — show after greeting or after scripted answer */}
                            {(mode === 'menu' || mode === 'scripted') && (
                                <motion.div
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-1.5 pt-2"
                                >
                                    {mode === 'scripted' && (
                                        <button
                                            onClick={handleBackToMenu}
                                            className="w-full text-left px-3.5 py-2 bg-gray-100 text-gray-500 rounded-xl text-[11px] font-bold hover:bg-gray-200 transition-colors flex items-center gap-2"
                                        >
                                            ← Back to Menu
                                        </button>
                                    )}
                                    {mode === 'menu' && (
                                        <>
                                            {MENU_OPTIONS.map(opt => (
                                                <button
                                                    key={opt.id}
                                                    onClick={() => handleMenuClick(opt)}
                                                    className="w-full text-left px-3.5 py-2.5 bg-white border border-gray-100 rounded-xl text-[12px] font-semibold text-gray-700 hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-700 transition-all flex items-center justify-between group shadow-sm"
                                                >
                                                    <span>{opt.label}</span>
                                                    <ChevronRight className="w-3.5 h-3.5 text-gray-300 group-hover:text-indigo-400 transition-colors" />
                                                </button>
                                            ))}
                                            {/* Connect with Agent — special option */}
                                            <button
                                                onClick={handleConnectAgent}
                                                className="w-full text-left px-3.5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl text-[12px] font-bold text-white shadow-md shadow-indigo-500/20 hover:shadow-lg transition-all flex items-center justify-between"
                                            >
                                                <span>🤝 Connect with Agent</span>
                                                <ChevronRight className="w-3.5 h-3.5 text-white/60" />
                                            </button>
                                        </>
                                    )}
                                </motion.div>
                            )}

                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input — only show in AI chat mode */}
                        {mode === 'ai_chat' && sessionStatus !== 'resolved' && (
                            <div className="p-3 border-t border-gray-100 bg-white flex-shrink-0">
                                <div className="flex items-center gap-2">
                                    <input
                                        value={input}
                                        onChange={e => setInput(e.target.value)}
                                        onKeyDown={handleKeyDown}
                                        placeholder="Ask about CODVerify..."
                                        className="flex-1 px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300 transition-colors"
                                        disabled={sessionStatus === 'resolved'}
                                    />
                                    <button
                                        onClick={handleSendAI}
                                        disabled={sending || !input.trim()}
                                        className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-md hover:bg-indigo-700 transition-all disabled:opacity-40"
                                    >
                                        <Send className="w-4 h-4" />
                                    </button>
                                </div>
                                <p className="text-[8px] text-gray-300 text-center mt-1 font-medium">Powered by CODVerify AI</p>
                            </div>
                        )}

                        {sessionStatus === 'resolved' && (
                            <div className="p-3 border-t border-gray-100 bg-emerald-50 text-center flex-shrink-0">
                                <p className="text-[11px] font-bold text-emerald-600">✅ Chat resolved. Thank you!</p>
                            </div>
                        )}
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}

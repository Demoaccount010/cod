export interface User {
    id: string;
    email: string;
    name: string;
    phone: string;
    role: 'merchant' | 'admin' | 'worker';
    company_name?: string;
    company_logo_url?: string;
    business_type?: string;
    status: string;
    email_verified: boolean;
    onboarding_completed: boolean;
    timezone: string;
    last_login?: string;
    created_at: string;
    wallet_balance: number;
    subscription?: Subscription;
    settings?: MerchantSettings;
}

export interface Subscription {
    id: string;
    plan_type: string;
    plan_name: string;
    monthly_quota: number;
    used_quota: number;
    price_monthly: number;
    billing_cycle: string;
    start_date: string;
    end_date: string;
    status: string;
}

export interface MerchantSettings {
    whatsapp_connected: boolean;
    whatsapp_phone_display?: string;
    whatsapp_business_name?: string;
    message_delay_seconds: number;
    working_hours_enabled: boolean;
    working_hours_start: string;
    working_hours_end: string;
    auto_cancel_on_no: boolean;
    auto_cancel_on_no_reply: boolean;
    no_reply_timeout_hours: number;
    max_retries: number;
    min_order_amount: number;
    notification_on_cancel: boolean;
    notification_daily_summary: boolean;
}

export interface Order {
    id: string;
    store_order_id: string;
    order_number: string;
    customer_name: string;
    customer_phone: string;
    customer_email?: string;
    order_amount: number;
    currency: string;
    products_json: Product[];
    shipping_address_json: Address;
    verification_status: string;
    verification_sent_at?: string;
    customer_response?: string;
    response_received_at?: string;
    response_time_seconds?: number;
    delivery_status: string;
    tracking_number?: string;
    risk_score: number;
    risk_factors_json?: string[];
    retry_count: number;
    notes?: string;
    tags?: string[];
    created_at: string;
}

export interface Product {
    name: string;
    quantity: number;
    price: number;
    image_url?: string;
}

export interface Address {
    line1: string;
    line2?: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
}

export interface Store {
    id: string;
    platform: string;
    store_url: string;
    store_name: string;
    is_active: boolean;
    total_orders: number;
    last_order_received_at?: string;
    connected_at: string;
}

export interface ApiKey {
    id: string;
    api_key: string;
    label: string;
    is_active: boolean;
    last_used_at?: string;
    created_at: string;
}

export interface Notification {
    id: string;
    title: string;
    message: string;
    type: string;
    is_read: boolean;
    action_url?: string;
    created_at: string;
}

export interface Ticket {
    id: string;
    ticket_number: string;
    subject: string;
    description: string;
    status: string;
    priority: string;
    category?: string;
    created_at: string;
}

export interface Partner {
    partner_name: string;
    partner_logo_url?: string;
    partner_website_url?: string;
    short_description?: string;
    full_description?: string;
    category?: string;
    seo_slug: string;
}

export interface BlogPost {
    id?: string;
    title: string;
    slug: string;
    content?: string;
    excerpt?: string;
    featured_image_url?: string;
    author_name?: string;
    category?: string;
    tags?: string[];
    reading_time_minutes?: number;
    published_at?: string;
    views_count?: number;
}

export interface PaginationMeta {
    total: number;
    page: number;
    limit: number;
    total_pages: number;
    has_next: boolean;
    has_prev: boolean;
}

export interface ApiResponse<T = any> {
    success: boolean;
    data: T;
    message: string;
    errors: string[];
}

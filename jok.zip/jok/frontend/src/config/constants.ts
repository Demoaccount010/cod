// API Configuration - supports environment variables
const getApiUrl = (): string => {
    // Priority: explicit env var > vite env var > localhost
    if (typeof (import.meta as any).env?.VITE_API_URL !== 'undefined' && (import.meta as any).env?.VITE_API_URL) {
        return (import.meta as any).env.VITE_API_URL;
    }
    // Default to FastAPI backend on localhost:8000
    return 'http://localhost:8000';
};

export const API_BASE_URL = getApiUrl();
export const APP_NAME = 'CODVerify';
export const APP_DESCRIPTION = 'Reduce COD RTO by 40% with Smart WhatsApp Verification';
export const FRONTEND_URL = import.meta.env.VITE_FRONTEND_URL || 'http://localhost:5173';

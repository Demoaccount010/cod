import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { workerApi } from '../../api';
import { Bot, Edit3, RotateCcw, Save, X } from 'lucide-react';
import { toast } from 'sonner';

export default function WorkerMerchantLimits() {
    const [merchants, setMerchants] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editValue, setEditValue] = useState(0);

    const fetchData = useCallback(() => {
        workerApi.getMerchantChatbotLimits()
            .then(r => setMerchants(r.data?.data?.merchants || []))
            .catch(() => toast.error('Failed to load'))
            .finally(() => setLoading(false));
    }, []);

    useEffect(() => { fetchData(); }, [fetchData]);

    const handleSaveLimit = async (merchantId: string) => {
        try {
            await workerApi.updateMerchantLimit(merchantId, editValue);
            toast.success('Limit updated');
            setEditingId(null);
            fetchData();
        } catch {
            toast.error('Failed to update limit');
        }
    };

    const handleResetUsage = async (merchantId: string) => {
        try {
            await workerApi.resetMerchantUsage(merchantId);
            toast.success('Usage counter reset');
            fetchData();
        } catch {
            toast.error('Failed to reset');
        }
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
    );

    return (
        <div className="max-w-5xl mx-auto space-y-6 pb-10">
            <Helmet><title>API Limits — Worker</title></Helmet>

            <div className="flex items-center gap-3">
                <div className="p-2.5 bg-purple-600 rounded-xl shadow-lg shadow-purple-500/20 text-white">
                    <Bot className="w-5 h-5" />
                </div>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 font-['Outfit']">Chatbot API Limits</h1>
                    <p className="text-gray-400 text-xs font-medium">Manage monthly request limits for each merchant</p>
                </div>
            </div>

            <div className="glass-card rounded-[28px] border border-white shadow-xl overflow-hidden">
                <table className="w-full">
                    <thead>
                        <tr className="bg-gray-50/50 border-b border-gray-100">
                            <th className="text-left px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Merchant</th>
                            <th className="text-center px-4 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                            <th className="text-center px-4 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Used</th>
                            <th className="text-center px-4 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Limit</th>
                            <th className="text-center px-4 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Remaining</th>
                            <th className="text-right px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {merchants.map((m, i) => (
                            <motion.tr
                                key={m.merchant_id}
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: i * 0.03 }}
                                className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors"
                            >
                                <td className="px-6 py-4">
                                    <p className="text-sm font-bold text-gray-900">{m.business_name || m.company_name || m.merchant_name}</p>
                                    <p className="text-[10px] text-gray-400">{m.merchant_email}</p>
                                </td>
                                <td className="text-center px-4 py-4">
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${m.is_enabled ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-400'
                                        }`}>
                                        {m.is_enabled ? 'Active' : 'Inactive'}
                                    </span>
                                </td>
                                <td className="text-center px-4 py-4 text-sm font-bold text-gray-700">{m.current_usage}</td>
                                <td className="text-center px-4 py-4">
                                    {editingId === m.merchant_id ? (
                                        <div className="flex items-center justify-center gap-1">
                                            <input
                                                type="number"
                                                value={editValue}
                                                onChange={e => setEditValue(Number(e.target.value))}
                                                className="w-20 px-2 py-1 border border-indigo-300 rounded-lg text-sm text-center outline-none"
                                                min={0}
                                            />
                                            <button onClick={() => handleSaveLimit(m.merchant_id)} className="p-1 text-emerald-500 hover:bg-emerald-50 rounded-lg">
                                                <Save className="w-3.5 h-3.5" />
                                            </button>
                                            <button onClick={() => setEditingId(null)} className="p-1 text-gray-400 hover:bg-gray-100 rounded-lg">
                                                <X className="w-3.5 h-3.5" />
                                            </button>
                                        </div>
                                    ) : (
                                        <span className="text-sm font-bold text-indigo-600">{m.monthly_limit}</span>
                                    )}
                                </td>
                                <td className="text-center px-4 py-4">
                                    <span className={`text-sm font-bold ${m.remaining > 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                                        {m.remaining}
                                    </span>
                                </td>
                                <td className="text-right px-6 py-4">
                                    <div className="flex items-center justify-end gap-1">
                                        <button
                                            onClick={() => { setEditingId(m.merchant_id); setEditValue(m.monthly_limit); }}
                                            className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                                            title="Edit Limit"
                                        >
                                            <Edit3 className="w-4 h-4" />
                                        </button>
                                        <button
                                            onClick={() => handleResetUsage(m.merchant_id)}
                                            className="p-2 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-xl transition-all"
                                            title="Reset Usage"
                                        >
                                            <RotateCcw className="w-4 h-4" />
                                        </button>
                                    </div>
                                </td>
                            </motion.tr>
                        ))}
                    </tbody>
                </table>

                {merchants.length === 0 && (
                    <div className="text-center py-16">
                        <Bot className="w-14 h-14 text-gray-200 mx-auto mb-3" />
                        <p className="text-sm font-bold text-gray-500">No merchants with chatbot configured</p>
                    </div>
                )}
            </div>
        </div>
    );
}

import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { workerApi } from '../../api';
import {
    Phone, PhoneMissed, MessageSquare, Clock, Power, Coffee,
    Activity, CheckCircle2, Users, Headphones, Zap, Timer, Store,
    Circle, Lock, AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';

function formatDuration(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

export default function WorkerDashboard() {
    const navigate = useNavigate();
    const [stats, setStats] = useState<any>(null);
    const [activeWorkers, setActiveWorkers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [dutyLoading, setDutyLoading] = useState(false);
    const [liveSeconds, setLiveSeconds] = useState(0);

    const fetchStats = useCallback(() => {
        Promise.all([
            workerApi.getDashboardStats(),
            workerApi.getActiveWorkers().catch(() => ({ data: { data: { workers: [] } } })),
        ]).then(([r, aw]) => {
            setStats(r.data?.data);
            setLiveSeconds(r.data?.data?.duty?.current_session_seconds || 0);
            setActiveWorkers(aw.data?.data?.workers || []);
        }).finally(() => setLoading(false));
    }, []);

    useEffect(() => { fetchStats(); }, [fetchStats]);

    // Live timer for on-duty
    useEffect(() => {
        if (stats?.duty?.status !== 'on_duty') return;
        const interval = setInterval(() => setLiveSeconds(s => s + 1), 1000);
        return () => clearInterval(interval);
    }, [stats?.duty?.status]);

    // Heartbeat ping every 60s while on duty
    useEffect(() => {
        if (stats?.duty?.status !== 'on_duty') return;
        workerApi.heartbeat().catch(() => { });
        const hbInterval = setInterval(() => {
            workerApi.heartbeat().catch(() => { });
        }, 60000);
        return () => clearInterval(hbInterval);
    }, [stats?.duty?.status]);

    // Auto off-duty when browser closes
    useEffect(() => {
        if (stats?.duty?.status !== 'on_duty') return;
        const handleBeforeUnload = () => { workerApi.toggleDuty().catch(() => { }); };
        const handleVisibility = () => { if (document.hidden) { workerApi.heartbeat().catch(() => { }); } };
        window.addEventListener('beforeunload', handleBeforeUnload);
        document.addEventListener('visibilitychange', handleVisibility);
        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
            document.removeEventListener('visibilitychange', handleVisibility);
        };
    }, [stats?.duty?.status]);

    const handleDutyToggle = async () => {
        setDutyLoading(true);
        try {
            await workerApi.toggleDuty();
            fetchStats();
        } finally {
            setDutyLoading(false);
        }
    };

    const handleBreak = async () => {
        setDutyLoading(true);
        try {
            await workerApi.takeBreak();
            fetchStats();
        } finally {
            setDutyLoading(false);
        }
    };

    const handleLockedNav = (to: string) => {
        if (!isOnDuty) {
            toast.error('⚠️ Please go On Duty first to access this section', { duration: 3000 });
            return;
        }
        navigate(to);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Loading Worker Panel...</p>
        </div>
    );

    const d = stats?.duty || {};
    const v = stats?.verification || {};
    const c = stats?.chats || {};
    const isOnDuty = d.status === 'on_duty';
    const isBreak = d.status === 'break';

    const pendingOrders = v.total_today - (v.answered || 0) - (v.not_picked || 0) - (v.cancelled || 0);
    const waitingChats = c.waiting || 0;

    // Quick action cards with lock state
    const quickActions = [
        {
            to: '/worker/orders',
            color: 'bg-blue-600',
            shadowColor: 'shadow-blue-500/20',
            icon: Phone,
            title: 'Verify Orders',
            sub: `${Math.max(0, pendingOrders)} pending`,
            locked: !isOnDuty,
            badge: Math.max(0, pendingOrders),
        },
        {
            to: '/worker/stores',
            color: 'bg-indigo-600',
            shadowColor: 'shadow-indigo-500/20',
            icon: Store,
            title: 'Stores',
            sub: 'Browse by merchant',
            locked: false,
            badge: 0,
        },
        {
            to: '/worker/chat',
            color: 'bg-purple-600',
            shadowColor: 'shadow-purple-500/20',
            icon: MessageSquare,
            title: 'Customer Support',
            sub: `${waitingChats} waiting`,
            locked: !isOnDuty,
            badge: waitingChats,
        },
        {
            to: '/worker/orders?tab=all',
            color: 'bg-emerald-600',
            shadowColor: 'shadow-emerald-500/20',
            icon: Activity,
            title: 'Performance',
            sub: `${v.total_today || 0} orders today`,
            locked: false,
            badge: 0,
        },
    ];

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet><title>Worker Dashboard — CODVerify</title></Helmet>

            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-xl shadow-lg text-white ${isOnDuty ? 'bg-emerald-600 shadow-emerald-500/20' : isBreak ? 'bg-amber-500 shadow-amber-500/20' : 'bg-gray-400 shadow-gray-400/20'}`}>
                            <Headphones className="w-5 h-5" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Worker Panel</h1>
                            <p className="text-gray-500 text-sm font-medium italic">Order verification & customer support command center</p>
                        </div>
                    </div>
                </motion.div>

                {/* Duty Controls */}
                <div className="flex items-center gap-3">
                    {isOnDuty && (
                        <button
                            onClick={handleBreak}
                            disabled={dutyLoading}
                            className="px-5 py-2.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-2xl text-xs font-bold hover:bg-amber-100 transition-all flex items-center gap-2"
                        >
                            <Coffee className="w-4 h-4" /> Break
                        </button>
                    )}
                    <button
                        onClick={handleDutyToggle}
                        disabled={dutyLoading}
                        className={`px-7 py-3 rounded-2xl text-sm font-bold shadow-lg transition-all flex items-center gap-2 ${isOnDuty
                            ? 'bg-rose-600 text-white shadow-rose-500/20 hover:bg-rose-700'
                            : 'bg-emerald-600 text-white shadow-emerald-500/20 hover:bg-emerald-700'
                            }`}
                    >
                        <Power className="w-4 h-4" />
                        {dutyLoading ? 'Updating...' : isOnDuty ? 'Go Off Duty' : isBreak ? 'Resume Duty' : 'Go On Duty'}
                    </button>
                </div>
            </div>

            {/* Off-Duty Warning Banner */}
            <AnimatePresence>
                {!isOnDuty && !isBreak && (
                    <motion.div
                        initial={{ opacity: 0, y: -8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        className="flex items-center gap-3 px-5 py-4 bg-amber-50 border border-amber-200 rounded-2xl"
                    >
                        <Lock className="w-5 h-5 text-amber-600 flex-shrink-0" />
                        <div>
                            <p className="text-sm font-bold text-amber-800">You are currently Off Duty</p>
                            <p className="text-xs text-amber-600 mt-0.5">Verify Orders and Customer Support are locked. Click "Go On Duty" to start your shift.</p>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Duty Status Banner */}
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`rounded-[32px] p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl ${isOnDuty
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-emerald-500/10'
                    : isBreak
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-amber-500/10'
                        : 'bg-gradient-to-r from-gray-200 to-gray-300 text-gray-700 shadow-gray-300/10'
                    }`}
            >
                <div className="flex items-center gap-4">
                    <div className={`w-4 h-4 rounded-full ${isOnDuty ? 'bg-white animate-pulse' : isBreak ? 'bg-white animate-bounce' : 'bg-gray-400'}`} />
                    <div>
                        <p className="text-lg font-bold font-['Outfit']">
                            {isOnDuty ? 'ON DUTY' : isBreak ? 'ON BREAK' : 'OFF DUTY'}
                        </p>
                        <p className="text-xs opacity-80 font-medium">
                            {isOnDuty ? 'You can receive orders and chat requests' : isBreak ? 'Chats paused — orders remain assigned' : 'You will not receive new assignments'}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-6">
                    {isOnDuty && (
                        <div className="flex items-center gap-2">
                            <Timer className="w-5 h-5 opacity-80" />
                            <span className="text-2xl font-black font-['Outfit'] tabular-nums">{formatDuration(liveSeconds)}</span>
                        </div>
                    )}
                    <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 opacity-60" />
                        <span className="text-sm font-bold">Today: {formatDuration(d.total_seconds_today || 0)}</span>
                    </div>
                </div>
            </motion.div>

            {/* Stats Cards */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                    { label: 'Calls Today', value: v.total_today || 0, icon: Phone, color: 'bg-indigo-600', sub: `${v.answered || 0} answered` },
                    { label: 'Confirmed', value: v.answered || 0, icon: CheckCircle2, color: 'bg-emerald-600', sub: `${v.total_today ? Math.round((v.answered / v.total_today) * 100) : 0}% rate` },
                    { label: 'Not Picked', value: v.not_picked || 0, icon: PhoneMissed, color: 'bg-amber-500', sub: `${v.cancelled || 0} cancelled` },
                    { label: 'Active Chats', value: c.active || 0, icon: MessageSquare, color: 'bg-purple-600', sub: `${c.waiting || 0} waiting` },
                ].map((card, i) => (
                    <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 + i * 0.05 }}
                        className="glass-card rounded-[32px] p-6 border border-white shadow-xl shadow-gray-900/5 hover:-translate-y-1 transition-all duration-500 group"
                    >
                        <div className={`w-14 h-14 ${card.color} rounded-2xl flex items-center justify-center mb-5 shadow-xl shadow-indigo-500/10 transition-transform group-hover:scale-110`}>
                            <card.icon className="w-7 h-7 text-white" />
                        </div>
                        <p className="text-3xl font-black text-gray-900 font-['Outfit'] tracking-tighter mb-1">{card.value}</p>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">{card.label}</p>
                        <p className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg inline-block">{card.sub}</p>
                    </motion.div>
                ))}
            </div>

            {/* Quick Actions — with lock state */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {quickActions.map((action, i) => {
                    const Icon = action.icon;
                    return (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 + i * 0.05 }}
                            onClick={() => action.locked ? handleLockedNav(action.to) : navigate(action.to)}
                            className={`glass-card rounded-[32px] p-7 border border-white shadow-xl shadow-gray-900/5 transition-all duration-500 group text-center cursor-pointer relative overflow-hidden ${action.locked ? 'opacity-60 hover:opacity-75' : 'hover:-translate-y-1'}`}
                        >
                            {/* Lock overlay */}
                            {action.locked && (
                                <div className="absolute inset-0 flex items-center justify-center bg-gray-100/60 rounded-[32px] z-10">
                                    <div className="flex flex-col items-center gap-1">
                                        <Lock className="w-6 h-6 text-gray-500" />
                                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Off Duty</span>
                                    </div>
                                </div>
                            )}
                            {/* Notification badge */}
                            {action.badge > 0 && !action.locked && (
                                <div className="absolute top-4 right-4 min-w-[22px] h-[22px] px-1.5 bg-red-500 text-white rounded-full text-[10px] font-black flex items-center justify-center shadow-lg animate-bounce z-20">
                                    {action.badge > 9 ? '9+' : action.badge}
                                </div>
                            )}
                            <div className={`w-14 h-14 ${action.color} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg ${action.shadowColor} group-hover:scale-110 transition-transform`}>
                                <Icon className="w-7 h-7 text-white" />
                            </div>
                            <h3 className="text-base font-bold text-gray-900 font-['Outfit']">{action.title}</h3>
                            <p className="text-xs text-gray-400 mt-1">{action.sub}</p>
                        </motion.div>
                    );
                })}
            </div>

            {/* Team Online */}
            {activeWorkers.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                    className="glass-card rounded-[32px] p-6 border border-white shadow-xl shadow-gray-900/5">
                    <div className="flex items-center gap-2 mb-4">
                        <Users className="w-5 h-5 text-indigo-500" />
                        <h2 className="text-base font-bold text-gray-900 font-['Outfit']">Team Online</h2>
                        <span className="ml-auto text-xs text-gray-400">{activeWorkers.length} colleague{activeWorkers.length !== 1 ? 's' : ''} online</span>
                    </div>
                    <div className="flex flex-wrap gap-3">
                        {activeWorkers.map(w => (
                            <div key={w.id} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/60 border border-gray-100">
                                <div className="relative">
                                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                                        {(w.name || 'W').charAt(0).toUpperCase()}
                                    </div>
                                    <Circle className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 fill-current ${w.duty_status === 'on_duty' ? 'text-emerald-500' : 'text-amber-400'}`} />
                                </div>
                                <div>
                                    <p className="text-xs font-semibold text-gray-800">{w.name || w.email}</p>
                                    <p className="text-[10px] text-gray-400 capitalize">{w.duty_status === 'on_duty' ? 'On duty' : 'Break'}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </motion.div>
            )}

            {/* Footer Status */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}
                className="py-8 flex items-center justify-center gap-6">
                <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-500" />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">System Online</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-200" />
                <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{isOnDuty ? 'Receiving Assignments' : 'Off Duty — No Assignments'}</span>
                </div>
            </motion.div>
        </div>
    );
}

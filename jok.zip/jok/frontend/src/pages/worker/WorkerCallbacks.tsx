import { useEffect, useState } from 'react';
import { workerApi } from '../../api';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Phone, PhoneCall, CheckCircle, XCircle, Clock, User, Package, RefreshCw, ChevronRight, Globe } from 'lucide-react';

type Callback = {
    id: string;
    order_id?: string;
    customer_name?: string;
    customer_phone?: string;
    merchant_name?: string;
    status: 'pending' | 'accepted' | 'in_progress' | 'resolved' | 'cancelled';
    request_time?: string;
    notes?: string;
    assigned_worker_id?: string | null;
    store_name?: string;
    domain?: string;
};

const STATUS_STYLES: Record<string, { cls: string; label: string }> = {
    pending:     { cls: 'bg-yellow-100 text-yellow-700 border-yellow-200',   label: 'Pending'     },
    accepted:    { cls: 'bg-blue-100 text-blue-700 border-blue-200',         label: 'Accepted'    },
    in_progress: { cls: 'bg-blue-100 text-blue-700 border-blue-200',         label: 'In Progress' },
    resolved:    { cls: 'bg-green-100 text-green-700 border-green-200',      label: 'Resolved'    },
    cancelled:   { cls: 'bg-red-100 text-red-700 border-red-200',            label: 'Cancelled'   },
};

export default function WorkerCallbacks() {
    const [callbacks, setCallbacks] = useState<Callback[]>([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState<'all' | 'pending' | 'in_progress' | 'resolved'>('all');
    const [actionLoading, setActionLoading] = useState<string | null>(null);
    const [resolveModal, setResolveModal] = useState<{ id: string } | null>(null);
    const [resolveNote, setResolveNote] = useState('');

    const fetchCallbacks = async () => {
        setLoading(true);
        try {
            const params = filter !== 'all' ? `status=${filter}` : undefined;
            const res = await workerApi.getCallbacks(params);
            setCallbacks(res.data?.data?.callbacks || res.data?.callbacks || []);
        } catch {
            toast.error('Failed to load callbacks');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchCallbacks(); }, [filter]);

    const handleAccept = async (id: string) => {
        setActionLoading(id);
        try {
            await workerApi.acceptCallback(id);
            toast.success('Callback accepted — assigned to you');
            fetchCallbacks();
        } catch {
            toast.error('Failed to accept callback');
        } finally {
            setActionLoading(null);
        }
    };

    const handleResolve = async () => {
        if (!resolveModal) return;
        setActionLoading(resolveModal.id);
        try {
            await workerApi.resolveCallback(resolveModal.id, { resolution_notes: resolveNote });
            toast.success('Callback marked as resolved');
            setResolveModal(null);
            setResolveNote('');
            fetchCallbacks();
        } catch {
            toast.error('Failed to resolve callback');
        } finally {
            setActionLoading(null);
        }
    };

    const handleCancel = async (id: string) => {
        setActionLoading(id);
        try {
            await workerApi.cancelCallback(id);
            toast.success('Callback cancelled');
            fetchCallbacks();
        } catch {
            toast.error('Failed to cancel callback');
        } finally {
            setActionLoading(null);
        }
    };

    const displayed = callbacks;

    return (
        <div className="p-6 max-w-5xl mx-auto">
            <div className="mb-8 flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <h1 className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tight">Customer Callbacks</h1>
                    <p className="text-gray-500 text-sm mt-1">Accept and resolve callback requests from customers.</p>
                </div>
                <button onClick={fetchCallbacks} className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-semibold hover:bg-gray-200 transition-all">
                    <RefreshCw className="w-4 h-4" /> Refresh
                </button>
            </div>

            {/* Filter tabs */}
            <div className="flex gap-2 mb-6 flex-wrap">
                {(['all', 'pending', 'in_progress', 'resolved'] as const).map(f => (
                    <button key={f} onClick={() => setFilter(f)}
                        className={`px-4 py-2 rounded-xl text-sm font-semibold capitalize transition-all border ${filter === f ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-200 hover:border-indigo-300'}`}>
                        {f}
                    </button>
                ))}
            </div>

            {loading ? (
                <div className="flex items-center justify-center h-64">
                    <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                </div>
            ) : displayed.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-2xl border border-gray-100">
                    <PhoneCall className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="text-gray-500 font-medium">No {filter !== 'all' ? filter : ''} callbacks found</p>
                    <p className="text-gray-400 text-sm mt-1">Check back later or change the filter</p>
                </div>
            ) : (
                <div className="space-y-3">
                    <AnimatePresence>
                        {displayed.map(cb => {
                            const s = STATUS_STYLES[cb.status] || STATUS_STYLES.pending;
                            const isLoading = actionLoading === cb.id;
                            return (
                                <motion.div key={cb.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                                    className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
                                    <div className="flex items-start gap-4 min-w-0">
                                        <div className="w-11 h-11 rounded-xl bg-indigo-50 flex items-center justify-center flex-shrink-0">
                                            <Phone className="w-5 h-5 text-indigo-600" />
                                        </div>
                                        <div className="min-w-0">
                                            <div className="flex items-center gap-2 flex-wrap">
                                                <p className="font-bold text-gray-900 text-sm">{cb.customer_name || 'Unknown Customer'}</p>
                                                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${s.cls}`}>{s.label}</span>
                                            </div>
                                            <p className="text-gray-500 text-sm mt-0.5">{cb.customer_phone || '—'}</p>
                                            <div className="flex items-center gap-4 mt-1.5 flex-wrap">
                                                {cb.order_id && (
                                                    <span className="flex items-center gap-1.5 text-xs text-gray-400">
                                                        <Package className="w-3.5 h-3.5" /> {cb.order_id}
                                                    </span>
                                                )}
                                                {cb.merchant_name && (
                                                    <span className="flex items-center gap-1.5 text-xs text-gray-400">
                                                        <User className="w-3.5 h-3.5" /> {cb.merchant_name}
                                                    </span>
                                                )}
                                                {(cb.store_name || cb.domain) && (
                                                    <span className="flex items-center gap-1.5 text-xs text-gray-400">
                                                        <Globe className="w-3.5 h-3.5" /> {cb.store_name || cb.domain}
                                                    </span>
                                                )}
                                                {cb.request_time && (
                                                    <span className="flex items-center gap-1.5 text-xs text-gray-400">
                                                        <Clock className="w-3.5 h-3.5" /> {new Date(cb.request_time).toLocaleString()}
                                                    </span>
                                                )}
                                            </div>
                                            {cb.notes && <p className="text-xs text-gray-400 mt-1 italic">"{cb.notes}"</p>}
                                        </div>
                                    </div>

                                    {/* Actions */}
                                    <div className="flex items-center gap-2 flex-shrink-0 flex-wrap sm:flex-nowrap">
                                        {cb.status === 'pending' && (
                                            <button onClick={() => handleAccept(cb.id)} disabled={isLoading}
                                                className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 disabled:opacity-60 transition-all">
                                                {isLoading ? <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <ChevronRight className="w-3.5 h-3.5" />}
                                                Accept
                                            </button>
                                        )}
                                        {(cb.status === 'accepted' || cb.status === 'in_progress') && (
                                            <>
                                                <button onClick={() => setResolveModal({ id: cb.id })} disabled={isLoading}
                                                    className="flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-bold hover:bg-green-700 disabled:opacity-60 transition-all">
                                                    <CheckCircle className="w-3.5 h-3.5" /> Resolve
                                                </button>
                                                <button onClick={() => handleCancel(cb.id)} disabled={isLoading}
                                                    className="flex items-center gap-1.5 px-4 py-2 bg-red-100 text-red-700 rounded-xl text-xs font-bold hover:bg-red-200 disabled:opacity-60 transition-all">
                                                    <XCircle className="w-3.5 h-3.5" /> Cancel
                                                </button>
                                            </>
                                        )}
                                        {(cb.status === 'resolved' || cb.status === 'cancelled') && (
                                            <span className="text-xs text-gray-400 italic">{cb.status === 'resolved' ? 'Done' : 'Cancelled'}</span>
                                        )}
                                    </div>
                                </motion.div>
                            );
                        })}
                    </AnimatePresence>
                </div>
            )}

            {/* Resolve Modal */}
            <AnimatePresence>
                {resolveModal && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
                        <motion.div initial={{ scale: 0.95, y: 10 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 10 }}
                            className="bg-white rounded-2xl shadow-2xl p-7 w-full max-w-md">
                            <h3 className="text-lg font-black text-gray-900 mb-2">Resolve Callback</h3>
                            <p className="text-sm text-gray-500 mb-5">Add notes about how this callback was handled (optional).</p>
                            <textarea rows={4} value={resolveNote} onChange={e => setResolveNote(e.target.value)}
                                placeholder="e.g. Customer confirmed order, provided tracking info..."
                                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400 resize-none mb-4" />
                            <div className="flex gap-3">
                                <button onClick={handleResolve} disabled={!!actionLoading}
                                    className="flex-1 py-2.5 bg-green-600 text-white rounded-xl text-sm font-bold hover:bg-green-700 disabled:opacity-60 transition-all">
                                    {actionLoading ? 'Resolving...' : 'Mark Resolved'}
                                </button>
                                <button onClick={() => { setResolveModal(null); setResolveNote(''); }}
                                    className="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-200 transition-all">
                                    Cancel
                                </button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

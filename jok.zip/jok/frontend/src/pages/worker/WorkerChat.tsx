import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { workerApi } from '../../api';
import {
    MessageSquare, Send, Check, User, Bot, ArrowLeft,
    Inbox, CheckCircle2, AlertCircle, Headphones, Lock,
    Globe, X, Wifi
} from 'lucide-react';
import { toast } from 'sonner';

function getSourceLabel(sess: any): string {
    const storeName = sess.merchant_store_name;
    const storeUrl = sess.merchant_store_url;
    const source = sess.source;

    if (storeName) return storeName;
    if (storeUrl) {
        try {
            return new URL(storeUrl.startsWith('http') ? storeUrl : `https://${storeUrl}`).hostname.replace('www.', '');
        } catch {
            return storeUrl;
        }
    }
    return source || 'Website';
}

// Floating popup for incoming chat request
function ChatRequestPopup({ session, onAccept, onReject, chatCount }: {
    session: any;
    onAccept: (id: string) => void;
    onReject: (id: string) => void;
    chatCount: number;
}) {
    const [timer, setTimer] = useState(30);
    const atLimit = chatCount >= 4;

    useEffect(() => {
        const t = setInterval(() => setTimer(s => {
            if (s <= 1) { clearInterval(t); onReject(session.id); return 0; }
            return s - 1;
        }), 1000);
        return () => clearInterval(t);
    }, [session.id, onReject]);

    return (
        <motion.div
            initial={{ opacity: 0, x: 100, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 100, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="fixed bottom-6 right-6 z-[999] w-80 bg-white rounded-3xl shadow-2xl shadow-black/20 border border-gray-100 overflow-hidden"
        >
            {/* Top progress bar */}
            <div className="h-1 bg-gray-100">
                <motion.div
                    initial={{ width: '100%' }}
                    animate={{ width: '0%' }}
                    transition={{ duration: 30, ease: 'linear' }}
                    className="h-full bg-orange-500"
                />
            </div>

            <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-orange-100 rounded-2xl flex items-center justify-center">
                            <MessageSquare className="w-5 h-5 text-orange-600" />
                        </div>
                        <div>
                            <p className="text-xs font-black text-orange-600 uppercase tracking-widest">New Chat Request</p>
                            <p className="text-sm font-bold text-gray-900">{session.visitor_name || 'Visitor'}</p>
                        </div>
                    </div>
                    <span className="text-xs font-black text-gray-400 bg-gray-100 px-2 py-1 rounded-lg">{timer}s</span>
                </div>

                {/* Website source */}
                <div className="flex items-center gap-2 mb-2 px-3 py-2 bg-blue-50 rounded-xl">
                    <Globe className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                    <p className="text-xs font-bold text-blue-700 truncate">From: {getSourceLabel(session)}</p>
                </div>

                {session.visitor_email && (
                    <p className="text-xs text-gray-400 mb-3 px-1">{session.visitor_email}</p>
                )}

                {/* Chat limit warning */}
                {atLimit && (
                    <div className="flex items-center gap-2 mb-3 px-3 py-2 bg-red-50 rounded-xl border border-red-100">
                        <AlertCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
                        <p className="text-xs font-bold text-red-600">Chat limit reached (4/4). Resolve a chat first.</p>
                    </div>
                )}

                <div className="flex gap-2">
                    <button
                        onClick={() => onReject(session.id)}
                        className="flex-1 px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-bold hover:bg-gray-200 transition-colors flex items-center justify-center gap-1.5"
                    >
                        <X className="w-4 h-4" /> Skip
                    </button>
                    <button
                        onClick={() => !atLimit && onAccept(session.id)}
                        disabled={atLimit}
                        className="flex-1 px-4 py-2.5 bg-orange-600 text-white rounded-xl text-sm font-bold hover:bg-orange-700 transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Check className="w-4 h-4" /> Accept
                    </button>
                </div>
            </div>
        </motion.div>
    );
}

export default function WorkerChat() {
    const [sessions, setSessions] = useState<{ my_sessions: any[]; waiting_sessions: any[]; resolved_sessions: any[]; active_count: number; max_chats: number }>({
        my_sessions: [], waiting_sessions: [], resolved_sessions: [], active_count: 0, max_chats: 4
    });
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const [messages, setMessages] = useState<any[]>([]);
    const [sessionInfo, setSessionInfo] = useState<any>(null);
    const [reply, setReply] = useState('');
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const [dutyStatus, setDutyStatus] = useState<string>('off_duty');
    // Popup management: track which sessions we've already shown/dismissed
    const [shownPopups, setShownPopups] = useState<Set<string>>(new Set());
    const [pendingPopup, setPendingPopup] = useState<any | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const fetchSessions = useCallback(() => {
        // Also fetch duty status
        workerApi.getDashboardStats().then(r => {
            setDutyStatus(r.data?.data?.duty?.status || 'off_duty');
        }).catch(() => { });

        workerApi.getChatSessions()
            .then(r => {
                const data = r.data?.data || { my_sessions: [], waiting_sessions: [], resolved_sessions: [], active_count: 0, max_chats: 4 };
                setSessions(data);

                // Check for new waiting sessions and show popup
                const waiting = data.waiting_sessions || [];
                if (waiting.length > 0 && dutyStatus === 'on_duty') {
                    const firstNew = waiting.find((s: any) => !shownPopups.has(s.id));
                    if (firstNew && !pendingPopup) {
                        setPendingPopup(firstNew);
                        setShownPopups(prev => new Set([...prev, firstNew.id]));
                    }
                }
            })
            .finally(() => setLoading(false));
    }, [dutyStatus, shownPopups, pendingPopup]);

    useEffect(() => { fetchSessions(); }, []);

    // Poll sessions every 4 seconds
    useEffect(() => {
        const interval = setInterval(fetchSessions, 4000);
        return () => clearInterval(interval);
    }, [fetchSessions]);

    // Load messages
    useEffect(() => {
        if (!activeSessionId) return;
        const load = () => {
            workerApi.getSessionMessages(activeSessionId).then(r => {
                setMessages(r.data?.data?.messages || []);
                setSessionInfo(r.data?.data?.session || null);
            });
        };
        load();
        const interval = setInterval(load, 3000);
        return () => clearInterval(interval);
    }, [activeSessionId]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleAccept = async (sessionId: string) => {
        try {
            await workerApi.acceptSession(sessionId);
            toast.success('✅ Chat accepted — say hello!');
            setActiveSessionId(sessionId);
            setPendingPopup(null);
            fetchSessions();
        } catch (e: any) {
            const msg = e?.response?.data?.detail || 'Failed to accept session';
            toast.error(msg);
            setPendingPopup(null);
        }
    };

    const handleRejectPopup = (_sessionId: string) => {
        setPendingPopup(null);
        // Don't call API — just skip. Session stays in queue for other workers.
    };

    const handleReply = async () => {
        if (!reply.trim() || !activeSessionId) return;
        setSending(true);
        try {
            await workerApi.replyToSession(activeSessionId, reply);
            setReply('');
            const r = await workerApi.getSessionMessages(activeSessionId);
            setMessages(r.data?.data?.messages || []);
        } catch {
            toast.error('Failed to send message');
        } finally {
            setSending(false);
        }
    };

    const handleResolve = async () => {
        if (!activeSessionId) return;
        try {
            await workerApi.resolveSession(activeSessionId);
            toast.success('Session resolved ✅');
            setActiveSessionId(null);
            setMessages([]);
            fetchSessions();
        } catch {
            toast.error('Failed to resolve session');
        }
    };

    const isOnDuty = dutyStatus === 'on_duty';
    const activeCount = sessions.active_count ?? sessions.my_sessions.length;
    const maxChats = sessions.max_chats ?? 4;

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Loading Chat System...</p>
        </div>
    );

    // Off-duty lock screen
    if (!isOnDuty) {
        return (
            <div className="max-w-7xl mx-auto pb-10">
                <Helmet><title>Customer Support — Worker Panel</title></Helmet>
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/worker" className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors">
                        <ArrowLeft className="w-5 h-5 text-gray-600" />
                    </Link>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Customer Support</h1>
                    </div>
                </div>
                <div className="flex flex-col items-center justify-center py-24 gap-5 glass-card rounded-[32px] border border-white shadow-xl">
                    <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center">
                        <Lock className="w-10 h-10 text-gray-300" />
                    </div>
                    <h2 className="text-xl font-bold text-gray-600 font-['Outfit']">You're Off Duty</h2>
                    <p className="text-sm text-gray-400 text-center max-w-sm">Go On Duty from the dashboard to start receiving customer chat requests.</p>
                    <Link to="/worker" className="px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all">
                        Go to Dashboard →
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto pb-10">
            <Helmet><title>Customer Support — Worker Panel</title></Helmet>

            {/* Chat request popup */}
            <AnimatePresence>
                {pendingPopup && (
                    <ChatRequestPopup
                        key={pendingPopup.id}
                        session={pendingPopup}
                        onAccept={handleAccept}
                        onReject={handleRejectPopup}
                        chatCount={activeCount}
                    />
                )}
            </AnimatePresence>

            {/* Header */}
            <div className="flex items-center justify-between gap-3 mb-6">
                <div className="flex items-center gap-3">
                    <Link to="/worker" className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors">
                        <ArrowLeft className="w-5 h-5 text-gray-600" />
                    </Link>
                    <div className="p-2.5 bg-purple-600 rounded-xl shadow-lg shadow-purple-500/20 text-white">
                        <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Customer Support</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Live chat sessions with customers</p>
                    </div>
                </div>

                {/* Chat capacity indicator */}
                <div className={`flex items-center gap-2 px-4 py-2 rounded-2xl border ${activeCount >= maxChats ? 'bg-red-50 border-red-200 text-red-700' : 'bg-emerald-50 border-emerald-200 text-emerald-700'}`}>
                    <Wifi className={`w-4 h-4 ${activeCount >= maxChats ? 'text-red-500' : 'text-emerald-500'}`} />
                    <span className="text-sm font-black">{activeCount}/{maxChats} chats</span>
                    {sessions.waiting_sessions.length > 0 && (
                        <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-[10px] font-black ml-1">
                            {sessions.waiting_sessions.length} waiting
                        </span>
                    )}
                </div>
            </div>

            {/* Chat Layout: Sidebar + Chat Area */}
            <div className="grid grid-cols-12 gap-6" style={{ height: 'calc(100vh - 200px)' }}>

                {/* Left: Sessions List */}
                <div className="col-span-4 glass-card rounded-[28px] border border-white shadow-xl overflow-hidden flex flex-col">
                    <div className="p-4 border-b border-gray-100 bg-gray-50/50">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Chat Sessions</p>
                    </div>

                    {/* Waiting Sessions */}
                    {sessions.waiting_sessions.length > 0 && (
                        <div className="border-b border-orange-100">
                            <div className="px-4 py-2 bg-orange-50">
                                <p className="text-[9px] font-black text-orange-600 uppercase tracking-widest flex items-center gap-1.5">
                                    <AlertCircle className="w-3 h-3" /> {sessions.waiting_sessions.length} Waiting
                                </p>
                            </div>
                            {sessions.waiting_sessions.map(s => (
                                <div key={s.id}
                                    className="flex items-center justify-between p-3 hover:bg-orange-50/50 transition-colors cursor-pointer border-b border-gray-50"
                                    onClick={() => activeCount < maxChats ? handleAccept(s.id) : toast.error('Chat limit reached (4/4). Resolve a chat first.')}
                                >
                                    <div className="flex items-center gap-3 min-w-0">
                                        <div className="w-9 h-9 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0">
                                            <User className="w-4 h-4 text-orange-600" />
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-xs font-bold text-gray-900 truncate">{s.visitor_name || 'Visitor'}</p>
                                            <p className="text-[10px] text-blue-500 font-semibold flex items-center gap-1 truncate">
                                                <Globe className="w-2.5 h-2.5 flex-shrink-0" /> {getSourceLabel(s)}
                                            </p>
                                        </div>
                                    </div>
                                    <button
                                        disabled={activeCount >= maxChats}
                                        className="px-2.5 py-1 bg-orange-600 text-white rounded-lg text-[9px] font-bold disabled:opacity-40 flex-shrink-0 ml-2"
                                    >
                                        Accept
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Active Sessions */}
                    <div className="flex-1 overflow-y-auto">
                        {sessions.my_sessions.length > 0 && (
                            <div className="px-4 py-2 bg-emerald-50">
                                <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1.5">
                                    <Headphones className="w-3 h-3" /> {sessions.my_sessions.length} Active
                                </p>
                            </div>
                        )}
                        {sessions.my_sessions.map(s => (
                            <div
                                key={s.id}
                                onClick={() => setActiveSessionId(s.id)}
                                className={`flex items-center gap-3 p-3 cursor-pointer transition-colors border-b border-gray-50 ${activeSessionId === s.id ? 'bg-indigo-50 border-l-4 border-l-indigo-500' : 'hover:bg-gray-50'}`}
                            >
                                <div className="w-9 h-9 bg-emerald-100 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <User className="w-4 h-4 text-emerald-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs font-bold text-gray-900 truncate">{s.visitor_name || 'Visitor'}</p>
                                    <p className="text-[10px] text-blue-500 font-semibold flex items-center gap-1 truncate">
                                        <Globe className="w-2.5 h-2.5 flex-shrink-0" /> {getSourceLabel(s)}
                                    </p>
                                </div>
                                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse flex-shrink-0" />
                            </div>
                        ))}

                        {/* Resolved */}
                        {sessions.resolved_sessions.length > 0 && (
                            <>
                                <div className="px-4 py-2 bg-gray-50 mt-2">
                                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Resolved</p>
                                </div>
                                {sessions.resolved_sessions.slice(0, 10).map(s => (
                                    <div
                                        key={s.id}
                                        onClick={() => setActiveSessionId(s.id)}
                                        className={`flex items-center gap-3 p-3 cursor-pointer transition-colors border-b border-gray-50 opacity-60 ${activeSessionId === s.id ? 'bg-gray-100' : 'hover:bg-gray-50'}`}
                                    >
                                        <div className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0">
                                            <CheckCircle2 className="w-4 h-4 text-gray-400" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-xs font-medium text-gray-500 truncate">{s.visitor_name || 'Visitor'}</p>
                                            <p className="text-[10px] text-gray-300 truncate">{new Date(s.resolved_at || s.created_at).toLocaleDateString()}</p>
                                        </div>
                                    </div>
                                ))}
                            </>
                        )}

                        {sessions.my_sessions.length === 0 && sessions.waiting_sessions.length === 0 && sessions.resolved_sessions.length === 0 && (
                            <div className="flex flex-col items-center justify-center h-full gap-3 px-6 text-center py-12">
                                <Inbox className="w-12 h-12 text-gray-200" />
                                <p className="text-sm font-bold text-gray-400">No Active Chats</p>
                                <p className="text-[10px] text-gray-300">New customer chats will appear as popups and here</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Right: Chat Area */}
                <div className="col-span-8 glass-card rounded-[28px] border border-white shadow-xl overflow-hidden flex flex-col">
                    {activeSessionId ? (
                        <>
                            {/* Chat Header */}
                            <div className="p-4 border-b border-gray-100 bg-gray-50/50 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
                                        <User className="w-5 h-5 text-indigo-600" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-900">{sessionInfo?.visitor_name || 'Visitor'}</p>
                                        <p className="text-[10px] text-gray-400 font-semibold flex items-center gap-1.5">
                                            {sessionInfo?.visitor_email && <span>{sessionInfo.visitor_email}</span>}
                                            <span className="flex items-center gap-1 text-blue-500">
                                                <Globe className="w-2.5 h-2.5" />
                                                {getSourceLabel(sessionInfo || {})}
                                            </span>
                                        </p>
                                    </div>
                                </div>
                                {sessionInfo?.status === 'human_active' && (
                                    <button
                                        onClick={handleResolve}
                                        className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-emerald-700 transition-all flex items-center gap-1.5"
                                    >
                                        <Check className="w-4 h-4" /> Resolve
                                    </button>
                                )}
                            </div>

                            {/* Messages */}
                            <div className="flex-1 overflow-y-auto p-6 space-y-4">
                                <AnimatePresence>
                                    {messages.map((m, i) => (
                                        <motion.div
                                            key={m.id || i}
                                            initial={{ opacity: 0, y: 5 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            className={`flex ${m.sender_type === 'visitor' ? 'justify-start' : 'justify-end'}`}
                                        >
                                            <div className={`max-w-[70%] px-5 py-3 rounded-2xl ${m.sender_type === 'visitor'
                                                ? 'bg-gray-100 text-gray-900 rounded-bl-sm'
                                                : m.sender_type === 'ai'
                                                    ? 'bg-purple-50 text-purple-900 rounded-br-sm border border-purple-100'
                                                    : m.sender_type === 'system'
                                                        ? 'bg-blue-50 text-blue-700 text-center mx-auto rounded-xl border border-blue-100 text-xs'
                                                        : 'bg-indigo-600 text-white rounded-br-sm shadow-md shadow-indigo-500/20'
                                                }`}>
                                                <div className="flex items-center gap-1.5 mb-1">
                                                    {m.sender_type === 'visitor' && <User className="w-3 h-3 text-gray-400" />}
                                                    {m.sender_type === 'ai' && <Bot className="w-3 h-3 text-purple-400" />}
                                                    {m.sender_type === 'worker' && <Headphones className="w-3 h-3 text-indigo-200" />}
                                                    <span className="text-[9px] font-bold opacity-60 uppercase tracking-wider">
                                                        {m.sender_type === 'visitor' ? 'Customer' : m.sender_type === 'ai' ? 'AI Bot' : m.sender_type === 'system' ? 'System' : 'You'}
                                                    </span>
                                                </div>
                                                <p className="text-sm leading-relaxed">{m.message}</p>
                                                <p className={`text-[9px] mt-1 opacity-40 ${m.sender_type === 'worker' ? 'text-right' : ''}`}>
                                                    {new Date(m.created_at).toLocaleTimeString()}
                                                </p>
                                            </div>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                                <div ref={messagesEndRef} />
                            </div>

                            {/* Reply Input */}
                            {sessionInfo?.status === 'human_active' && (
                                <div className="p-4 border-t border-gray-100 bg-gray-50/30">
                                    <div className="flex items-center gap-3">
                                        <input
                                            value={reply}
                                            onChange={e => setReply(e.target.value)}
                                            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleReply()}
                                            placeholder="Type your reply..."
                                            className="flex-1 px-5 py-3.5 bg-white border border-gray-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all"
                                        />
                                        <button
                                            onClick={handleReply}
                                            disabled={sending || !reply.trim()}
                                            className="p-3.5 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all disabled:opacity-50"
                                        >
                                            <Send className="w-5 h-5" />
                                        </button>
                                    </div>
                                </div>
                            )}

                            {sessionInfo?.status === 'resolved' && (
                                <div className="p-4 border-t border-gray-100 bg-emerald-50 text-center">
                                    <p className="text-xs font-bold text-emerald-600 flex items-center justify-center gap-1.5">
                                        <CheckCircle2 className="w-4 h-4" /> This session has been resolved
                                    </p>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center px-10">
                            <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mb-2">
                                <MessageSquare className="w-10 h-10 text-gray-300" />
                            </div>
                            <h3 className="text-xl font-bold text-gray-400 font-['Outfit']">Select a Chat</h3>
                            <p className="text-xs text-gray-300 max-w-sm">
                                Click a session on the left to view the conversation. New incoming chats will appear as a popup notification.
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

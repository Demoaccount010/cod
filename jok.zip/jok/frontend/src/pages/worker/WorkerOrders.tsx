import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { workerApi } from '../../api';
import { formatCurrency } from '../../lib/utils';
import {
    Phone, PhoneOff, PhoneForwarded, XCircle, CheckCircle2,
    Clock, MapPin, User, Store, Package, ArrowLeft,
    Search, ChevronLeft, ChevronRight, Lock, Unlock, AlertCircle,
    RefreshCw, ListFilter,
} from 'lucide-react';
import { toast } from 'sonner';

export default function WorkerOrders() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const storeIdParam = searchParams.get('store_id') || '';

    const [activeTab, setActiveTab] = useState<'pending' | 'verified' | 'all'>('pending');
    const [orders, setOrders] = useState<any[]>([]);
    const [verified, setVerified] = useState<any[]>([]);
    const [allOrders, setAllOrders] = useState<any[]>([]);
    const [totalAll, setTotalAll] = useState(0);
    const [loading, setLoading] = useState(true);
    const [verifying, setVerifying] = useState('');
    const [claiming, setClaiming] = useState('');
    const [search, setSearch] = useState('');
    const [searchInput, setSearchInput] = useState('');
    const [page, setPage] = useState(1);
    const [orderTypeFilter, setOrderTypeFilter] = useState('');
    const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

    const PAGE_SIZE = 30;

    const fetchPending = useCallback(async () => {
        const qs = storeIdParam ? `?store_id=${storeIdParam}` : undefined;
        const [p, v] = await Promise.all([
            workerApi.getPendingOrders(qs),
            workerApi.getVerifiedOrders(),
        ]);
        setOrders(p.data?.data?.orders || []);
        setVerified(v.data?.data?.verifications || []);
    }, [storeIdParam]);

    const fetchAll = useCallback(async () => {
        const params = new URLSearchParams({ page: String(page), limit: String(PAGE_SIZE) });
        if (search) params.set('search', search);
        if (orderTypeFilter) params.set('order_type', orderTypeFilter);
        if (storeIdParam) params.set('store_id', storeIdParam);
        const res = await workerApi.getAllOrders(`?${params.toString()}`);
        const d = res.data?.data;
        setAllOrders(d?.orders || []);
        setTotalAll(d?.total || 0);
    }, [page, search, orderTypeFilter, storeIdParam]);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            if (activeTab !== 'all') await fetchPending();
            else await fetchAll();
        } catch { /* silent */ } finally { setLoading(false); }
    }, [activeTab, fetchPending, fetchAll]);

    useEffect(() => { fetchData(); }, [fetchData]);

    // Debounced search
    const handleSearchInput = (v: string) => {
        setSearchInput(v);
        if (searchTimeout.current) clearTimeout(searchTimeout.current);
        searchTimeout.current = setTimeout(() => { setSearch(v); setPage(1); }, 400);
    };

    const handleVerify = async (orderId: string, callStatus: string) => {
        if (callStatus === 'cancel' && !window.confirm('Cancel this order? This cannot be undone.')) return;
        setVerifying(orderId);
        try {
            const res = await workerApi.verifyOrder(orderId, { call_status: callStatus, call_notes: '', call_duration_seconds: 0 });
            toast.success(res.data?.message || `Marked as ${callStatus}`);
            fetchPending();
        } catch (err: any) { toast.error(err?.response?.data?.detail || 'Failed to update order'); }
        finally { setVerifying(''); }
    };

    const handleClaim = async (e: React.MouseEvent, orderId: string) => {
        e.stopPropagation();
        setClaiming(orderId);
        try {
            await workerApi.claimOrder(orderId);
            toast.success('Order claimed');
            fetchPending();
        } catch (err: any) {
            toast.error(err?.response?.data?.message || 'Already claimed by another worker');
            fetchPending();
        } finally { setClaiming(''); }
    };

    const handleRelease = async (e: React.MouseEvent, orderId: string) => {
        e.stopPropagation();
        setClaiming(orderId);
        try {
            await workerApi.releaseOrder(orderId);
            toast.success('Order released');
            fetchPending();
        } catch { toast.error('Failed to release'); }
        finally { setClaiming(''); }
    };

    const totalPages = Math.ceil(totalAll / PAGE_SIZE);

    return (
        <div className="max-w-7xl mx-auto space-y-6 pb-10">
            <Helmet><title>Order Verification — Worker Panel</title></Helmet>

            {/* Header */}
            <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-3">
                    <Link to="/worker" className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                        <ArrowLeft className="w-5 h-5 text-slate-400" />
                    </Link>
                    <div className="p-2.5 bg-blue-600 rounded-xl text-white">
                        <Phone className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-white">Order Verification</h1>
                        <p className="text-slate-400 text-sm">Verify COD orders by calling customers</p>
                    </div>
                </div>
                <button onClick={fetchData} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-all text-sm">
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                    Refresh
                </button>
            </div>

            {storeIdParam && (
                <div className="flex items-center gap-2 text-sm text-indigo-400">
                    <Store className="w-4 h-4" /> Filtered by store
                    <button onClick={() => navigate('/worker/orders')} className="text-slate-500 hover:text-white ml-1 underline text-xs">clear</button>
                </div>
            )}

            {/* Tabs */}
            <div className="flex gap-1.5 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit">
                {(['pending', 'verified', 'all'] as const).map(tab => (
                    <button key={tab} onClick={() => { setActiveTab(tab); setPage(1); }}
                        className={`px-5 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-white/15 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}>
                        {tab === 'pending' ? `Pending (${orders.length})` : tab === 'verified' ? `Done (${verified.length})` : 'All Orders'}
                    </button>
                ))}
            </div>

            {/* All-orders filters */}
            {activeTab === 'all' && (
                <div className="flex flex-wrap gap-3">
                    <div className="relative flex-1 min-w-[200px] max-w-xs">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input value={searchInput} onChange={e => handleSearchInput(e.target.value)} placeholder="Name, phone, #order…"
                            className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500/50" />
                    </div>
                    <select value={orderTypeFilter} onChange={e => { setOrderTypeFilter(e.target.value); setPage(1); }}
                        className="px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-sm focus:outline-none">
                        <option value="">All Types</option>
                        <option value="cod">COD</option>
                        <option value="prepaid">Prepaid</option>
                        <option value="manual">Manual</option>
                    </select>
                </div>
            )}

            {/* Content */}
            {loading ? (
                <div className="flex items-center justify-center py-20">
                    <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
                </div>
            ) : (
                <div className="space-y-3">
                    <AnimatePresence mode="popLayout">

                        {/* ── PENDING TAB ── */}
                        {activeTab === 'pending' && orders.map((o, i) => (
                            <motion.div key={o.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }} transition={{ delay: i * 0.04 }}
                                onClick={() => navigate(`/worker/orders/${o.id}`)}
                                className="relative rounded-2xl border border-white/10 bg-white/5 hover:bg-white/[0.08] cursor-pointer transition-all overflow-hidden">
                                {o.claimed_by_me && <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-500 to-purple-500" />}
                                <div className="p-5 flex flex-col lg:flex-row lg:items-center gap-4">
                                    <div className="flex items-center gap-3 min-w-[160px]">
                                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                                            {(o.merchant?.company_name || o.merchant?.name || 'M').charAt(0)}
                                        </div>
                                        <div>
                                            <p className="text-sm font-semibold text-white">{o.merchant?.company_name || o.merchant?.name}</p>
                                            <p className="text-xs text-slate-500">{o.merchant?.store_name || o.merchant?.platform}</p>
                                        </div>
                                    </div>
                                    <div className="flex-1 grid sm:grid-cols-3 gap-3">
                                        <div className="flex items-center gap-2">
                                            <User className="w-4 h-4 text-slate-500 shrink-0" />
                                            <div>
                                                <p className="text-sm text-white font-medium">{o.customer_name}</p>
                                                <p className="text-xs text-slate-400">{o.customer_phone}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                                            <p className="text-xs text-slate-400 line-clamp-2">{o.customer_address || 'No address'}</p>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Package className="w-4 h-4 text-slate-500 shrink-0" />
                                            <div>
                                                <p className="text-sm font-bold text-white">{formatCurrency(o.order_amount)}</p>
                                                <p className="text-xs text-slate-400">#{o.order_number || o.store_order_id}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 flex-wrap" onClick={e => e.stopPropagation()}>
                                        {o.claimed_by_me ? (
                                            <>
                                                <span className="flex items-center gap-1 px-2 py-1 rounded-lg bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs font-medium">
                                                    <Lock className="w-3 h-3" /> Mine
                                                </span>
                                                <button disabled={claiming === o.id} onClick={e => handleRelease(e, o.id)}
                                                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-red-500/10 text-slate-500 hover:text-red-400 text-xs transition-all disabled:opacity-50">
                                                    <Unlock className="w-3 h-3" /> Release
                                                </button>
                                            </>
                                        ) : o.claimed_by_worker_id ? (
                                            <span className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-medium">
                                                <AlertCircle className="w-3 h-3" /> Taken
                                            </span>
                                        ) : (
                                            <button disabled={claiming === o.id} onClick={e => handleClaim(e, o.id)}
                                                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-indigo-500/20 hover:border-indigo-500/40 text-slate-400 hover:text-indigo-300 text-xs font-medium transition-all disabled:opacity-50">
                                                <Unlock className="w-3 h-3" /> Claim
                                            </button>
                                        )}
                                        <button disabled={verifying === o.id || (!!o.claimed_by_worker_id && !o.claimed_by_me)} onClick={() => handleVerify(o.id, 'answered')}
                                            className="px-3 py-2 bg-green-600 hover:bg-green-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Done</button>
                                        <button disabled={verifying === o.id} onClick={() => handleVerify(o.id, 'not_picked')}
                                            className="px-3 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1"><PhoneOff className="w-3.5 h-3.5" /> No Answer</button>
                                        <button disabled={verifying === o.id} onClick={() => handleVerify(o.id, 'cancel')}
                                            className="px-3 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> Cancel</button>
                                        <button disabled={verifying === o.id} onClick={() => handleVerify(o.id, 'callback')}
                                            className="px-3 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1"><PhoneForwarded className="w-3.5 h-3.5" /> CB</button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                        {activeTab === 'pending' && orders.length === 0 && (
                            <div className="text-center py-20 text-slate-500"><CheckCircle2 className="w-14 h-14 mx-auto mb-3 opacity-25" /><p className="font-semibold">All clear — no pending orders</p></div>
                        )}

                        {/* ── VERIFIED TAB ── */}
                        {activeTab === 'verified' && verified.map((v, i) => (
                            <motion.div key={v.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                                className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/10 gap-3 flex-wrap">
                                <div className="flex items-center gap-3">
                                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0 ${v.call_status === 'answered' ? 'bg-green-600' : v.call_status === 'cancel' ? 'bg-red-600' : 'bg-amber-500'}`}>
                                        {v.call_status === 'answered' ? <CheckCircle2 className="w-4 h-4" /> : v.call_status === 'cancel' ? <XCircle className="w-4 h-4" /> : <PhoneOff className="w-4 h-4" />}
                                    </div>
                                    <div>
                                        <p className="text-sm font-semibold text-white">{v.customer_name || 'Customer'}</p>
                                        <p className="text-xs text-slate-400">{v.customer_phone} · {formatCurrency(v.order_amount)}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3">
                                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase ${v.call_status === 'answered' ? 'bg-green-600/20 text-green-400' : v.call_status === 'cancel' ? 'bg-red-600/20 text-red-400' : 'bg-amber-500/20 text-amber-400'}`}>{v.call_status}</span>
                                    <span className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(v.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                            </motion.div>
                        ))}
                        {activeTab === 'verified' && verified.length === 0 && (
                            <div className="text-center py-20 text-slate-500"><Phone className="w-14 h-14 mx-auto mb-3 opacity-25" /><p className="font-semibold">No verifications yet today</p></div>
                        )}

                        {/* ── ALL ORDERS TAB ── */}
                        {activeTab === 'all' && allOrders.map((o, i) => (
                            <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
                                onClick={() => navigate(`/worker/orders/${o.id}`)}
                                className="rounded-2xl border border-white/10 bg-white/5 hover:bg-white/[0.08] cursor-pointer transition-all p-4 flex flex-col sm:flex-row sm:items-center gap-3">
                                <div className="flex-1 grid sm:grid-cols-4 gap-3">
                                    <div><p className="text-xs text-slate-500 mb-0.5">Customer</p><p className="text-sm font-medium text-white">{o.customer_name}</p><p className="text-xs text-slate-400">{o.customer_phone}</p></div>
                                    <div><p className="text-xs text-slate-500 mb-0.5">Order</p><p className="text-sm font-medium text-white">#{o.order_number || o.store_order_id}</p><p className="text-xs text-slate-400">{o.order_type || 'cod'}</p></div>
                                    <div><p className="text-xs text-slate-500 mb-0.5">Amount</p><p className="text-sm font-bold text-white">{formatCurrency(o.order_amount)}</p></div>
                                    <div><p className="text-xs text-slate-500 mb-0.5">Status</p>
                                        <span className={`text-xs px-2 py-0.5 rounded-lg font-medium ${o.verification_status === 'confirmed' ? 'bg-green-600/20 text-green-400' : o.verification_status === 'cancelled' ? 'bg-red-600/20 text-red-400' : 'bg-amber-500/20 text-amber-400'}`}>{o.verification_status}</span>
                                    </div>
                                </div>
                                <div className="text-xs text-slate-500 shrink-0">{new Date(o.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</div>
                            </motion.div>
                        ))}
                        {activeTab === 'all' && allOrders.length === 0 && !loading && (
                            <div className="text-center py-20 text-slate-500"><ListFilter className="w-14 h-14 mx-auto mb-3 opacity-25" /><p className="font-semibold">No orders match your filters</p></div>
                        )}
                    </AnimatePresence>

                    {/* Pagination */}
                    {activeTab === 'all' && totalPages > 1 && (
                        <div className="flex items-center justify-center gap-3 pt-2">
                            <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white disabled:opacity-30 transition-all"><ChevronLeft className="w-4 h-4" /></button>
                            <span className="text-sm text-slate-400">Page {page} of {totalPages}</span>
                            <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)} className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white disabled:opacity-30 transition-all"><ChevronRight className="w-4 h-4" /></button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

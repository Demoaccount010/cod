import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Store, RefreshCw, ExternalLink, Package,
  AlertCircle, CheckCircle, Search,
} from 'lucide-react';
import { workerApi } from '../../api';

interface StoreCard {
  id: string;
  store_name: string;
  platform: string;
  domain: string;
  is_active: boolean;
  merchant: { name: string; company_name: string; status?: string };
  pending_orders: number;
  confirmed_today: number;
  total_today: number;
}

const platformColor: Record<string, string> = {
  shopify: 'bg-green-500/20 text-green-400 border-green-500/30',
  woocommerce: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  manual: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
};

const platformIcon: Record<string, string> = {
  shopify: '🛒',
  woocommerce: '🔌',
  manual: '✏️',
};

export default function WorkerStores() {
  const navigate = useNavigate();
  const [stores, setStores] = useState<StoreCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchStores = async () => {
    setLoading(true);
    try {
      const res = await workerApi.getStores();
      setStores(res.data?.data?.stores || []);
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStores(); }, []);

  const filtered = stores.filter(s =>
    s.store_name?.toLowerCase().includes(search.toLowerCase()) ||
    s.merchant?.company_name?.toLowerCase().includes(search.toLowerCase()) ||
    s.domain?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0a0a0f] p-6">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Store className="w-6 h-6 text-indigo-400" />
            Merchant Stores
          </h1>
          <p className="text-slate-400 mt-1 text-sm">
            {stores.length} active store{stores.length !== 1 ? 's' : ''} — sorted by most urgent
          </p>
        </div>
        <button
          onClick={fetchStores}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-all"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-6 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search stores…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500/50"
        />
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-52 rounded-2xl bg-white/5 animate-pulse border border-white/5" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-slate-500">
          <Store className="w-12 h-12 mb-3 opacity-30" />
          <p className="text-lg font-medium">No stores found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((store, i) => (
            <motion.div
              key={store.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="relative rounded-2xl border border-white/10 bg-gradient-to-br from-white/5 to-transparent backdrop-blur-sm overflow-hidden group hover:border-indigo-500/40 transition-all duration-300"
            >
              {/* Urgent glow */}
              {store.pending_orders > 0 && (
                <div className="absolute inset-0 rounded-2xl ring-1 ring-red-500/20 pointer-events-none" />
              )}

              <div className="p-5">
                {/* Top row */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-base">
                      {platformIcon[store.platform?.toLowerCase()] || '🏪'}
                    </div>
                    <div>
                      <p className="font-semibold text-white text-sm leading-tight">{store.store_name}</p>
                      <p className="text-slate-500 text-xs">{store.merchant?.company_name || store.merchant?.name}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${platformColor[store.platform?.toLowerCase()] || 'bg-white/10 text-slate-400 border-white/10'}`}>
                    {store.platform || 'manual'}
                  </span>
                </div>

                {/* Domain */}
                {store.domain && (
                  <p className="text-xs text-slate-500 mb-4 truncate flex items-center gap-1">
                    <ExternalLink className="w-3 h-3 shrink-0" />
                    {store.domain}
                  </p>
                )}

                {/* Stats row */}
                <div className="flex gap-3 mb-4">
                  <div className="flex-1 rounded-xl bg-red-500/10 border border-red-500/20 p-2.5 text-center">
                    <p className={`text-xl font-bold ${store.pending_orders > 0 ? 'text-red-400' : 'text-slate-500'}`}>
                      {store.pending_orders}
                    </p>
                    <p className="text-[10px] text-slate-500 font-medium mt-0.5">Pending</p>
                  </div>
                  <div className="flex-1 rounded-xl bg-green-500/10 border border-green-500/20 p-2.5 text-center">
                    <p className="text-xl font-bold text-green-400">{store.confirmed_today}</p>
                    <p className="text-[10px] text-slate-500 font-medium mt-0.5">Done today</p>
                  </div>
                  <div className="flex-1 rounded-xl bg-white/5 border border-white/10 p-2.5 text-center">
                    <p className="text-xl font-bold text-slate-300">{store.total_today}</p>
                    <p className="text-[10px] text-slate-500 font-medium mt-0.5">Total</p>
                  </div>
                </div>

                {/* Status badge + CTA */}
                <div className="flex items-center gap-2">
                  {store.pending_orders > 0 ? (
                    <span className="flex items-center gap-1 text-xs text-amber-400">
                      <AlertCircle className="w-3 h-3" />
                      {store.pending_orders} need attention
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-xs text-green-400">
                      <CheckCircle className="w-3 h-3" />
                      All clear
                    </span>
                  )}
                  <button
                    onClick={() => navigate(`/worker/orders?store_id=${store.id}`)}
                    className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition-colors"
                  >
                    <Package className="w-3.5 h-3.5" />
                    View Orders
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

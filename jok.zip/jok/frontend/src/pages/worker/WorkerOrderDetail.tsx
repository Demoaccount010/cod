import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, Phone, User, MapPin, Package, CheckCircle,
  XCircle, PhoneOff, PhoneMissed, Calendar, Clock, RefreshCw,
  ShoppingBag, CreditCard, Truck, Circle,
} from 'lucide-react';
import { workerApi } from '../../api';
import { toast } from 'sonner';

interface OrderData {
  id: string;
  order_number: string;
  store_order_id: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  customer_address: string;
  order_amount: number;
  currency: string;
  order_type: string;
  payment_method: string;
  payment_status: string;
  fulfillment_status: string;
  verification_status: string;
  tracking_number: string;
  tracking_url: string;
  tracking_company: string;
  delivery_status: string;
  products_json: any[];
  notes: string;
  created_at: string;
}

interface Verification {
  id: string;
  call_status: string;
  call_notes: string;
  call_duration_seconds: number;
  created_at: string;
  worker_id: string;
}

const statusBadge: Record<string, { bg: string; text: string; icon: React.ReactNode }> = {
  pending:     { bg: 'bg-amber-500/20 border-amber-500/30', text: 'text-amber-400', icon: <Clock className="w-3.5 h-3.5" /> },
  confirmed:   { bg: 'bg-green-500/20 border-green-500/30', text: 'text-green-400', icon: <CheckCircle className="w-3.5 h-3.5" /> },
  cancelled:   { bg: 'bg-red-500/20 border-red-500/30', text: 'text-red-400', icon: <XCircle className="w-3.5 h-3.5" /> },
  no_response: { bg: 'bg-gray-500/20 border-gray-500/30', text: 'text-gray-400', icon: <PhoneMissed className="w-3.5 h-3.5" /> },
  sent:        { bg: 'bg-sky-500/20 border-sky-500/30', text: 'text-sky-400', icon: <Phone className="w-3.5 h-3.5" /> },
};

const callStatusLabel: Record<string, string> = {
  answered: 'Answered',
  not_picked: 'Not Picked',
  cancel: 'Cancelled',
  callback: 'Callback Scheduled',
  claimed: 'Claimed',
};

export default function WorkerOrderDetail() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<OrderData | null>(null);
  const [merchant, setMerchant] = useState<any>(null);
  const [verifications, setVerifications] = useState<Verification[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [notes, setNotes] = useState('');

  const fetchOrder = async () => {
    if (!orderId) return;
    setLoading(true);
    try {
      const res = await workerApi.getOrderTracking(orderId);
      const d = res.data?.data;
      setOrder(d?.order || null);
      setMerchant(d?.merchant || null);
      setVerifications((d?.verifications || []).filter((v: Verification) => v.call_status !== 'claimed'));
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'Failed to load order details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchOrder(); }, [orderId]);

  const handleAction = async (action: 'answered' | 'not_picked' | 'cancel' | 'callback') => {
    if (!orderId) return;
    if (action === 'cancel' && !window.confirm('Cancel this order? This cannot be undone.')) return;
    setSubmitting(true);
    try {
      await workerApi.verifyOrder(orderId, { call_status: action, call_notes: notes });
      toast.success(action === 'answered' ? 'Order confirmed!' : action === 'cancel' ? 'Order cancelled.' : `Marked as ${action}`);
      await fetchOrder();
      setNotes('');
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'Action failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const badge = order ? (statusBadge[order.verification_status] ?? statusBadge.pending) : statusBadge.pending;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex flex-col items-center justify-center text-slate-500">
        <Package className="w-12 h-12 mb-3 opacity-30" />
        <p className="text-lg font-medium">Order not found</p>
        <button onClick={() => navigate(-1)} className="mt-4 text-indigo-400 hover:text-indigo-300 text-sm">
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] p-4 sm:p-6">
      {/* Back */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Back to orders
      </button>

      <div className="max-w-3xl mx-auto space-y-4">
        {/* Header card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-5"
        >
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-widest mb-1">Order</p>
              <h1 className="text-2xl font-bold text-white">#{order.order_number || order.store_order_id}</h1>
              {merchant?.store_name && <p className="text-slate-400 text-sm mt-0.5">{merchant.store_name}</p>}
            </div>
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-sm font-medium ${badge.bg} ${badge.text}`}>
              {badge.icon}
              {order.verification_status.replace('_', ' ')}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-3">
            <div className="flex items-center gap-1.5 text-sm text-slate-400">
              <CreditCard className="w-4 h-4 text-slate-500" />
              {order.payment_method?.toUpperCase() || 'COD'} · <span className="text-white font-semibold ml-1">₹{order.order_amount}</span>
            </div>
            <div className="flex items-center gap-1.5 text-sm text-slate-400">
              <Calendar className="w-4 h-4 text-slate-500" />
              {new Date(order.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
            </div>
            {order.order_type && (
              <div className="flex items-center gap-1.5 text-sm text-slate-400">
                <ShoppingBag className="w-4 h-4 text-slate-500" />
                {order.order_type}
              </div>
            )}
          </div>
        </motion.div>

        {/* Customer & address */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="rounded-2xl border border-white/10 bg-white/5 p-5 space-y-3"
        >
          <h2 className="text-white font-semibold text-sm uppercase tracking-wide">Customer</h2>
          <div className="flex items-center gap-2 text-slate-300">
            <User className="w-4 h-4 text-slate-500 shrink-0" />
            {order.customer_name}
          </div>
          <a href={`tel:${order.customer_phone}`} className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors">
            <Phone className="w-4 h-4 shrink-0" />
            {order.customer_phone}
          </a>
          {order.customer_address && (
            <div className="flex items-start gap-2 text-slate-400 text-sm">
              <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
              {order.customer_address}
            </div>
          )}
        </motion.div>

        {/* Products */}
        {order.products_json && order.products_json.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="rounded-2xl border border-white/10 bg-white/5 p-5"
          >
            <h2 className="text-white font-semibold text-sm uppercase tracking-wide mb-3">Products</h2>
            <div className="space-y-2">
              {order.products_json.map((p: any, i: number) => (
                <div key={i} className="flex items-center justify-between gap-2 py-2 border-b border-white/5 last:border-0">
                  <div>
                    <p className="text-slate-200 text-sm">{p.title || p.name}</p>
                    {p.variant_title && <p className="text-slate-500 text-xs">{p.variant_title}</p>}
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-white text-sm font-medium">×{p.quantity}</p>
                    {p.price && <p className="text-slate-400 text-xs">₹{p.price}</p>}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Tracking */}
        {(order.tracking_number || order.delivery_status) && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="rounded-2xl border border-white/10 bg-white/5 p-5"
          >
            <h2 className="text-white font-semibold text-sm uppercase tracking-wide mb-3">Tracking</h2>
            <div className="flex flex-wrap gap-3 text-sm text-slate-400">
              {order.tracking_company && (
                <span className="flex items-center gap-1.5"><Truck className="w-4 h-4 text-slate-500" />{order.tracking_company}</span>
              )}
              {order.tracking_number && (
                <span className="font-mono text-slate-300">{order.tracking_number}</span>
              )}
              {order.delivery_status && (
                <span className="text-sky-400 capitalize">{order.delivery_status}</span>
              )}
            </div>
            {order.tracking_url && (
              <a href={order.tracking_url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-indigo-400 hover:text-indigo-300 text-sm transition-colors">
                Track shipment →
              </a>
            )}
          </motion.div>
        )}

        {/* Verification actions — only if pending/sent */}
        {['pending', 'sent', 'no_response'].includes(order.verification_status) && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.12 }}
            className="rounded-2xl border border-indigo-500/30 bg-indigo-500/5 p-5"
          >
            <h2 className="text-white font-semibold text-sm uppercase tracking-wide mb-3">Record Call</h2>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Notes (optional)…"
              rows={2}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder-slate-600 resize-none focus:outline-none focus:border-indigo-500/50 mb-3"
            />
            <div className="flex flex-wrap gap-2">
              <button
                disabled={submitting}
                onClick={() => handleAction('answered')}
                className="flex-1 min-w-[120px] flex items-center justify-center gap-2 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 disabled:opacity-50 text-white text-sm font-medium transition-colors"
              >
                <CheckCircle className="w-4 h-4" /> Answered
              </button>
              <button
                disabled={submitting}
                onClick={() => handleAction('not_picked')}
                className="flex-1 min-w-[120px] flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white text-sm font-medium transition-colors"
              >
                <PhoneOff className="w-4 h-4" /> Not Picked
              </button>
              <button
                disabled={submitting}
                onClick={() => handleAction('callback')}
                className="flex-1 min-w-[120px] flex items-center justify-center gap-2 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-sm font-medium transition-colors"
              >
                <Phone className="w-4 h-4" /> Schedule Callback
              </button>
              <button
                disabled={submitting}
                onClick={() => handleAction('cancel')}
                className="flex-1 min-w-[120px] flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-600/80 hover:bg-red-600 disabled:opacity-50 text-white text-sm font-medium transition-colors"
              >
                <XCircle className="w-4 h-4" /> Cancel Order
              </button>
            </div>
          </motion.div>
        )}

        {/* Verification history */}
        {verifications.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="rounded-2xl border border-white/10 bg-white/5 p-5"
          >
            <h2 className="text-white font-semibold text-sm uppercase tracking-wide mb-4">History</h2>
            <div className="relative pl-5">
              {/* Timeline line */}
              <div className="absolute left-1.5 top-2 bottom-2 w-px bg-white/10" />
              <div className="space-y-4">
                {verifications.map((v) => (
                  <div key={v.id} className="relative">
                    <Circle className="absolute -left-4 top-1 w-2.5 h-2.5 text-indigo-500 fill-indigo-500" />
                    <div className="bg-white/5 rounded-xl p-3">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-white text-sm font-medium capitalize">
                          {callStatusLabel[v.call_status] || v.call_status}
                        </span>
                        <span className="text-xs text-slate-500">
                          {new Date(v.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      {v.call_notes && <p className="text-slate-400 text-xs mt-1">{v.call_notes}</p>}
                      {v.call_duration_seconds > 0 && (
                        <p className="text-slate-500 text-xs mt-0.5">
                          <Clock className="inline w-3 h-3 mr-0.5" />
                          {Math.floor(v.call_duration_seconds / 60)}m {v.call_duration_seconds % 60}s
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { adminApi } from '../../api';
import {
    Headphones, Plus, Trash2, Clock, Phone, MessageSquare,
    Power, Coffee, X, Eye, EyeOff, CheckCircle2,
    ClipboardList, UserCheck, AlertCircle, ChevronDown, RefreshCw,
    BarChart3, Calendar
} from 'lucide-react';
import { toast } from 'sonner';

function formatDuration(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
}

function formatCurrency(amount: number, currency = 'INR') {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount);
}

export default function AdminStaff() {
    const [workers, setWorkers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
    const [creating, setCreating] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    // Order assignment state
    const [unassignedOrders, setUnassignedOrders] = useState<any[]>([]);
    const [assignments, setAssignments] = useState<any[]>([]);
    const [showAssignPanel, setShowAssignPanel] = useState(true);
    const [selectedWorker, setSelectedWorker] = useState<Record<string, string>>({});
    const [assigning, setAssigning] = useState<string | null>(null);
    const [loadingOrders, setLoadingOrders] = useState(false);
    // Worker profile modal
    const [profileWorker, setProfileWorker] = useState<any | null>(null);
    const [profileData, setProfileData] = useState<any | null>(null);
    const [profileLoading, setProfileLoading] = useState(false);

    const fetchWorkers = useCallback(() => {
        adminApi.getWorkers()
            .then(r => setWorkers(r.data?.data?.workers || []))
            .finally(() => setLoading(false));
    }, []);

    const fetchOrderData = useCallback(() => {
        setLoadingOrders(true);
        Promise.all([
            adminApi.getUnassignedOrders().catch(() => null),
            adminApi.getStaffAssignments().catch(() => null),
        ]).then(([uRes, aRes]) => {
            setUnassignedOrders(uRes?.data?.data?.orders || []);
            setAssignments(aRes?.data?.data?.assignments || []);
        }).finally(() => setLoadingOrders(false));
    }, []);

    useEffect(() => {
        fetchWorkers();
        fetchOrderData();
    }, [fetchWorkers, fetchOrderData]);

    // Poll every 15 seconds for live updates
    useEffect(() => {
        const interval = setInterval(() => {
            fetchWorkers();
            fetchOrderData();
        }, 15000);
        return () => clearInterval(interval);
    }, [fetchWorkers, fetchOrderData]);

    const handleCreate = async () => {
        if (!form.name || !form.email || !form.password) {
            toast.error('Name, email, and password are required');
            return;
        }
        setCreating(true);
        try {
            await adminApi.createWorker(form);
            toast.success('Worker account created');
            setShowCreate(false);
            setForm({ name: '', email: '', password: '', phone: '' });
            fetchWorkers();
        } catch (e: any) {
            toast.error(e.response?.data?.message || 'Failed to create worker');
        } finally {
            setCreating(false);
        }
    };

    const handleDelete = async (id: string, name: string) => {
        if (!confirm(`Remove worker "${name}"? This cannot be undone.`)) return;
        try {
            await adminApi.deleteWorker(id);
            toast.success('Worker removed');
            fetchWorkers();
        } catch {
            toast.error('Failed to remove worker');
        }
    };

    const handleViewProfile = async (worker: any) => {
        setProfileWorker(worker);
        setProfileData(null);
        setProfileLoading(true);
        try {
            const res = await adminApi.getWorkerDailyLogs(worker.id);
            setProfileData(res.data?.data);
        } catch {
            toast.error('Failed to load worker profile');
        } finally {
            setProfileLoading(false);
        }
    };

    const handleAssign = async (orderId: string) => {
        const workerId = selectedWorker[orderId];
        if (!workerId) { toast.error('Please select a worker'); return; }
        setAssigning(orderId);
        try {
            await adminApi.assignOrder({ order_id: orderId, worker_id: workerId });
            toast.success('Order assigned successfully');
            // Remove from unassigned list immediately
            setUnassignedOrders(prev => prev.filter(o => o.id !== orderId));
            setSelectedWorker(prev => { const n = { ...prev }; delete n[orderId]; return n; });
            fetchOrderData();
        } catch (e: any) {
            toast.error(e.response?.data?.message || 'Failed to assign order');
        } finally {
            setAssigning(null);
        }
    };

    const onDutyWorkers = workers.filter(w => w.duty_status === 'on_duty');
    const assignmentsByWorker: Record<string, number> = {};
    assignments.forEach(a => {
        assignmentsByWorker[a.worker_id] = (assignmentsByWorker[a.worker_id] || 0) + 1;
    });

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Loading Staff...</p>
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet><title>Staff Management — Admin</title></Helmet>

            {/* Worker Profile Modal */}
            <AnimatePresence>
                {profileWorker && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                            onClick={() => setProfileWorker(null)}
                        />
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
                            <motion.div
                                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 30, scale: 0.95 }}
                                className="bg-white rounded-[28px] shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col pointer-events-auto"
                            >
                                {/* Modal Header */}
                                <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white text-lg font-bold shadow-lg ${
                                            profileWorker.duty_status === 'on_duty' ? 'bg-emerald-600' : profileWorker.duty_status === 'break' ? 'bg-amber-500' : 'bg-gray-400'
                                        }`}>
                                            {profileWorker.name?.[0]?.toUpperCase() || 'W'}
                                        </div>
                                        <div>
                                            <p className="text-lg font-bold text-gray-900 font-['Outfit']">{profileWorker.name}</p>
                                            <p className="text-xs text-gray-400">{profileWorker.email}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => setProfileWorker(null)} className="p-2 hover:bg-gray-200 rounded-xl transition-colors">
                                        <X className="w-5 h-5 text-gray-400" />
                                    </button>
                                </div>

                                {/* Modal Body */}
                                <div className="overflow-y-auto flex-1 p-6">
                                    {profileLoading ? (
                                        <div className="flex items-center justify-center py-12">
                                            <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                                        </div>
                                    ) : profileData ? (
                                        <>
                                            {/* Totals Summary */}
                                            <div className="grid grid-cols-3 gap-4 mb-6">
                                                <div className="text-center p-4 bg-indigo-50 rounded-2xl">
                                                    <p className="text-2xl font-black text-indigo-700 font-['Outfit']">{profileData.totals?.total_calls || 0}</p>
                                                    <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center justify-center gap-1 mt-1">
                                                        <Phone className="w-3 h-3" /> Total Calls
                                                    </p>
                                                </div>
                                                <div className="text-center p-4 bg-purple-50 rounded-2xl">
                                                    <p className="text-2xl font-black text-purple-700 font-['Outfit']">{profileData.totals?.total_chats || 0}</p>
                                                    <p className="text-[10px] font-bold text-purple-400 uppercase tracking-widest flex items-center justify-center gap-1 mt-1">
                                                        <MessageSquare className="w-3 h-3" /> Total Chats
                                                    </p>
                                                </div>
                                                <div className="text-center p-4 bg-emerald-50 rounded-2xl">
                                                    <p className="text-2xl font-black text-emerald-700 font-['Outfit']">{profileData.totals?.active_days || 0}</p>
                                                    <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest flex items-center justify-center gap-1 mt-1">
                                                        <Calendar className="w-3 h-3" /> Active Days
                                                    </p>
                                                </div>
                                            </div>

                                            {/* Per-Day Logs Table */}
                                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                                <BarChart3 className="w-4 h-4" /> Last 30 Days Activity
                                            </p>
                                            {profileData.daily_logs?.length > 0 ? (
                                                <div className="border border-gray-100 rounded-2xl overflow-hidden">
                                                    <table className="w-full text-sm">
                                                        <thead>
                                                            <tr className="bg-gray-50">
                                                                <th className="text-left px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-widest">Date</th>
                                                                <th className="text-center px-4 py-3 text-[10px] font-black text-indigo-400 uppercase tracking-widest">Calls</th>
                                                                <th className="text-center px-4 py-3 text-[10px] font-black text-purple-400 uppercase tracking-widest">Chats</th>
                                                                <th className="text-center px-4 py-3 text-[10px] font-black text-emerald-400 uppercase tracking-widest">Sessions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {profileData.daily_logs.map((day: any, i: number) => (
                                                                <tr key={day.date} className={`border-t border-gray-50 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}`}>
                                                                    <td className="px-4 py-3 font-semibold text-gray-700">
                                                                        {new Date(day.date).toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' })}
                                                                    </td>
                                                                    <td className="px-4 py-3 text-center">
                                                                        <span className={`font-bold ${day.calls > 0 ? 'text-indigo-700' : 'text-gray-300'}`}>{day.calls}</span>
                                                                    </td>
                                                                    <td className="px-4 py-3 text-center">
                                                                        <span className={`font-bold ${day.chats > 0 ? 'text-purple-700' : 'text-gray-300'}`}>{day.chats}</span>
                                                                    </td>
                                                                    <td className="px-4 py-3 text-center">
                                                                        <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
                                                                            day.sessions > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-400'
                                                                        }`}>{day.sessions > 0 ? `${day.sessions} session${day.sessions > 1 ? 's' : ''}` : '—'}</span>
                                                                    </td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            ) : (
                                                <div className="text-center py-10 text-gray-400">
                                                    <BarChart3 className="w-10 h-10 mx-auto mb-2 text-gray-200" />
                                                    <p className="text-sm font-medium">No activity in the last 30 days</p>
                                                </div>
                                            )}
                                        </>
                                    ) : null}
                                </div>
                            </motion.div>
                        </div>
                    </>
                )}
            </AnimatePresence>

            {/* Header */}
            <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20 text-white">
                        <Headphones className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Staff Management</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Manage workers, assignments, and duty tracking</p>
                    </div>
                </div>
                <button
                    onClick={() => setShowCreate(!showCreate)}
                    className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
                >
                    <Plus className="w-4 h-4" /> Add Worker
                </button>
            </div>

            {/* Stats Bar */}
            <div className="grid grid-cols-3 gap-4">
                <div className="glass-card rounded-2xl border border-white shadow-lg p-4 flex items-center gap-3">
                    <div className="p-2 bg-rose-100 rounded-xl">
                        <AlertCircle className="w-5 h-5 text-rose-600" />
                    </div>
                    <div>
                        <p className="text-2xl font-black text-gray-900 font-['Outfit']">{unassignedOrders.length}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Unassigned Orders</p>
                    </div>
                </div>
                <div className="glass-card rounded-2xl border border-white shadow-lg p-4 flex items-center gap-3">
                    <div className="p-2 bg-emerald-100 rounded-xl">
                        <UserCheck className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                        <p className="text-2xl font-black text-gray-900 font-['Outfit']">{onDutyWorkers.length}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Workers Online</p>
                    </div>
                </div>
                <div className="glass-card rounded-2xl border border-white shadow-lg p-4 flex items-center gap-3">
                    <div className="p-2 bg-indigo-100 rounded-xl">
                        <ClipboardList className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                        <p className="text-2xl font-black text-gray-900 font-['Outfit']">{assignments.length}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Active Assignments</p>
                    </div>
                </div>
            </div>

            {/* Create Worker Form */}
            <AnimatePresence>
                {showCreate && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="glass-card rounded-[28px] border border-white shadow-xl overflow-hidden"
                    >
                        <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex items-center justify-between">
                            <p className="text-sm font-bold text-gray-900 font-['Outfit']">Create Worker Account</p>
                            <button onClick={() => setShowCreate(false)} className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors">
                                <X className="w-4 h-4 text-gray-400" />
                            </button>
                        </div>
                        <div className="p-6 grid sm:grid-cols-2 gap-4">
                            <input
                                value={form.name}
                                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                                placeholder="Full Name *"
                                className="px-4 py-3 border border-gray-200 rounded-xl text-sm focus:ring-4 focus:ring-indigo-500/5 outline-none"
                            />
                            <input
                                value={form.email}
                                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                                placeholder="Email Address *"
                                type="email"
                                className="px-4 py-3 border border-gray-200 rounded-xl text-sm focus:ring-4 focus:ring-indigo-500/5 outline-none"
                            />
                            <div className="relative">
                                <input
                                    value={form.password}
                                    onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                                    placeholder="Password *"
                                    type={showPassword ? 'text' : 'password'}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:ring-4 focus:ring-indigo-500/5 outline-none pr-12"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                </button>
                            </div>
                            <input
                                value={form.phone}
                                onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                                placeholder="Phone (optional)"
                                className="px-4 py-3 border border-gray-200 rounded-xl text-sm focus:ring-4 focus:ring-indigo-500/5 outline-none"
                            />
                        </div>
                        <div className="px-6 pb-6 flex justify-end">
                            <button
                                onClick={handleCreate}
                                disabled={creating}
                                className="px-8 py-3 bg-emerald-600 text-white rounded-xl text-sm font-bold shadow-md hover:bg-emerald-700 transition-all flex items-center gap-2 disabled:opacity-50"
                            >
                                <CheckCircle2 className="w-4 h-4" /> {creating ? 'Creating...' : 'Create Worker'}
                            </button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* ── Order Assignment Panel ── */}
            <div className="glass-card rounded-[28px] border border-white shadow-xl overflow-hidden">
                {/* Panel Header */}
                <button
                    onClick={() => setShowAssignPanel(!showAssignPanel)}
                    className="w-full p-5 border-b border-gray-100 bg-gray-50/50 flex items-center justify-between hover:bg-gray-100/50 transition-colors"
                >
                    <div className="flex items-center gap-3">
                        <ClipboardList className="w-5 h-5 text-indigo-600" />
                        <span className="text-sm font-bold text-gray-900 font-['Outfit']">Order Assignment</span>
                        {unassignedOrders.length > 0 && (
                            <span className="px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full text-[11px] font-black">
                                {unassignedOrders.length} unassigned
                            </span>
                        )}
                    </div>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={e => { e.stopPropagation(); fetchOrderData(); }}
                            className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors text-gray-400"
                            title="Refresh"
                        >
                            <RefreshCw className={`w-3.5 h-3.5 ${loadingOrders ? 'animate-spin' : ''}`} />
                        </button>
                        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${showAssignPanel ? 'rotate-180' : ''}`} />
                    </div>
                </button>

                <AnimatePresence>
                    {showAssignPanel && (
                        <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                        >
                            {/* Unassigned Orders Table */}
                            <div className="p-5">
                                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Unassigned COD Orders</p>
                                {unassignedOrders.length === 0 ? (
                                    <div className="text-center py-8 text-gray-400">
                                        <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-emerald-300" />
                                        <p className="text-sm font-medium">All orders are assigned</p>
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        {unassignedOrders.map(order => (
                                            <div key={order.id} className="flex flex-col sm:flex-row sm:items-center gap-3 p-4 bg-rose-50/60 border border-rose-100 rounded-2xl">
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-2 flex-wrap">
                                                        <span className="text-sm font-bold text-gray-900 font-['Outfit']">#{order.order_number}</span>
                                                        <span className="text-xs text-gray-500">{order.customer_name}</span>
                                                        {order.order_amount && (
                                                            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                                                                {formatCurrency(order.order_amount, order.currency)}
                                                            </span>
                                                        )}
                                                    </div>
                                                    <p className="text-[10px] text-gray-400 mt-0.5">
                                                        {order.created_at ? new Date(order.created_at).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' }) : ''}
                                                    </p>
                                                </div>
                                                <div className="flex items-center gap-2 shrink-0">
                                                    <select
                                                        value={selectedWorker[order.id] || ''}
                                                        onChange={e => setSelectedWorker(prev => ({ ...prev, [order.id]: e.target.value }))}
                                                        className="px-3 py-2 border border-gray-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500/20 outline-none bg-white"
                                                    >
                                                        <option value="">Select worker…</option>
                                                        {onDutyWorkers.map(w => (
                                                            <option key={w.id} value={w.id}>{w.name}</option>
                                                        ))}
                                                        {onDutyWorkers.length === 0 && (
                                                            <option disabled>No workers online</option>
                                                        )}
                                                    </select>
                                                    <button
                                                        onClick={() => handleAssign(order.id)}
                                                        disabled={assigning === order.id || !selectedWorker[order.id]}
                                                        className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all disabled:opacity-40 flex items-center gap-1.5"
                                                    >
                                                        {assigning === order.id ? (
                                                            <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                                        ) : (
                                                            <UserCheck className="w-3.5 h-3.5" />
                                                        )}
                                                        Assign
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Current Assignments */}
                            {assignments.length > 0 && (
                                <div className="px-5 pb-5 border-t border-gray-100 pt-4">
                                    <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Current Assignments</p>
                                    <div className="space-y-2">
                                        {assignments.map((a, i) => (
                                            <div key={i} className="flex items-center justify-between p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                                                <div className="flex items-center gap-3">
                                                    <span className="text-xs font-bold text-gray-700">#{a.order_number}</span>
                                                    <span className="text-xs text-gray-500">{a.customer_name}</span>
                                                    {a.order_amount && (
                                                        <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full font-semibold">
                                                            {formatCurrency(a.order_amount, a.currency)}
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <div className={`w-2 h-2 rounded-full ${a.worker_duty_status === 'on_duty' ? 'bg-emerald-500' : 'bg-gray-300'}`} />
                                                    <span className="text-xs font-semibold text-indigo-700">{a.worker_name}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            {/* Workers List */}
            <div className="space-y-4">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest px-1">All Workers ({workers.length})</p>
                {workers.map((w, i) => {
                    const isOnDuty = w.duty_status === 'on_duty';
                    const isBreak = w.duty_status === 'break';
                    const totalSeconds = (w.total_duty_seconds || 0) + (w.current_session_seconds || 0);
                    const workerAssignments = assignmentsByWorker[w.id] || 0;

                    return (
                        <motion.div
                            key={w.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.05 }}
                            className="glass-card rounded-[28px] border border-white shadow-xl shadow-gray-900/5 p-6"
                        >
                            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                                {/* Worker Info */}
                                <div className="flex items-center gap-4">
                                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-bold shadow-lg ${isOnDuty ? 'bg-emerald-600 shadow-emerald-500/20' : isBreak ? 'bg-amber-500 shadow-amber-500/20' : 'bg-gray-300'}`}>
                                        {w.name?.[0]?.toUpperCase() || 'W'}
                                    </div>
                                    <div>
                                        <p className="text-lg font-bold text-gray-900 font-['Outfit']">{w.name}</p>
                                        <p className="text-xs text-gray-400 font-medium">{w.email}</p>
                                        {w.phone && <p className="text-[10px] text-gray-300">{w.phone}</p>}
                                    </div>
                                </div>

                                {/* Status Badge */}
                                <div className="flex items-center gap-2">
                                    <div className={`px-4 py-2 rounded-2xl flex items-center gap-2 ${isOnDuty ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : isBreak ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-gray-100 text-gray-500 border border-gray-200'}`}>
                                        {isBreak ? <Coffee className="w-3.5 h-3.5" /> : <Power className="w-3.5 h-3.5" />}
                                        <span className="text-[10px] font-black uppercase tracking-widest">
                                            {isOnDuty ? 'On Duty' : isBreak ? 'On Break' : 'Off Duty'}
                                        </span>
                                        {isOnDuty && <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
                                    </div>
                                </div>

                                {/* Stats */}
                                <div className="flex items-center gap-6">
                                    <div className="text-center">
                                        <p className="text-xl font-black text-gray-900 font-['Outfit']">{w.today_verifications || 0}</p>
                                        <div className="flex items-center gap-1 text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                                            <Phone className="w-3 h-3" /> Calls
                                        </div>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-xl font-black text-gray-900 font-['Outfit']">{w.active_chats || 0}</p>
                                        <div className="flex items-center gap-1 text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                                            <MessageSquare className="w-3 h-3" /> Chats
                                        </div>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-xl font-black text-gray-900 font-['Outfit']">{formatDuration(totalSeconds)}</p>
                                        <div className="flex items-center gap-1 text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                                            <Clock className="w-3 h-3" /> Time
                                        </div>
                                    </div>
                                    {workerAssignments > 0 && (
                                        <div className="text-center">
                                            <p className="text-xl font-black text-indigo-600 font-['Outfit']">{workerAssignments}</p>
                                            <div className="flex items-center gap-1 text-[9px] font-bold text-indigo-400 uppercase tracking-widest">
                                                <ClipboardList className="w-3 h-3" /> Assigned
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Actions */}
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={() => handleViewProfile(w)}
                                        className="p-2.5 text-gray-300 hover:text-indigo-500 hover:bg-indigo-50 rounded-xl transition-all"
                                        title="View Profile"
                                    >
                                        <BarChart3 className="w-5 h-5" />
                                    </button>
                                    <button
                                        onClick={() => handleDelete(w.id, w.name)}
                                        className="p-2.5 text-gray-300 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                                        title="Remove Worker"
                                    >
                                        <Trash2 className="w-5 h-5" />
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    );
                })}

                {workers.length === 0 && (
                    <div className="text-center py-20">
                        <Headphones className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                        <p className="text-lg font-bold text-gray-600 font-['Outfit']">No Staff Members</p>
                        <p className="text-xs text-gray-400 mt-1">Click "Add Worker" to create your first staff account</p>
                    </div>
                )}
            </div>
        </div>
    );
}

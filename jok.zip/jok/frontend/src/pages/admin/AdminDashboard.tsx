import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { adminApi } from '../../api';
import { formatCurrency } from '../../lib/utils';
import { Users, Wallet, AlertTriangle, Activity, Zap, TrendingUp, ShieldCheck, ArrowUpRight, Globe, UserPlus, Store, ExternalLink } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function AdminDashboard() {
    const [stats, setStats] = useState<any>(null);
    const [billingStats, setBillingStats] = useState<any>(null);
    const [chart, setChart] = useState<any[]>([]);
    const [newRequests, setNewRequests] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        Promise.all([adminApi.getDashboardStats(), adminApi.getChartData('30d'), adminApi.getBillingOverview(), adminApi.getNewRequests()])
            .then(([s, c, b, r]) => {
                setStats(s.data?.data);
                setChart(c.data?.data || []);
                setBillingStats(b.data?.data);
                setNewRequests(r.data?.data?.pending_requests || []);
            })
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Retrieving Global Telemetry...</p>
        </div>
    );

    const m = stats?.merchants || {};
    const o = stats?.orders || {};
    const b = billingStats || {};

    const cards = [
        { label: 'Network Merchants', value: m.total || 0, icon: Users, color: 'bg-indigo-600', sub: `${m.active || 0} ACTIVE NODES`, trend: '+12%' },
        { label: 'Operational Cycles', value: b.today_orders || o.today || 0, icon: Activity, color: 'bg-blue-600', sub: `${o.total || 0} CUMULATIVE`, trend: '+8%' },
        { label: 'System Revenue', value: formatCurrency(b.total_revenue || 0), icon: Wallet, color: 'bg-emerald-600', sub: `₹${(b.today_revenue || 0).toFixed(0)} INTERNAL SYNC`, trend: '+24%' },
        { label: 'Standard Protocol', value: `₹${b.per_order_rate || 0}`, icon: Zap, color: 'bg-purple-600', sub: `${b.low_balance_merchants || 0} CRITICAL BALANCES`, trend: 'STABLE' },
    ];

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet><title>Command Center - CODVerify Intelligence</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-gray-900 rounded-xl shadow-lg shadow-gray-900/10">
                            <Globe className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Intelligence Command</h1>
                            <p className="text-gray-500 text-sm font-medium italic">Global network status and revenue architecture monitoring</p>
                        </div>
                    </div>
                </motion.div>

                <div className="flex items-center gap-3">
                    <div className="px-5 py-2.5 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Master Node: Operational</span>
                    </div>
                </div>
            </div>

            {/* Global Wallet Matrix */}
            {b.total_wallet_balance !== undefined && (
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="relative overflow-hidden premium-gradient rounded-[40px] p-10 text-white shadow-2xl shadow-indigo-500/10"
                >
                    <div className="absolute top-0 right-0 p-12 opacity-10">
                        <TrendingUp className="w-48 h-48" />
                    </div>

                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
                        <div>
                            <p className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.4em] mb-4">Cumulative Network Liquidity</p>
                            <div className="flex items-baseline gap-4">
                                <h2 className="text-5xl lg:text-7xl font-black font-['Outfit'] tracking-tighter italic">{formatCurrency(b.total_wallet_balance)}</h2>
                                <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-lg text-[10px] font-bold text-emerald-300 border border-white/10 flex items-center gap-1">
                                    <ArrowUpRight className="w-3 h-3" /> 14.2% Growth
                                </span>
                            </div>
                        </div>

                        {(b.low_balance_merchants || 0) > 0 && (
                            <motion.div
                                animate={{ scale: [1, 1.02, 1] }}
                                transition={{ duration: 2, repeat: Infinity }}
                                className="flex items-center gap-4 px-8 py-5 bg-white/10 backdrop-blur-xl border border-white/20 rounded-[32px] shadow-2xl"
                            >
                                <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-400 border border-amber-500/30">
                                    <AlertTriangle className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="text-sm font-bold font-['Outfit'] tracking-tight text-white">{b.low_balance_merchants} Merchants Flagged</p>
                                    <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest">Critical Balance Protocol Active</p>
                                </div>
                            </motion.div>
                        )}
                    </div>
                </motion.div>
            )}

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">

                {/* ═══ NEW SERVICE REQUESTS ══════════════════════════════════ */}
                {newRequests.length > 0 && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.15 }}
                        className="col-span-full glass-card rounded-[32px] p-8 border border-orange-100 shadow-xl shadow-orange-500/5 mb-2"
                    >
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                                    <UserPlus className="w-6 h-6 text-white" />
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-gray-900 font-['Outfit'] tracking-tight">New Service Requests</h3>
                                    <p className="text-[10px] font-bold text-orange-600 uppercase tracking-widest">{newRequests.length} pending — requires action</p>
                                </div>
                            </div>
                            <a href="/admin/contracts" className="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-orange-500/20 hover:bg-orange-700 transition-all flex items-center gap-1.5">
                                <ExternalLink className="w-3.5 h-3.5" /> Manage
                            </a>
                        </div>
                        <div className="space-y-3">
                            {newRequests.slice(0, 5).map((r: any) => (
                                <div key={r.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-white rounded-2xl border border-gray-100 hover:border-orange-100 transition-all group">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-md ${r.source === 'shopify' ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-indigo-500 to-purple-600'
                                            }`}>
                                            {r.source === 'shopify' ? <Store className="w-5 h-5" /> : <Globe className="w-5 h-5" />}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900">{r.name}</p>
                                            <p className="text-xs text-gray-500">{r.email} {r.company_name ? `• ${r.company_name}` : ''}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <span className={`px-2.5 py-1 rounded-lg text-[9px] font-bold uppercase tracking-widest ${r.source === 'shopify'
                                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                                : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                            }`}>
                                            {r.source === 'shopify' ? 'Shopify App' : 'Website'}
                                        </span>
                                        <span className="text-[10px] text-gray-400 font-semibold">
                                            {new Date(r.created_at).toLocaleDateString()}
                                        </span>
                                    </div>
                                </div>
                            ))}
                            {newRequests.length > 5 && (
                                <p className="text-center text-xs text-gray-400 font-bold pt-2">+{newRequests.length - 5} more requests — <a href="/admin/contracts" className="text-orange-600 underline">view all</a></p>
                            )}
                        </div>
                    </motion.div>
                )}
                {cards.map((c, i) => (
                    <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 + (i * 0.05) }}
                        className="glass-card rounded-[32px] p-6 border border-white shadow-xl shadow-gray-900/5 hover:-translate-y-1 transition-all duration-500 group"
                    >
                        <div className={`w-14 h-14 ${c.color} rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-indigo-500/10 transition-transform group-hover:scale-110`}>
                            <c.icon className="w-7 h-7 text-white" />
                        </div>
                        <div className="flex justify-between items-start mb-1">
                            <p className="text-3xl font-black text-gray-900 font-['Outfit'] tracking-tighter">{c.value}</p>
                            <span className="text-[10px] font-black text-emerald-500">{c.trend}</span>
                        </div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">{c.label}</p>
                        <p className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg inline-block">{c.sub}</p>
                    </motion.div>
                ))}
            </div>

            {/* Performance Analytics */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="glass-card rounded-[40px] border border-white p-8 lg:p-12 shadow-2xl shadow-gray-900/5 bg-white/50 backdrop-blur-md"
            >
                <div className="flex items-center justify-between mb-12">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-900 border border-gray-100">
                            <BarChart className="w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tighter uppercase italic">Network Verification Cycles</h3>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">30-Day Cumulative Synchronization Performance</p>
                        </div>
                    </div>
                </div>

                {chart.length > 0 ? (
                    <div className="h-[350px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chart} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                                <defs>
                                    <linearGradient id="confirmedGradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#4F46E5" stopOpacity={1} />
                                        <stop offset="100%" stopColor="#818CF8" stopOpacity={1} />
                                    </linearGradient>
                                    <linearGradient id="cancelledGradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.8} />
                                        <stop offset="100%" stopColor="#FB7185" stopOpacity={0.8} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                                <XAxis
                                    dataKey="date"
                                    axisLine={false}
                                    tickLine={false}
                                    tick={{ fontSize: 10, fontWeight: 700, fill: '#94A3B8' }}
                                    tickFormatter={(v: string) => v.slice(5).replace('-', '/')}
                                    dy={10}
                                />
                                <YAxis
                                    axisLine={false}
                                    tickLine={false}
                                    tick={{ fontSize: 10, fontWeight: 700, fill: '#94A3B8' }}
                                />
                                <Tooltip
                                    contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.15)', padding: '16px' }}
                                    cursor={{ fill: '#F1F5F9' }}
                                />
                                <Bar dataKey="confirmed" fill="url(#confirmedGradient)" radius={[8, 8, 0, 0]} barSize={20} />
                                <Bar dataKey="cancelled" fill="url(#cancelledGradient)" radius={[8, 8, 0, 0]} barSize={20} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                ) : (
                    <div className="h-64 flex flex-col items-center justify-center text-gray-300 gap-4">
                        <Activity className="w-12 h-12 opacity-20" />
                        <p className="text-sm font-bold uppercase tracking-widest italic">Zero Telemetry Data in Current Period</p>
                    </div>
                )}
            </motion.div>

            {/* Infrastructure Health Tip */}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="py-10 flex items-center justify-center gap-8"
            >
                <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-500" />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">E2E Integrity Verified</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-200" />
                <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-indigo-500" />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Load Balancing Active</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-200" />
                <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Sub-250ms Response Time</span>
                </div>
            </motion.div>
        </div>
    );
}

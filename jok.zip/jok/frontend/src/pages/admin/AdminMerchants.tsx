import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { adminApi } from '../../api';
import { Users, Search, Filter, Mail, Phone, Calendar, AlertTriangle, ShieldCheck, ShieldAlert, Trash2 } from 'lucide-react';
import { formatCurrency } from '../../lib/utils';
import { toast } from 'sonner';

export default function AdminMerchants() {
    const [merchants, setMerchants] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [error, setError] = useState('');
    const [deleting, setDeleting] = useState<string | null>(null);

    const fetchMerchants = () => {
        adminApi.getMerchants('')
            .then(r => setMerchants(r.data?.data?.merchants || r.data?.data || []))
            .catch(() => setError('Failed to load merchants'))
            .finally(() => setLoading(false));
    };

    useEffect(() => { fetchMerchants(); }, []);

    const handleDelete = async (id: string, name: string) => {
        if (!confirm(`Permanently delete "${name}"?\n\nThis will delete ALL their data: orders, stores, billing, settings, API keys, etc. This CANNOT be undone.`)) return;
        setDeleting(id);
        try {
            await adminApi.deleteMerchant(id);
            toast.success('Merchant and all data permanently deleted');
            setMerchants(prev => prev.filter(m => m.id !== id));
        } catch (e: any) {
            toast.error(e.response?.data?.detail || 'Failed to delete merchant');
        } finally {
            setDeleting(null);
        }
    };

    const filtered = merchants.filter(m =>
        m.name?.toLowerCase().includes(search.toLowerCase()) ||
        m.email?.toLowerCase().includes(search.toLowerCase()) ||
        m.company_name?.toLowerCase().includes(search.toLowerCase())
    );

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Accessing Merchant Registry...</p>
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet><title>Merchant Management | Admin Command</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20 text-white">
                            <Users className="w-5 h-5" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Merchant Registry</h1>
                            <p className="text-gray-500 text-sm font-medium italic">Monitor individual node health, liquidity, and operational status</p>
                        </div>
                    </div>
                </motion.div>

                <div className="flex items-center gap-3">
                    <div className="px-4 py-2 bg-white border border-gray-100 rounded-2xl shadow-sm flex items-center gap-2">
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Nodes:</span>
                        <span className="text-sm font-bold text-gray-900">{merchants.length}</span>
                    </div>
                </div>
            </div>

            {/* Global Search & Filters */}
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid lg:grid-cols-4 gap-4"
            >
                <div className="lg:col-span-3 relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-400 group-focus-within:text-indigo-600 transition-colors" />
                    <input
                        placeholder="Filter registry by name, identity, or endpoint..."
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white border border-gray-100 rounded-[24px] text-sm font-bold focus:ring-4 focus:ring-indigo-500/5 outline-none shadow-sm transition-all"
                    />
                </div>
                <button className="lg:col-span-1 px-8 py-4 bg-gray-50 text-gray-400 rounded-[24px] border border-gray-100 text-xs font-black uppercase tracking-widest hover:bg-white hover:text-indigo-600 hover:border-indigo-100 transition-all flex items-center justify-center gap-2">
                    <Filter className="w-4 h-4" /> Refine Parameters
                </button>
            </motion.div>

            {/* Registry Records */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white/50 backdrop-blur-md"
            >
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-separate border-spacing-0">
                        <thead>
                            <tr className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                                <th className="px-10 py-6 border-b border-gray-100">Identity Profile</th>
                                <th className="px-10 py-6 border-b border-gray-100">Contact Endpoints</th>
                                <th className="px-10 py-6 border-b border-gray-100 text-center">Liquidity</th>
                                <th className="px-10 py-6 border-b border-gray-100">Verification Status</th>
                                <th className="px-10 py-6 border-b border-gray-100 text-right">Operational Link</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            <AnimatePresence>
                                {filtered.map((m, i) => (
                                    <motion.tr
                                        key={m.id || i}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, scale: 0.95 }}
                                        transition={{ delay: i * 0.05 }}
                                        className="hover:bg-indigo-50/30 transition-all group"
                                    >
                                        <td className="px-10 py-6">
                                            <div className="flex items-center gap-5">
                                                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-700 flex items-center justify-center text-white text-lg font-black font-['Outfit'] shadow-lg group-hover:scale-110 transition-transform">
                                                    {m.company_name?.charAt(0) || m.name?.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="text-lg font-bold text-gray-900 font-['Outfit'] tracking-tight leading-none mb-1.5">{m.company_name || m.name}</p>
                                                    <p className="text-[10px] font-black text-gray-400 items-center flex gap-1.5 uppercase tracking-widest">
                                                        Admin: {m.name}
                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-10 py-6">
                                            <div className="space-y-1">
                                                <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                                                    <Mail className="w-3.5 h-3.5 text-indigo-400" />
                                                    {m.email}
                                                </div>
                                                <div className="flex items-center gap-2 text-[10px] font-black text-gray-300 uppercase italic">
                                                    <Phone className="w-3 h-3" />
                                                    {m.phone || 'NO LINK'}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-10 py-6 text-center">
                                            <div className="inline-flex flex-col items-center">
                                                <span className={`text-lg font-black font-['Outfit'] tracking-tighter ${m.wallet_balance < 500 ? 'text-rose-500 animate-pulse' : 'text-gray-900'}`}>
                                                    {formatCurrency(m.wallet_balance || 0)}
                                                </span>
                                                <div className="mt-1 flex items-center gap-1.5">
                                                    <div className={`w-1.5 h-1.5 rounded-full ${m.wallet_balance < 500 ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Active Reserve</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-10 py-6">
                                            <div className="flex justify-center">
                                                {m.status === 'active' ? (
                                                    <div className="px-4 py-1.5 bg-emerald-50 text-emerald-600 text-[9px] font-black uppercase tracking-widest rounded-xl border border-emerald-100 flex items-center gap-2">
                                                        <ShieldCheck className="w-3.5 h-3.5" /> High Integrity
                                                    </div>
                                                ) : (
                                                    <div className="px-4 py-1.5 bg-gray-50 text-gray-400 text-[9px] font-black uppercase tracking-widest rounded-xl border border-gray-100 flex items-center gap-2">
                                                        <ShieldAlert className="w-3.5 h-3.5" /> Standby Node
                                                    </div>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-10 py-6 text-right">
                                            <button
                                                onClick={() => handleDelete(m.id, m.company_name || m.name)}
                                                disabled={deleting === m.id}
                                                className="p-3 bg-gray-50 text-gray-300 rounded-2xl hover:bg-rose-50 hover:text-rose-500 hover:shadow-xl hover:shadow-rose-500/10 hover:border-rose-100 border border-transparent transition-all disabled:opacity-40"
                                                title="Delete merchant"
                                            >
                                                {deleting === m.id
                                                    ? <div className="w-5 h-5 border-2 border-rose-300 border-t-rose-600 rounded-full animate-spin" />
                                                    : <Trash2 className="w-5 h-5" />}
                                            </button>
                                        </td>
                                    </motion.tr>
                                ))}
                            </AnimatePresence>
                        </tbody>
                    </table>
                </div>

                {error && (
                    <div className="px-10 py-12 text-center">
                        <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto mb-3" />
                        <p className="text-sm font-bold text-gray-600">{error}</p>
                        <p className="text-xs text-gray-400 mt-1">Check backend connection and try again</p>
                    </div>
                )}

                {!error && filtered.length === 0 && (
                    <div className="px-10 py-16 text-center">
                        <Users className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-lg font-bold text-gray-600 font-['Outfit']">No Merchants Found</p>
                        <p className="text-xs text-gray-400 mt-1 max-w-md mx-auto">
                            {search ? 'No merchants match your search criteria. Try a different query.' : 'No merchants have registered yet. They will appear here once users sign up.'}
                        </p>
                    </div>
                )}

                <div className="px-10 py-8 border-t border-gray-100 bg-gray-50/30 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-gray-300" />
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Last registry sweep: Just now</p>
                    </div>
                </div>
            </motion.div>

            {/* Network Insight Footer */}
            <div className="py-10 text-center border-t border-gray-50 opacity-30 mt-10">
                <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.4em]">Integrated Intelligence Cluster Node v2.0</p>
            </div>
        </div>
    );
}

import { useState } from 'react';
import { Upload, Trash2, Copy, Download, Image as ImageIcon } from 'lucide-react';

type MediaFile = {
    id: string;
    name: string;
    url: string;
    size: string;
    uploadedAt: string;
    type: 'image' | 'video' | 'document';
};

const defaultMedia: MediaFile[] = [
    { id: '1', name: 'hero-background.jpg', url: '/images/hero.jpg', size: '2.4 MB', uploadedAt: '2 days ago', type: 'image' },
    { id: '2', name: 'feature-icon-1.svg', url: '/images/feature1.svg', size: '45 KB', uploadedAt: '1 week ago', type: 'image' },
    { id: '3', name: 'feature-icon-2.svg', url: '/images/feature2.svg', size: '52 KB', uploadedAt: '1 week ago', type: 'image' },
    { id: '4', name: 'demo-video.mp4', url: '/videos/demo.mp4', size: '15.3 MB', uploadedAt: '3 days ago', type: 'video' },
];

export default function MediaManager() {
    const [media, setMedia] = useState<MediaFile[]>(defaultMedia);
    const [dragActive, setDragActive] = useState(false);

    const deleteMedia = (id: string) => {
        setMedia(media.filter(m => m.id !== id));
    };

    const copyToClipboard = (url: string) => {
        navigator.clipboard.writeText(url);
    };

    const handleDrag = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            const newMedia: MediaFile = {
                id: String(Date.now()),
                name: file.name,
                url: URL.createObjectURL(file),
                size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
                uploadedAt: 'Just now',
                type: file.type.startsWith('image') ? 'image' : 'video'
            };
            setMedia([newMedia, ...media]);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-black text-gray-900">Media Library</h1>
                    <p className="text-gray-600">Manage your images, videos, and documents</p>
                </div>

                {/* Upload Area */}
                <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-12 text-center mb-8 transition-colors ${
                        dragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300 bg-white'
                    }`}
                >
                    <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Drag & drop your files</h3>
                    <p className="text-gray-600 mb-4">or</p>
                    <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700">
                        Browse Files
                    </button>
                    <p className="text-xs text-gray-500 mt-4">
                        Supported formats: JPG, PNG, GIF, MP4, PDF (Max 50 MB)
                    </p>
                </div>

                {/* Media Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {media.map((file) => (
                        <div key={file.id} className="bg-white rounded-lg border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow">
                            {/* Thumbnail */}
                            <div className="aspect-square bg-gray-100 flex items-center justify-center overflow-hidden">
                                {file.type === 'image' ? (
                                    <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-500">
                                        <ImageIcon className="w-8 h-8 text-white opacity-50" />
                                    </div>
                                )}
                            </div>

                            {/* Details */}
                            <div className="p-4">
                                <p className="font-bold text-gray-900 text-sm truncate mb-1">{file.name}</p>
                                <p className="text-xs text-gray-600 mb-3">{file.size}</p>
                                <p className="text-[10px] text-gray-500 mb-4">{file.uploadedAt}</p>

                                {/* Actions */}
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => copyToClipboard(file.url)}
                                        className="flex-1 p-2 bg-blue-50 text-blue-600 rounded hover:bg-blue-100 text-xs font-bold flex items-center justify-center gap-1"
                                        title="Copy URL"
                                    >
                                        <Copy className="w-3 h-3" />
                                    </button>
                                    <button
                                        className="flex-1 p-2 bg-gray-50 text-gray-600 rounded hover:bg-gray-100 text-xs font-bold flex items-center justify-center gap-1"
                                        title="Download"
                                    >
                                        <Download className="w-3 h-3" />
                                    </button>
                                    <button
                                        onClick={() => deleteMedia(file.id)}
                                        className="flex-1 p-2 bg-red-50 text-red-600 rounded hover:bg-red-100 text-xs font-bold flex items-center justify-center gap-1"
                                        title="Delete"
                                    >
                                        <Trash2 className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Storage Info */}
                <div className="mt-12 bg-white rounded-xl border border-gray-100 p-6">
                    <h3 className="font-bold text-gray-900 mb-4">Storage Usage</h3>
                    <div className="mb-4">
                        <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-600">Used</span>
                            <span className="text-gray-900 font-bold">245 MB / 1000 MB</span>
                        </div>
                        <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-600 rounded-full" style={{ width: '24.5%' }} />
                        </div>
                    </div>
                    <p className="text-xs text-gray-600">
                        You have 755 MB remaining. Upgrade your plan for unlimited storage.
                    </p>
                </div>
            </div>
        </div>
    );
}

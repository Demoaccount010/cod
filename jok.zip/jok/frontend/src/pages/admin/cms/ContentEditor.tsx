import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Save, X, Eye, Undo2, Copy } from 'lucide-react';

const sections = {
    hero: {
        name: 'Hero Section',
        fields: [
            { name: 'headline', label: 'Headline', type: 'textarea', value: 'Eliminate Financial Friction' },
            { name: 'subheading', label: 'Subheading', type: 'text', value: 'Reduce COD RTO by up to 42%...' },
            { name: 'backgroundColor', label: 'Background Color', type: 'color', value: '#ffffff' },
            { name: 'cta_text', label: 'CTA Button Text', type: 'text', value: 'Start Deployment' },
        ]
    },
    features: {
        name: 'Features Section',
        fields: [
            { name: 'title', label: 'Section Title', type: 'textarea', value: 'Built for Complex Operations' },
            { name: 'description', label: 'Section Description', type: 'textarea', value: 'Industry leading...' },
            { name: 'feature_1_title', label: 'Feature 1 Title', type: 'text', value: 'Neural Verification' },
            { name: 'feature_1_desc', label: 'Feature 1 Description', type: 'textarea', value: 'Advanced WhatsApp...' },
        ]
    },
    roi: {
        name: 'ROI/Economics Section',
        fields: [
            { name: 'title', label: 'Section Title', type: 'text', value: 'ROI Engineering' },
            { name: 'amount', label: 'Monthly Savings', type: 'text', value: '₹1,40,000' },
            { name: 'rto_reduction', label: 'RTO Reduction %', type: 'text', value: '40%' },
        ]
    },
    footer: {
        name: 'Footer',
        fields: [
            { name: 'company_name', label: 'Company Name', type: 'text', value: 'CODVerify' },
            { name: 'copyright_year', label: 'Copyright Year', type: 'text', value: '2026' },
            { name: 'footer_links', label: 'Footer Links', type: 'textarea', value: 'API, Documentation, Support...' },
        ]
    }
};

export default function ContentEditor() {
    const { section } = useParams();
    const navigate = useNavigate();
    const config = sections[section as keyof typeof sections];
    
    const [formData, setFormData] = useState(() => {
        const data: Record<string, string> = {};
        config?.fields.forEach(f => {
            data[f.name] = f.value;
        });
        return data;
    });
    
    const [saved, setSaved] = useState(false);
    const [showPreview, setShowPreview] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
        setSaved(false);
    };

    const handleSave = () => {
        console.log('Saving:', formData);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
    };

    if (!config) {
        return (
            <div className="p-8">
                <p className="text-red-600">Section not found</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <button 
                            onClick={() => navigate('/admin/cms')}
                            className="text-indigo-600 font-bold mb-2 hover:text-indigo-700"
                        >
                            ← Back to CMS
                        </button>
                        <h1 className="text-3xl font-black text-gray-900">{config.name}</h1>
                        <p className="text-gray-600 text-sm mt-1">Edit and manage {config.name.toLowerCase()}</p>
                    </div>
                    <button 
                        onClick={() => navigate('/admin/cms')}
                        className="p-2 hover:bg-gray-200 rounded-lg"
                    >
                        <X className="w-6 h-6 text-gray-600" />
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Editor */}
                    <div className="lg:col-span-2">
                        <div className="bg-white rounded-xl border border-gray-100 p-8">
                            <form className="space-y-6">
                                {config.fields.map((field) => (
                                    <div key={field.name}>
                                        <label className="block text-sm font-bold text-gray-900 mb-2">
                                            {field.label}
                                        </label>
                                        {field.type === 'textarea' ? (
                                            <textarea
                                                name={field.name}
                                                value={formData[field.name]}
                                                onChange={handleChange}
                                                rows={4}
                                                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                                            />
                                        ) : field.type === 'color' ? (
                                            <input
                                                type="color"
                                                name={field.name}
                                                value={formData[field.name]}
                                                onChange={handleChange}
                                                className="h-12 rounded-lg cursor-pointer"
                                            />
                                        ) : (
                                            <input
                                                type={field.type}
                                                name={field.name}
                                                value={formData[field.name]}
                                                onChange={handleChange}
                                                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                                            />
                                        )}
                                    </div>
                                ))}
                            </form>
                        </div>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-4">
                        {/* Save Status */}
                        {saved && (
                            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                                <p className="text-green-700 font-bold text-sm">✓ Changes saved successfully</p>
                            </div>
                        )}

                        {/* Action Buttons */}
                        <button
                            onClick={handleSave}
                            className="w-full px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 flex items-center justify-center gap-2"
                        >
                            <Save className="w-5 h-5" /> Save Changes
                        </button>

                        <button
                            onClick={() => setShowPreview(!showPreview)}
                            className="w-full px-6 py-3 bg-white text-gray-900 rounded-lg font-bold border border-gray-200 hover:border-indigo-600 flex items-center justify-center gap-2"
                        >
                            <Eye className="w-5 h-5" /> Preview
                        </button>

                        <button className="w-full px-6 py-3 bg-white text-gray-900 rounded-lg font-bold border border-gray-200 hover:border-gray-300 flex items-center justify-center gap-2">
                            <Copy className="w-5 h-5" /> Duplicate
                        </button>

                        <button className="w-full px-6 py-3 bg-white text-gray-900 rounded-lg font-bold border border-gray-200 hover:border-gray-300 flex items-center justify-center gap-2">
                            <Undo2 className="w-5 h-5" /> Revert
                        </button>

                        {/* Info Box */}
                        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                            <p className="text-blue-700 text-xs font-medium leading-relaxed">
                                <strong>Tip:</strong> Changes are saved automatically. Preview how your changes look in real-time.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

import { useState } from 'react';
import { Save, Palette, Globe, Shield } from 'lucide-react';

export default function SettingsPage() {
    const [saved, setSaved] = useState(false);
    const [settings, setSettings] = useState({
        siteTitle: 'CODVerify',
        siteDescription: 'Intelligence-Led RTO Reduction for E-commerce',
        contactEmail: 'hello@codverify.tech',
        supportEmail: 'support@codverify.tech',
        phone: '+91-XXXXX-XXXXX',
        address: 'Mumbai, India',
        primaryColor: '#4f46e5',
        secondaryColor: '#a855f7',
        backgroundColor: '#ffffff',
        textColor: '#1f2937',
        socialLinks: {
            twitter: 'https://twitter.com/codverify',
            linkedin: 'https://linkedin.com/company/codverify',
            instagram: 'https://instagram.com/codverify',
        },
        seo: {
            keywords: 'COD, RTO, Verification, E-commerce',
            ogImage: '/og-image.jpg',
            ogTitle: 'CODVerify - Reduce RTO by 42%',
        }
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setSettings(prev => ({
            ...prev,
            [name]: value
        }));
        setSaved(false);
    };

    const handleNestedChange = (group: string, field: string, value: string) => {
        setSettings(prev => {
            const updated = { ...prev };
            if (group === 'socialLinks' && 'socialLinks' in updated) {
                updated.socialLinks = { ...updated.socialLinks, [field]: value };
            } else if (group === 'seo' && 'seo' in updated) {
                updated.seo = { ...updated.seo, [field]: value };
            }
            return updated;
        });
        setSaved(false);
    };

    const handleSave = () => {
        console.log('Saving settings:', settings);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-black text-gray-900">Website Settings</h1>
                    <p className="text-gray-600">Manage your website's core configuration</p>
                </div>

                {/* Save Status */}
                {saved && (
                    <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
                        <p className="text-green-700 font-bold">✓ Settings saved successfully</p>
                    </div>
                )}

                <div className="space-y-8">
                    {/* General Settings */}
                    <div className="bg-white rounded-xl border border-gray-100 p-8">
                        <div className="flex items-center gap-3 mb-6">
                            <Globe className="w-6 h-6 text-blue-600" />
                            <h2 className="text-xl font-bold text-gray-900">General Settings</h2>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Site Title</label>
                                <input
                                    type="text"
                                    name="siteTitle"
                                    value={settings.siteTitle}
                                    onChange={handleInputChange}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Contact Email</label>
                                <input
                                    type="email"
                                    name="contactEmail"
                                    value={settings.contactEmail}
                                    onChange={handleInputChange}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Support Email</label>
                                <input
                                    type="email"
                                    name="supportEmail"
                                    value={settings.supportEmail}
                                    onChange={handleInputChange}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Phone Number</label>
                                <input
                                    type="tel"
                                    name="phone"
                                    value={settings.phone}
                                    onChange={handleInputChange}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div className="md:col-span-2">
                                <label className="block text-sm font-bold text-gray-900 mb-2">Site Description</label>
                                <textarea
                                    name="siteDescription"
                                    value={settings.siteDescription}
                                    onChange={handleInputChange}
                                    rows={3}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Branding & Colors */}
                    <div className="bg-white rounded-xl border border-gray-100 p-8">
                        <div className="flex items-center gap-3 mb-6">
                            <Palette className="w-6 h-6 text-purple-600" />
                            <h2 className="text-xl font-bold text-gray-900">Branding & Colors</h2>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Primary Color</label>
                                <div className="flex gap-3">
                                    <input
                                        type="color"
                                        value={settings.primaryColor}
                                        onChange={(e) => setSettings({ ...settings, primaryColor: e.target.value })}
                                        className="h-12 rounded-lg cursor-pointer"
                                    />
                                    <input
                                        type="text"
                                        value={settings.primaryColor}
                                        onChange={(e) => setSettings({ ...settings, primaryColor: e.target.value })}
                                        className="flex-1 px-4 py-3 border border-gray-200 rounded-lg font-mono text-sm"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Secondary Color</label>
                                <div className="flex gap-3">
                                    <input
                                        type="color"
                                        value={settings.secondaryColor}
                                        onChange={(e) => setSettings({ ...settings, secondaryColor: e.target.value })}
                                        className="h-12 rounded-lg cursor-pointer"
                                    />
                                    <input
                                        type="text"
                                        value={settings.secondaryColor}
                                        onChange={(e) => setSettings({ ...settings, secondaryColor: e.target.value })}
                                        className="flex-1 px-4 py-3 border border-gray-200 rounded-lg font-mono text-sm"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Social Media Links */}
                    <div className="bg-white rounded-xl border border-gray-100 p-8">
                        <div className="flex items-center gap-3 mb-6">
                            <Shield className="w-6 h-6 text-green-600" />
                            <h2 className="text-xl font-bold text-gray-900">Social Media Links</h2>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Twitter</label>
                                <input
                                    type="text"
                                    value={settings.socialLinks.twitter}
                                    onChange={(e) => handleNestedChange('socialLinks', 'twitter', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">LinkedIn</label>
                                <input
                                    type="text"
                                    value={settings.socialLinks.linkedin}
                                    onChange={(e) => handleNestedChange('socialLinks', 'linkedin', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Instagram</label>
                                <input
                                    type="text"
                                    value={settings.socialLinks.instagram}
                                    onChange={(e) => handleNestedChange('socialLinks', 'instagram', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                            </div>
                        </div>
                    </div>

                    {/* SEO Settings */}
                    <div className="bg-white rounded-xl border border-gray-100 p-8">
                        <h2 className="text-xl font-bold text-gray-900 mb-6">SEO Settings</h2>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-bold text-gray-900 mb-2">Meta Keywords</label>
                                <input
                                    type="text"
                                    value={settings.seo.keywords}
                                    onChange={(e) => handleNestedChange('seo', 'keywords', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                    placeholder="Comma separated keywords"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Save Button */}
                    <div className="flex justify-end gap-4">
                        <button className="px-6 py-3 bg-gray-200 text-gray-900 rounded-lg font-bold hover:bg-gray-300">
                            Reset
                        </button>
                        <button
                            onClick={handleSave}
                            className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 flex items-center gap-2"
                        >
                            <Save className="w-5 h-5" /> Save Settings
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

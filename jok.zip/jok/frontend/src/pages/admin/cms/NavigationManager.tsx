import { useState } from 'react';
import { Plus, Trash2, GripVertical, Edit2 } from 'lucide-react';

type MenuItem = {
    id: string;
    label: string;
    url: string;
    target?: '_blank' | '_self';
    order: number;
};

const defaultNavigation: MenuItem[] = [
    { id: '1', label: 'Technology', url: '#technology', order: 1 },
    { id: '2', label: 'Intelligence', url: '#intelligence', order: 2 },
    { id: '3', label: 'Economics', url: '#economics', order: 3 },
    { id: '4', label: 'Case Studies', url: '#cases', order: 4 },
    { id: '5', label: 'Services', url: '/services', order: 5 },
    { id: '6', label: 'Blog', url: '/blog', order: 6 },
];

export default function NavigationManager() {
    const [items, setItems] = useState<MenuItem[]>(defaultNavigation);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editData, setEditData] = useState<MenuItem | null>(null);
    const [newItem, setNewItem] = useState({ label: '', url: '' });

    const addItem = () => {
        if (newItem.label && newItem.url) {
            const item: MenuItem = {
                id: String(Date.now()),
                label: newItem.label,
                url: newItem.url,
                order: items.length + 1
            };
            setItems([...items, item]);
            setNewItem({ label: '', url: '' });
        }
    };

    const deleteItem = (id: string) => {
        setItems(items.filter(i => i.id !== id));
    };

    const updateItem = (id: string, data: Partial<MenuItem>) => {
        setItems(items.map(i => i.id === id ? { ...i, ...data } : i));
        setEditingId(null);
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-black text-gray-900">Navigation Menu</h1>
                    <p className="text-gray-600">Manage your website's main navigation menu</p>
                </div>

                {/* Add New Item */}
                <div className="bg-white rounded-xl border border-gray-100 p-6 mb-8">
                    <h2 className="text-lg font-bold text-gray-900 mb-4">Add Menu Item</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                        <input
                            type="text"
                            value={newItem.label}
                            onChange={(e) => setNewItem({ ...newItem, label: e.target.value })}
                            placeholder="Menu label"
                            className="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                        <input
                            type="text"
                            value={newItem.url}
                            onChange={(e) => setNewItem({ ...newItem, url: e.target.value })}
                            placeholder="URL or #anchor"
                            className="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                        <button
                            onClick={addItem}
                            className="px-4 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 flex items-center justify-center gap-2 col-span-1 sm:col-span-2"
                        >
                            <Plus className="w-4 h-4" /> Add Item
                        </button>
                    </div>
                </div>

                {/* Menu Items List */}
                <div className="space-y-2">
                    {items.map((item) => (
                        <div key={item.id} className="bg-white rounded-lg border border-gray-100 p-4 hover:shadow-md transition-shadow">
                            <div className="flex items-center gap-4">
                                <GripVertical className="w-5 h-5 text-gray-400 cursor-grab" />

                                {editingId === item.id ? (
                                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
                                        <input
                                            type="text"
                                            value={editData?.label || ''}
                                            onChange={(e) => setEditData({ ...editData!, label: e.target.value })}
                                            className="px-3 py-2 border border-gray-200 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                                        />
                                        <input
                                            type="text"
                                            value={editData?.url || ''}
                                            onChange={(e) => setEditData({ ...editData!, url: e.target.value })}
                                            className="px-3 py-2 border border-gray-200 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                                        />
                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => updateItem(item.id, editData!)}
                                                className="flex-1 px-3 py-2 bg-green-600 text-white rounded font-bold text-sm hover:bg-green-700"
                                            >
                                                Save
                                            </button>
                                            <button
                                                onClick={() => setEditingId(null)}
                                                className="flex-1 px-3 py-2 bg-gray-200 text-gray-900 rounded font-bold text-sm hover:bg-gray-300"
                                            >
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex-1">
                                            <p className="font-bold text-gray-900">{item.label}</p>
                                            <code className="text-xs text-gray-600">{item.url}</code>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <button
                                                onClick={() => {
                                                    setEditingId(item.id);
                                                    setEditData(item);
                                                }}
                                                className="p-2 hover:bg-gray-100 rounded"
                                            >
                                                <Edit2 className="w-4 h-4 text-gray-600" />
                                            </button>
                                            <button
                                                onClick={() => deleteItem(item.id)}
                                                className="p-2 hover:bg-red-50 rounded"
                                            >
                                                <Trash2 className="w-4 h-4 text-red-600" />
                                            </button>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Save Info */}
                <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <p className="text-blue-700 text-sm font-medium">
                        Changes are automatically saved. Your navigation menu will update across all pages immediately.
                    </p>
                </div>
            </div>
        </div>
    );
}

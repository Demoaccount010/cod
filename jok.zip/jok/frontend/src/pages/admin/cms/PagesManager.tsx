import { useState } from 'react';
import { Plus, Edit2, Trash2, Eye } from 'lucide-react';

type Page = {
    id: string;
    title: string;
    slug: string;
    status: 'published' | 'draft';
    sections: string[];
    updatedAt: string;
};

const defaultPages: Page[] = [
    {
        id: '1',
        title: 'Homepage',
        slug: 'home',
        status: 'published',
        sections: ['hero', 'features', 'roi', 'cta', 'footer'],
        updatedAt: '2 mins ago'
    },
    {
        id: '2',
        title: 'About Us',
        slug: 'about',
        status: 'published',
        sections: ['hero', 'team', 'mission'],
        updatedAt: '5 hours ago'
    },
    {
        id: '3',
        title: 'Pricing',
        slug: 'pricing',
        status: 'published',
        sections: ['hero', 'plans', 'faq'],
        updatedAt: '1 day ago'
    },
    {
        id: '4',
        title: 'Blog',
        slug: 'blog',
        status: 'draft',
        sections: ['hero', 'blog-list'],
        updatedAt: 'Just now'
    },
];

export default function PagesManager() {
    const [pages, setPages] = useState<Page[]>(defaultPages);
    const [showNewPageModal, setShowNewPageModal] = useState(false);
    const [newPageData, setNewPageData] = useState({ title: '', slug: '' });

    const addPage = () => {
        if (newPageData.title && newPageData.slug) {
            const newPage: Page = {
                id: String(pages.length + 1),
                title: newPageData.title,
                slug: newPageData.slug,
                status: 'draft',
                sections: [],
                updatedAt: 'Just now'
            };
            setPages([...pages, newPage]);
            setNewPageData({ title: '', slug: '' });
            setShowNewPageModal(false);
        }
    };

    const deletePage = (id: string) => {
        setPages(pages.filter(p => p.id !== id));
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-black text-gray-900">Pages</h1>
                        <p className="text-gray-600">Manage all your website pages</p>
                    </div>
                    <button
                        onClick={() => setShowNewPageModal(true)}
                        className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 flex items-center gap-2"
                    >
                        <Plus className="w-5 h-5" /> New Page
                    </button>
                </div>

                {/* Pages Table */}
                <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
                    <table className="w-full">
                        <thead className="bg-gray-50 border-b border-gray-100">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Page</th>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Slug</th>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Sections</th>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Updated</th>
                                <th className="px-6 py-3 text-right text-xs font-bold text-gray-600 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {pages.map((page) => (
                                <tr key={page.id} className="hover:bg-gray-50 transition-colors">
                                    <td className="px-6 py-4">
                                        <p className="font-bold text-gray-900">{page.title}</p>
                                    </td>
                                    <td className="px-6 py-4">
                                        <code className="bg-gray-100 px-3 py-1 rounded text-xs text-gray-700">/{page.slug}</code>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                            page.status === 'published'
                                                ? 'bg-green-100 text-green-700'
                                                : 'bg-yellow-100 text-yellow-700'
                                        }`}>
                                            {page.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <p className="text-sm text-gray-600">{page.sections.length} sections</p>
                                    </td>
                                    <td className="px-6 py-4">
                                        <p className="text-sm text-gray-600">{page.updatedAt}</p>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center justify-end gap-2">
                                            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="View">
                                                <Eye className="w-4 h-4 text-gray-600" />
                                            </button>
                                            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Edit">
                                                <Edit2 className="w-4 h-4 text-gray-600" />
                                            </button>
                                            <button 
                                                onClick={() => deletePage(page.id)}
                                                className="p-2 hover:bg-red-50 rounded-lg transition-colors" title="Delete"
                                            >
                                                <Trash2 className="w-4 h-4 text-red-600" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* New Page Modal */}
                {showNewPageModal && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                        <div className="bg-white rounded-xl p-8 max-w-md w-full">
                            <h2 className="text-2xl font-black text-gray-900 mb-6">Create New Page</h2>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-bold text-gray-900 mb-2">Page Title</label>
                                    <input
                                        type="text"
                                        value={newPageData.title}
                                        onChange={(e) => setNewPageData({ ...newPageData, title: e.target.value })}
                                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        placeholder="e.g., Contact Us"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-900 mb-2">URL Slug</label>
                                    <input
                                        type="text"
                                        value={newPageData.slug}
                                        onChange={(e) => setNewPageData({ ...newPageData, slug: e.target.value })}
                                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        placeholder="e.g., contact-us"
                                    />
                                </div>
                                <div className="flex gap-3 pt-4">
                                    <button
                                        onClick={() => setShowNewPageModal(false)}
                                        className="flex-1 px-4 py-3 bg-gray-100 text-gray-900 rounded-lg font-bold hover:bg-gray-200"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        onClick={addPage}
                                        className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700"
                                    >
                                        Create
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

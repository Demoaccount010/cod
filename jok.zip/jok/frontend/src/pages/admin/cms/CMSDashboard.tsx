import { Link } from 'react-router-dom';
import { FileText, Settings, Navigation, Image, BarChart3, Plus } from 'lucide-react';

export default function CMSDashboard() {

    const menuItems = [
        { id: 'pages', label: 'Pages', icon: FileText, color: 'bg-blue-100 text-blue-700' },
        { id: 'content', label: 'Content', icon: BarChart3, color: 'bg-green-100 text-green-700' },
        { id: 'navigation', label: 'Navigation', icon: Navigation, color: 'bg-purple-100 text-purple-700' },
        { id: 'media', label: 'Media', icon: Image, color: 'bg-orange-100 text-orange-700' },
        { id: 'settings', label: 'Settings', icon: Settings, color: 'bg-gray-100 text-gray-700' },
    ];

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-12">
                    <h1 className="text-4xl font-black text-gray-900 mb-2">Website CMS</h1>
                    <p className="text-gray-600">Complete control over your website content</p>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-600 text-sm font-medium">Pages</p>
                                <p className="text-3xl font-black text-gray-900">12</p>
                            </div>
                            <FileText className="w-12 h-12 text-blue-500 opacity-20" />
                        </div>
                    </div>
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-600 text-sm font-medium">Last Updated</p>
                                <p className="text-lg font-bold text-gray-900">2 mins ago</p>
                            </div>
                            <BarChart3 className="w-12 h-12 text-green-500 opacity-20" />
                        </div>
                    </div>
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-600 text-sm font-medium">Media Files</p>
                                <p className="text-3xl font-black text-gray-900">28</p>
                            </div>
                            <Image className="w-12 h-12 text-orange-500 opacity-20" />
                        </div>
                    </div>
                </div>

                {/* Menu Grid */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                    {menuItems.map((item) => {
                        const Icon = item.icon;
                        return (
                            <Link
                                key={item.id}
                                to={`/admin/cms/${item.id}`}
                                className="group p-6 rounded-xl border-2 bg-white border-gray-100 hover:border-indigo-200 hover:shadow-md transition-all cursor-pointer"
                            >
                                <div className={`w-14 h-14 rounded-lg ${item.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                                    <Icon className="w-7 h-7" />
                                </div>
                                <h3 className="font-bold text-gray-900 mb-1">{item.label}</h3>
                                <p className="text-xs text-gray-600">Manage {item.label.toLowerCase()}</p>
                            </Link>
                        );
                    })}
                </div>

                {/* Recent Changes */}
                <div className="mt-12 bg-white rounded-xl p-8 border border-gray-100">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-900">Recent Changes</h2>
                        <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold text-sm hover:bg-indigo-700 flex items-center gap-2">
                            <Plus className="w-4 h-4" /> New Page
                        </button>
                    </div>
                    <div className="space-y-4">
                        {[
                            { page: 'Homepage', section: 'Hero Section', user: 'You', time: '2 mins ago' },
                            { page: 'About', section: 'Content', user: 'You', time: '1 hour ago' },
                            { page: 'Homepage', section: 'Features', user: 'You', time: '3 hours ago' },
                        ].map((change, i) => (
                            <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                                <div>
                                    <p className="font-bold text-gray-900">{change.page}</p>
                                    <p className="text-sm text-gray-600">{change.section}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm text-gray-600">{change.user}</p>
                                    <p className="text-xs text-gray-500">{change.time}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

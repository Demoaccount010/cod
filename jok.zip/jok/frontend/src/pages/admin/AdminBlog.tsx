import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useRef, useCallback } from 'react';
import { adminApi } from '../../api';
import {
    Plus, FileText, Eye, EyeOff, Trash2, Edit3, Save, X, Clock,
    Bold, Italic, Heading1, Heading2, Link, Image, List, ListOrdered,
    Quote, Code, Minus, Globe, Tag, Search, MoreVertical,
    CheckCircle2, AlertCircle, Undo2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// ─── Rich Text Editor Toolbar ───
function EditorToolbar({ editorRef }: { editorRef: React.RefObject<HTMLDivElement | null> }) {
    const exec = (cmd: string, value?: string) => {
        document.execCommand(cmd, false, value);
        editorRef.current?.focus();
    };

    const insertLink = () => {
        const url = prompt('Enter URL:');
        if (url) exec('createLink', url);
    };

    const insertImage = () => {
        const url = prompt('Enter image URL:');
        if (url) exec('insertImage', url);
    };

    const tools = [
        { icon: Bold, cmd: () => exec('bold'), tip: 'Bold' },
        { icon: Italic, cmd: () => exec('italic'), tip: 'Italic' },
        { sep: true },
        { icon: Heading1, cmd: () => exec('formatBlock', '<h1>'), tip: 'Heading 1' },
        { icon: Heading2, cmd: () => exec('formatBlock', '<h2>'), tip: 'Heading 2' },
        { sep: true },
        { icon: List, cmd: () => exec('insertUnorderedList'), tip: 'Bullet List' },
        { icon: ListOrdered, cmd: () => exec('insertOrderedList'), tip: 'Numbered List' },
        { icon: Quote, cmd: () => exec('formatBlock', '<blockquote>'), tip: 'Quote' },
        { icon: Code, cmd: () => exec('formatBlock', '<pre>'), tip: 'Code Block' },
        { sep: true },
        { icon: Link, cmd: insertLink, tip: 'Insert Link' },
        { icon: Image, cmd: insertImage, tip: 'Insert Image' },
        { icon: Minus, cmd: () => exec('insertHorizontalRule'), tip: 'Divider' },
        { sep: true },
        { icon: Undo2, cmd: () => exec('undo'), tip: 'Undo' },
    ];

    return (
        <div className="flex items-center gap-1 p-3 border-b border-gray-100 bg-gray-50/50 rounded-t-2xl flex-wrap">
            {tools.map((t, i) =>
                t.sep ? (
                    <div key={i} className="w-px h-6 bg-gray-200 mx-1" />
                ) : (
                    <button
                        key={i}
                        type="button"
                        onMouseDown={(e) => { e.preventDefault(); t.cmd?.(); }}
                        title={t.tip}
                        className="p-2 rounded-lg text-gray-500 hover:bg-white hover:text-indigo-600 hover:shadow-sm transition-all active:scale-90"
                    >
                        {t.icon && <t.icon className="w-4 h-4" />}
                    </button>
                )
            )}
        </div>
    );
}


// ─── Blog Editor Modal ───
interface BlogPost {
    id?: string;
    title: string;
    content: string;
    excerpt: string;
    featured_image_url: string;
    category: string;
    tags: string[];
    meta_title: string;
    meta_description: string;
    is_published: boolean;
    is_featured: boolean;
    slug?: string;
    created_at?: string;
    views_count?: number;
    reading_time_minutes?: number;
}

const EMPTY_POST: BlogPost = {
    title: '', content: '', excerpt: '', featured_image_url: '',
    category: '', tags: [], meta_title: '', meta_description: '',
    is_published: false, is_featured: false,
};

const CATEGORIES = ['E-Commerce', 'COD Verification', 'RTO Reduction', 'Shopify Tips', 'Business Growth', 'Technology', 'Other'];

function BlogEditor({ post, onSave, onClose }: {
    post: BlogPost;
    onSave: (data: BlogPost) => Promise<void>;
    onClose: () => void;
}) {
    const [form, setForm] = useState<BlogPost>(post);
    const [saving, setSaving] = useState(false);
    const [tab, setTab] = useState<'write' | 'seo'>('write');
    const [tagInput, setTagInput] = useState('');
    const editorRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (editorRef.current && post.content) {
            editorRef.current.innerHTML = post.content;
        }
    }, []);

    const handleSave = async (publish?: boolean) => {
        setSaving(true);
        const content = editorRef.current?.innerHTML || '';
        const data = { ...form, content };
        if (publish !== undefined) data.is_published = publish;
        try {
            await onSave(data);
        } finally {
            setSaving(false);
        }
    };

    const addTag = () => {
        if (tagInput.trim() && !form.tags.includes(tagInput.trim())) {
            setForm(f => ({ ...f, tags: [...f.tags, tagInput.trim()] }));
            setTagInput('');
        }
    };

    const removeTag = (tag: string) => {
        setForm(f => ({ ...f, tags: f.tags.filter(t => t !== tag) }));
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto py-8 px-4"
            onClick={onClose}
        >
            <motion.div
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 30, scale: 0.95 }}
                className="bg-white rounded-[32px] w-full max-w-5xl shadow-2xl border border-gray-100 relative overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-gray-100">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-100 rounded-xl text-purple-600">
                            <Edit3 className="w-5 h-5" />
                        </div>
                        <div>
                            <h2 className="text-xl font-black font-['Outfit'] tracking-tight">
                                {post.id ? 'Edit Post' : 'Create New Post'}
                            </h2>
                            <p className="text-xs text-gray-400 font-medium">
                                {post.id ? `Editing: ${post.title}` : 'Write your blog post below'}
                            </p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                        <X className="w-5 h-5 text-gray-400" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex gap-1 p-2 mx-6 mt-4 bg-gray-100 rounded-xl w-fit">
                    {(['write', 'seo'] as const).map(t => (
                        <button
                            key={t}
                            onClick={() => setTab(t)}
                            className={`px-5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${tab === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                        >
                            {t === 'write' ? '✍️ Write' : '🔍 SEO & Meta'}
                        </button>
                    ))}
                </div>

                <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
                    {tab === 'write' && (
                        <>
                            {/* Title */}
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Title *</label>
                                <input
                                    value={form.title}
                                    onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                                    placeholder="Your blog post title..."
                                    className="w-full px-5 py-4 bg-gray-50 border border-transparent rounded-2xl text-lg font-bold font-['Outfit'] focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all placeholder:text-gray-300"
                                />
                            </div>

                            {/* Category & Featured Image */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Category</label>
                                    <select
                                        value={form.category}
                                        onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                                        className="w-full px-5 py-3.5 bg-gray-50 border border-transparent rounded-2xl text-sm font-bold focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all appearance-none"
                                    >
                                        <option value="">Select Category</option>
                                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Featured Image URL</label>
                                    <input
                                        value={form.featured_image_url}
                                        onChange={e => setForm(f => ({ ...f, featured_image_url: e.target.value }))}
                                        placeholder="https://..."
                                        className="w-full px-5 py-3.5 bg-gray-50 border border-transparent rounded-2xl text-sm font-bold focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all placeholder:text-gray-300"
                                    />
                                </div>
                            </div>

                            {/* Excerpt */}
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Excerpt (Short Summary)</label>
                                <textarea
                                    value={form.excerpt}
                                    onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))}
                                    placeholder="Brief description of your post..."
                                    rows={2}
                                    className="w-full px-5 py-3.5 bg-gray-50 border border-transparent rounded-2xl text-sm font-medium focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all placeholder:text-gray-300 resize-none"
                                />
                            </div>

                            {/* Rich Text Editor */}
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Content *</label>
                                <div className="border border-gray-200 rounded-2xl overflow-hidden bg-white shadow-sm">
                                    <EditorToolbar editorRef={editorRef} />
                                    <div
                                        ref={editorRef}
                                        contentEditable
                                        suppressContentEditableWarning
                                        className="min-h-[350px] max-h-[500px] overflow-y-auto p-6 outline-none prose prose-sm prose-indigo max-w-none
                                            [&_h1]:text-2xl [&_h1]:font-black [&_h1]:font-['Outfit'] [&_h1]:tracking-tight [&_h1]:mb-3 [&_h1]:text-gray-900
                                            [&_h2]:text-xl [&_h2]:font-bold [&_h2]:font-['Outfit'] [&_h2]:tracking-tight [&_h2]:mb-2.5 [&_h2]:text-gray-800
                                            [&_p]:text-sm [&_p]:text-gray-600 [&_p]:leading-relaxed [&_p]:mb-3
                                            [&_a]:text-indigo-600 [&_a]:underline [&_a]:decoration-indigo-300 [&_a:hover]:text-indigo-800
                                            [&_img]:rounded-xl [&_img]:shadow-md [&_img]:my-4 [&_img]:max-w-full
                                            [&_blockquote]:border-l-4 [&_blockquote]:border-indigo-200 [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:text-gray-500
                                            [&_pre]:bg-gray-900 [&_pre]:text-green-400 [&_pre]:p-4 [&_pre]:rounded-xl [&_pre]:text-xs [&_pre]:overflow-x-auto
                                            [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:space-y-1.5
                                            [&_ol]:list-decimal [&_ol]:pl-5 [&_ol]:space-y-1.5
                                            [&_li]:text-sm [&_li]:text-gray-600
                                            [&_hr]:my-6 [&_hr]:border-gray-200
                                        "
                                        data-placeholder="Start writing your blog post..."
                                    />
                                </div>
                            </div>

                            {/* Tags */}
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Tags</label>
                                <div className="flex flex-wrap gap-2 mb-3">
                                    {form.tags.map(tag => (
                                        <span key={tag} className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-indigo-100">
                                            {tag}
                                            <button type="button" onClick={() => removeTag(tag)} className="hover:text-red-500 transition-colors">
                                                <X className="w-3 h-3" />
                                            </button>
                                        </span>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <input
                                        value={tagInput}
                                        onChange={e => setTagInput(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addTag())}
                                        placeholder="Add tag..."
                                        className="flex-1 px-4 py-2.5 bg-gray-50 border border-transparent rounded-xl text-sm font-bold focus:bg-white focus:border-indigo-200 outline-none transition-all placeholder:text-gray-300"
                                    />
                                    <button type="button" onClick={addTag} className="px-4 py-2.5 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-all">
                                        Add
                                    </button>
                                </div>
                            </div>
                        </>
                    )}

                    {tab === 'seo' && (
                        <div className="space-y-5">
                            <div className="p-5 bg-indigo-50/50 border border-indigo-100 rounded-2xl">
                                <p className="text-xs text-indigo-800 font-bold flex items-center gap-2">
                                    <Search className="w-4 h-4" /> SEO settings help your post rank better in search engines
                                </p>
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Meta Title</label>
                                <input
                                    value={form.meta_title}
                                    onChange={e => setForm(f => ({ ...f, meta_title: e.target.value }))}
                                    placeholder="SEO title (defaults to post title)"
                                    className="w-full px-5 py-3.5 bg-gray-50 border border-transparent rounded-2xl text-sm font-bold focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all placeholder:text-gray-300"
                                />
                                <p className="text-xs text-gray-400 mt-1 ml-1">{(form.meta_title || form.title).length}/60 characters</p>
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Meta Description</label>
                                <textarea
                                    value={form.meta_description}
                                    onChange={e => setForm(f => ({ ...f, meta_description: e.target.value }))}
                                    placeholder="Brief description for search engines..."
                                    rows={3}
                                    className="w-full px-5 py-3.5 bg-gray-50 border border-transparent rounded-2xl text-sm font-medium focus:bg-white focus:border-indigo-200 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all placeholder:text-gray-300 resize-none"
                                />
                                <p className="text-xs text-gray-400 mt-1 ml-1">{form.meta_description.length}/160 characters</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <label className="flex items-center gap-3 cursor-pointer p-4 bg-gray-50 rounded-2xl flex-1 hover:bg-gray-100 transition-colors">
                                    <input
                                        type="checkbox"
                                        checked={form.is_featured}
                                        onChange={e => setForm(f => ({ ...f, is_featured: e.target.checked }))}
                                        className="w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                    />
                                    <span className="text-sm font-bold text-gray-700">⭐ Featured Post</span>
                                </label>
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer Actions */}
                <div className="flex items-center justify-between p-6 border-t border-gray-100 bg-gray-50/30">
                    <button
                        onClick={onClose}
                        className="px-6 py-3 text-sm font-bold text-gray-400 hover:text-gray-600 transition-colors"
                    >
                        Cancel
                    </button>
                    <div className="flex items-center gap-3">
                        <button
                            onClick={() => handleSave(false)}
                            disabled={saving || !form.title}
                            className="px-6 py-3 bg-gray-200 text-gray-700 rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-gray-300 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2"
                        >
                            <Save className="w-4 h-4" /> Save Draft
                        </button>
                        <button
                            onClick={() => handleSave(true)}
                            disabled={saving || !form.title}
                            className="px-8 py-3 bg-indigo-600 text-white rounded-2xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2"
                        >
                            {saving ? 'Saving...' : <><Globe className="w-4 h-4" /> Publish</>}
                        </button>
                    </div>
                </div>
            </motion.div>
        </motion.div>
    );
}


// ─── Main Admin Blog Component ───
export default function AdminBlog() {
    const [posts, setPosts] = useState<BlogPost[]>([]);
    const [loading, setLoading] = useState(true);
    const [editor, setEditor] = useState<BlogPost | null>(null);
    const [filter, setFilter] = useState<'all' | 'published' | 'draft'>('all');
    const [search, setSearch] = useState('');
    const [menuOpen, setMenuOpen] = useState<string | null>(null);
    const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

    const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
        setToast({ msg, type });
        setTimeout(() => setToast(null), 3000);
    };

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = `page=1&limit=100${filter !== 'all' ? `&status=${filter}` : ''}`;
            const r = await adminApi.getBlogPosts(params);
            setPosts(r.data?.data?.posts || r.data?.data || []);
        } catch {
            showToast('Failed to load posts', 'error');
        } finally {
            setLoading(false);
        }
    }, [filter]);

    useEffect(() => { load(); }, [load]);

    const handleSave = async (data: BlogPost) => {
        try {
            if (data.id) {
                await adminApi.updatePost(data.id, data);
                showToast('Post updated successfully');
            } else {
                await adminApi.createPost(data);
                showToast('Post created successfully');
            }
            setEditor(null);
            load();
        } catch (err: any) {
            showToast(err?.response?.data?.detail || 'Failed to save post', 'error');
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Are you sure you want to delete this post?')) return;
        try {
            await adminApi.deletePost(id);
            showToast('Post deleted');
            load();
        } catch {
            showToast('Failed to delete post', 'error');
        }
        setMenuOpen(null);
    };

    const handleTogglePublish = async (post: BlogPost) => {
        try {
            await adminApi.updatePost(post.id!, { is_published: !post.is_published });
            showToast(post.is_published ? 'Post unpublished' : 'Post published');
            load();
        } catch {
            showToast('Failed to update post', 'error');
        }
        setMenuOpen(null);
    };

    const filteredPosts = posts.filter(p =>
        !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.category?.toLowerCase().includes(search.toLowerCase())
    );

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Loading Blog Posts...</p>
        </div>
    );

    return (
        <div className="space-y-8 pb-10">
            <Helmet><title>Blog Manager | Admin</title></Helmet>

            {/* Toast */}
            <AnimatePresence>
                {toast && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className={`fixed top-6 right-6 z-[60] px-6 py-3 rounded-2xl text-sm font-bold shadow-xl flex items-center gap-2 ${toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}
                    >
                        {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                        {toast.msg}
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-purple-600 rounded-xl shadow-lg shadow-purple-600/20 text-white">
                        <FileText className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Blog Manager</h1>
                        <p className="text-gray-500 text-sm font-medium">Create, edit, and publish blog posts</p>
                    </div>
                </div>
                <button
                    onClick={() => setEditor({ ...EMPTY_POST })}
                    className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-indigo-600/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2"
                >
                    <Plus className="w-4 h-4" /> New Blog Post
                </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4">
                {[
                    { label: 'Total Posts', value: posts.length, color: 'bg-indigo-50 text-indigo-600 border-indigo-100' },
                    { label: 'Published', value: posts.filter(p => p.is_published).length, color: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
                    { label: 'Drafts', value: posts.filter(p => !p.is_published).length, color: 'bg-amber-50 text-amber-600 border-amber-100' },
                ].map((s, i) => (
                    <div key={i} className={`${s.color} border rounded-2xl p-5 text-center`}>
                        <p className="text-2xl font-black font-['Outfit']">{s.value}</p>
                        <p className="text-[10px] font-bold uppercase tracking-widest mt-1 opacity-70">{s.label}</p>
                    </div>
                ))}
            </div>

            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <div className="flex gap-1.5 p-1.5 bg-gray-100 rounded-xl">
                    {(['all', 'published', 'draft'] as const).map(f => (
                        <button
                            key={f}
                            onClick={() => setFilter(f)}
                            className={`px-5 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${filter === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                        >
                            {f === 'all' ? 'All Posts' : f}
                        </button>
                    ))}
                </div>
                <div className="relative">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                    <input
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        placeholder="Search posts..."
                        className="pl-10 pr-5 py-2.5 bg-gray-50 border border-transparent rounded-xl text-sm font-medium focus:bg-white focus:border-indigo-200 outline-none transition-all w-64 placeholder:text-gray-300"
                    />
                </div>
            </div>

            {/* Posts List */}
            <div className="bg-white rounded-[32px] border border-gray-100 overflow-hidden shadow-xl shadow-gray-900/5">
                <div className="divide-y divide-gray-50">
                    {filteredPosts.map((post, i) => (
                        <motion.div
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.03 }}
                            key={post.id || i}
                            className="p-6 flex items-center justify-between hover:bg-gray-50/50 group transition-all relative"
                        >
                            <div className="flex items-center gap-5 flex-1 min-w-0">
                                {/* Thumbnail */}
                                <div className="w-16 h-12 bg-gray-100 rounded-xl overflow-hidden shadow-sm shrink-0 border border-gray-100 group-hover:scale-105 transition-transform">
                                    {post.featured_image_url ?
                                        <img src={post.featured_image_url} className="w-full h-full object-cover" alt="" /> :
                                        <div className="w-full h-full flex items-center justify-center text-gray-300"><FileText className="w-5 h-5" /></div>
                                    }
                                </div>
                                {/* Info */}
                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-gray-900 font-['Outfit'] tracking-tight truncate group-hover:text-indigo-600 transition-colors">
                                        {post.title}
                                    </h3>
                                    <div className="flex items-center gap-3 mt-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                                        {post.category && (
                                            <span className="flex items-center gap-1 text-indigo-400">
                                                <Tag className="w-3 h-3" /> {post.category}
                                            </span>
                                        )}
                                        <span className="flex items-center gap-1">
                                            <Eye className="w-3 h-3" /> {post.views_count || 0} views
                                        </span>
                                        {post.reading_time_minutes && (
                                            <span className="flex items-center gap-1">
                                                <Clock className="w-3 h-3" /> {post.reading_time_minutes} min
                                            </span>
                                        )}
                                        {post.created_at && (
                                            <span>{new Date(post.created_at).toLocaleDateString()}</span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Status & Actions */}
                            <div className="flex items-center gap-4 shrink-0">
                                <span className={`px-3 py-1.5 rounded-xl text-[9px] font-bold uppercase tracking-widest border ${post.is_published ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                                    {post.is_published ? 'Published' : 'Draft'}
                                </span>

                                {/* Action menu */}
                                <div className="relative">
                                    <button
                                        onClick={() => setMenuOpen(menuOpen === post.id ? null : post.id!)}
                                        className="p-2.5 bg-gray-50 text-gray-400 rounded-xl hover:bg-white hover:text-indigo-600 hover:shadow-md transition-all"
                                    >
                                        <MoreVertical className="w-4 h-4" />
                                    </button>

                                    <AnimatePresence>
                                        {menuOpen === post.id && (
                                            <motion.div
                                                initial={{ opacity: 0, scale: 0.9 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                exit={{ opacity: 0, scale: 0.9 }}
                                                className="absolute right-0 top-12 bg-white rounded-2xl border border-gray-100 shadow-2xl py-2 w-52 z-30"
                                            >
                                                <button
                                                    onClick={() => { setEditor(post); setMenuOpen(null); }}
                                                    className="w-full px-4 py-3 text-left text-sm font-bold text-gray-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-3 transition-colors"
                                                >
                                                    <Edit3 className="w-4 h-4" /> Edit Post
                                                </button>
                                                <button
                                                    onClick={() => handleTogglePublish(post)}
                                                    className="w-full px-4 py-3 text-left text-sm font-bold text-gray-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-3 transition-colors"
                                                >
                                                    {post.is_published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                                    {post.is_published ? 'Unpublish' : 'Publish'}
                                                </button>
                                                <div className="border-t border-gray-100 my-1" />
                                                <button
                                                    onClick={() => handleDelete(post.id!)}
                                                    className="w-full px-4 py-3 text-left text-sm font-bold text-red-600 hover:bg-red-50 flex items-center gap-3 transition-colors"
                                                >
                                                    <Trash2 className="w-4 h-4" /> Delete
                                                </button>
                                            </motion.div>
                                        )}
                                    </AnimatePresence>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>

                {filteredPosts.length === 0 && (
                    <div className="py-20 text-center">
                        <FileText className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
                            {search ? 'No posts match your search' : 'No blog posts yet'}
                        </p>
                        {!search && (
                            <button
                                onClick={() => setEditor({ ...EMPTY_POST })}
                                className="mt-4 px-6 py-3 bg-indigo-600 text-white rounded-2xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2 mx-auto"
                            >
                                <Plus className="w-4 h-4" /> Create Your First Post
                            </button>
                        )}
                    </div>
                )}
            </div>

            {/* Editor Modal */}
            <AnimatePresence>
                {editor && (
                    <BlogEditor
                        post={editor}
                        onSave={handleSave}
                        onClose={() => setEditor(null)}
                    />
                )}
            </AnimatePresence>

            {/* Click outside to close menu */}
            {menuOpen && (
                <div
                    className="fixed inset-0 z-20"
                    onClick={() => setMenuOpen(null)}
                />
            )}
        </div>
    );
}

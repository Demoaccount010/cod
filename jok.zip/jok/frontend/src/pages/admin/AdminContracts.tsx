import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { adminApi } from '../../api';
import { FileText, Plus, Search, Trash2, CheckCircle, X, CreditCard, Calendar, ShieldCheck, Clock, UserPlus, Zap } from 'lucide-react';

const SERVICE_OPTIONS = [
    'SMS Verification',
    'Call Verification',
    'WhatsApp Verification',
    'Personal Customer Support',
    '24x7 Monitoring',
    'RTO Analytics',
    'Fraud Detection',
    'Multi-Country Support',
];

const CHATBOT_TIERS = [
    {
        id: 'none',
        name: 'No Chatbot',
        description: 'No chatbot included in this plan',
        icon: '\u2716',
        color: 'border-gray-200 bg-gray-50 text-gray-500',
        activeColor: 'border-gray-400 bg-gray-100 text-gray-700 ring-2 ring-gray-300',
    },
    {
        id: 'chatbot_basic',
        name: 'Basic Chatbot',
        description: 'Rule-based chatbot + Customer support widget',
        icon: '\uD83D\uDCAC',
        color: 'border-blue-100 bg-blue-50/50 text-blue-700',
        activeColor: 'border-blue-400 bg-blue-50 text-blue-700 ring-2 ring-blue-300',
    },
    {
        id: 'chatbot_ai',
        name: 'AI Chatbot',
        description: 'AI-powered smart chatbot with natural language understanding',
        icon: '\uD83E\uDD16',
        color: 'border-purple-100 bg-purple-50/50 text-purple-700',
        activeColor: 'border-purple-400 bg-purple-50 text-purple-700 ring-2 ring-purple-300',
    },
    {
        id: 'chatbot_full',
        name: 'Full Suite',
        description: 'AI Chatbot + Live Agent + Customer Support (Complete package)',
        icon: '\u2B50',
        color: 'border-amber-100 bg-amber-50/50 text-amber-700',
        activeColor: 'border-amber-400 bg-amber-50 text-amber-700 ring-2 ring-amber-300',
    },
];

export default function AdminContracts() {
    const [contracts, setContracts] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [users, setUsers] = useState<any[]>([]);
    const [search, setSearch] = useState('');
    const [activatingId, setActivatingId] = useState<string | null>(null);

    // Create form state
    const [form, setForm] = useState({
        user_id: '',
        type: 'monthly',
        services: [] as string[],
        duration_months: 1,
        total_amount: 0,
        advance_amount: 0,
        monthly_amount: 0,
        currency: 'INR',
        notes: '',
        chatbot_tier: 'none',
    });
    const [creating, setCreating] = useState(false);

    useEffect(() => { loadContracts(); }, []);

    const loadContracts = async () => {
        try {
            const res = await adminApi.getContracts('');
            setContracts(res.data?.data?.contracts || []);
        } catch { }
        setLoading(false);
    };

    const loadUsers = async () => {
        try {
            const res = await adminApi.getAvailableUsers();
            setUsers(res.data?.data?.users || []);
        } catch { }
    };

    const openCreate = () => {
        loadUsers();
        setShowCreate(true);
    };

    const toggleService = (s: string) => {
        setForm(p => ({
            ...p,
            services: p.services.includes(s) ? p.services.filter(x => x !== s) : [...p.services, s],
        }));
    };

    const handleCreate = async () => {
        if (!form.user_id) return alert('Select a user');
        if (form.services.length === 0) return alert('Select at least one service');
        setCreating(true);
        try {
            await adminApi.createContract(form);
            setShowCreate(false);
            setForm({ user_id: '', type: 'monthly', services: [], duration_months: 1, total_amount: 0, advance_amount: 0, monthly_amount: 0, currency: 'INR', notes: '', chatbot_tier: 'none' });
            loadContracts();
        } catch (err: any) {
            alert(err.response?.data?.detail || 'Failed to create');
        }
        setCreating(false);
    };

    const handleActivate = async (contractId: string) => {
        setActivatingId(contractId);
        try {
            await adminApi.updateContract(contractId, { status: 'active' });
            loadContracts();
        } catch (err: any) {
            alert(err.response?.data?.detail || 'Failed to activate');
        }
        setActivatingId(null);
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Delete this contract?')) return;
        try {
            await adminApi.deleteContract(id);
            loadContracts();
        } catch { }
    };

    const statusColor: any = {
        pending: 'bg-amber-50 text-amber-700 border-amber-200',
        active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        expired: 'bg-gray-50 text-gray-500 border-gray-200',
        cancelled: 'bg-rose-50 text-rose-700 border-rose-200',
        completed: 'bg-blue-50 text-blue-700 border-blue-200',
    };

    const filterBySearch = (c: any) => {
        if (!search) return true;
        const q = search.toLowerCase();
        const userName = c.user?.name || '';
        const email = c.user?.email || '';
        return c.contract_number?.toLowerCase().includes(q) || userName.toLowerCase().includes(q) || email.toLowerCase().includes(q);
    };

    // Split contracts into two groups
    const pendingContracts = contracts.filter(c => c.status === 'pending').filter(filterBySearch);
    const activeContracts = contracts.filter(c => c.status !== 'pending').filter(filterBySearch);

    const renderContractCard = (c: any, showActivateBtn: boolean) => (
        <motion.div key={c.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
            className="glass-card rounded-2xl p-5 border border-gray-100 hover:border-indigo-100 hover:shadow-lg transition-all group">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className="text-sm font-bold text-gray-900 font-['Outfit']">{c.contract_number}</span>
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-widest border ${statusColor[c.status] || ''}`}>
                            {c.status}
                        </span>
                        <span className="text-[9px] font-bold text-gray-400 uppercase bg-gray-50 px-2 py-0.5 rounded">{c.type}</span>
                    </div>
                    <p className="text-xs text-gray-500 font-medium">
                        <span className="font-bold text-gray-700">{c.user?.name || '—'}</span> • {c.user?.email || '—'}
                        {c.user?.company_name && <span className="text-gray-400"> • {c.user.company_name}</span>}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-[10px] font-semibold text-gray-400 flex-wrap">
                        <span><Calendar className="w-3 h-3 inline mr-0.5" /> {c.duration_months} months</span>
                        <span><CreditCard className="w-3 h-3 inline mr-0.5" /> {c.currency === 'USD' ? '$' : '₹'}{Number(c.total_amount).toLocaleString()}</span>
                        {c.type === 'monthly' && <span>Monthly: {c.currency === 'USD' ? '$' : '₹'}{Number(c.monthly_amount).toLocaleString()}</span>}
                        {c.start_date && <span>Start: {new Date(c.start_date).toLocaleDateString()}</span>}
                        {c.end_date && <span>End: {new Date(c.end_date).toLocaleDateString()}</span>}
                    </div>
                    {c.services && c.services.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                            {(c.services as any[]).map((s: any, i: number) => (
                                <span key={i} className="text-[9px] font-bold bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-md">
                                    {typeof s === 'string' ? s : s.name || ''}
                                </span>
                            ))}
                        </div>
                    )}
                </div>
                <div className="flex items-center gap-2">
                    {showActivateBtn && (
                        <button onClick={() => handleActivate(c.id)} disabled={activatingId === c.id}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center gap-1.5 disabled:opacity-50">
                            {activatingId === c.id ? (
                                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            ) : (
                                <ShieldCheck className="w-3.5 h-3.5" />
                            )}
                            Activate
                        </button>
                    )}
                    <button onClick={() => handleDelete(c.id)} className="p-2 text-gray-300 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all">
                        <Trash2 className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </motion.div>
    );

    return (
        <div className="max-w-6xl mx-auto space-y-6 pb-10">
            <Helmet><title>Manage Contracts - Admin</title></Helmet>

            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Contract Management</h1>
                        <p className="text-gray-400 text-xs font-semibold">{contracts.length} contracts total</p>
                    </div>
                </div>
                <button onClick={openCreate} className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center gap-2">
                    <Plus className="w-4 h-4" /> New Contract
                </button>
            </div>

            {/* Search */}
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-100 rounded-xl text-sm font-semibold focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none" placeholder="Search by contract number, name, or email..." />
            </div>

            {loading ? (
                <div className="flex justify-center py-20"><div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" /></div>
            ) : (
                <>
                    {/* ═══ SECTION 1: Pending Activations ═══════════════════════ */}
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-amber-100 rounded-lg">
                                <UserPlus className="w-4 h-4 text-amber-600" />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-gray-900 font-['Outfit']">Pending Activations</h2>
                                <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest">{pendingContracts.length} awaiting activation</p>
                            </div>
                        </div>
                        {pendingContracts.length === 0 ? (
                            <div className="text-center py-10 glass-card rounded-2xl border border-amber-50">
                                <Clock className="w-10 h-10 text-amber-200 mx-auto mb-3" />
                                <p className="text-gray-400 font-semibold text-sm">No pending contracts</p>
                                <p className="text-gray-300 text-xs mt-1">New contracts will appear here</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {pendingContracts.map(c => renderContractCard(c, true))}
                            </div>
                        )}
                    </div>

                    {/* ═══ SECTION 2: Active & Other Contracts ═════════════════ */}
                    <div>
                        <div className="flex items-center gap-3 mb-4 mt-8">
                            <div className="p-2 bg-emerald-100 rounded-lg">
                                <Zap className="w-4 h-4 text-emerald-600" />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-gray-900 font-['Outfit']">Active & Completed Contracts</h2>
                                <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">{activeContracts.length} contracts</p>
                            </div>
                        </div>
                        {activeContracts.length === 0 ? (
                            <div className="text-center py-10 glass-card rounded-2xl border border-emerald-50">
                                <ShieldCheck className="w-10 h-10 text-emerald-200 mx-auto mb-3" />
                                <p className="text-gray-400 font-semibold text-sm">No active contracts yet</p>
                                <p className="text-gray-300 text-xs mt-1">Activate pending contracts to see them here</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {activeContracts.map(c => renderContractCard(c, false))}
                            </div>
                        )}
                    </div>
                </>
            )}

            {/* ── CREATE CONTRACT MODAL ───────────────────────────────── */}
            <AnimatePresence>
                {showCreate && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
                        onClick={() => setShowCreate(false)}>
                        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-white rounded-3xl p-6 sm:p-8 w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl"
                            onClick={e => e.stopPropagation()}>
                            <div className="flex items-center justify-between mb-6">
                                <h3 className="text-xl font-bold text-gray-900 font-['Outfit']">Create Contract</h3>
                                <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="w-5 h-5 text-gray-400" /></button>
                            </div>

                            <div className="space-y-5">
                                {/* User select */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Select User</label>
                                    <select value={form.user_id} onChange={e => setForm(p => ({ ...p, user_id: e.target.value }))}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20">
                                        <option value="">— Choose user —</option>
                                        {users.map((u: any) => (
                                            <option key={u.id} value={u.id}>{u.name} ({u.email}) {u.account_status === 'active' ? '✅' : u.account_status === 'pending_activation' ? '🟡' : ''}</option>
                                        ))}
                                    </select>
                                </div>

                                {/* Type */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Plan Type</label>
                                    <div className="flex gap-3">
                                        {['contract', 'monthly'].map(t => (
                                            <button key={t} type="button" onClick={() => setForm(p => ({ ...p, type: t }))}
                                                className={`flex-1 py-3 rounded-xl text-sm font-bold border-2 transition-all capitalize ${form.type === t ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-100 bg-gray-50 text-gray-500 hover:border-gray-200'}`}>
                                                {t}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Duration */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Duration (Months)</label>
                                    <input type="number" min={1} value={form.duration_months} onChange={e => setForm(p => ({ ...p, duration_months: +e.target.value }))}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                </div>

                                {/* Amounts */}
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Total Amount</label>
                                        <input type="number" min={0} value={form.total_amount} onChange={e => setForm(p => ({ ...p, total_amount: +e.target.value }))}
                                            className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                    </div>
                                    {form.type === 'contract' ? (
                                        <div>
                                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Advance (Pay Now)</label>
                                            <input type="number" min={0} value={form.advance_amount} onChange={e => setForm(p => ({ ...p, advance_amount: +e.target.value }))}
                                                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                        </div>
                                    ) : (
                                        <div>
                                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Monthly Amount</label>
                                            <input type="number" min={0} value={form.monthly_amount} onChange={e => setForm(p => ({ ...p, monthly_amount: +e.target.value }))}
                                                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                        </div>
                                    )}
                                </div>

                                {/* Currency */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Currency</label>
                                    <select value={form.currency} onChange={e => setForm(p => ({ ...p, currency: e.target.value }))}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20">
                                        <option value="INR">INR (₹)</option>
                                        <option value="USD">USD ($)</option>
                                    </select>
                                </div>

                                {/* Services */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Services</label>
                                    <div className="flex flex-wrap gap-2">
                                        {SERVICE_OPTIONS.map(s => (
                                            <button key={s} type="button" onClick={() => toggleService(s)}
                                                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${form.services.includes(s) ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-gray-50 text-gray-500 border-gray-100 hover:border-gray-200'}`}>
                                                {form.services.includes(s) && <CheckCircle className="w-3 h-3 inline mr-1" />}{s}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Chatbot Tier */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Chatbot Tier</label>
                                    <div className="grid grid-cols-2 gap-2">
                                        {CHATBOT_TIERS.map(tier => (
                                            <button key={tier.id} type="button"
                                                onClick={() => setForm(p => ({ ...p, chatbot_tier: tier.id }))}
                                                className={`p-3 rounded-xl border-2 text-left transition-all ${form.chatbot_tier === tier.id ? tier.activeColor : tier.color + ' hover:shadow-sm'
                                                    }`}>
                                                <div className="flex items-center gap-2 mb-1">
                                                    <span className="text-lg">{tier.icon}</span>
                                                    <span className="text-xs font-bold">{tier.name}</span>
                                                </div>
                                                <p className="text-[10px] opacity-75 leading-relaxed">{tier.description}</p>
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Notes */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Notes (visible to user)</label>
                                    <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={3}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium outline-none resize-none focus:ring-2 focus:ring-indigo-500/20" placeholder="Optional notes..." />
                                </div>

                                {/* Submit */}
                                <button onClick={handleCreate} disabled={creating}
                                    className="w-full py-3.5 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                                    {creating ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Plus className="w-4 h-4" />}
                                    {creating ? 'Creating...' : 'Create Contract'}
                                </button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

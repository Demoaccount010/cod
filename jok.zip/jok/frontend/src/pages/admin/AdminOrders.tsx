import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { adminApi } from '../../api';
import {
    Store, ShoppingCart, Search, CheckCircle, XCircle, Clock,
    AlertCircle, ChevronLeft, Hash, User, Calendar, Package, Zap
} from 'lucide-react';

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
    confirmed: { label: 'Verified', color: 'bg-emerald-50 text-emerald-600 border-emerald-100', icon: CheckCircle },
    cancelled: { label: 'Cancelled', color: 'bg-rose-50 text-rose-600 border-rose-100', icon: XCircle },
    pending: { label: 'Pending', color: 'bg-amber-50 text-amber-600 border-amber-100', icon: Clock },
    failed: { label: 'Failed', color: 'bg-gray-100 text-gray-400 border-gray-200', icon: AlertCircle },
};

const PLAN_COLOR: Record<string, string> = {
    trial: 'bg-gray-100 text-gray-600',
    plan_1: 'bg-blue-50 text-blue-600',
    plan_2: 'bg-purple-50 text-purple-600',
    plan_3: 'bg-indigo-50 text-indigo-700',
    enterprise: 'bg-amber-50 text-amber-700',
};

const STATUS_DOT: Record<string, string> = {
    active: 'bg-emerald-400',
    trial: 'bg-amber-400',
    inactive: 'bg-gray-300',
    suspended: 'bg-rose-400',
};

export default function AdminOrders() {
    const [view, setView] = useState<'stores' | 'orders'>('stores');
    const [stores, setStores] = useState<any[]>([]);
    const [orders, setOrders] = useState<any[]>([]);
    const [selectedStore, setSelected] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    useEffect(() => {
        adminApi.getStores()
            .then((r: any) => setStores(r.data?.data?.stores || []))
            .finally(() => setLoading(false));
    }, []);

    const openStore = (store: any) => {
        setSelected(store);
        setView('orders');
        setLoading(true);
        adminApi.getOrdersByMerchant(store.merchant_id, 'limit=50')
            .then((r: any) => setOrders(r.data?.data?.orders || []))
            .finally(() => setLoading(false));
    };

    const backToStores = () => {
        setView('stores');
        setSelected(null);
        setOrders([]);
        setSearch('');
    };

    const filteredStores = stores.filter((s: any) =>
        (s.name || '').toLowerCase().includes(search.toLowerCase()) ||
        (s.company_name || '').toLowerCase().includes(search.toLowerCase()) ||
        (s.shop_domain || '').toLowerCase().includes(search.toLowerCase()) ||
        (s.email || '').toLowerCase().includes(search.toLowerCase())
    );

    const filteredOrders = orders.filter((o: any) =>
        (o.order_number || '').toLowerCase().includes(search.toLowerCase()) ||
        (o.customer_name || '').toLowerCase().includes(search.toLowerCase())
    );

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">
                {view === 'stores' ? 'Loading Stores...' : 'Loading Orders...'}
            </p>
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet>
                <title>{view === 'stores' ? 'Merchant Stores' : `${selectedStore?.company_name || 'Store'} Orders`} | Admin</title>
            </Helmet>

            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        {view === 'orders' && (
                            <button onClick={backToStores} className="p-2 rounded-xl bg-gray-100 hover:bg-indigo-50 hover:text-indigo-600 transition-all">
                                <ChevronLeft className="w-5 h-5" />
                            </button>
                        )}
                        <div className="p-2.5 bg-gray-900 rounded-xl text-white">
                            {view === 'stores' ? <Store className="w-5 h-5" /> : <ShoppingCart className="w-5 h-5" />}
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
                                {view === 'stores' ? 'All Merchant Stores' : (selectedStore?.company_name || 'Orders')}
                            </h1>
                            <p className="text-gray-500 text-sm font-medium">
                                {view === 'stores'
                                    ? `${stores.length} merchants connected`
                                    : `${selectedStore?.shop_domain || ''} · ${orders.length} orders`}
                            </p>
                        </div>
                    </div>
                </motion.div>

                <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        placeholder={view === 'stores' ? 'Search stores...' : 'Search orders...'}
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="pl-10 pr-4 py-3 bg-white border border-gray-100 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none shadow-sm w-72"
                    />
                </div>
            </div>

            {/* STORES VIEW */}
            <AnimatePresence mode="wait">
                {view === 'stores' && (
                    <motion.div key="stores" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                        {filteredStores.length === 0 ? (
                            <div className="text-center py-24 text-gray-400">
                                <Store className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                                <p className="font-bold text-lg">No merchants found</p>
                            </div>
                        ) : (
                            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
                                {filteredStores.map((store: any, i: number) => (
                                    <motion.div
                                        key={store.merchant_id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: i * 0.05 }}
                                        onClick={() => openStore(store)}
                                        className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm hover:shadow-xl hover:shadow-indigo-500/10 hover:border-indigo-100 cursor-pointer transition-all duration-300 group"
                                    >
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-black text-lg">
                                                    {(store.company_name || store.name || '?')[0].toUpperCase()}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-gray-900 text-sm">{store.company_name || store.name}</p>
                                                    <p className="text-xs text-gray-400 font-medium">{store.email}</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-1.5">
                                                <div className={`w-2 h-2 rounded-full ${STATUS_DOT[store.status] || 'bg-gray-300'}`} />
                                                <span className="text-xs font-bold text-gray-500 uppercase">{store.status}</span>
                                            </div>
                                        </div>

                                        {store.shop_domain && (
                                            <div className="flex items-center gap-2 mb-4 text-xs text-gray-500 font-medium bg-gray-50 rounded-xl px-3 py-2">
                                                <Zap className="w-3 h-3 text-green-500" />
                                                {store.shop_domain}
                                                <span className="ml-auto text-xs bg-green-50 text-green-600 px-2 py-0.5 rounded-full font-bold">SHOPIFY</span>
                                            </div>
                                        )}

                                        <div className="flex items-center justify-between mb-4">
                                            <span className={`text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full ${PLAN_COLOR[store.plan_type] || PLAN_COLOR.trial}`}>
                                                {store.plan_name || 'Trial'}
                                            </span>
                                            <span className="text-xs text-gray-400 font-medium">
                                                {store.joined_at ? new Date(store.joined_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: '2-digit' }) : ''}
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-3 gap-2">
                                            {[
                                                { label: 'Total', value: store.order_stats?.total || 0, color: 'text-gray-800' },
                                                { label: 'Confirmed', value: store.order_stats?.confirmed || 0, color: 'text-emerald-600' },
                                                { label: 'Cancelled', value: store.order_stats?.cancelled || 0, color: 'text-rose-500' },
                                            ].map(stat => (
                                                <div key={stat.label} className="bg-gray-50 rounded-xl p-3 text-center">
                                                    <p className={`text-lg font-black ${stat.color}`}>{stat.value}</p>
                                                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">{stat.label}</p>
                                                </div>
                                            ))}
                                        </div>

                                        <div className="mt-4 flex items-center justify-end gap-1 text-xs text-gray-400 group-hover:text-indigo-500 transition-colors">
                                            <Package className="w-3.5 h-3.5" />
                                            <span className="font-semibold">View Orders &rarr;</span>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </motion.div>
                )}

                {/* ORDERS VIEW */}
                {view === 'orders' && (
                    <motion.div key="orders" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                        <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left border-separate border-spacing-0">
                                    <thead>
                                        <tr className="bg-gray-50/80 text-xs font-black text-gray-400 uppercase tracking-widest">
                                            <th className="px-8 py-5 border-b border-gray-100">Order</th>
                                            <th className="px-8 py-5 border-b border-gray-100">Customer</th>
                                            <th className="px-8 py-5 border-b border-gray-100">Date</th>
                                            <th className="px-8 py-5 border-b border-gray-100 text-center">Status</th>
                                            <th className="px-8 py-5 border-b border-gray-100 text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-50">
                                        <AnimatePresence>
                                            {filteredOrders.length === 0 ? (
                                                <tr>
                                                    <td colSpan={5} className="px-8 py-16 text-center text-gray-400 text-sm font-medium">
                                                        No orders found for this merchant.
                                                    </td>
                                                </tr>
                                            ) : filteredOrders.map((o: any, i: number) => {
                                                const cfg = STATUS_CONFIG[o.verification_status] || STATUS_CONFIG.pending;
                                                const Icon = cfg.icon;
                                                return (
                                                    <motion.tr
                                                        key={o.id || i}
                                                        initial={{ opacity: 0 }}
                                                        animate={{ opacity: 1 }}
                                                        transition={{ delay: i * 0.03 }}
                                                        className="hover:bg-indigo-50/20 transition-all"
                                                    >
                                                        <td className="px-8 py-5">
                                                            <div className="flex items-center gap-3">
                                                                <div className="w-9 h-9 rounded-xl bg-gray-50 flex items-center justify-center border border-gray-100">
                                                                    <Hash className="w-4 h-4 text-gray-400" />
                                                                </div>
                                                                <p className="font-bold text-gray-900 text-sm">#{o.order_number}</p>
                                                            </div>
                                                        </td>
                                                        <td className="px-8 py-5">
                                                            <div className="flex items-center gap-2">
                                                                <User className="w-4 h-4 text-gray-300" />
                                                                <span className="text-sm font-semibold text-gray-600">{o.customer_name || '\u2014'}</span>
                                                            </div>
                                                        </td>
                                                        <td className="px-8 py-5">
                                                            <div className="flex items-center gap-2 text-xs text-gray-500 font-medium">
                                                                <Calendar className="w-3.5 h-3.5 text-gray-300" />
                                                                {o.created_at ? new Date(o.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) : ''}
                                                            </div>
                                                        </td>
                                                        <td className="px-8 py-5">
                                                            <div className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest border flex items-center gap-1.5 w-fit mx-auto ${cfg.color}`}>
                                                                <Icon className="w-3 h-3" />
                                                                {cfg.label}
                                                            </div>
                                                        </td>
                                                        <td className="px-8 py-5 text-right">
                                                            <span className="font-bold text-gray-800 text-sm">
                                                                {o.currency === 'INR' ? '\u20B9' : '$'}{o.order_amount || '\u2014'}
                                                            </span>
                                                        </td>
                                                    </motion.tr>
                                                );
                                            })}
                                        </AnimatePresence>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { adminApi } from '../../api';
import { formatCurrency } from '../../lib/utils';
import {
    Wallet, ArrowUpRight, ArrowDownLeft, DollarSign, IndianRupee,
    Layers, Plus, Tag, Clock, Calendar, MessageSquare,
    ShieldAlert, ShieldCheck, Settings, Activity, Zap,
    AlertTriangle, MoreHorizontal, Eye, Trash2, Send, User
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// ─── Admin Billing ───
export function AdminBilling() {
    const [overview, setOverview] = useState<any>(null);
    const [transactions, setTransactions] = useState<any[]>([]);
    const [newRate, setNewRate] = useState('');
    const [loading, setLoading] = useState(true);
    const [tab, setTab] = useState<'overview' | 'transactions' | 'pricing'>('overview');

    useEffect(() => {
        Promise.all([adminApi.getBillingOverview(), adminApi.getAllTransactions('page=1&limit=20'), adminApi.getPricing()])
            .then(([o, t, p]) => {
                setOverview(o.data?.data);
                setTransactions(t.data?.data?.transactions || []);
                setNewRate(String(p.data?.data?.per_order_rate || 1));
            })
            .finally(() => setLoading(false));
    }, []);

    const updateRate = async () => {
        await adminApi.updatePricing({ per_order_rate: parseFloat(newRate) });
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Processing Financial Architecture...</p>
        </div>
    );

    const o = overview || {};

    return (
        <div className="space-y-8 pb-10">
            <Helmet><title>Financial Control | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-emerald-600 rounded-xl shadow-lg shadow-emerald-600/20 text-white">
                        <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Financial Command</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Monitor global revenue cycles and manage node liquidity</p>
                    </div>
                </div>
            </div>

            <div className="grid sm:grid-cols-4 gap-6">
                {[
                    { label: 'Total Internal Revenue', value: formatCurrency(o.total_revenue || 0), icon: DollarSign, color: 'bg-indigo-600', sub: 'CUMULATIVE SYNC' },
                    { label: 'Active Cycle Revenue', value: formatCurrency(o.today_revenue || 0), icon: Zap, color: 'bg-emerald-600', sub: 'TODAY\'S HANDSHAKE' },
                    { label: 'Standard Protocol Rate', value: `₹${o.per_order_rate || 0}`, icon: IndianRupee, color: 'bg-purple-600', sub: 'PER VERIFICATION' },
                    { label: 'Liquidity Alerts', value: o.low_balance_merchants || 0, icon: AlertTriangle, color: 'bg-amber-600', sub: 'CRITICAL NODES' },
                ].map((c, i) => (
                    <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="glass-card rounded-[32px] p-6 border border-white shadow-xl shadow-gray-900/5 bg-white"
                    >
                        <div className={`w-12 h-12 ${c.color} rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/10`}>
                            <c.icon className="w-6 h-6 text-white" />
                        </div>
                        <p className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tighter mb-0.5">{c.value}</p>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{c.label}</p>
                        <p className="text-[9px] font-bold text-indigo-400 mt-2">{c.sub}</p>
                    </motion.div>
                ))}
            </div>

            <div className="flex gap-2 p-1.5 bg-gray-100 rounded-2xl w-fit">
                {(['overview', 'transactions', 'pricing'] as const).map(t => (
                    <button
                        key={t}
                        onClick={() => setTab(t)}
                        className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${tab === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        {t === 'pricing' ? 'Protocol Optimization' : t}
                    </button>
                ))}
            </div>

            <AnimatePresence mode="wait">
                {tab === 'transactions' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white">
                        <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                            <h3 className="text-xl font-black font-['Outfit'] tracking-tighter uppercase italic">Global Ledger</h3>
                            <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">View Full Archive</button>
                        </div>
                        <div className="divide-y divide-gray-50 max-h-[500px] overflow-y-auto">
                            {transactions.map((t: any, i: number) => (
                                <div key={i} className="flex items-center justify-between py-5 px-8 hover:bg-gray-50 group transition-colors">
                                    <div className="flex items-center gap-5">
                                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-sm group-hover:scale-110 transition-transform ${t.transaction_type === 'wallet_debit' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100'}`}>
                                            {t.transaction_type === 'wallet_debit' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900 tracking-tight">{t.description || (t.transaction_type === 'wallet_debit' ? 'Verification Deduction' : 'Liquidity Injection')}</p>
                                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.users?.company_name || t.users?.name || 'ANONYMOUS NODE'} • {new Date(t.created_at).toLocaleDateString()} • {new Date(t.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                        </div>
                                    </div>
                                    <span className={`text-lg font-black font-['Outfit'] tracking-tighter ${t.transaction_type === 'wallet_debit' ? 'text-rose-600' : 'text-emerald-600'}`}>
                                        {t.transaction_type === 'wallet_debit' ? '-' : '+'}₹{Number(t.amount).toFixed(2)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}

                {tab === 'pricing' && (
                    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="glass-card rounded-[40px] border border-white p-10 max-w-xl shadow-2xl bg-white relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 opacity-[0.03]">
                            <Zap className="w-48 h-48" />
                        </div>
                        <div className="relative z-10">
                            <h3 className="text-3xl font-black font-['Outfit'] tracking-tighter uppercase italic mb-8">Protocol Economics</h3>
                            <div className="space-y-6">
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-1">Current Intelligence Rate (₹/Verification)</label>
                                    <div className="relative group">
                                        <IndianRupee className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-indigo-600 transition-colors" />
                                        <input
                                            type="number"
                                            step="0.1"
                                            value={newRate}
                                            onChange={e => setNewRate(e.target.value)}
                                            className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-transparent rounded-[24px] text-lg font-black font-['Outfit'] focus:bg-white focus:border-indigo-100 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all"
                                        />
                                    </div>
                                </div>
                                <button onClick={updateRate} className="w-full py-5 bg-gray-900 text-white rounded-[24px] font-black text-sm shadow-xl shadow-gray-900/20 hover:bg-indigo-600 transition-all active:scale-95 flex items-center justify-center gap-3">
                                    Broadcast New Protocol <Send className="w-4 h-4" />
                                </button>
                                <p className="text-[10px] font-bold text-gray-400 text-center uppercase tracking-widest italic">Note: Changes propagate instantly to all active sub-nodes.</p>
                            </div>
                        </div>
                    </motion.div>
                )}


                {tab === 'overview' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
                        <div className="glass-card rounded-[40px] border border-white p-10 shadow-2xl bg-white">
                            <h3 className="text-xl font-black font-['Outfit'] tracking-tighter uppercase italic mb-8">Node Ecosystem Health</h3>
                            <div className="grid sm:grid-cols-2 gap-6">
                                {[
                                    { label: 'Network Reserve (All Users)', value: formatCurrency(o.total_wallet_balance || 0), icon: Wallet, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                                    { label: 'Synchronized Pulses Today', value: o.today_orders || 0, icon: Activity, color: 'text-blue-600', bg: 'bg-blue-50' },
                                    { label: 'Integrated Intelligence Nodes', value: o.total_merchants || 0, icon: Layers, color: 'text-purple-600', bg: 'bg-purple-50' },
                                    { label: 'Critical Liquidity Alerts', value: o.low_balance_merchants || 0, icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
                                ].map((item, i) => (
                                    <div key={i} className="flex items-center gap-6 p-6 bg-gray-50/50 rounded-3xl border border-gray-100 hover:bg-white hover:shadow-lg transition-all">
                                        <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center shrink-0`}>
                                            <item.icon className="w-7 h-7" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{item.label}</p>
                                            <p className="text-3xl font-black font-['Outfit'] tracking-tighter text-gray-900">{item.value}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

// ─── Admin Partners ───
export function AdminPartners() {
    const [partners, setPartners] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        adminApi.getPartners()
            .then(r => setPartners(r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Scanning Ecosystem Clusters...</p>
        </div>
    );

    return (
        <div className="space-y-8">
            <Helmet><title>Ecosystem Matrix | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-gray-900 rounded-xl shadow-lg shadow-gray-900/10 text-white">
                        <Layers className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Ecosystem Matrix</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Configure high-trust network nodes and partners</p>
                    </div>
                </div>
                <button className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-600/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Provision New Node
                </button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {partners.map((p: any, i: number) => (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        key={p.id || i}
                        className="glass-card rounded-3xl border border-gray-100 p-8 hover:shadow-2xl hover:shadow-indigo-500/5 transition-all duration-500 group relative overflow-hidden bg-white"
                    >
                        <div className="relative z-10">
                            <div className="flex justify-between items-start mb-6">
                                <h3 className="text-xl font-black text-gray-900 font-['Outfit'] tracking-tighter uppercase italic group-hover:text-indigo-600 transition-colors">{p.partner_name}</h3>
                                <div className={`w-2.5 h-2.5 rounded-full ${p.is_active ? 'bg-emerald-500' : 'bg-gray-300'} animate-pulse`} />
                            </div>
                            <p className="text-sm text-gray-400 font-medium leading-relaxed mb-6 italic line-clamp-2">"{p.short_description || p.category || 'Core Integrated Node'}"</p>
                            <div className="flex items-center justify-between pt-6 border-t border-gray-50">
                                <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${p.is_active ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-gray-50 text-gray-400 border-gray-100'}`}>
                                    {p.is_active ? 'Operational' : 'Decommissioned'}
                                </span>
                                <div className="flex gap-2">
                                    <button className="p-2.5 bg-gray-50 text-gray-400 rounded-xl hover:bg-gray-900 hover:text-white transition-all"><Settings className="w-4 h-4" /></button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>

            {partners.length === 0 && (
                <div className="py-24 text-center bg-gray-50/50 rounded-[40px] border border-dashed border-gray-200">
                    <Layers className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Zero Ecosystem Nodes Detected</p>
                </div>
            )}
        </div>
    );
}

// ─── Admin Blog ───
export function AdminBlog() {
    const [posts, setPosts] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        adminApi.getBlogPosts('page=1&limit=50')
            .then(r => setPosts(r.data?.data?.posts || r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Accessing Knowledge Archive...</p>
        </div>
    );

    return (
        <div className="space-y-8">
            <Helmet><title>Knowledge Propagation | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-purple-600 rounded-xl shadow-lg shadow-purple-600/20 text-white">
                        <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Knowledge Propagation</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Broadcast strategic intelligence and optimization logs</p>
                    </div>
                </div>
                <button className="px-6 py-3 bg-gray-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-gray-900/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Deploy New Intelligence
                </button>
            </div>

            <div className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white">
                <div className="divide-y divide-gray-50">
                    {posts.map((p: any, i: number) => (
                        <motion.div
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            key={p.id || i}
                            className="p-8 flex items-center justify-between hover:bg-gray-50 group transition-all"
                        >
                            <div className="flex items-center gap-6">
                                <div className="w-20 h-14 bg-gray-100 rounded-2xl overflow-hidden shadow-sm shrink-0 border border-gray-100 group-hover:scale-105 transition-transform">
                                    {p.featured_image_url ? <img src={p.featured_image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-300"><MessageSquare className="w-6 h-6" /></div>}
                                </div>
                                <div>
                                    <p className="text-lg font-bold text-gray-900 font-['Outfit'] tracking-tight mb-1 group-hover:text-indigo-600 transition-colors uppercase italic">{p.title}</p>
                                    <div className="flex items-center gap-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                        <span className="flex items-center gap-1.5 text-indigo-400"><Tag className="w-3 h-3" /> {p.category}</span>
                                        <span className="flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> {p.views_count || 0} READ CYCLE SYNC</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-8">
                                <span className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded-xl border ${p.is_published ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                                    {p.is_published ? 'Propagation Active' : 'Staged/Draft'}
                                </span>
                                <button className="p-3 bg-gray-50 text-gray-300 rounded-2xl hover:bg-white hover:text-indigo-600 hover:shadow-lg transition-all"><MoreHorizontal className="w-5 h-5" /></button>
                            </div>
                        </motion.div>
                    ))}
                </div>
                {posts.length === 0 && (
                    <div className="py-24 text-center bg-gray-50/50">
                        <MessageSquare className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Archive Empty - No Intelligence Deployed</p>
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Admin Support ───
export function AdminSupport() {
    const [tickets, setTickets] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        adminApi.getTickets('page=1&limit=50')
            .then(r => setTickets(r.data?.data?.tickets || r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Synchronizing Support Nodes...</p>
        </div>
    );

    const statusColor: any = {
        open: 'bg-blue-50 text-blue-600 border-blue-100',
        in_progress: 'bg-amber-50 text-amber-600 border-amber-100',
        resolved: 'bg-emerald-50 text-emerald-600 border-emerald-100',
        closed: 'bg-gray-50 text-gray-400 border-gray-100'
    };

    return (
        <div className="space-y-8">
            <Helmet><title>Support Gateway | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-blue-600 rounded-xl shadow-lg shadow-blue-600/20 text-white">
                        <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Support Gateway</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Resolve high-priority synchronization faults and tickets</p>
                    </div>
                </div>
            </div>

            <div className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white">
                <div className="divide-y divide-gray-50">
                    {tickets.map((t: any, i: number) => (
                        <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.05 }}
                            key={t.id || i}
                            className="p-8 flex items-center justify-between hover:bg-gray-50 transition-all group"
                        >
                            <div className="flex items-center gap-6">
                                <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-400 border border-gray-100 group-hover:bg-white transition-all shadow-sm">
                                    <MessageSquare className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1.5">Critical Protocol #{t.ticket_number}</p>
                                    <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] tracking-tight mb-1 group-hover:text-indigo-600 transition-colors uppercase italic">{t.subject}</h3>
                                    <div className="flex items-center gap-4 text-[10px] font-black text-gray-400 uppercase tracking-widest italic">
                                        <span className="flex items-center gap-1.5"><Zap className="w-3 h-3" /> Priority: {t.priority}</span>
                                        <span className="flex items-center gap-1.5"><Calendar className="w-3 h-3" /> Stamped: {new Date(t.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-8">
                                <span className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest border ${statusColor[t.status] || 'bg-gray-100 text-gray-400 border-gray-200'}`}>
                                    {t.status?.replace('_', ' ')}
                                </span>
                                <button className="p-3 bg-gray-50 text-gray-400 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"><ArrowUpRight className="w-5 h-5" /></button>
                            </div>
                        </motion.div>
                    ))}
                </div>
                {tickets.length === 0 && (
                    <div className="py-24 text-center bg-gray-50/50">
                        <ShieldCheck className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Ecosystem Status: Optimized - Zero Faults Detected</p>
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Admin Blacklist ───
export function AdminBlacklist() {
    const [items, setItems] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [phone, setPhone] = useState('');
    const [reason, setReason] = useState('');

    useEffect(() => {
        adminApi.getBlacklist('page=1&limit=100')
            .then(r => setItems(r.data?.data?.items || r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    const add = async () => {
        if (!phone) return;
        await adminApi.addBlacklist({ phone_number: phone, reason });
        setPhone('');
        setReason('');
        adminApi.getBlacklist('page=1&limit=100').then(r => setItems(r.data?.data?.items || r.data?.data || []));
    };

    const remove = async (id: string) => {
        await adminApi.removeBlacklist(id);
        setItems(p => p.filter(i => i.id !== id));
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-rose-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Syncing Threat Signatures...</p>
        </div>
    );

    return (
        <div className="space-y-8">
            <Helmet><title>Threat Protocols | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-rose-600 rounded-xl shadow-lg shadow-rose-600/20 text-white">
                        <ShieldAlert className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Threat Protocols</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Manage global blacklist signatures and risk identifiers</p>
                    </div>
                </div>
            </div>

            <div className="glass-card rounded-[40px] border border-white p-8 bg-white/50 backdrop-blur-md shadow-2xl shadow-rose-500/5">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em] mb-6">Provision New Blacklist Node</p>
                <div className="flex flex-col md:flex-row gap-4">
                    <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone Identifier..." className="flex-1 px-8 py-4 bg-white border border-gray-100 rounded-[24px] text-sm font-bold focus:ring-4 focus:ring-rose-500/5 outline-none transition-all shadow-sm" />
                    <input value={reason} onChange={e => setReason(e.target.value)} placeholder="Risk Detail..." className="flex-1 px-8 py-4 bg-white border border-gray-100 rounded-[24px] text-sm font-bold focus:ring-4 focus:ring-rose-500/5 outline-none transition-all shadow-sm" />
                    <button onClick={add} className="px-10 py-4 bg-rose-600 text-white rounded-[24px] text-[10px] font-black uppercase tracking-widest shadow-lg shadow-rose-600/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2">
                        <Plus className="w-4 h-4" /> Add Protocol
                    </button>
                </div>
            </div>

            <div className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white">
                <div className="divide-y divide-gray-50">
                    {items.map((item, i) => (
                        <motion.div
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            key={item.id || i}
                            className="p-8 flex items-center justify-between hover:bg-rose-50/10 transition-all group"
                        >
                            <div className="flex items-center gap-6">
                                <div className="w-14 h-14 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-500 border border-rose-100 group-hover:scale-110 transition-transform">
                                    <ShieldAlert className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="text-lg font-black text-gray-900 font-['Outfit'] tracking-tight mb-1 uppercase tracking-tighter">{item.phone_number_hash || item.phone_number || 'HIDDEN_ENDPOINT'}</p>
                                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5 italic font-medium"><Zap className="w-3 h-3 text-rose-400" /> {item.reason || 'IDENTIFIED AS HIGH RISK THREAT'}</p>
                                </div>
                            </div>
                            <button onClick={() => remove(item.id)} className="p-3 bg-gray-50 text-gray-400 rounded-2xl hover:bg-rose-600 hover:text-white transition-all shadow-sm"><Trash2 className="w-5 h-5" /></button>
                        </motion.div>
                    ))}
                </div>
                {items.length === 0 && (
                    <div className="py-24 text-center bg-gray-50/50">
                        <ShieldCheck className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Network Status: Secured - No active blacklist protocols</p>
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Admin Settings ───
export function AdminSettings() {
    const [settings, setSettings] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        adminApi.getSettings()
            .then(r => setSettings(r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    const save = async () => {
        setSaving(true);
        await adminApi.updateSettings({ settings: settings.map((s: any) => ({ setting_key: s.setting_key, setting_value: s.setting_value })) });
        setSaving(false);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Accessing Master Parameters...</p>
        </div>
    );

    return (
        <div className="space-y-8 max-w-4xl">
            <Helmet><title>System Configurations | Admin</title></Helmet>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-gray-900 rounded-xl shadow-lg shadow-gray-900/10 text-white">
                        <Settings className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">System Configurations</h1>
                        <p className="text-gray-500 text-sm font-medium italic">Adjust global ecosystem parameters and synchronization logic</p>
                    </div>
                </div>
            </div>

            <div className="glass-card rounded-[40px] border border-white p-10 bg-white/50 backdrop-blur-md shadow-2xl shadow-gray-900/5">
                <div className="space-y-8">
                    {Array.isArray(settings) && settings.map((s: any, i: number) => (
                        <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-8 border-b border-gray-100 last:border-0 last:pb-0">
                            <div className="max-w-md">
                                <p className="text-sm font-black text-gray-900 font-['Outfit'] uppercase tracking-tight mb-1">{s.setting_label || s.setting_key}</p>
                                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest italic">{s.setting_group || 'CORE_SYSTEM_PARAM'}</p>
                            </div>
                            <input
                                value={s.setting_value || ''}
                                onChange={e => {
                                    const ns = [...settings];
                                    ns[i] = { ...ns[i], setting_value: e.target.value };
                                    setSettings(ns);
                                }}
                                className="px-6 py-3 bg-white border border-gray-100 rounded-[18px] text-[10px] font-black uppercase tracking-widest w-full sm:w-64 focus:ring-4 focus:ring-indigo-500/5 outline-none transition-all shadow-sm"
                            />
                        </div>
                    ))}
                    {(!Array.isArray(settings) || settings.length === 0) && (
                        <div className="py-10 text-center text-gray-400">
                            <ShieldAlert className="w-12 h-12 mx-auto mb-4 opacity-10" />
                            <p className="text-sm font-bold uppercase tracking-widest italic">No customizable parameters detected</p>
                        </div>
                    )}
                </div>

                {Array.isArray(settings) && settings.length > 0 && (
                    <button
                        onClick={save}
                        disabled={saving}
                        className="mt-10 px-12 py-5 bg-gray-900 text-white rounded-[24px] font-black text-[10px] uppercase tracking-[0.3em] shadow-2xl shadow-gray-900/20 hover:bg-black transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
                    >
                        {saving ? 'Synchronizing Cluster...' : 'Commit Master Changes'} <Zap className="w-4 h-4" />
                    </button>
                )}
            </div>
        </div>
    );
}

// ─── Admin Activity Logs ───
export function AdminLogs() {
    const [logs, setLogs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        adminApi.getActivityLogs('page=1&limit=50')
            .then(r => setLogs(r.data?.data?.logs || r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Scanning Global Telemetry Logs...</p>
        </div>
    );

    return (
        <div className="space-y-8">
            <Helmet><title>Telemetry Logs | Admin</title></Helmet>
            <div className="flex items-center gap-3 mb-8">
                <div className="p-2.5 bg-gray-900 rounded-xl shadow-lg shadow-gray-900/10 text-white">
                    <Activity className="w-5 h-5" />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Telemetry Logs</h1>
                    <p className="text-gray-500 text-sm font-medium italic">Monitor every atomic event across the intelligence ecosystem</p>
                </div>
            </div>

            <div className="glass-card rounded-[40px] border border-white overflow-hidden shadow-2xl shadow-gray-900/5 bg-white">
                <div className="divide-y divide-gray-50 max-h-[700px] overflow-y-auto">
                    {logs.map((l: any, i: number) => (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: i * 0.02 }}
                            key={i}
                            className="p-6 px-10 hover:bg-gray-50 transition-all group flex items-center justify-between"
                        >
                            <div className="flex items-center gap-8">
                                <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest w-32 shrink-0">
                                    {new Date(l.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                </div>
                                <div>
                                    <p className="text-sm font-black text-gray-900 font-['Outfit'] tracking-tight uppercase italic group-hover:text-indigo-600 transition-colors">{l.action}</p>
                                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2 mt-1">
                                        <Layers className="w-3 h-3" /> ENTITY: {l.entity_type} <span className="text-indigo-200">|</span> <User className="w-3 h-3" /> NODE: {l.user_id?.slice(0, 12)}...
                                    </p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-[9px] font-bold text-gray-300 italic">{new Date(l.created_at).toLocaleDateString()}</p>
                            </div>
                        </motion.div>
                    ))}
                </div>
                {logs.length === 0 && (
                    <div className="py-24 text-center bg-gray-50/50">
                        <Activity className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Global Silence - No Telemetry Detected</p>
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Admin System Health ───
export function AdminHealth() {
    const [health, setHealth] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        adminApi.getSystemHealth()
            .then(r => setHealth(r.data?.data))
            .catch(() => setHealth({ status: 'error' }))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Scanning Infrastructure Clusters...</p>
        </div>
    );

    return (
        <div className="space-y-8">
            <Helmet><title>Infrastructure Health | Admin</title></Helmet>
            <div className="flex items-center gap-3 mb-8">
                <div className="p-2.5 bg-emerald-600 rounded-xl shadow-lg shadow-emerald-600/20 text-white">
                    <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Infrastructure Pulse</h1>
                    <p className="text-gray-500 text-sm font-medium italic">Monitor real-time system integrity and master node health</p>
                </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                    { label: 'Intelligence Status', value: health?.status?.toUpperCase() || 'UNKNOWN', icon: Zap, status: health?.status === 'healthy' ? 'good' : 'bad' },
                    { label: 'Ecosystem Registry', value: health?.database?.toUpperCase() || 'UNKNOWN', icon: Layers, status: health?.database === 'connected' ? 'good' : 'bad' },
                    { label: 'Sync Scheduler', value: health?.scheduler?.toUpperCase() || 'UNKNOWN', icon: Activity, status: health?.scheduler === 'running' ? 'good' : 'amber' },
                    { label: 'Continuous Uptime', value: health?.uptime || 'N/A', icon: Clock, status: 'neutral' },
                ].map((item, i) => (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                        key={i}
                        className="glass-card rounded-[32px] p-8 border border-white shadow-xl shadow-gray-900/5 bg-white flex flex-col items-center text-center"
                    >
                        <div className={`w-16 h-16 rounded-[24px] flex items-center justify-center mb-6 shadow-sm border ${item.status === 'good' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : item.status === 'bad' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-gray-50 text-gray-400 border-gray-100'}`}>
                            <item.icon className="w-8 h-8" />
                        </div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">{item.label}</p>
                        <div className="flex items-center gap-2">
                            {item.status !== 'neutral' && <div className={`w-2 h-2 rounded-full ${item.status === 'good' ? 'bg-emerald-500' : item.status === 'amber' ? 'bg-amber-500' : 'bg-rose-500'} animate-pulse`} />}
                            <p className={`text-2xl font-black font-['Outfit'] tracking-tighter ${item.status === 'good' ? 'text-emerald-600' : item.status === 'bad' ? 'text-rose-600' : 'text-gray-900'}`}>{item.value}</p>
                        </div>
                    </motion.div>
                ))}
            </div>

            <div className="bg-gray-900 rounded-[40px] p-12 text-white relative overflow-hidden shadow-2xl">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent" />
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-10">
                    <div className="max-w-xl">
                        <h3 className="text-3xl font-black font-['Outfit'] tracking-tighter uppercase italic mb-4">Integrity Diagnostics</h3>
                        <p className="text-gray-400 font-medium italic leading-relaxed">
                            Global verification sequences are currently operating within nominal parameters.
                            The intelligence engine is distributing load across 4 redundant clusters with
                            zero propagation delay detected in the current cycle.
                        </p>
                    </div>
                    <div className="flex gap-4">
                        <div className="px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-center">
                            <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-1">Latency</p>
                            <p className="text-xl font-bold font-['Outfit']">14ms</p>
                        </div>
                        <div className="px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-center">
                            <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-1">Throughput</p>
                            <p className="text-xl font-bold font-['Outfit']">1.2k/s</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

// ─── Admin Reviews ───────────────────────────────────────────────────────────
export function AdminReviews() {
    const [reviews, setReviews] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'featured'>('all');
    const [editId, setEditId] = useState<string | null>(null);
    const [editData, setEditData] = useState<any>({});
    const [saving, setSaving] = useState(false);

    const load = async () => {
        setLoading(true);
        const param = filter === 'all' ? '' : `status=${filter}`;
        adminApi.getReviews(param)
            .then(r => setReviews(r.data?.data?.reviews || r.data?.data || []))
            .finally(() => setLoading(false));
    };

    useEffect(() => { load(); }, [filter]);

    const handleUpdate = async (id: string, updates: any) => {
        setSaving(true);
        await adminApi.updateReview(id, updates);
        setSaving(false);
        await load();
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Delete this review permanently?')) return;
        await adminApi.deleteReview(id);
        await load();
    };

    const startEdit = (r: any) => {
        setEditId(r.id);
        setEditData({ title: r.title || '', body: r.body || '', admin_note: r.admin_note || '' });
    };

    const saveEdit = async () => {
        if (!editId) return;
        await handleUpdate(editId, editData);
        setEditId(null);
    };

    const stars = (n: number) => '★'.repeat(Math.max(0, n)) + '☆'.repeat(Math.max(0, 5 - n));

    return (
        <div className="space-y-6">
            <Helmet><title>Review Management | Admin</title></Helmet>

            <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-amber-500 rounded-xl text-white shadow-lg shadow-amber-500/20">
                        <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Review Management</h1>
                        <p className="text-gray-500 text-sm">Moderate, approve, and manage customer reviews</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    {(['all', 'pending', 'approved', 'featured'] as const).map(f => (
                        <button key={f} onClick={() => setFilter(f)}
                            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${filter === f ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                                }`}
                        >{f}</button>
                    ))}
                </div>
            </div>

            {loading ? (
                <div className="flex items-center justify-center py-24">
                    <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                </div>
            ) : reviews.length === 0 ? (
                <div className="py-24 text-center">
                    <MessageSquare className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No reviews found</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {reviews.map((r: any) => (
                        <motion.div key={r.id} layout className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                            {editId === r.id ? (
                                <div className="space-y-3">
                                    <input value={editData.title}
                                        onChange={e => setEditData((p: any) => ({ ...p, title: e.target.value }))}
                                        placeholder="Review title"
                                        className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-amber-400"
                                    />
                                    <textarea value={editData.body}
                                        onChange={e => setEditData((p: any) => ({ ...p, body: e.target.value }))}
                                        rows={3} placeholder="Review body"
                                        className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:border-amber-400"
                                    />
                                    <input value={editData.admin_note}
                                        onChange={e => setEditData((p: any) => ({ ...p, admin_note: e.target.value }))}
                                        placeholder="Admin note (internal)"
                                        className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-amber-400"
                                    />
                                    <div className="flex gap-2">
                                        <button onClick={saveEdit} disabled={saving} className="px-4 py-2 bg-amber-500 text-white rounded-lg text-sm font-bold disabled:opacity-50">Save</button>
                                        <button onClick={() => setEditId(null)} className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg text-sm font-bold">Cancel</button>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex gap-4">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2 flex-wrap">
                                            <div className="w-9 h-9 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-sm">
                                                {r.author_name?.[0]?.toUpperCase() || '?'}
                                            </div>
                                            <div>
                                                <div className="font-bold text-sm text-gray-900">{r.author_name}</div>
                                                <div className="text-xs text-gray-400">{r.author_company}{r.author_role ? ` · ${r.author_role}` : ''}</div>
                                            </div>
                                            <span className="text-amber-400 text-sm">{stars(r.rating || 5)}</span>
                                            <div className="ml-auto flex gap-1.5 flex-wrap">
                                                {r.is_approved ? (
                                                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-full">Approved</span>
                                                ) : (
                                                    <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs font-bold rounded-full">Pending</span>
                                                )}
                                                {r.is_featured && (
                                                    <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full">★ Featured</span>
                                                )}
                                            </div>
                                        </div>
                                        {r.title && <p className="font-semibold text-gray-800 text-sm mb-1">{r.title}</p>}
                                        <p className="text-gray-600 text-sm leading-relaxed">{r.body}</p>
                                        {r.admin_note && <p className="text-xs text-indigo-500 mt-2 italic">Note: {r.admin_note}</p>}
                                        <p className="text-xs text-gray-400 mt-2">{new Date(r.created_at).toLocaleDateString()}</p>
                                    </div>
                                    <div className="flex flex-col gap-2 flex-shrink-0 min-w-[90px]">
                                        {!r.is_approved ? (
                                            <button onClick={() => handleUpdate(r.id, { is_approved: true })}
                                                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition-colors"
                                            >✓ Approve</button>
                                        ) : (
                                            <button onClick={() => handleUpdate(r.id, { is_approved: false })}
                                                className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-xs font-bold transition-colors"
                                            >Unpublish</button>
                                        )}
                                        <button onClick={() => handleUpdate(r.id, { is_featured: !r.is_featured })}
                                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${r.is_featured ? 'bg-indigo-50 text-indigo-700' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                                        >{r.is_featured ? 'Unfeature' : '★ Feature'}</button>
                                        <button onClick={() => startEdit(r)} className="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 text-gray-600 rounded-lg text-xs font-bold transition-colors">✏ Edit</button>
                                        <button onClick={() => handleDelete(r.id)} className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg text-xs font-bold transition-colors">✕ Delete</button>
                                    </div>
                                </div>
                            )}
                        </motion.div>
                    ))}
                </div>
            )}
        </div>
    );
}

// ─── Admin Contact Inquiries ──────────────────────────────────────────────────
export function AdminContactInquiries() {
    const [inquiries, setInquiries] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [expanded, setExpanded] = useState<string | null>(null);

    const load = () => {
        adminApi.getContactInquiries()
            .then(r => setInquiries(r.data?.data?.inquiries || r.data?.data || []))
            .finally(() => setLoading(false));
    };

    useEffect(() => { load(); }, []);

    const markHandled = async (id: string) => {
        await adminApi.markInquiryHandled(id);
        load();
    };

    const parseDesc = (desc: string) => {
        const lines = (desc || '').split('\n');
        const data: any = {};
        const msgStart = lines.findIndex((l: string) => l === '');
        lines.slice(0, msgStart >= 0 ? msgStart : lines.length).forEach((l: string) => {
            const idx = l.indexOf(': ');
            if (idx > -1) { data[l.slice(0, idx).trim()] = l.slice(idx + 2).trim(); }
        });
        data.message = lines.slice((msgStart >= 0 ? msgStart : lines.length) + 1).join('\n').trim();
        return data;
    };

    return (
        <div className="space-y-6">
            <Helmet><title>Contact Inquiries | Admin</title></Helmet>
            <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-600/20">
                    <Send className="w-5 h-5" />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Contact Inquiries</h1>
                    <p className="text-gray-500 text-sm">Messages submitted via the public contact form</p>
                </div>
            </div>

            {loading ? (
                <div className="flex items-center justify-center py-24">
                    <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                </div>
            ) : inquiries.length === 0 ? (
                <div className="py-24 text-center">
                    <Send className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No contact inquiries yet</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {inquiries.map((inq: any) => {
                        const parsed = parseDesc(inq.description || '');
                        const isExpanded = expanded === inq.id;
                        return (
                            <div key={inq.id} className={`bg-white rounded-2xl border shadow-sm transition-all ${inq.status === 'resolved' ? 'border-emerald-100 opacity-75' : 'border-gray-100'}`}>
                                <div className="flex items-center gap-4 p-5 cursor-pointer" onClick={() => setExpanded(isExpanded ? null : inq.id)}>
                                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${inq.status === 'resolved' ? 'bg-emerald-400' : 'bg-blue-500 animate-pulse'}`} />
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold text-sm text-gray-900">{parsed.Name || 'Unknown'}</div>
                                        <div className="text-xs text-gray-400 truncate">{parsed.Email}{parsed.Company ? ` · ${parsed.Company}` : ''}</div>
                                    </div>
                                    <div className="text-xs text-gray-400 flex-shrink-0">{new Date(inq.created_at).toLocaleDateString()}</div>
                                    <span className={`px-2 py-0.5 text-xs font-bold rounded-full flex-shrink-0 ${inq.status === 'resolved' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>
                                        {inq.status === 'resolved' ? 'Handled' : 'New'}
                                    </span>
                                </div>
                                <AnimatePresence>
                                    {isExpanded && (
                                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                                            <div className="px-5 pb-5 border-t border-gray-50 pt-4 space-y-3">
                                                <div className="grid grid-cols-2 gap-2 text-sm">
                                                    {parsed.Email && <div><span className="text-gray-400 text-xs">Email: </span><a href={`mailto:${parsed.Email}`} className="text-blue-500 hover:underline">{parsed.Email}</a></div>}
                                                    {parsed.Phone && parsed.Phone !== 'N/A' && <div><span className="text-gray-400 text-xs">Phone: </span><span className="text-gray-700">{parsed.Phone}</span></div>}
                                                    {parsed.Company && parsed.Company !== 'N/A' && <div><span className="text-gray-400 text-xs">Company: </span><span className="text-gray-700">{parsed.Company}</span></div>}
                                                </div>
                                                {parsed.message && (
                                                    <div className="p-4 bg-gray-50 rounded-xl text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{parsed.message}</div>
                                                )}
                                                <div className="flex gap-2">
                                                    {parsed.Email && (
                                                        <a href={`mailto:${parsed.Email}?subject=Re: Your CODVerify Inquiry`}
                                                            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
                                                        >↩ Reply via Email</a>
                                                    )}
                                                    {inq.status !== 'resolved' && (
                                                        <button onClick={() => markHandled(inq.id)}
                                                            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition-colors"
                                                        >✓ Mark as Handled</button>
                                                    )}
                                                </div>
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

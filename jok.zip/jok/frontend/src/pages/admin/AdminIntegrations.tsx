import { useEffect, useState } from 'react';
import { adminApi } from '../../api';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
    Zap, Mail, Brain, DollarSign, CreditCard,
    CheckCircle, XCircle, RefreshCw, Save, Eye, EyeOff, IndianRupee
} from 'lucide-react';

type Tab = 'ai' | 'email' | 'pricing' | 'payments';

export default function AdminIntegrations() {
    const [tab, setTab] = useState<Tab>('ai');
    const [status, setStatus] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    // AI (Groq)
    const [groq, setGroq] = useState({ api_key: '', model: 'llama3-8b-8192', system_prompt: '' });
    const [showGroqKey, setShowGroqKey] = useState(false);

    // SMTP / Email
    const [smtp, setSmtp] = useState({ host: '', port: '587', username: '', password: '', from_email: '', from_name: 'CODVerify' });
    const [showSmtpPass, setShowSmtpPass] = useState(false);
    const [testEmail, setTestEmail] = useState('');

    // Per-country pricing
    const [pricing, setPricing] = useState<any[]>([]);

    // Payment gateways (read-only masked)
    const [gateways, setGateways] = useState<any>(null);

    useEffect(() => {
        Promise.all([
            adminApi.getIntegrationsStatus(),
            adminApi.getIntegrationsPricing(),
            adminApi.getPaymentGateways(),
        ]).then(([s, p, g]) => {
            setStatus(s.data?.data || s.data || null);
            setPricing(p.data?.data?.pricing || p.data?.pricing || []);
            setGateways(g.data?.data || g.data || null);
        }).catch(() => toast.error('Failed to load integrations'))
          .finally(() => setLoading(false));
    }, []);

    const handleSaveGroq = async () => {
        setSaving(true);
        try {
            await adminApi.saveGroqConfig(groq);
            toast.success('Groq AI configuration saved');
        } catch { toast.error('Failed to save Groq config'); }
        finally { setSaving(false); }
    };

    const handleTestGroq = async () => {
        try {
            const res = await adminApi.testGroqConnection();
            toast.success(res.data?.message || 'Groq connection successful');
        } catch { toast.error('Groq connection failed'); }
    };

    const handleSaveSmtp = async () => {
        setSaving(true);
        try {
            await adminApi.saveSmtpConfig(smtp);
            toast.success('SMTP configuration saved');
        } catch { toast.error('Failed to save SMTP config'); }
        finally { setSaving(false); }
    };

    const handleTestSmtp = async () => {
        try {
            await adminApi.testSmtpWebhook();
            toast.success('SMTP webhook test sent');
        } catch { toast.error('SMTP test failed'); }
    };

    const handleSendTestEmail = async () => {
        if (!testEmail) return toast.error('Enter a recipient email');
        try {
            await adminApi.sendTestEmail({ to_email: testEmail });
            toast.success(`Test email sent to ${testEmail}`);
        } catch { toast.error('Failed to send test email'); }
    };

    const handleSavePricing = async () => {
        setSaving(true);
        try {
            await adminApi.updateIntegrationsPricing({ pricing });
            toast.success('Per-country pricing updated');
        } catch { toast.error('Failed to update pricing'); }
        finally { setSaving(false); }
    };

    const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
        { id: 'ai', label: 'AI (Groq)', icon: Brain },
        { id: 'email', label: 'Email / SMTP', icon: Mail },
        { id: 'pricing', label: 'Country Pricing', icon: IndianRupee },
        { id: 'payments', label: 'Payment Gateways', icon: CreditCard },
    ];

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        </div>
    );

    return (
        <div className="p-6 max-w-5xl mx-auto">
            <div className="mb-8">
                <h1 className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tight">Integrations</h1>
                <p className="text-gray-500 text-sm mt-1">Configure AI, email, payment gateways, and per-country pricing.</p>
            </div>

            {/* Status badges */}
            {status && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                    {[
                        { label: 'Groq AI', ok: status.groq_configured },
                        { label: 'Email SMTP', ok: status.smtp_configured },
                        { label: 'Razorpay', ok: status.razorpay_configured },
                        { label: 'Stripe', ok: status.stripe_configured },
                    ].map(s => (
                        <div key={s.label} className={`flex items-center gap-2 px-4 py-3 rounded-xl border text-sm font-semibold ${s.ok ? 'bg-green-50 border-green-200 text-green-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
                            {s.ok ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            {s.label}
                        </div>
                    ))}
                </div>
            )}

            {/* Tabs */}
            <div className="flex gap-2 flex-wrap mb-8 border-b border-gray-100 pb-0">
                {tabs.map(t => (
                    <button key={t.id} onClick={() => setTab(t.id)}
                        className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl border-b-2 transition-all ${tab === t.id ? 'border-indigo-600 text-indigo-700 bg-indigo-50/60' : 'border-transparent text-gray-500 hover:text-gray-800'}`}>
                        <t.icon className="w-4 h-4" />
                        {t.label}
                    </button>
                ))}
            </div>

            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">

                {/* ── AI (Groq) ── */}
                {tab === 'ai' && (
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-7 space-y-5">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                                <Brain className="w-5 h-5 text-purple-600" />
                            </div>
                            <div>
                                <h2 className="font-bold text-gray-900">Groq AI Configuration</h2>
                                <p className="text-xs text-gray-400">Powers the AI chatbot on your platform.</p>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">API Key</label>
                            <div className="relative">
                                <input type={showGroqKey ? 'text' : 'password'} value={groq.api_key}
                                    onChange={e => setGroq(p => ({ ...p, api_key: e.target.value }))}
                                    placeholder="gsk_xxxxxxxx..."
                                    className="w-full pl-4 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400 font-mono" />
                                <button onClick={() => setShowGroqKey(s => !s)} className="absolute right-3 top-3 text-gray-400">
                                    {showGroqKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">Model</label>
                            <select value={groq.model} onChange={e => setGroq(p => ({ ...p, model: e.target.value }))}
                                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400">
                                <option value="llama3-8b-8192">Llama 3 8B (Fast)</option>
                                <option value="llama3-70b-8192">Llama 3 70B (Smart)</option>
                                <option value="mixtral-8x7b-32768">Mixtral 8x7B</option>
                                <option value="gemma2-9b-it">Gemma 2 9B</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">System Prompt</label>
                            <textarea rows={5} value={groq.system_prompt}
                                onChange={e => setGroq(p => ({ ...p, system_prompt: e.target.value }))}
                                placeholder="You are a helpful assistant for CODVerify..."
                                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400 resize-none" />
                        </div>
                        <div className="flex gap-3 pt-2">
                            <button onClick={handleSaveGroq} disabled={saving}
                                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-60">
                                <Save className="w-4 h-4" /> Save Config
                            </button>
                            <button onClick={handleTestGroq}
                                className="flex items-center gap-2 px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-200 transition-all">
                                <Zap className="w-4 h-4" /> Test Connection
                            </button>
                        </div>
                    </div>
                )}

                {/* ── Email / SMTP ── */}
                {tab === 'email' && (
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-7 space-y-5">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                                <Mail className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                                <h2 className="font-bold text-gray-900">SMTP Email Configuration</h2>
                                <p className="text-xs text-gray-400">Transactional emails: signup, password reset, invoices.</p>
                            </div>
                        </div>
                        <div className="grid sm:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">SMTP Host</label>
                                <input value={smtp.host} onChange={e => setSmtp(p => ({ ...p, host: e.target.value }))}
                                    placeholder="smtp.gmail.com" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">Port</label>
                                <input value={smtp.port} onChange={e => setSmtp(p => ({ ...p, port: e.target.value }))}
                                    placeholder="587" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">Username</label>
                                <input value={smtp.username} onChange={e => setSmtp(p => ({ ...p, username: e.target.value }))}
                                    placeholder="your@email.com" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">Password</label>
                                <div className="relative">
                                    <input type={showSmtpPass ? 'text' : 'password'} value={smtp.password}
                                        onChange={e => setSmtp(p => ({ ...p, password: e.target.value }))}
                                        placeholder="App password" className="w-full pl-4 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                                    <button onClick={() => setShowSmtpPass(s => !s)} className="absolute right-3 top-3 text-gray-400">
                                        {showSmtpPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">From Email</label>
                                <input value={smtp.from_email} onChange={e => setSmtp(p => ({ ...p, from_email: e.target.value }))}
                                    placeholder="noreply@codverify.tech" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-1.5">From Name</label>
                                <input value={smtp.from_name} onChange={e => setSmtp(p => ({ ...p, from_name: e.target.value }))}
                                    placeholder="CODVerify" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                            </div>
                        </div>
                        <div className="flex gap-3 pt-2 flex-wrap">
                            <button onClick={handleSaveSmtp} disabled={saving}
                                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-60">
                                <Save className="w-4 h-4" /> Save SMTP
                            </button>
                            <button onClick={handleTestSmtp}
                                className="flex items-center gap-2 px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-200 transition-all">
                                <Zap className="w-4 h-4" /> Test Webhook
                            </button>
                        </div>
                        <div className="border-t border-gray-100 pt-5">
                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Send Test Email</p>
                            <div className="flex gap-3">
                                <input value={testEmail} onChange={e => setTestEmail(e.target.value)}
                                    placeholder="recipient@example.com" type="email"
                                    className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-400" />
                                <button onClick={handleSendTestEmail}
                                    className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all">
                                    <Mail className="w-4 h-4" /> Send
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* ── Country Pricing ── */}
                {tab === 'pricing' && (
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-7">
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                                    <DollarSign className="w-5 h-5 text-green-600" />
                                </div>
                                <div>
                                    <h2 className="font-bold text-gray-900">Per-Country Pricing</h2>
                                    <p className="text-xs text-gray-400">Cost per verification per country and channel.</p>
                                </div>
                            </div>
                            <button onClick={handleSavePricing} disabled={saving}
                                className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 disabled:opacity-60">
                                <Save className="w-4 h-4" /> Save Pricing
                            </button>
                        </div>
                        {pricing.length === 0 ? (
                            <div className="text-center py-12 text-gray-400">
                                <RefreshCw className="w-8 h-8 mx-auto mb-3 opacity-40 animate-spin" />
                                <p className="text-sm">Loading pricing data...</p>
                            </div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="text-left border-b border-gray-100">
                                            <th className="pb-3 pr-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Country</th>
                                            <th className="pb-3 pr-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Channel</th>
                                            <th className="pb-3 pr-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Price (INR)</th>
                                            <th className="pb-3 text-xs font-bold text-gray-400 uppercase tracking-widest">Price (USD)</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-50">
                                        {pricing.map((row: any, i: number) => (
                                            <tr key={i} className="hover:bg-gray-50/50">
                                                <td className="py-3 pr-4 font-semibold text-gray-700">{row.country_code || row.country}</td>
                                                <td className="py-3 pr-4 text-gray-500">{row.channel}</td>
                                                <td className="py-3 pr-4">
                                                    <input type="number" step="0.01" value={row.price_inr ?? row.price ?? ''}
                                                        onChange={e => {
                                                            const updated = [...pricing];
                                                            updated[i] = { ...updated[i], price_inr: parseFloat(e.target.value) };
                                                            setPricing(updated);
                                                        }}
                                                        className="w-24 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-indigo-400 font-mono" />
                                                </td>
                                                <td className="py-3">
                                                    <input type="number" step="0.001" value={row.price_usd ?? ''}
                                                        onChange={e => {
                                                            const updated = [...pricing];
                                                            updated[i] = { ...updated[i], price_usd: parseFloat(e.target.value) };
                                                            setPricing(updated);
                                                        }}
                                                        className="w-24 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-indigo-400 font-mono" />
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                )}

                {/* ── Payment Gateways ── */}
                {tab === 'payments' && (
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-7 space-y-6">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center">
                                <CreditCard className="w-5 h-5 text-orange-600" />
                            </div>
                            <div>
                                <h2 className="font-bold text-gray-900">Payment Gateway Status</h2>
                                <p className="text-xs text-gray-400">Keys are configured via environment variables for security.</p>
                            </div>
                        </div>
                        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
                            <span className="font-bold">Note: </span>API keys are stored as environment variables on the server. The values shown below are masked for security. To update them, change the environment variables and restart the server.
                        </div>
                        {gateways ? (
                            <div className="grid sm:grid-cols-2 gap-4">
                                {Object.entries(gateways).map(([key, gw]: [string, any]) => {
                                    const isObj = gw && typeof gw === 'object';
                                    const configured = isObj ? (gw.configured ?? gw.enabled ?? false) : !!gw;
                                    const displayName = key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                                    return (
                                        <div key={key} className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-2">
                                            <div className="flex items-center justify-between">
                                                <p className="text-sm font-bold text-gray-700">{displayName}</p>
                                                {configured
                                                    ? <CheckCircle className="w-4 h-4 text-green-500" />
                                                    : <XCircle className="w-4 h-4 text-red-400" />}
                                            </div>
                                            {isObj && Object.entries(gw).map(([fk, fv]: [string, any]) => (
                                                <div key={fk} className="flex items-center justify-between gap-2">
                                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{fk.replace(/_/g, ' ')}</p>
                                                    <p className="text-xs font-mono text-gray-600 truncate max-w-[60%]">
                                                        {typeof fv === 'boolean' ? (fv ? 'Yes' : 'No') : (String(fv || '—'))}
                                                    </p>
                                                </div>
                                            ))}
                                            {!isObj && <p className="text-xs font-mono text-gray-600 truncate">{String(gw || '—')}</p>}
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <p className="text-gray-400 text-sm">No gateway data returned. Check server environment variables.</p>
                        )}
                    </div>
                )}
            </motion.div>
        </div>
    );
}

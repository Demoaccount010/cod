import { useState, useEffect, useRef } from 'react';
import api from '../../api/client';
import { toast } from 'sonner';
import { Briefcase, Plus, Trash2, Eye, EyeOff, Edit3, Star, RefreshCw, X, Check, AlertCircle, Calendar } from 'lucide-react';

const JOB_TYPES = ['Full-time', 'Part-time', 'Remote', 'Contract', 'Internship'];
const EXP_LEVELS = ['Fresher', 'Junior', 'Mid-level', 'Senior', 'Lead', 'Director'];
const DEPTS = ['Engineering', 'Product', 'Design', 'Marketing', 'Sales', 'Operations', 'Finance', 'HR', 'Legal', 'Customer Support', 'Data / Analytics', 'Other'];

const EMPTY_JOB = {
    title: '',
    department: DEPTS[0],
    location: '',
    job_type: 'Full-time',
    experience_level: 'Mid-level',
    salary_min: '',
    salary_max: '',
    salary_currency: 'INR',
    salary_disclosed: true,
    description: '',
    requirements: '',
    benefits: '',
    how_to_apply: '',
    application_email: 'careers@codverify.tech',
    application_url: '',
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    is_active: true,
    is_featured: false,
    slots: 1,
};

function RichEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
    const editorRef = useRef<HTMLDivElement>(null);

    const execCmd = (cmd: string, arg?: string) => {
        document.execCommand(cmd, false, arg);
        if (editorRef.current) onChange(editorRef.current.innerHTML);
    };

    return (
        <div className="border border-white/10 rounded-2xl overflow-hidden focus-within:border-[#635BFF]/50">
            {/* Toolbar */}
            <div className="flex flex-wrap gap-1 p-3 bg-white/5 border-b border-white/10">
                {[
                    { label: 'B', cmd: 'bold', title: 'Bold' },
                    { label: 'I', cmd: 'italic', title: 'Italic' },
                    { label: 'U', cmd: 'underline', title: 'Underline' },
                ].map(b => (
                    <button
                        key={b.cmd}
                        type="button"
                        title={b.title}
                        onClick={() => execCmd(b.cmd)}
                        className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-sm font-bold transition-colors"
                    >
                        {b.label}
                    </button>
                ))}
                <div className="w-px bg-white/10 mx-1" />
                <button type="button" title="Heading 1" onClick={() => execCmd('formatBlock', '<h1>')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-xs font-bold transition-colors">H1</button>
                <button type="button" title="Heading 2" onClick={() => execCmd('formatBlock', '<h2>')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-xs font-bold transition-colors">H2</button>
                <button type="button" title="Paragraph" onClick={() => execCmd('formatBlock', '<p>')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-xs font-bold transition-colors">P</button>
                <div className="w-px bg-white/10 mx-1" />
                <button type="button" title="Unordered List" onClick={() => execCmd('insertUnorderedList')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-xs font-bold transition-colors">• List</button>
                <button type="button" title="Ordered List" onClick={() => execCmd('insertOrderedList')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-[#635BFF]/20 hover:text-white rounded-lg text-xs font-bold transition-colors">1. List</button>
                <div className="w-px bg-white/10 mx-1" />
                <button type="button" title="Clear Formatting" onClick={() => execCmd('removeFormat')} className="px-3 py-1.5 bg-white/5 text-white/60 hover:bg-red-500/20 hover:text-red-400 rounded-lg text-xs font-bold transition-colors">Clear</button>
            </div>
            {/* Editable area */}
            <div
                ref={editorRef}
                contentEditable
                suppressContentEditableWarning
                onInput={() => { if (editorRef.current) onChange(editorRef.current.innerHTML); }}
                dangerouslySetInnerHTML={{ __html: value }}
                className="min-h-[240px] p-5 text-white/80 text-sm leading-relaxed outline-none
                    [&_h1]:text-xl [&_h1]:font-black [&_h1]:text-white [&_h1]:mb-3 [&_h1]:mt-4
                    [&_h2]:text-base [&_h2]:font-bold [&_h2]:text-white/80 [&_h2]:mb-2 [&_h2]:mt-4
                    [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:space-y-1
                    [&_ol]:list-decimal [&_ol]:pl-5 [&_ol]:space-y-1
                    [&_strong]:font-bold [&_strong]:text-white
                    bg-transparent"
            />
        </div>
    );
}

function JobForm({ initial, onSubmit, onCancel, loading }: { initial: any; onSubmit: (d: any) => void; onCancel: () => void; loading: boolean }) {
    const [form, setForm] = useState<any>(initial);

    const set = (k: string, v: any) => setForm((p: any) => ({ ...p, [k]: v }));

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!form.title || !form.department || !form.location || !form.description) {
            toast.error('Please fill all required fields (title, department, location, description)');
            return;
        }
        onSubmit({
            ...form,
            salary_min: form.salary_min ? Number(form.salary_min) : null,
            salary_max: form.salary_max ? Number(form.salary_max) : null,
            slots: Number(form.slots) || 1,
            end_date: form.end_date || null,
            start_date: form.start_date || null,
        });
    };

    const input = "w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder-white/20 focus:outline-none focus:border-[#635BFF]/50 transition-colors";
    const select = input + " cursor-pointer";
    const label = "text-white/60 text-xs font-bold uppercase tracking-wider mb-1.5 block";

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                    <label className={label}>Job Title *</label>
                    <input className={input} value={form.title} onChange={e => set('title', e.target.value)} placeholder="e.g. Senior Backend Engineer" required />
                </div>
                <div>
                    <label className={label}>Department *</label>
                    <select className={select} value={form.department} onChange={e => set('department', e.target.value)}>
                        {DEPTS.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                </div>
                <div>
                    <label className={label}>Location *</label>
                    <input className={input} value={form.location} onChange={e => set('location', e.target.value)} placeholder="Remote / Delhi NCR / Mumbai" required />
                </div>
                <div>
                    <label className={label}>Job Type</label>
                    <select className={select} value={form.job_type} onChange={e => set('job_type', e.target.value)}>
                        {JOB_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                <div>
                    <label className={label}>Experience Level</label>
                    <select className={select} value={form.experience_level} onChange={e => set('experience_level', e.target.value)}>
                        {EXP_LEVELS.map(e => <option key={e} value={e}>{e}</option>)}
                    </select>
                </div>
                <div>
                    <label className={label}>Number of Openings</label>
                    <input type="number" min={1} className={input} value={form.slots} onChange={e => set('slots', e.target.value)} />
                </div>
            </div>

            {/* Salary */}
            <div className="p-5 bg-white/3 rounded-2xl border border-white/8 space-y-4">
                <div className="flex items-center justify-between">
                    <h4 className="text-white font-bold text-sm">Salary Range</h4>
                    <label className="flex items-center gap-2 cursor-pointer">
                        <span className="text-white/40 text-xs">Disclose salary</span>
                        <button
                            type="button"
                            onClick={() => set('salary_disclosed', !form.salary_disclosed)}
                            className={`w-10 h-5 rounded-full transition-colors ${form.salary_disclosed ? 'bg-[#635BFF]' : 'bg-white/10'}`}
                        >
                            <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform mx-0.5 ${form.salary_disclosed ? 'translate-x-5' : 'translate-x-0'}`} />
                        </button>
                    </label>
                </div>
                {form.salary_disclosed && (
                    <div className="grid grid-cols-3 gap-3">
                        <div>
                            <label className={label}>Currency</label>
                            <select className={select} value={form.salary_currency} onChange={e => set('salary_currency', e.target.value)}>
                                <option value="INR">INR (₹)</option>
                                <option value="USD">USD ($)</option>
                                <option value="EUR">EUR (€)</option>
                            </select>
                        </div>
                        <div>
                            <label className={label}>Min / yr</label>
                            <input type="number" className={input} value={form.salary_min} onChange={e => set('salary_min', e.target.value)} placeholder="1200000" />
                        </div>
                        <div>
                            <label className={label}>Max / yr</label>
                            <input type="number" className={input} value={form.salary_max} onChange={e => set('salary_max', e.target.value)} placeholder="2000000" />
                        </div>
                    </div>
                )}
            </div>

            {/* Dates */}
            <div className="grid sm:grid-cols-2 gap-4">
                <div>
                    <label className={label}>Start Date</label>
                    <input type="date" className={input} value={form.start_date} onChange={e => set('start_date', e.target.value)} />
                </div>
                <div>
                    <label className={label}>End Date (auto-expires)</label>
                    <input type="date" className={input} value={form.end_date} onChange={e => set('end_date', e.target.value)} min={form.start_date || undefined} />
                    <p className="text-white/30 text-xs mt-1">Leave empty = no expiry</p>
                </div>
            </div>

            {/* Description — Rich Editor */}
            <div>
                <label className={label}>Job Description * <span className="text-[#635BFF] normal-case font-normal">(supports H1, H2, Bold, Lists)</span></label>
                <RichEditor value={form.description} onChange={v => set('description', v)} />
            </div>

            {/* Apply Info */}
            <div className="p-5 bg-white/3 rounded-2xl border border-white/8 space-y-4">
                <h4 className="text-white font-bold text-sm">Application Details</h4>
                <div>
                    <label className={label}>How to Apply Instructions</label>
                    <textarea rows={3} className={input + " resize-none"} value={form.how_to_apply} onChange={e => set('how_to_apply', e.target.value)} placeholder="e.g. Send resume to careers@codverify.tech with subject: [Role] Name" />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                        <label className={label}>Application Email</label>
                        <input type="email" className={input} value={form.application_email} onChange={e => set('application_email', e.target.value)} placeholder="careers@codverify.tech" />
                    </div>
                    <div>
                        <label className={label}>Application URL (optional)</label>
                        <input type="url" className={input} value={form.application_url} onChange={e => set('application_url', e.target.value)} placeholder="https://forms.example.com/apply" />
                    </div>
                </div>
            </div>

            {/* Flags */}
            <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-3 cursor-pointer">
                    <button
                        type="button"
                        onClick={() => set('is_active', !form.is_active)}
                        className={`w-10 h-5 rounded-full transition-colors ${form.is_active ? 'bg-emerald-500' : 'bg-white/10'}`}
                    >
                        <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform mx-0.5 ${form.is_active ? 'translate-x-5' : 'translate-x-0'}`} />
                    </button>
                    <span className="text-white/70 text-sm">Active (visible on site)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                    <button
                        type="button"
                        onClick={() => set('is_featured', !form.is_featured)}
                        className={`w-10 h-5 rounded-full transition-colors ${form.is_featured ? 'bg-amber-500' : 'bg-white/10'}`}
                    >
                        <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform mx-0.5 ${form.is_featured ? 'translate-x-5' : 'translate-x-0'}`} />
                    </button>
                    <span className="text-white/70 text-sm">Featured (pinned at top)</span>
                </label>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
                <button type="button" onClick={onCancel} className="px-6 py-3 bg-white/5 text-white/60 rounded-xl font-bold text-sm hover:bg-white/10 transition-colors border border-white/10">
                    <X className="w-4 h-4 inline mr-2" />Cancel
                </button>
                <button type="submit" disabled={loading} className="flex-1 px-6 py-3 bg-[#635BFF] text-white rounded-xl font-bold text-sm hover:bg-[#5244e3] transition-colors disabled:opacity-50">
                    {loading ? <RefreshCw className="w-4 h-4 inline mr-2 animate-spin" /> : <Check className="w-4 h-4 inline mr-2" />}
                    Save Job Posting
                </button>
            </div>
        </form>
    );
}

export default function AdminJobs() {
    const [jobs, setJobs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [mode, setMode] = useState<'list' | 'create' | 'edit'>('list');
    const [editJob, setEditJob] = useState<any>(null);
    const [templateLoading, setTemplateLoading] = useState(false);
    const [newJobData, setNewJobData] = useState<any>(EMPTY_JOB);

    const load = () => {
        setLoading(true);
        api.get('/api/v1/admin/jobs')
            .then((r: any) => setJobs(r.data?.data?.jobs || []))
            .finally(() => setLoading(false));
    };

    useEffect(() => { load(); }, []);

    const loadTemplate = async () => {
        setTemplateLoading(true);
        try {
            const r = await api.get('/api/v1/admin/jobs/template');
            setNewJobData({ ...EMPTY_JOB, ...(r.data?.data?.template || {}) });
            setMode('create');
        } catch {
            setNewJobData(EMPTY_JOB);
            setMode('create');
        } finally {
            setTemplateLoading(false);
        }
    };

    const handleCreate = async (data: any) => {
        setSaving(true);
        try {
            await api.post('/api/v1/admin/jobs', data);
            toast.success('Job posting created!');
            setMode('list');
            load();
        } catch (e: any) {
            toast.error(e?.response?.data?.detail || 'Failed to create job');
        } finally {
            setSaving(false);
        }
    };

    const handleUpdate = async (data: any) => {
        setSaving(true);
        try {
            await api.put(`/api/v1/admin/jobs/${editJob.id}`, data);
            toast.success('Job updated!');
            setMode('list');
            setEditJob(null);
            load();
        } catch (e: any) {
            toast.error(e?.response?.data?.detail || 'Failed to update job');
        } finally {
            setSaving(false);
        }
    };

    const toggleJob = async (job: any) => {
        try {
            await api.post(`/api/v1/admin/jobs/${job.id}/toggle`);
            toast.success(job.is_active ? 'Job deactivated' : 'Job activated');
            load();
        } catch {
            toast.error('Failed to toggle job');
        }
    };

    const deleteJob = async (job: any) => {
        if (!window.confirm(`Delete "${job.title}"? This cannot be undone.`)) return;
        try {
            await api.delete(`/api/v1/admin/jobs/${job.id}`);
            toast.success('Job deleted');
            load();
        } catch {
            toast.error('Failed to delete job');
        }
    };

    const expireOld = async () => {
        try {
            const r = await api.post('/api/v1/admin/jobs/expire-old');
            toast.success(r.data?.message || 'Done');
            load();
        } catch {
            toast.error('Failed');
        }
    };

    const today = new Date().toISOString().split('T')[0];

    return (
        <div className="p-6 space-y-6">
            {/* Header */}
            <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-black text-white font-['Outfit'] flex items-center gap-3">
                        <Briefcase className="w-7 h-7 text-[#635BFF]" /> Job Postings
                    </h1>
                    <p className="text-white/40 text-sm mt-1">{jobs.length} total postings</p>
                </div>
                <div className="flex gap-3">
                    {mode === 'list' && (
                        <>
                            <button onClick={expireOld} className="px-4 py-2 bg-white/5 text-white/60 rounded-xl text-sm font-bold hover:bg-white/10 transition-colors border border-white/10 flex items-center gap-2">
                                <RefreshCw className="w-4 h-4" /> Expire Old
                            </button>
                            <button
                                onClick={loadTemplate}
                                disabled={templateLoading}
                                className="px-5 py-2.5 bg-[#635BFF] text-white rounded-xl text-sm font-bold hover:bg-[#5244e3] transition-colors flex items-center gap-2 disabled:opacity-50"
                            >
                                {templateLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                                Create Job (From Template)
                            </button>
                        </>
                    )}
                    {mode !== 'list' && (
                        <button onClick={() => { setMode('list'); setEditJob(null); }} className="px-4 py-2 bg-white/5 text-white/60 rounded-xl text-sm font-bold hover:bg-white/10 transition-colors border border-white/10">
                            ← Back to List
                        </button>
                    )}
                </div>
            </div>

            {/* Create / Edit Form */}
            {(mode === 'create' || mode === 'edit') && (
                <div className="bg-[#0d2444] border border-white/10 rounded-[28px] p-8">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2.5 bg-[#635BFF]/15 rounded-xl">
                            {mode === 'create' ? <Plus className="w-5 h-5 text-[#635BFF]" /> : <Edit3 className="w-5 h-5 text-[#635BFF]" />}
                        </div>
                        <div>
                            <h2 className="text-lg font-black text-white">{mode === 'create' ? 'New Job Posting' : 'Edit Job Posting'}</h2>
                            {mode === 'create' && <p className="text-white/30 text-xs">Template pre-filled — just customize the variables</p>}
                        </div>
                    </div>
                    <JobForm
                        initial={mode === 'create' ? newJobData : { ...EMPTY_JOB, ...editJob }}
                        onSubmit={mode === 'create' ? handleCreate : handleUpdate}
                        onCancel={() => { setMode('list'); setEditJob(null); }}
                        loading={saving}
                    />
                </div>
            )}

            {/* Job List */}
            {mode === 'list' && (
                <div className="space-y-3">
                    {loading ? (
                        <div className="flex items-center justify-center py-16">
                            <RefreshCw className="w-8 h-8 text-[#635BFF] animate-spin" />
                        </div>
                    ) : jobs.length === 0 ? (
                        <div className="py-20 text-center border border-dashed border-white/10 rounded-[28px]">
                            <Briefcase className="w-12 h-12 text-white/10 mx-auto mb-4" />
                            <h3 className="text-white font-bold mb-2">No job postings yet</h3>
                            <p className="text-white/30 text-sm mb-6">Click "Create Job (From Template)" to get started with a professional template</p>
                            <button onClick={loadTemplate} className="px-6 py-3 bg-[#635BFF] text-white rounded-xl font-bold text-sm hover:bg-[#5244e3] transition-colors">
                                <Plus className="w-4 h-4 inline mr-2" /> Create First Job
                            </button>
                        </div>
                    ) : jobs.map(job => {
                        const isExpired = job.end_date && job.end_date.split('T')[0] < today;
                        const daysLeft = job.end_date ? Math.max(0, Math.ceil((new Date(job.end_date).getTime() - Date.now()) / 86400000)) : null;
                        return (
                            <div
                                key={job.id}
                                className={`p-6 rounded-[20px] border transition-all ${job.is_active && !isExpired ? 'border-white/10 bg-white/3' : 'border-white/5 bg-white/1 opacity-60'}`}
                            >
                                <div className="flex flex-wrap items-start gap-4">
                                    <div className="flex-1 min-w-0">
                                        <div className="flex flex-wrap items-center gap-2 mb-2">
                                            {job.is_featured && <Star className="w-4 h-4 text-amber-400" />}
                                            <span className="text-xs px-2 py-0.5 bg-[#635BFF]/15 text-[#635BFF] rounded-full border border-[#635BFF]/20 font-bold">{job.department}</span>
                                            <span className="text-xs px-2 py-0.5 bg-white/5 text-white/40 rounded-full border border-white/10 font-bold">{job.job_type}</span>
                                            <span className="text-xs px-2 py-0.5 bg-white/5 text-white/40 rounded-full border border-white/10 font-bold">{job.experience_level}</span>
                                            {isExpired && <span className="text-xs px-2 py-0.5 bg-red-500/20 text-red-400 rounded-full border border-red-500/20 font-bold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Expired</span>}
                                            {!isExpired && daysLeft !== null && (
                                                <span className={`text-xs px-2 py-0.5 rounded-full border font-bold flex items-center gap-1 ${daysLeft <= 7 ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-white/5 text-white/30 border-white/10'}`}>
                                                    <Calendar className="w-3 h-3" /> {daysLeft}d left
                                                </span>
                                            )}
                                        </div>
                                        <h3 className="text-white font-black text-lg font-['Outfit']">{job.title}</h3>
                                        <p className="text-white/40 text-sm mt-1">{job.location} · {job.slots} opening{job.slots !== 1 ? 's' : ''}</p>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                        <button onClick={() => { setEditJob(job); setMode('edit'); }} className="p-2.5 bg-white/5 text-white/40 hover:text-[#635BFF] hover:bg-[#635BFF]/10 rounded-xl transition-colors border border-white/10" title="Edit">
                                            <Edit3 className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => toggleJob(job)} className={`p-2.5 rounded-xl transition-colors border ${job.is_active ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20' : 'bg-white/5 text-white/30 border-white/10 hover:bg-emerald-500/10 hover:text-emerald-400 hover:border-emerald-500/20'}`} title={job.is_active ? 'Deactivate' : 'Activate'}>
                                            {job.is_active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                                        </button>
                                        <button onClick={() => deleteJob(job)} className="p-2.5 bg-white/5 text-white/40 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-colors border border-white/10" title="Delete">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { MessageSquare, Eye, EyeOff, ShieldCheck, Zap, Sparkles, ArrowRight, Lock, Mail, RefreshCw } from 'lucide-react';
import { authApi } from '../../api';

export default function LoginPage() {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [show, setShow] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [emailNotVerified, setEmailNotVerified] = useState(false);
    const [resendLoading, setResendLoading] = useState(false);
    const [resendSent, setResendSent] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setEmailNotVerified(false);
        setLoading(true);
        try {
            await login(email, password);
            navigate('/dashboard');
        } catch (err: any) {
            const detail = err.response?.data?.detail || '';
            if (err.response?.status === 403 && detail.toLowerCase().includes('verify')) {
                setEmailNotVerified(true);
                setError('Please verify your email before logging in.');
            } else {
                setError(detail || 'Authentication failed. Verify your credentials.');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleResend = async () => {
        if (!email) {
            setError('Please enter your email address above first.');
            return;
        }
        setResendLoading(true);
        try {
            await authApi.resendVerification(email);
            setResendSent(true);
        } catch {
            setError('Failed to resend. Please try again.');
        } finally {
            setResendLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-white flex overflow-hidden">
            <Helmet><title>Log in - CODVerify Intelligence</title></Helmet>

            {/* Left Side: Brand Experience */}
            <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden premium-gradient">
                <div className="absolute inset-0">
                    {/* Animated Background Elements */}
                    <motion.div
                        animate={{
                            scale: [1, 1.2, 1],
                            rotate: [0, 90, 0],
                            opacity: [0.3, 0.5, 0.3]
                        }}
                        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                        className="absolute -top-24 -left-24 w-96 h-96 bg-indigo-400 rounded-full blur-[120px]"
                    />
                    <motion.div
                        animate={{
                            scale: [1, 1.3, 1],
                            rotate: [0, -90, 0],
                            opacity: [0.2, 0.4, 0.2]
                        }}
                        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                        className="absolute -bottom-48 -right-48 w-[500px] h-[500px] bg-purple-500 rounded-full blur-[150px]"
                    />
                </div>

                <div className="relative z-10 w-full flex flex-col justify-between p-16">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-4"
                    >
                        <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center shadow-2xl">
                            <MessageSquare className="w-7 h-7 text-white" />
                        </div>
                        <span className="text-3xl font-black text-white font-['Outfit'] tracking-tighter">CODVerify<span className="text-indigo-300">.</span></span>
                    </motion.div>

                    <div className="max-w-xl">
                        <motion.div
                            initial={{ opacity: 0, x: -30 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 }}
                        >
                            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-lg rounded-full border border-white/10 mb-8">
                                <Sparkles className="w-4 h-4 text-amber-400" />
                                <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Intelligence V2.4 Active</span>
                            </div>
                            <h2 className="text-6xl font-extrabold text-white font-['Outfit'] tracking-tight mb-6 leading-[1.1]">
                                Secure Your <br />
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-purple-200 italic">E-Commerce</span> Revenue<span className="text-indigo-400">.</span>
                            </h2>
                            <p className="text-indigo-100/70 text-lg font-medium leading-relaxed mb-12">
                                Eliminate RTO friction with our neural verification engine.
                                Predict behavioral patterns before they impact your bottom line.
                            </p>
                        </motion.div>

                        <div className="grid grid-cols-2 gap-8">
                            {[
                                { label: 'RTO REDUCTION', value: '42.8%', icon: ShieldCheck },
                                { label: 'SYNC LATENCY', value: '< 240ms', icon: Zap },
                            ].map((stat, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.4 + (i * 0.1) }}
                                    className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6"
                                >
                                    <stat.icon className="w-5 h-5 text-indigo-300 mb-3" />
                                    <p className="text-2xl font-bold text-white font-['Outfit']">{stat.value}</p>
                                    <p className="text-[10px] font-bold text-indigo-200/50 uppercase tracking-widest mt-1">{stat.label}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>

                    <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.7 }}
                        className="text-xs font-bold text-indigo-300/40 uppercase tracking-[0.4em]"
                    >
                        Trusted by 1,200+ Global Enterprises
                    </motion.p>
                </div>
            </div>

            {/* Right Side: Authentication Form */}
            <div className="flex-1 flex flex-col justify-center px-8 lg:px-24 py-12 relative">
                <div className="absolute top-0 right-0 p-12 opacity-[0.03] lg:hidden">
                    <MessageSquare className="w-40 h-40 text-black" />
                </div>

                <div className="w-full max-w-sm mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mb-12"
                    >
                        <div className="lg:hidden flex items-center gap-3 mb-8">
                            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
                                <MessageSquare className="w-5 h-5 text-white" />
                            </div>
                            <span className="text-xl font-bold text-gray-900 font-['Outfit']">CODVerify</span>
                        </div>
                        <h1 className="text-4xl font-extrabold text-gray-900 font-['Outfit'] tracking-tight mb-2 italic">Access Portal</h1>
                        <p className="text-gray-400 font-medium">Re-establish your intelligence connection</p>
                    </motion.div>

                    <AnimatePresence mode="wait">
                        {error && (
                            <motion.div
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 10 }}
                                className="mb-8 space-y-3"
                            >
                                <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-bold shadow-sm">
                                    <AlertTriangle className="w-5 h-5 shrink-0" />
                                    {error}
                                </div>
                                {emailNotVerified && (
                                    <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl">
                                        {resendSent ? (
                                            <p className="text-amber-700 text-sm font-bold text-center">
                                                ✅ Verification email sent! Check your inbox.
                                            </p>
                                        ) : (
                                            <div className="flex items-center justify-between gap-3">
                                                <p className="text-amber-700 text-xs font-medium">Didn't get the verification email?</p>
                                                <button
                                                    type="button"
                                                    onClick={handleResend}
                                                    disabled={resendLoading}
                                                    className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 text-white rounded-xl text-xs font-bold hover:bg-amber-600 transition-all disabled:opacity-60 shrink-0"
                                                >
                                                    {resendLoading ? (
                                                        <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                                    ) : (
                                                        <RefreshCw className="w-3 h-3" />
                                                    )}
                                                    Resend
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </motion.div>
                        )}
                    </AnimatePresence>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-5">
                            <div className="group">
                                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Identity Identifier</label>
                                <div className="relative">
                                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                    <input
                                        type="email"
                                        required
                                        value={email}
                                        onChange={e => setEmail(e.target.value)}
                                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border border-gray-100 rounded-[20px] text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all placeholder:text-gray-300"
                                        placeholder="node@network.com"
                                    />
                                </div>
                            </div>
                            <div className="group">
                                <div className="flex justify-between items-center mb-2">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Neural Key</label>
                                    <Link to="/forgot-password" className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 uppercase tracking-widest transition-colors">Reset Protocol?</Link>
                                </div>
                                <div className="relative">
                                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                    <input
                                        type={show ? 'text' : 'password'}
                                        required
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        className="w-full pl-12 pr-12 py-4 bg-gray-50/50 border border-gray-100 rounded-[20px] text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all placeholder:text-gray-300"
                                        placeholder="••••••••••••"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShow(!show)}
                                        className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-indigo-600 transition-colors"
                                    >
                                        {show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full py-4 bg-gray-900 text-white rounded-[20px] font-bold text-sm shadow-2xl shadow-gray-900/20 hover:bg-black transition-all group overflow-hidden relative active:scale-[0.98]"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                            <span className="relative z-10 flex items-center justify-center gap-2">
                                {loading ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                        Authenticating...
                                    </>
                                ) : (
                                    <>
                                        Initiate Access
                                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                    </>
                                )}
                            </span>
                        </button>
                    </form>

                    <div className="mt-10 text-center">
                        <p className="text-sm font-medium text-gray-400">
                            New segment administrator?
                            <Link to="/signup" className="ml-2 text-indigo-600 font-bold hover:text-indigo-800 transition-colors decoration-indigo-200 decoration-2 underline-offset-4 hover:underline">
                                Deploy Account
                            </Link>
                        </p>
                    </div>
                </div>

                <div className="mt-auto pt-10 flex justify-center gap-8 opacity-20">
                    <p className="text-[9px] font-black uppercase tracking-[0.4em]">Encrypted</p>
                    <p className="text-[9px] font-black uppercase tracking-[0.4em]">Cloud Native</p>
                    <p className="text-[9px] font-black uppercase tracking-[0.4em]">Neural v2</p>
                </div>
            </div>
        </div>
    );
}

const AlertTriangle = ({ className }: { className?: string }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
);

import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Loader2, MessageSquare, ArrowRight, Mail } from 'lucide-react';
import { authApi } from '../../api';

type Status = 'verifying' | 'success' | 'error' | 'expired';

export default function VerifyEmailPage() {
    const { token } = useParams<{ token: string }>();
    const navigate = useNavigate();
    const [status, setStatus] = useState<Status>('verifying');
    const [errorMsg, setErrorMsg] = useState('');
    const [countdown, setCountdown] = useState(5);

    useEffect(() => {
        if (!token) {
            setStatus('error');
            setErrorMsg('No verification token found in URL.');
            return;
        }

        authApi.verifyEmail(token)
            .then(() => {
                setStatus('success');
                // Countdown to redirect to login
                const interval = setInterval(() => {
                    setCountdown(prev => {
                        if (prev <= 1) {
                            clearInterval(interval);
                            navigate('/login');
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
                return () => clearInterval(interval);
            })
            .catch((err: any) => {
                const detail = err.response?.data?.detail || 'Verification failed.';
                if (detail.toLowerCase().includes('expired')) {
                    setStatus('expired');
                } else {
                    setStatus('error');
                }
                setErrorMsg(detail);
            });
    }, [token, navigate]);

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-6">
            <Helmet>
                <title>
                    {status === 'verifying' ? 'Verifying Email...' :
                        status === 'success' ? 'Email Verified! - CODVerify' :
                            'Verification Failed - CODVerify'}
                </title>
            </Helmet>

            <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="max-w-md w-full bg-white rounded-[32px] shadow-2xl shadow-indigo-500/10 border border-indigo-50 p-10 text-center"
            >
                {/* Logo */}
                <div className="flex items-center justify-center gap-3 mb-8">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xl font-black text-gray-900 font-['Outfit'] tracking-tight">
                        CODVerify<span className="text-indigo-500">.</span>
                    </span>
                </div>

                {/* Verifying State */}
                {status === 'verifying' && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-6"
                    >
                        <div className="w-20 h-20 rounded-full bg-indigo-50 flex items-center justify-center mx-auto">
                            <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-extrabold text-gray-900 font-['Outfit'] mb-2">
                                Verifying Your Email
                            </h1>
                            <p className="text-gray-400 text-sm font-medium">
                                Please wait while we confirm your email address...
                            </p>
                        </div>
                    </motion.div>
                )}

                {/* Success State */}
                {status === 'success' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                            <CheckCircle className="w-10 h-10 text-emerald-500" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-extrabold text-gray-900 font-['Outfit'] mb-2">
                                Email Verified! 🎉
                            </h1>
                            <p className="text-gray-400 text-sm font-medium mb-6">
                                Your account is now active. You'll be redirected to login in{' '}
                                <span className="font-bold text-indigo-600">{countdown}s</span>.
                            </p>
                        </div>
                        <Link
                            to="/login"
                            className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gray-900 text-white rounded-2xl font-bold text-sm hover:bg-black transition-all group"
                        >
                            Go to Login
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Link>
                    </motion.div>
                )}

                {/* Expired State */}
                {status === 'expired' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="w-20 h-20 rounded-full bg-amber-50 flex items-center justify-center mx-auto">
                            <Mail className="w-10 h-10 text-amber-500" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-extrabold text-gray-900 font-['Outfit'] mb-2">
                                Link Expired
                            </h1>
                            <p className="text-gray-400 text-sm font-medium mb-2">
                                This verification link has expired (valid for 24 hours).
                            </p>
                            <p className="text-gray-400 text-sm">
                                Please log in and request a new verification email.
                            </p>
                        </div>
                        <Link
                            to="/login"
                            className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-indigo-600 text-white rounded-2xl font-bold text-sm hover:bg-indigo-700 transition-all"
                        >
                            Back to Login
                        </Link>
                    </motion.div>
                )}

                {/* Error State */}
                {status === 'error' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="w-20 h-20 rounded-full bg-rose-50 flex items-center justify-center mx-auto">
                            <XCircle className="w-10 h-10 text-rose-500" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-extrabold text-gray-900 font-['Outfit'] mb-2">
                                Verification Failed
                            </h1>
                            <p className="text-gray-400 text-sm font-medium">
                                {errorMsg || 'This link is invalid or has already been used.'}
                            </p>
                        </div>
                        <Link
                            to="/login"
                            className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gray-900 text-white rounded-2xl font-bold text-sm hover:bg-black transition-all"
                        >
                            Back to Login
                        </Link>
                    </motion.div>
                )}
            </motion.div>
        </div>
    );
}

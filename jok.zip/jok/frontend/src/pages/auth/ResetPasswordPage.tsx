import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Eye, EyeOff, Lock, CheckCircle, AlertTriangle, ArrowRight } from 'lucide-react';
import { authApi } from '../../api';

const PASSWORD_RULES = [
    { label: 'At least 8 characters', test: (p: string) => p.length >= 8 },
    { label: 'One uppercase letter', test: (p: string) => /[A-Z]/.test(p) },
    { label: 'One lowercase letter', test: (p: string) => /[a-z]/.test(p) },
    { label: 'One number', test: (p: string) => /\d/.test(p) },
    { label: 'One special character', test: (p: string) => /[!@#$%^&*(),.?":{}|<>]/.test(p) },
];

export default function ResetPasswordPage() {
    const { token } = useParams<{ token: string }>();
    const navigate = useNavigate();
    const [password, setPassword] = useState('');
    const [confirm, setConfirm] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const allRulesPassed = PASSWORD_RULES.every(r => r.test(password));
    const passwordsMatch = password === confirm && confirm.length > 0;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!allRulesPassed) {
            setError('Password does not meet all requirements.');
            return;
        }
        if (!passwordsMatch) {
            setError('Passwords do not match.');
            return;
        }

        setLoading(true);
        try {
            await authApi.resetPassword({ token, new_password: password });
            setSuccess(true);
            setTimeout(() => navigate('/login'), 3000);
        } catch (err: any) {
            const detail = err.response?.data?.detail;
            setError(typeof detail === 'string' ? detail : (detail?.message || 'Reset failed. The link may have expired.'));
        } finally {
            setLoading(false);
        }
    };

    if (!token) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-6">
                <div className="text-center">
                    <p className="text-gray-500 font-medium">Invalid reset link.</p>
                    <Link to="/forgot-password" className="text-indigo-600 font-bold">Request a new one →</Link>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-6">
            <Helmet>
                <title>Reset Password - CODVerify</title>
            </Helmet>

            <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="max-w-md w-full bg-white rounded-[32px] shadow-2xl shadow-indigo-500/10 border border-indigo-50 p-10"
            >
                {/* Logo */}
                <div className="flex items-center gap-3 mb-8">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xl font-black text-gray-900 font-['Outfit'] tracking-tight">
                        CODVerify<span className="text-indigo-500">.</span>
                    </span>
                </div>

                <AnimatePresence mode="wait">
                    {!success ? (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                        >
                            <div className="mb-8">
                                <h1 className="text-3xl font-extrabold text-gray-900 font-['Outfit'] tracking-tight mb-2">
                                    Set New Password
                                </h1>
                                <p className="text-gray-400 text-sm font-medium">
                                    Choose a strong password to secure your account.
                                </p>
                            </div>

                            {error && (
                                <motion.div
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-bold"
                                >
                                    <AlertTriangle className="w-5 h-5 shrink-0" />
                                    {error}
                                </motion.div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-5">
                                {/* New Password */}
                                <div className="group">
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">
                                        New Password
                                    </label>
                                    <div className="relative">
                                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                        <input
                                            type={showPassword ? 'text' : 'password'}
                                            required
                                            value={password}
                                            onChange={e => setPassword(e.target.value)}
                                            className="w-full pl-12 pr-12 py-4 bg-gray-50/50 border border-gray-100 rounded-[20px] text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all placeholder:text-gray-300"
                                            placeholder="Create a strong password"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-indigo-600 transition-colors"
                                        >
                                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>

                                {/* Password Strength Rules */}
                                {password.length > 0 && (
                                    <motion.div
                                        initial={{ opacity: 0, height: 0 }}
                                        animate={{ opacity: 1, height: 'auto' }}
                                        className="grid grid-cols-2 gap-1.5 px-1"
                                    >
                                        {PASSWORD_RULES.map(rule => (
                                            <div
                                                key={rule.label}
                                                className={`flex items-center gap-1.5 text-[11px] font-semibold transition-colors ${rule.test(password) ? 'text-emerald-600' : 'text-gray-300'}`}
                                            >
                                                <div className={`w-1.5 h-1.5 rounded-full ${rule.test(password) ? 'bg-emerald-500' : 'bg-gray-200'}`} />
                                                {rule.label}
                                            </div>
                                        ))}
                                    </motion.div>
                                )}

                                {/* Confirm Password */}
                                <div className="group">
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">
                                        Confirm Password
                                    </label>
                                    <div className="relative">
                                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                        <input
                                            type={showConfirm ? 'text' : 'password'}
                                            required
                                            value={confirm}
                                            onChange={e => setConfirm(e.target.value)}
                                            className={`w-full pl-12 pr-12 py-4 bg-gray-50/50 border rounded-[20px] text-sm font-bold focus:ring-4 outline-none transition-all placeholder:text-gray-300 ${confirm.length > 0
                                                    ? passwordsMatch
                                                        ? 'border-emerald-300 focus:ring-emerald-500/10 focus:border-emerald-500'
                                                        : 'border-rose-300 focus:ring-rose-500/10 focus:border-rose-500'
                                                    : 'border-gray-100 focus:ring-indigo-500/10 focus:border-indigo-500'
                                                }`}
                                            placeholder="Repeat your password"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowConfirm(!showConfirm)}
                                            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-indigo-600 transition-colors"
                                        >
                                            {showConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                        </button>
                                    </div>
                                    {confirm.length > 0 && !passwordsMatch && (
                                        <p className="text-[11px] text-rose-500 font-semibold mt-1.5 ml-1">Passwords do not match</p>
                                    )}
                                </div>

                                <button
                                    type="submit"
                                    disabled={loading || !allRulesPassed || !passwordsMatch}
                                    className="w-full py-4 bg-gray-900 text-white rounded-[20px] font-bold text-sm shadow-xl hover:bg-black transition-all group flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    {loading ? (
                                        <>
                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                            Resetting Password...
                                        </>
                                    ) : (
                                        <>
                                            Reset Password
                                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                        </>
                                    )}
                                </button>
                            </form>
                        </motion.div>
                    ) : (
                        <motion.div
                            key="success"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-center py-4"
                        >
                            <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-emerald-500/20">
                                <CheckCircle className="w-10 h-10 text-emerald-500" />
                            </div>
                            <h2 className="text-2xl font-extrabold text-gray-900 font-['Outfit'] mb-3">
                                Password Reset!
                            </h2>
                            <p className="text-gray-400 text-sm font-medium mb-6">
                                Your password has been updated. Redirecting you to login...
                            </p>
                            <Link
                                to="/login"
                                className="inline-flex items-center gap-2 px-8 py-3.5 bg-gray-900 text-white rounded-2xl font-bold text-sm hover:bg-black transition-all"
                            >
                                Go to Login
                                <ArrowRight className="w-4 h-4" />
                            </Link>
                        </motion.div>
                    )}
                </AnimatePresence>
            </motion.div>
        </div>
    );
}

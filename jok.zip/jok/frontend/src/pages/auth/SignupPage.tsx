import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { MessageSquare, Eye, EyeOff, CheckCircle, Sparkles, ShieldCheck, Zap, User, Building, Mail, Phone, Lock, ArrowRight, AlertTriangle, ChevronDown } from 'lucide-react';

const COUNTRY_CODES = [
    { code: '+91', flag: '🇮🇳', name: 'India', placeholder: '98765 43210' },
    { code: '+1', flag: '🇺🇸', name: 'USA', placeholder: '(555) 000-0000' },
    { code: '+44', flag: '🇬🇧', name: 'UK', placeholder: '7700 900000' },
    { code: '+61', flag: '🇦🇺', name: 'Australia', placeholder: '400 000 000' },
    { code: '+971', flag: '🇦🇪', name: 'UAE', placeholder: '50 000 0000' },
];

export default function SignupPage() {
    const { signup } = useAuth();
    const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', company_name: '' });
    const [show, setShow] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [countryCode, setCountryCode] = useState(COUNTRY_CODES[0]);
    const [phoneLocal, setPhoneLocal] = useState('');
    const [showCountryDrop, setShowCountryDrop] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const fullPhone = `${countryCode.code}${phoneLocal.replace(/\D/g, '')}`;
        try {
            await signup({ ...form, phone: fullPhone });
            setSuccess(true);
        } catch (err: any) {
            const detail = err.response?.data?.detail;
            setError(typeof detail === 'string' ? detail : (detail?.message || 'Registration failed. Please try again.'));
        } finally {
            setLoading(false);
        }
    };

    const update = (key: string, val: string) => setForm(p => ({ ...p, [key]: val }));

    if (success) {
        return (
            <div className="min-h-screen bg-white flex items-center justify-center p-6 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-50 via-white to-white">
                <Helmet><title>Thank You - CODVerify</title></Helmet>
                <motion.div
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    className="max-w-lg w-full glass-card rounded-[40px] p-10 sm:p-12 border border-white shadow-2xl shadow-indigo-500/10 text-center relative overflow-hidden"
                >
                    <div className="absolute top-0 right-0 p-12 opacity-5">
                        <ShieldCheck className="w-40 h-40 text-emerald-600" />
                    </div>

                    <div className="relative z-10">
                        <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-emerald-500/20">
                            <CheckCircle className="w-10 h-10 text-white" />
                        </div>
                        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 font-['Outfit'] tracking-tight mb-3 italic">Thank You!</h1>
                        <p className="text-gray-500 font-semibold text-sm sm:text-base mb-2">
                            Thank you for showing your interest in CODVerify.
                        </p>
                        <p className="text-gray-400 font-medium text-sm max-w-sm mx-auto mb-8 leading-relaxed">
                            Our representative will contact you soon and help you to activate your account with a personalized plan tailored to your business.
                        </p>
                        <div className="bg-indigo-50 border border-indigo-200 rounded-2xl px-5 py-4 mb-8 max-w-sm mx-auto">
                            <p className="text-indigo-700 font-bold text-xs sm:text-sm">📧 We've also sent a verification email to your address.</p>
                        </div>
                        <Link to="/login" className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-4 bg-gray-900 text-white rounded-[24px] font-bold text-sm shadow-2xl shadow-gray-900/20 hover:bg-black transition-all active:scale-95 group">
                            Go to Login
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Link>
                    </div>
                </motion.div>
            </div>
        );
    }


    return (
        <div className="min-h-screen bg-white flex overflow-hidden">
            <Helmet><title>Deploy Node - CODVerify Intelligence</title></Helmet>

            {/* Left Side: Brand Experience */}
            <div className="hidden lg:flex lg:w-[45%] relative overflow-hidden premium-gradient">
                <div className="absolute inset-0">
                    <motion.div
                        animate={{
                            scale: [1, 1.2, 1],
                            opacity: [0.3, 0.4, 0.3]
                        }}
                        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                        className="absolute top-1/2 left-0 w-96 h-96 bg-indigo-400 rounded-full blur-[120px]"
                    />
                </div>

                <div className="relative z-10 w-full flex flex-col justify-between p-16">
                    <Link to="/" className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center shadow-2xl">
                            <MessageSquare className="w-7 h-7 text-white" />
                        </div>
                        <span className="text-3xl font-black text-white font-['Outfit'] tracking-tighter">CODVerify<span className="text-indigo-300">.</span></span>
                    </Link>

                    <div>
                        <motion.div
                            initial={{ opacity: 0, x: -30 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 }}
                        >
                            <h2 className="text-5xl font-extrabold text-white font-['Outfit'] tracking-tight mb-8 leading-[1.1]">
                                Activate Your <br />
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-purple-200 italic">Neural Shield</span> Today<span className="text-indigo-400">.</span>
                            </h2>
                            <ul className="space-y-6">
                                {[
                                    { text: '50 Neural Credits included', icon: Zap, color: 'text-amber-400' },
                                    { text: 'Ecosystem link in < 120s', icon: LinkIcon, color: 'text-indigo-300' },
                                    { text: 'Zero deployment cost', icon: Sparkles, color: 'text-purple-300' },
                                ].map((t, i) => (
                                    <motion.li
                                        key={i}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: 0.4 + (i * 0.1) }}
                                        className="flex items-center gap-4 text-indigo-100/90 font-bold"
                                    >
                                        <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                                            <t.icon className={`w-5 h-5 ${t.color}`} />
                                        </div>
                                        {t.text}
                                    </motion.li>
                                ))}
                            </ul>
                        </motion.div>
                    </div>

                    <div className="bg-white/5 backdrop-blur-md rounded-3xl p-6 border border-white/10">
                        <p className="text-sm font-medium text-indigo-100/60 leading-relaxed italic">
                            "CODVerify transformed our RTO landscape within 48 hours. The ROI was instantaneous."
                        </p>
                        <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mt-4">Chief Operations @ Global Logistics</p>
                    </div>
                </div>
            </div>

            {/* Right Side: Registration Form */}
            <div className="flex-1 flex flex-col justify-center px-8 lg:px-24 py-12 relative overflow-y-auto sidebar-scroll">
                <div className="w-full max-w-lg mx-auto">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mb-10"
                    >
                        <div className="lg:hidden flex items-center gap-3 mb-8">
                            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
                                <MessageSquare className="w-5 h-5 text-white" />
                            </div>
                            <span className="text-xl font-bold text-gray-900 font-['Outfit']">CODVerify</span>
                        </div>
                        <h1 className="text-4xl font-extrabold text-gray-900 font-['Outfit'] tracking-tight mb-2 italic">Node Deployment</h1>
                        <p className="text-gray-400 font-medium">Provision your administrative environment</p>
                    </motion.div>

                    {error && (
                        <motion.div
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="mb-8 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-bold"
                        >
                            <AlertTriangle className="w-5 h-5" />
                            {error}
                        </motion.div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-2 gap-5">
                            <div className="group">
                                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Admin Identity</label>
                                <div className="relative">
                                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                    <input required value={form.name} onChange={e => update('name', e.target.value)} className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" placeholder="Full Name" />
                                </div>
                            </div>
                            <div className="group">
                                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Ecosystem Label</label>
                                <div className="relative">
                                    <Building className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                    <input required value={form.company_name} onChange={e => update('company_name', e.target.value)} className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" placeholder="Company Name" />
                                </div>
                            </div>
                        </div>

                        <div className="group">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Network Endpoint (Email)</label>
                            <div className="relative">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                <input type="email" required value={form.email} onChange={e => update('email', e.target.value)} className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" placeholder="node@network.com" />
                            </div>
                        </div>

                        <div className="group">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Mobile Number</label>
                            <div className="flex gap-2">
                                {/* Country Code Dropdown */}
                                <div className="relative flex-shrink-0">
                                    <button
                                        type="button"
                                        onClick={() => setShowCountryDrop(!showCountryDrop)}
                                        className="flex items-center gap-2 px-3 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold hover:border-indigo-300 transition-all min-w-[100px]"
                                    >
                                        <span className="text-lg">{countryCode.flag}</span>
                                        <span className="text-gray-700">{countryCode.code}</span>
                                        <ChevronDown className="w-3 h-3 text-gray-400" />
                                    </button>
                                    {showCountryDrop && (
                                        <div className="absolute top-full left-0 mt-2 w-52 bg-white rounded-2xl border border-gray-100 shadow-2xl shadow-gray-900/10 z-50 overflow-hidden">
                                            {COUNTRY_CODES.map(c => (
                                                <button
                                                    key={c.code}
                                                    type="button"
                                                    onClick={() => { setCountryCode(c); setShowCountryDrop(false); }}
                                                    className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold ${countryCode.code === c.code ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}
                                                >
                                                    <span className="text-lg">{c.flag}</span>
                                                    <span>{c.name}</span>
                                                    <span className="ml-auto text-gray-400 text-xs">{c.code}</span>
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                {/* Phone number input */}
                                <div className="relative flex-1">
                                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                                    <input
                                        required
                                        value={phoneLocal}
                                        onChange={e => setPhoneLocal(e.target.value)}
                                        className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
                                        placeholder={countryCode.placeholder}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="group">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1 group-focus-within:text-indigo-600 transition-colors">Neural Access Key</label>
                            <div className="relative">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-300 group-focus-within:text-indigo-500 transition-colors" />
                                <input type={show ? 'text' : 'password'} required minLength={8} value={form.password} onChange={e => update('password', e.target.value)} className="w-full pl-11 pr-12 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" placeholder="Min 8 characters required" />
                                <button type="button" onClick={() => setShow(!show)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 hover:text-indigo-600 transition-colors">
                                    {show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                </button>
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full py-4 bg-gray-900 text-white rounded-[24px] font-bold text-sm shadow-2xl shadow-gray-900/20 hover:bg-black transition-all group overflow-hidden relative active:scale-[0.98] mt-4"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                            <span className="relative z-10 flex items-center justify-center gap-2">
                                {loading ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                        Provisioning Node...
                                    </>
                                ) : (
                                    <>
                                        Initiate Deployment
                                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                    </>
                                )}
                            </span>
                        </button>
                    </form>

                    <div className="mt-10 text-center">
                        <p className="text-sm font-medium text-gray-400">
                            Already part of the network?
                            <Link to="/login" className="ml-2 text-indigo-600 font-bold hover:text-indigo-800 transition-colors decoration-indigo-200 decoration-2 underline-offset-4 hover:underline">
                                Re-establish Link
                            </Link>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}

const LinkIcon = ({ className }: { className?: string }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
    </svg>
);

import SEO from '../../components/SEO';
import { useEffect, useState } from 'react';

import { Briefcase, MapPin, Clock, DollarSign, Users, ArrowRight, Sparkles, ChevronDown, ChevronUp, Calendar, Mail, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const API_BASE = import.meta.env.VITE_API_URL || 'https://api.codverify.tech';

async function fetchJobs(department?: string): Promise<any> {
    const params = department ? `?department=${encodeURIComponent(department)}` : '';
    const r = await fetch(`${API_BASE}/api/v1/jobs${params}`);
    return r.json();
}

function SalaryBadge({ job }: { job: any }) {
    if (!job.salary_disclosed) return <span className="text-white/30 italic text-xs">Salary not disclosed</span>;
    const sym = job.salary_currency === 'USD' ? '$' : '₹';
    const fmt = (n: number) => n >= 100000 ? `${(n / 100000).toFixed(1)}L` : `${(n / 1000).toFixed(0)}K`;
    if (job.salary_min && job.salary_max) return <span>{sym}{fmt(job.salary_min)} – {sym}{fmt(job.salary_max)}/yr</span>;
    if (job.salary_min) return <span>From {sym}{fmt(job.salary_min)}/yr</span>;
    return null;
}

function JobCard({ job, expanded, onToggle }: { job: any; expanded: boolean; onToggle: () => void }) {
    const daysLeft = job.end_date
        ? Math.max(0, Math.ceil((new Date(job.end_date).getTime() - Date.now()) / 86400000))
        : null;

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-[28px] border transition-all duration-500 overflow-hidden ${expanded
                ? 'border-[#635BFF]/40 bg-white/5 shadow-2xl shadow-[#635BFF]/10'
                : 'border-white/8 bg-white/3 hover:border-white/15 hover:bg-white/5'
                } ${job.is_featured ? 'border-amber-500/30' : ''}`}
        >
            {/* Header */}
            <button
                onClick={onToggle}
                className="w-full p-8 flex flex-col sm:flex-row sm:items-center gap-6 text-left group"
                aria-expanded={expanded}
            >
                {job.is_featured && (
                    <div className="absolute top-4 right-4 px-3 py-1 bg-amber-500/20 text-amber-400 text-[10px] font-black uppercase tracking-widest rounded-full border border-amber-500/30">
                        ⭐ Featured
                    </div>
                )}

                <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap gap-2 mb-3">
                        <span className="px-3 py-1 bg-[#635BFF]/15 text-[#635BFF] text-[10px] font-black uppercase tracking-wider rounded-full border border-[#635BFF]/20">
                            {job.department}
                        </span>
                        <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded-full border ${job.job_type === 'Remote'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-white/5 text-white/40 border-white/10'
                            }`}>
                            {job.job_type}
                        </span>
                        <span className="px-3 py-1 bg-white/5 text-white/30 text-[10px] font-black uppercase tracking-wider rounded-full border border-white/10">
                            {job.experience_level}
                        </span>
                        {job.slots > 1 && (
                            <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-black uppercase tracking-wider rounded-full border border-blue-500/20">
                                {job.slots} Openings
                            </span>
                        )}
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-white font-['Outfit'] tracking-tight mb-2 group-hover:text-[#635BFF] transition-colors">
                        {job.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-white/40">
                        <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" />{job.location}</span>
                        <span className="flex items-center gap-1.5"><DollarSign className="w-3.5 h-3.5" /><SalaryBadge job={job} /></span>
                        {daysLeft !== null && (
                            <span className={`flex items-center gap-1.5 ${daysLeft <= 7 ? 'text-red-400' : 'text-white/40'}`}>
                                <Calendar className="w-3.5 h-3.5" />
                                {daysLeft === 0 ? 'Last day!' : `${daysLeft} days left`}
                            </span>
                        )}
                    </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                    <div className={`p-3 rounded-xl transition-all ${expanded ? 'bg-[#635BFF] text-white' : 'bg-white/5 text-white/30 group-hover:bg-white/10'}`}>
                        {expanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                </div>
            </button>

            {/* Expanded Content */}
            <AnimatePresence>
                {expanded && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.35 }}
                    >
                        <div className="px-8 pb-8 border-t border-white/8 pt-8">
                            {/* Rich HTML description */}
                            <div
                                className="prose prose-invert prose-sm max-w-none mb-8
                                    prose-h1:text-2xl prose-h1:font-black prose-h1:text-white prose-h1:font-['Outfit'] prose-h1:mb-4 prose-h1:mt-2
                                    prose-h2:text-lg prose-h2:font-bold prose-h2:text-white/80 prose-h2:mb-3 prose-h2:mt-6
                                    prose-p:text-white/60 prose-p:leading-relaxed
                                    prose-li:text-white/60 prose-li:leading-relaxed
                                    prose-strong:text-white prose-strong:font-bold
                                    prose-ul:space-y-1 prose-ul:list-disc prose-ul:pl-5"
                                dangerouslySetInnerHTML={{ __html: job.description }}
                            />

                            {/* Apply Section */}
                            <div className="mt-8 p-6 bg-[#635BFF]/10 rounded-2xl border border-[#635BFF]/20">
                                <h4 className="text-white font-bold mb-2">📨 How to Apply</h4>
                                {job.how_to_apply && (
                                    <p className="text-white/60 text-sm mb-4">{job.how_to_apply}</p>
                                )}
                                <div className="flex flex-wrap gap-3">
                                    {job.application_email && (
                                        <a
                                            href={`mailto:${job.application_email}?subject=Application: ${job.title}`}
                                            className="inline-flex items-center gap-2 px-6 py-3 bg-[#635BFF] text-white rounded-xl font-bold text-sm hover:bg-[#5244e3] transition-colors"
                                        >
                                            <Mail className="w-4 h-4" /> Send Application
                                        </a>
                                    )}
                                    {job.application_url && (
                                        <a
                                            href={job.application_url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 text-white rounded-xl font-bold text-sm hover:bg-white/15 transition-colors border border-white/10"
                                        >
                                            <ExternalLink className="w-4 h-4" /> Apply Online
                                        </a>
                                    )}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.div>
    );
}

export function CareersPage() {
    const [jobs, setJobs] = useState<any[]>([]);
    const [departments, setDepartments] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeDept, setActiveDept] = useState('');
    const [expandedId, setExpandedId] = useState<string | null>(null);

    useEffect(() => {
        fetchJobs()
            .then(r => {
                if (r.success) {
                    setJobs(r.data?.jobs || []);
                    setDepartments(r.data?.departments || []);
                }
            })
            .finally(() => setLoading(false));
    }, []);

    const filtered = activeDept ? jobs.filter(j => j.department === activeDept) : jobs;

    return (
        <div className="min-h-screen pt-32 pb-20 overflow-hidden relative bg-[#0A2540]">
            <SEO
                title="Careers — Join CODVerify"
                description="Exciting career opportunities at CODVerify. Join our team and help shape the future of e-commerce order verification in India."
                canonical="/careers"
                keywords="codverify jobs, careers, work at codverify, engineering jobs india, ecommerce startup jobs"
            />

            {/* Background glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-[#635BFF]/8 rounded-full blur-3xl pointer-events-none" />

            <div className="max-w-4xl mx-auto px-6 relative z-10">
                {/* Hero */}
                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-20"
                >
                    <div className="stripe-badge rounded-full inline-flex items-center gap-2 px-5 py-2 mb-6">
                        <Briefcase className="w-4 h-4 text-indigo-400" />
                        <span className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em]">We're Hiring</span>
                    </div>
                    <h1 className="text-5xl lg:text-7xl font-black text-white font-['Outfit'] tracking-tighter mb-6">
                        Build the Future<br />
                        <span className="text-gradient-hero italic">with us.</span>
                    </h1>
                    <p className="text-xl text-white/40 font-medium max-w-2xl mx-auto">
                        Join a fast-moving team on a mission to eliminate RTO losses for India's e-commerce ecosystem.
                        We value builders, thinkers, and owners.
                    </p>

                    {/* Stats */}
                    <div className="flex flex-wrap justify-center gap-8 mt-12">
                        {[
                            { icon: Users, label: 'Team Size', value: '10–30' },
                            { icon: Clock, label: 'Founded', value: '2024' },
                            { icon: MapPin, label: 'Location', value: 'Remote / Delhi' },
                        ].map((s) => (
                            <div key={s.label} className="flex flex-col items-center gap-1">
                                <s.icon className="w-5 h-5 text-[#635BFF] mb-1" />
                                <div className="text-2xl font-black text-white font-['Outfit']">{s.value}</div>
                                <div className="text-[10px] text-white/30 uppercase tracking-widest font-bold">{s.label}</div>
                            </div>
                        ))}
                    </div>
                </motion.div>

                {/* Department Filter */}
                {departments.length > 0 && (
                    <div className="flex flex-wrap gap-2 justify-center mb-12">
                        <button
                            onClick={() => setActiveDept('')}
                            className={`px-5 py-2 rounded-full text-[11px] font-black uppercase tracking-widest transition-all ${!activeDept ? 'bg-[#635BFF] text-white shadow-lg shadow-[#635BFF]/20' : 'bg-white/5 text-white/40 hover:text-white/60 border border-white/10'}`}
                        >
                            All Departments
                        </button>
                        {departments.map(d => (
                            <button
                                key={d}
                                onClick={() => setActiveDept(d)}
                                className={`px-5 py-2 rounded-full text-[11px] font-black uppercase tracking-widest transition-all ${activeDept === d ? 'bg-[#635BFF] text-white shadow-lg shadow-[#635BFF]/20' : 'bg-white/5 text-white/40 hover:text-white/60 border border-white/10'}`}
                            >
                                {d}
                            </button>
                        ))}
                    </div>
                )}

                {/* Job Listings */}
                {loading ? (
                    <div className="flex flex-col items-center justify-center py-24 gap-4">
                        <div className="w-12 h-12 border-4 border-[#635BFF] border-t-transparent rounded-full animate-spin" />
                        <p className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Loading Opportunities...</p>
                    </div>
                ) : filtered.length === 0 ? (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="py-32 text-center bg-white/3 rounded-[40px] border border-dashed border-white/10"
                    >
                        <Sparkles className="w-12 h-12 text-white/10 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white font-['Outfit'] mb-2">No openings right now</h3>
                        <p className="text-sm text-white/30">
                            We don't have open positions in this department right now.<br />
                            Send your CV to <a href="mailto:careers@codverify.tech" className="text-[#635BFF] hover:underline">careers@codverify.tech</a> — we'll reach out when something opens up!
                        </p>
                    </motion.div>
                ) : (
                    <div className="flex flex-col gap-4">
                        {filtered.map((job: any) => (
                            <JobCard
                                key={job.id}
                                job={job}
                                expanded={expandedId === job.id}
                                onToggle={() => setExpandedId(expandedId === job.id ? null : job.id)}
                            />
                        ))}
                    </div>
                )}

                {/* Culture Section */}
                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="mt-24 p-10 rounded-[40px] bg-gradient-to-br from-[#635BFF]/15 to-white/3 border border-[#635BFF]/20"
                >
                    <h2 className="text-3xl font-black text-white font-['Outfit'] tracking-tight mb-6">Why CODVerify?</h2>
                    <div className="grid sm:grid-cols-2 gap-6">
                        {[
                            { emoji: '🚀', title: 'High Impact', desc: 'Your work processes millions of orders. See real impact on day 1.' },
                            { emoji: '🌍', title: 'Remote Friendly', desc: 'Work from anywhere. We judge results, not hours.' },
                            { emoji: '📈', title: 'Fast Growth', desc: 'Early team = early equity + fast career growth.' },
                            { emoji: '🤝', title: 'Transparent Culture', desc: 'No politics, direct feedback, everyone has a voice.' },
                        ].map(c => (
                            <div key={c.title} className="flex gap-4">
                                <div className="text-3xl">{c.emoji}</div>
                                <div>
                                    <h4 className="text-white font-bold mb-1">{c.title}</h4>
                                    <p className="text-white/50 text-sm">{c.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="mt-8 pt-8 border-t border-white/10 flex flex-wrap items-center gap-4">
                        <p className="text-white/50 text-sm flex-1">Don't see your role? We'd still love to hear from you.</p>
                        <a href="mailto:careers@codverify.tech" className="inline-flex items-center gap-2 px-6 py-3 bg-[#635BFF] text-white rounded-xl font-bold text-sm hover:bg-[#5244e3] transition-colors">
                            <Mail className="w-4 h-4" /> careers@codverify.tech <ArrowRight className="w-4 h-4" />
                        </a>
                    </div>
                </motion.div>
            </div>
        </div>
    );
}

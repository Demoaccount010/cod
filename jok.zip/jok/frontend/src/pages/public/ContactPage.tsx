﻿import { useState } from 'react';
import SEO from '../../components/SEO';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Mail, Phone, MapPin, Sparkles, MessageSquare, CheckCircle } from 'lucide-react';
import { publicApi } from '../../api';

export default function ContactPage() {
    const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', message: '' });
    const [submitted, setSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await publicApi.submitContact(form);
            setSubmitted(true);
        } catch {
            setSubmitted(true);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#0A2540] overflow-hidden">
            <SEO
                title="Contact Us â€” Get a Quote for COD Verification"
                description="Contact CODVerify for custom COD verification pricing, enterprise integrations, or partnership inquiries. Response within 24 hours."
                canonical="/contact"
                keywords="contact codverify, cod verification pricing, ecommerce support, order verification quote"
            />

            {/* â”€â”€â”€ Background â”€â”€â”€ */}
            <div className="absolute inset-0 stripe-mesh-bg opacity-50" />
            <div className="absolute inset-0 grid-pattern-dark opacity-20" />
            <div className="absolute top-20 right-[10%] w-80 h-80 bg-[#635BFF]/20 rounded-full blur-[120px] animate-float" />
            <div className="absolute bottom-0 left-[5%] w-72 h-72 bg-[#00D4AA]/15 rounded-full blur-[100px] animate-float-delay" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-32 pb-20 relative z-10">

                {/* Hero */}
                <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
                    <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-8">
                        <MessageSquare className="w-3.5 h-3.5 text-[#00D4AA]" />
                        <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Get In Touch</span>
                    </div>
                    <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white font-['Outfit'] tracking-tighter mb-6 leading-[0.95]">
                        Talk to Our<br /><span className="text-gradient-hero">Team</span>
                    </h1>
                    <p className="text-white/45 text-base sm:text-lg font-medium leading-relaxed">
                        Get a custom quote, ask about integration, or just say hi.<br className="hidden sm:block" />We respond within 24 hours.
                    </p>
                </motion.div>

                <div className="grid lg:grid-cols-5 gap-8 lg:gap-12 items-start max-w-6xl mx-auto">

                    {/* Left â€” Contact Info */}
                    <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-2 space-y-6">
                        {[
                            { icon: Mail, title: 'Email Us', desc: 'support@codverify.tech', sub: 'Response within 24 hours' },
                            { icon: Phone, title: 'Call Us', desc: '+91 98765 43210', sub: 'Monâ€“Sat, 9AMâ€“9PM IST' },
                            { icon: MapPin, title: 'Headquarters', desc: 'Mumbai, Maharashtra', sub: 'India' },
                        ].map((item, i) => (
                            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.1 }}
                                className="glass-card-ultra rounded-2xl p-5 sm:p-6 flex items-start gap-4 group">
                                <div className="w-12 h-12 rounded-xl bg-[#635BFF]/15 flex items-center justify-center shrink-0 group-hover:bg-[#635BFF]/25 transition-colors">
                                    <item.icon className="w-5 h-5 text-[#635BFF]" />
                                </div>
                                <div>
                                    <p className="text-xs font-bold text-white/35 uppercase tracking-widest mb-1">{item.title}</p>
                                    <p className="text-white font-bold text-sm sm:text-base">{item.desc}</p>
                                    <p className="text-white/35 text-xs mt-0.5">{item.sub}</p>
                                </div>
                            </motion.div>
                        ))}

                        {/* Info card */}
                        <div className="glass-card-ultra rounded-2xl p-5 sm:p-6 relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-5 opacity-[0.04]">
                                <Sparkles className="w-20 h-20" />
                            </div>
                            <h4 className="text-white font-bold font-['Outfit'] mb-2">Priority Support</h4>
                            <p className="text-sm text-white/40 leading-relaxed">For high-volume enterprise deployments, our priority team responds within 1 hour, 24/7/365.</p>
                        </div>
                    </motion.div>

                    {/* Right â€” Form */}
                    <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }} className="lg:col-span-3">
                        <AnimatePresence mode="wait">
                            {submitted ? (
                                <motion.div
                                    key="success"
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="glass-card-ultra rounded-3xl p-12 sm:p-16 text-center relative overflow-hidden"
                                >
                                    <div className="absolute inset-0 bg-gradient-to-br from-[#635BFF]/10 to-[#00D4AA]/10" />
                                    <div className="relative z-10">
                                        <div className="w-20 h-20 sm:w-24 sm:h-24 bg-[#00D4AA]/15 border border-[#00D4AA]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                                            <CheckCircle className="w-10 h-10 sm:w-12 sm:h-12 text-[#00D4AA]" />
                                        </div>
                                        <h3 className="text-3xl sm:text-4xl font-black text-white font-['Outfit'] tracking-tighter mb-4">Message Sent!</h3>
                                        <p className="text-white/45 font-medium max-w-sm mx-auto leading-relaxed mb-8">Our team will get back to you within 24 hours.</p>
                                        <button onClick={() => setSubmitted(false)} className="text-xs font-bold uppercase tracking-[0.3em] text-white/30 hover:text-white/60 transition-colors">Send Another</button>
                                    </div>
                                </motion.div>
                            ) : (
                                <motion.form key="form" onSubmit={handleSubmit} className="glass-card-ultra rounded-3xl p-6 sm:p-10 space-y-5 sm:space-y-6">
                                    <div className="grid sm:grid-cols-2 gap-5 sm:gap-6">
                                        <div>
                                            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Your Name</label>
                                            <input required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                                                className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white placeholder:text-white/20 focus:outline-none focus:border-[#635BFF]/50 focus:bg-white/8 transition-all"
                                                placeholder="Rahul Sharma" />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Email</label>
                                            <input type="email" required value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                                                className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white placeholder:text-white/20 focus:outline-none focus:border-[#635BFF]/50 focus:bg-white/8 transition-all"
                                                placeholder="you@company.com" />
                                        </div>
                                    </div>
                                    <div className="grid sm:grid-cols-2 gap-5 sm:gap-6">
                                        <div>
                                            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Phone</label>
                                            <input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
                                                className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white placeholder:text-white/20 focus:outline-none focus:border-[#635BFF]/50 focus:bg-white/8 transition-all"
                                                placeholder="+91 98765 43210" />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Company</label>
                                            <input value={form.company} onChange={e => setForm(p => ({ ...p, company: e.target.value }))}
                                                className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white placeholder:text-white/20 focus:outline-none focus:border-[#635BFF]/50 focus:bg-white/8 transition-all"
                                                placeholder="Your Store Name" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Message</label>
                                        <textarea required rows={5} value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                                            className="w-full px-4 py-4 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white placeholder:text-white/20 focus:outline-none focus:border-[#635BFF]/50 focus:bg-white/8 transition-all resize-none"
                                            placeholder="Tell us about your verification requirements, order volume, and which platforms you use..." />
                                    </div>
                                    <button type="submit" disabled={loading}
                                        className="stripe-button w-full py-4 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-3 group disabled:opacity-60">
                                        {loading
                                            ? <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Sending...</>
                                            : <><Send className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" /> Send Message</>
                                        }
                                    </button>
                                </motion.form>
                            )}
                        </AnimatePresence>
                    </motion.div>
                </div>
            </div>
        </div>
    );
}



import SEO from '../../components/SEO';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Code, Terminal, Globe, Zap, Key, ArrowRight, Copy, Check } from 'lucide-react';
import { useState } from 'react';

const endpoints = [
    {
        method: 'POST', path: '/api/v1/webhooks/store', tag: 'Orders',
        desc: 'Receive new COD orders from your store. CODVerify auto-triggers verification.',
        body: `{\n  "order_id": "ORDER_123",\n  "customer_name": "Rahul Verma",\n  "customer_phone": "+919876543210",\n  "order_amount": 1499.00,\n  "currency": "INR",\n  "items": [{"name": "Blue Kurti", "qty": 2, "price": 749.50}],\n  "shipping_address": "12 MG Road, Bangalore"\n}`,
    },
    {
        method: 'GET', path: '/api/v1/merchant/orders', tag: 'Orders',
        desc: 'List all your orders with filtering, pagination, and status breakdown.',
        body: null,
    },
    {
        method: 'GET', path: '/api/v1/merchant/orders/{id}', tag: 'Orders',
        desc: 'Get full details of a single order including message history.',
        body: null,
    },
    {
        method: 'GET', path: '/api/v1/merchant/billing/wallet', tag: 'Billing',
        desc: 'Fetch current wallet balance, last recharge, and usage stats.',
        body: null,
    },
    {
        method: 'POST', path: '/api/v1/merchant/billing/wallet/add-money', tag: 'Billing',
        desc: 'Initiate a wallet recharge (triggers Razorpay payment link).',
        body: `{ "amount": 500 }`,
    },
    {
        method: 'GET', path: '/api/v1/merchant/dashboard/stats', tag: 'Dashboard',
        desc: 'Returns verified/cancelled/pending counts + wallet balance for dashboard.',
        body: null,
    },
];

const sdkExamples = [
    {
        lang: 'curl', label: 'cURL',
        code: `curl -X POST https://api.codverify.tech/api/v1/webhooks/store \\
  -H "X-API-Key: YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "order_id": "ORDER_123",
    "customer_name": "Rahul Verma",
    "customer_phone": "+919876543210",
    "order_amount": 1499.00
  }'`,
    },
    {
        lang: 'javascript', label: 'JavaScript',
        code: `const response = await fetch('https://api.codverify.tech/api/v1/webhooks/store', {
  method: 'POST',
  headers: {
    'X-API-Key': process.env.CODVERIFY_API_KEY,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    order_id: order.id,
    customer_name: order.customer.name,
    customer_phone: order.customer.phone,
    order_amount: order.total_price
  })
});`,
    },
    {
        lang: 'python', label: 'Python',
        code: `import requests

response = requests.post(
    'https://api.codverify.tech/api/v1/webhooks/store',
    headers={'X-API-Key': os.environ['CODVERIFY_API_KEY']},
    json={
        'order_id': order['id'],
        'customer_name': order['customer']['name'],
        'customer_phone': order['customer']['phone'],
        'order_amount': float(order['total_price'])
    }
)`,
    },
];

const methodColors: Record<string, string> = {
    GET: 'bg-[#00D4AA]/15 text-[#00D4AA]',
    POST: 'bg-[#635BFF]/15 text-[#635BFF]',
    PUT: 'bg-[#FF9E2C]/15 text-[#FF9E2C]',
    DELETE: 'bg-red-500/15 text-red-400',
};

function CodeBlock({ code }: { code: string }) {
    const [copied, setCopied] = useState(false);
    const copy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };
    return (
        <div className="relative bg-gray-950 rounded-2xl p-6 font-mono text-sm text-gray-300 overflow-x-auto">
            <button onClick={copy} className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors">
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <pre className="whitespace-pre-wrap">{code}</pre>
        </div>
    );
}

export default function DocsPage() {
    const [activeLang, setActiveLang] = useState('curl');
    const activeExample = sdkExamples.find(s => s.lang === activeLang)!;

    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="API Documentation — Developer Guide"
                description="CODVerify REST API documentation: endpoints, authentication, webhooks, SDK examples in cURL, JavaScript & Python. Integrate COD order verification in under 10 minutes."
                canonical="/docs"
                keywords="codverify api, cod verification api, order verification webhook, developer documentation, rest api ecommerce"
            />

            <div className="relative pt-32 pb-16 stripe-mesh-bg">
                <div className="max-w-5xl mx-auto px-6 text-center">
                    <div className="stripe-badge rounded-full inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-white/70 uppercase tracking-[0.2em] mb-6">
                        <Terminal className="w-3.5 h-3.5" /> Developer Docs
                    </div>
                    <h1 className="text-5xl font-black tracking-tighter text-white mb-6">API Documentation</h1>
                    <p className="text-xl text-white/40 max-w-2xl mx-auto leading-relaxed">
                        Integrate CODVerify in under 10 minutes. Simple REST API with JSON payloads.
                    </p>
                </div>
            </div>

            <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 relative z-10">
                {/* Authentication */}
                <section className="mb-16">
                    <div className="flex items-center gap-3 mb-6">
                        <Key className="w-5 h-5 text-[#635BFF]" />
                        <h2 className="text-2xl font-black text-white">Authentication</h2>
                    </div>
                    <p className="text-white/40 mb-6 leading-relaxed">
                        All API requests require your <strong>API Key</strong> in the <code className="bg-white/10 px-2 py-0.5 rounded text-sm font-mono text-white/70">X-API-Key</code> header.
                        Get your API key from <Link to="/dashboard/api-keys" className="text-[#635BFF] hover:underline">Dashboard → API Keys</Link>.
                    </p>
                    <CodeBlock code={`X-API-Key: ck_live_xxxxxxxxxxxxxxxxxxxxxxxxxx`} />
                </section>

                {/* Quick Start */}
                <section className="mb-16">
                    <div className="flex items-center gap-3 mb-6">
                        <Zap className="w-5 h-5 text-[#635BFF]" />
                        <h2 className="text-2xl font-black text-white">Quick Start</h2>
                    </div>
                    <p className="text-white/40 mb-6">Send your first order for verification. Just POST to the webhook endpoint.</p>
                    <div className="flex gap-2 mb-4">
                        {sdkExamples.map(s => (
                            <button key={s.lang} onClick={() => setActiveLang(s.lang)}
                                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeLang === s.lang ? 'bg-[#635BFF] text-white' : 'bg-white/8 text-white/50 border border-white/10 hover:bg-white/12 hover:text-white/70'}`}>
                                {s.label}
                            </button>
                        ))}
                    </div>
                    <CodeBlock code={activeExample.code} />
                </section>

                {/* Endpoint Reference */}
                <section className="mb-16">
                    <div className="flex items-center gap-3 mb-6">
                        <Code className="w-5 h-5 text-[#635BFF]" />
                        <h2 className="text-2xl font-black text-white">Endpoint Reference</h2>
                    </div>
                    <div className="space-y-4">
                        {endpoints.map((ep, i) => (
                            <motion.div key={i} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} viewport={{ once: true }}
                                className="border border-white/8 bg-white/3 rounded-2xl p-6 hover:border-white/15 transition-all">
                                <div className="flex items-center gap-3 mb-3">
                                    <span className={`text-xs font-black px-2.5 py-1 rounded-lg ${methodColors[ep.method]}`}>{ep.method}</span>
                                    <code className="text-sm font-mono text-[#80E9FF] bg-white/5 px-3 py-1 rounded-lg">{ep.path}</code>
                                    <span className="text-xs bg-white/5 text-white/30 border border-white/8 rounded-full px-2.5 py-0.5 font-bold">{ep.tag}</span>
                                </div>
                                <p className="text-white/40 text-sm mb-4">{ep.desc}</p>
                                {ep.body && (
                                    <div>
                                        <div className="text-xs text-white/25 font-bold uppercase tracking-widest mb-2">Request Body</div>
                                        <CodeBlock code={ep.body} />
                                    </div>
                                )}
                            </motion.div>
                        ))}
                    </div>
                </section>

                {/* Webhook Events */}
                <section>
                    <div className="flex items-center gap-3 mb-6">
                        <Globe className="w-5 h-5 text-[#635BFF]" />
                        <h2 className="text-2xl font-black text-white">Webhook Events</h2>
                    </div>
                    <p className="text-white/40 mb-6">CODVerify sends events to your <strong>Callback URL</strong> (configured in Settings) when order status changes.</p>
                    <CodeBlock code={`{\n  "event": "order.confirmed",\n  "order_id": "ORDER_123",\n  "customer_phone": "+919876543210",\n  "status": "confirmed",\n  "timestamp": "2026-03-03T07:30:00Z"\n}`} />
                    <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {['order.confirmed', 'order.cancelled', 'order.no_reply', 'order.failed', 'wallet.low_balance', 'order.delivered'].map(evt => (
                            <div key={evt} className="bg-white/5 border border-white/8 rounded-xl p-4 font-mono text-xs text-[#80E9FF]">{evt}</div>
                        ))}
                    </div>
                </section>

                <div className="mt-16 glass-card-ultra rounded-3xl border border-white/10 p-8 text-center">
                    <h3 className="text-xl font-black text-white mb-2">Need Help?</h3>
                    <p className="text-white/40 text-sm mb-6">Our support team is available 24/7 to help with integration.</p>
                    <div className="flex justify-center gap-4">
                        <Link to="/contact" className="stripe-button px-6 py-3 text-white rounded-full font-bold text-sm flex items-center gap-2">
                            Contact Support <ArrowRight className="w-4 h-4" />
                        </Link>
                        <Link to="/dashboard/support" className="px-6 py-3 bg-white/8 border border-white/15 text-white/60 rounded-full font-bold text-sm hover:bg-white/12 transition-all">
                            Open Ticket
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

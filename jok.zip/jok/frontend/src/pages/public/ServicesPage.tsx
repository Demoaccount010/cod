import { Link } from 'react-router-dom';
import { motion, useInView } from 'framer-motion';
import SEO from '../../components/SEO';
import { MessageSquare, Shield, Bot, Zap, BarChart3, Clock, ArrowRight, Sparkles, Star, Brain, Users, Mail, Layers, CheckCircle } from 'lucide-react';
import { useRef, type ReactNode } from 'react';

// ─── Reveal Wrapper ───────────────────────────────────────────────────────────
function RevealSection({ children, className = '' }: { children: ReactNode; className?: string }) {
    const ref = useRef<HTMLDivElement>(null);
    const isInView = useInView(ref, { once: true, margin: '-80px' });
    return (
        <motion.div ref={ref} initial={{ opacity: 0, y: 40 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className={className}>
            {children}
        </motion.div>
    );
}

const services = [
    {
        icon: MessageSquare,
        title: 'WhatsApp Verification',
        desc: 'The moment a COD order lands, your customer gets an interactive WhatsApp message. One tap to confirm, one tap to cancel — no call, no SMS confusion. Built-in retry logic ensures no order goes unacknowledged.',
        features: ['Interactive confirm/cancel buttons', 'Auto-retry on no response', 'Custom WhatsApp templates', 'Real-time delivery status'],
        gradient: 'from-[#25D366] to-[#128C7E]',
        glow: '#25D366',
    },
    {
        icon: Brain,
        title: 'AI Risk Scoring',
        desc: 'Before any message is sent, our AI evaluates every order using multiple signals. Orders from high-risk customers are flagged, held, or escalated — saving you shipping costs before they happen.',
        features: ['Customer RTO history scoring', 'Cancellation rate analysis', 'High-value order flag', 'Address completeness check'],
        gradient: 'from-[#635BFF] to-[#7A73FF]',
        glow: '#635BFF',
    },
    {
        icon: Bot,
        title: 'AI Personal Chatbot',
        desc: 'A fully trained AI chatbot lives on your store\'s website. It answers order questions, handles address updates, and manages FAQs — automatically, 24/7. No scripts. No wait time.',
        features: ['Embedded on your store website', 'Multi-turn conversation memory', 'Order tracking & status replies', 'Handles address/quantity changes'],
        gradient: 'from-[#FF80B5] to-[#FF9E2C]',
        glow: '#FF80B5',
    },
    {
        icon: Users,
        title: 'Live Support Workers',
        desc: 'When the AI hits its limits, it hands off instantly to a real human agent from our team. Your customers get answers, your brand looks professional — without hiring a single support staff member.',
        features: ['Real agents pick up live sessions', 'Instant AI → human handoff', 'Chat session history visible', 'Callback scheduling support'],
        gradient: 'from-[#FF9E2C] to-[#FF6B6B]',
        glow: '#FF9E2C',
    },
    {
        icon: Mail,
        title: 'Daily Summary on Email',
        desc: 'Every morning you receive a clean, structured performance email — verifications sent, confirmation rates, orders shipped, and fake orders blocked. Know your numbers without logging into a dashboard.',
        features: ['Daily automated email digest', 'Verification rate breakdown', 'Fake orders caught yesterday', 'Revenue protected summary'],
        gradient: 'from-[#00D4AA] to-[#80E9FF]',
        glow: '#00D4AA',
    },
    {
        icon: Layers,
        title: 'Shopify & WooCommerce',
        desc: 'Native webhook integrations with Shopify and WooCommerce. Orders flow in the moment they\'re placed, confirmations push back to your store as tags or notes in real time — zero manual work.',
        features: ['Shopify webhook integration', 'WooCommerce order notes sync', 'Custom API for any platform', 'Real-time status updates'],
        gradient: 'from-[#80E9FF] to-[#635BFF]',
        glow: '#80E9FF',
    },
    {
        icon: Shield,
        title: 'Fraud Detection & Blacklist',
        desc: 'Customers who repeatedly cancel, ghost, or generate RTOs are automatically added to your blacklist. Future orders from them are flagged before a single message is sent — protecting your inventory proactively.',
        features: ['Auto-blacklist on serial RTOs', 'Risk score per order', 'Phone number history tracking', 'Manual override controls'],
        gradient: 'from-[#00D4AA] to-[#635BFF]',
        glow: '#00D4AA',
    },
    {
        icon: Clock,
        title: '24×7 Monitoring & Retry Logic',
        desc: 'Our scheduler runs around the clock — retrying unanswered verifications, checking timeouts, and ensuring no order gets stuck. You sleep. We work.',
        features: ['Configurable retry intervals', 'Timeout-based auto-cancel', 'Zero-downtime monitoring', 'Background job health alerts'],
        gradient: 'from-[#635BFF] to-[#FF80B5]',
        glow: '#635BFF',
    },
];

const whyUs = [
    { icon: Zap, title: 'Instant Integration', desc: 'Shopify and WooCommerce connect in minutes. Custom stores via Webhook API — no developers needed.', color: '#00D4AA' },
    { icon: Star, title: 'Contract-Based, Not Self-Serve', desc: 'We work with selected brands. You get a dedicated executive, not a support ticket queue.', color: '#FF9E2C' },
    { icon: BarChart3, title: 'Real-time Dashboard', desc: 'Live visibility into every verification — who replied, who didn\'t, and what got blocked.', color: '#635BFF' },
    { icon: Shield, title: 'Enterprise Security', desc: 'Bank-grade encryption, SOC2-ready infrastructure. Your customer data never leaves our secure environment.', color: '#80E9FF' },
];

export default function ServicesPage() {
    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="Services — E-Commerce COD Protection Suite"
                description="SMS, WhatsApp & Voice Call order verification, AI chatbot, fraud detection, RTO analytics, and 24/7 dedicated support for your e-commerce store. Reduce RTO by 45%."
                canonical="/services"
                keywords="cod verification services, whatsapp order verification, sms verification, voice call verification, ai chatbot ecommerce, rto reduction, fraud detection"
                structuredData={{
                    "@context": "https://schema.org",
                    "@type": "Service",
                    "serviceType": "COD Order Verification",
                    "provider": { "@type": "Organization", "name": "CODVerify", "url": "https://codverify.tech" },
                    "areaServed": ["IN", "US"],
                    "description": "AI-powered COD order verification services including WhatsApp, SMS, Voice Call verification, fraud detection, and RTO analytics"
                }}
            />

            {/* ═══ HERO ═══ */}
            <section className="relative pt-32 pb-24 overflow-hidden">
                <div className="absolute inset-0 stripe-mesh-bg opacity-50" />
                <div className="absolute inset-0 grid-pattern-dark opacity-25" />

                {/* Floating orbs */}
                <div className="absolute top-32 right-[10%] w-80 h-80 bg-[#635BFF]/20 rounded-full blur-[120px] animate-float" />
                <div className="absolute bottom-0 left-[5%] w-96 h-96 bg-[#00D4AA]/15 rounded-full blur-[120px] animate-float-delay" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }} className="text-center max-w-3xl mx-auto">
                        <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-8">
                            <Sparkles className="w-3.5 h-3.5 text-[#FF9E2C]" />
                            <span className="text-xs font-bold text-white/80 uppercase tracking-[0.2em]">Enterprise Protection Suite</span>
                        </div>
                        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white font-['Outfit'] tracking-tighter leading-[0.95] mb-6">
                            Every Tool Your<br />
                            <span className="text-gradient-hero">COD Business</span> Needs.
                        </h1>
                        <p className="text-base sm:text-lg lg:text-xl text-white/45 font-medium leading-relaxed mb-10 max-w-2xl mx-auto">
                            WhatsApp verification, AI risk scoring, personal chatbot, live support workers, daily email summaries — one platform that works while you sleep.
                        </p>
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Link to="/signup" className="stripe-button text-white rounded-full font-bold text-sm px-8 py-4 flex items-center gap-2 group">
                                Start Free Trial <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                            </Link>
                            <Link to="/contact" className="px-8 py-4 rounded-full font-bold text-sm text-white border border-white/15 hover:bg-white/5 transition-all">
                                Talk to Sales
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* ═══ SERVICES GRID ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 bg-gradient-to-b from-[#0A2540] via-[#0D1B2A] to-[#0A2540]" />
                <div className="absolute inset-0 noise-overlay" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection className="text-center mb-16">
                        <h2 className="text-3xl md:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-4">
                            Our <span className="text-gradient-stripe">Services</span>
                        </h2>
                        <p className="text-white/40 max-w-xl mx-auto text-lg">
                            A comprehensive suite of tools to protect your revenue and grow your business.
                        </p>
                    </RevealSection>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5 lg:gap-6">
                        {services.map((s, i) => (
                            <RevealSection key={i}>
                                <motion.div
                                    whileHover={{ y: -4 }}
                                    transition={{ type: 'spring', stiffness: 300 }}
                                    className="relative glass-card-ultra rounded-3xl p-7 sm:p-8 group overflow-hidden h-full border border-white/8 transition-all duration-500"
                                    style={{
                                        ['--sglow' as string]: s.glow,
                                    }}
                                >
                                    {/* Color-matched glow on hover */}
                                    <div
                                        className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                                        style={{ boxShadow: `0 0 0 1px ${s.glow}40, 0 20px 60px ${s.glow}20` }}
                                    />
                                    {/* Top accent line on hover */}
                                    <div
                                        className="absolute top-0 left-0 right-0 h-[2px] rounded-t-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                                        style={{ background: `linear-gradient(90deg, transparent, ${s.glow}, transparent)` }}
                                    />
                                    {/* Background glow blob */}
                                    <div
                                        className="absolute -top-16 -right-16 w-48 h-48 rounded-full blur-[80px] opacity-0 group-hover:opacity-30 transition-opacity duration-700"
                                        style={{ background: s.glow }}
                                    />

                                    <div className="relative z-10">
                                        <div
                                            className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.gradient} flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-500`}
                                            style={{ boxShadow: `0 8px 24px ${s.glow}40` }}
                                        >
                                            <s.icon className="w-7 h-7 text-white" />
                                        </div>
                                        <h3 className="text-xl font-bold text-white font-['Outfit'] tracking-tight mb-3">{s.title}</h3>
                                        <p className="text-sm text-white/45 font-medium leading-relaxed mb-6">{s.desc}</p>
                                        <div className="grid grid-cols-2 gap-2.5">
                                            {s.features.map((f, fi) => (
                                                <div key={fi} className="flex items-center gap-2">
                                                    <div
                                                        className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0"
                                                        style={{ background: `${s.glow}20` }}
                                                    >
                                                        <CheckCircle className="w-2.5 h-2.5" style={{ color: s.glow }} />
                                                    </div>
                                                    <span className="text-[11px] sm:text-xs font-semibold text-white/55">{f}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </motion.div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ WHY US ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 bg-[#0A2540]" />
                <div className="absolute inset-0 hero-gradient opacity-40" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection className="text-center mb-16">
                        <h2 className="text-3xl md:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-4">
                            Why <span className="text-gradient-hero">Brands</span> Choose Us
                        </h2>
                        <p className="text-white/40 max-w-lg mx-auto text-lg">We serve only selected businesses. Quality over quantity, always.</p>
                    </RevealSection>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        {whyUs.map((w, i) => (
                            <RevealSection key={i}>
                                <motion.div
                                    whileHover={{ y: -5, scale: 1.03 }}
                                    transition={{ type: 'spring', stiffness: 300 }}
                                    className="glass-card-ultra rounded-2xl p-7 group cursor-default relative overflow-hidden h-full"
                                >
                                    <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full blur-[50px] opacity-0 group-hover:opacity-40 transition-opacity duration-700" style={{ background: w.color }} />
                                    <div className="relative z-10">
                                        <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5" style={{ background: `${w.color}15` }}>
                                            <w.icon className="w-6 h-6" style={{ color: w.color }} />
                                        </div>
                                        <h3 className="text-lg font-bold text-white font-['Outfit'] mb-2">{w.title}</h3>
                                        <p className="text-sm text-white/40 font-medium leading-relaxed">{w.desc}</p>
                                    </div>
                                </motion.div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ PRICING CTA ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 stripe-gradient-dark" />
                <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection>
                        <div className="glass-card-ultra rounded-3xl p-10 sm:p-14 lg:p-20 relative overflow-hidden text-center">
                            <div className="absolute inset-0 grid-pattern-dark opacity-15" />
                            {/* Corner glows */}
                            <div className="absolute -top-24 -left-24 w-64 h-64 bg-[#635BFF]/20 rounded-full blur-[100px]" />
                            <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-[#00D4AA]/15 rounded-full blur-[100px]" />
                            <div className="absolute top-0 right-20 opacity-[0.02]">
                                <Sparkles className="w-48 h-48" />
                            </div>

                            <div className="relative z-10">
                                <div className="stripe-badge rounded-full px-4 py-1.5 inline-flex items-center gap-2 mb-8">
                                    <Star className="w-3.5 h-3.5 text-[#FF9E2C]" />
                                    <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Limited Access</span>
                                </div>
                                <h2 className="text-3xl md:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-6">
                                    Industry's <span className="text-gradient-hero">Lowest Prices</span>
                                </h2>
                                <p className="text-base text-white/45 font-medium max-w-xl mx-auto mb-4 leading-relaxed">
                                    The most competitive rates for e-commerce COD verification — guaranteed lowest in the market. Custom plans tailored to your exact needs.
                                </p>
                                <p className="text-sm text-white/30 font-semibold mb-10">
                                    ⚡ We serve only a limited number of websites at a time to ensure premium service quality.
                                </p>
                                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                    <Link to="/contact" className="stripe-button text-white rounded-full font-bold text-sm px-10 py-4 flex items-center gap-3 group shadow-xl">
                                        Contact Us for Pricing <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                    </Link>
                                    <Link to="/signup" className="px-8 py-4 rounded-full font-bold text-sm text-white border border-white/15 hover:bg-white/5 transition-all">
                                        Register Your Interest
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </RevealSection>
                </div>
            </section>
        </div>
    );
}

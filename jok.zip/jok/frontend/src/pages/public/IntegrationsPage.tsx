import { useState } from 'react';
import SEO from '../../components/SEO';
import { motion } from 'framer-motion';
import type { ReactElement } from 'react';
import {
    Zap, Code, Copy, Check, ChevronRight, Globe,
    ArrowRight, Terminal, Key, CheckCircle, Package
} from 'lucide-react';
import { Link } from 'react-router-dom';

/* ── tiny copy-to-clipboard hook ── */
function useCopy() {
    const [copied, setCopied] = useState<string | null>(null);
    const copy = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopied(id);
        setTimeout(() => setCopied(null), 2000);
    };
    return { copied, copy };
}

function CodeBlock({ code, id }: { code: string; id: string }) {
    const { copied, copy } = useCopy();
    return (
        <div className="relative group">
            <pre className="bg-gray-950 text-gray-200 rounded-2xl p-5 text-xs overflow-x-auto leading-relaxed border border-gray-800 font-mono">
                <code>{code}</code>
            </pre>
            <button
                onClick={() => copy(code, id)}
                className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 bg-gray-800 hover:bg-indigo-600 text-gray-300 hover:text-white rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all opacity-0 group-hover:opacity-100"
            >
                {copied === id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied === id ? 'Copied!' : 'Copy'}
            </button>
        </div>
    );
}

/* ── platform tab data ── */
const platforms = [
    {
        id: 'shopify',
        name: 'Shopify',
        icon: '🛍️',
        color: 'from-green-500 to-emerald-600',
        shadow: 'shadow-green-500/20',
        border: 'border-green-200',
        badge: 'Most Popular',
        badgeColor: 'bg-green-100 text-green-700',
    },
    {
        id: 'woocommerce',
        name: 'WooCommerce',
        icon: '🟣',
        color: 'from-purple-500 to-violet-600',
        shadow: 'shadow-purple-500/20',
        border: 'border-purple-200',
        badge: 'WordPress',
        badgeColor: 'bg-purple-100 text-purple-700',
    },
    {
        id: 'custom',
        name: 'Custom / REST API',
        icon: '⚡',
        color: 'from-indigo-500 to-blue-600',
        shadow: 'shadow-indigo-500/20',
        border: 'border-indigo-200',
        badge: 'For Developers',
        badgeColor: 'bg-indigo-100 text-indigo-700',
    },
];

const WEBHOOK_URL = 'https://your-codverify-space.hf.space/api/v1/webhook/order/new';

/* ── per-platform content ── */
function ShopifyGuide() {
    const orderPayload = `{
  "store_order_id": "{{ order.id }}",
  "order_number": "{{ order.order_number }}",
  "customer_name": "{{ customer.first_name }} {{ customer.last_name }}",
  "customer_phone": "{{ customer.phone }}",
  "customer_email": "{{ customer.email }}",
  "order_amount": {{ subtotal_price }},
  "currency": "INR",
  "payment_method": "cod",
  "products": [
    {% for item in line_items %}
    {
      "name": "{{ item.title }}",
      "quantity": {{ item.quantity }},
      "price": {{ item.price }}
    }{% unless forloop.last %},{% endunless %}
    {% endfor %}
  ],
  "shipping_address": {
    "address1": "{{ shipping_address.address1 }}",
    "city": "{{ shipping_address.city }}",
    "state": "{{ shipping_address.province }}",
    "pincode": "{{ shipping_address.zip }}",
    "country": "{{ shipping_address.country_code }}"
  }
}`;

    return (
        <div className="space-y-8">
            {/* Steps */}
            {[
                {
                    n: 1, title: 'Get your API Key',
                    desc: 'Login to CODVerify dashboard → API Keys → Copy your API key and secret.',
                    extra: <Link to="/signup" className="inline-flex items-center gap-1.5 mt-3 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all"><Key className="w-3.5 h-3.5" />Get API Key<ArrowRight className="w-3.5 h-3.5" /></Link>
                },
                {
                    n: 2, title: 'Go to Shopify → Settings → Notifications',
                    desc: 'Scroll to "Webhooks" at the bottom. Click "Create webhook".',
                },
                {
                    n: 3, title: 'Configure the Webhook',
                    desc: 'Set Event = "Order payment", Format = JSON, and enter the URL below:',
                    extra: <CodeBlock id="shopify-url" code={WEBHOOK_URL} />
                },
                {
                    n: 4, title: 'Set API Key Header',
                    desc: 'In Shopify webhook settings → "Custom headers" → Add:',
                    extra: <CodeBlock id="shopify-header" code={`X-API-Key: your_api_key_here`} />
                },
                {
                    n: 5, title: 'Map the Payload',
                    desc: 'Shopify sends Liquid template data. Use this format for the webhook body:',
                    extra: <CodeBlock id="shopify-payload" code={orderPayload} />
                },
                {
                    n: 6, title: 'Test It!',
                    desc: 'Click "Send test notification" in Shopify. You should see the order appear in your CODVerify dashboard within seconds.',
                },
            ].map(step => (
                <div key={step.n} className="flex gap-5">
                    <div className="flex-shrink-0 w-8 h-8 bg-green-600 rounded-xl flex items-center justify-center text-white text-xs font-black">
                        {step.n}
                    </div>
                    <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-white text-sm mb-1">{step.title}</h4>
                        <p className="text-white/45 text-sm leading-relaxed">{step.desc}</p>
                        {step.extra && <div className="mt-3">{step.extra}</div>}
                    </div>
                </div>
            ))}

            <div className="p-4 bg-[#00D4AA]/10 rounded-2xl border border-[#00D4AA]/20">
                <p className="text-[#00D4AA] text-sm font-semibold">✅ That's it! No plugin or code changes required for Shopify.</p>
            </div>
        </div>
    );
}

function WooCommerceGuide() {
    const phpCode = `<?php
/**
 * CODVerify WooCommerce Integration
 * Add this to your theme's functions.php
 */
add_action('woocommerce_payment_complete', 'codverify_send_order', 10, 1);
add_action('woocommerce_order_status_processing', 'codverify_send_order', 10, 1);

function codverify_send_order($order_id) {
    $order = wc_get_order($order_id);
    
    // Only COD orders
    if ($order->get_payment_method() !== 'cod') return;
    
    $items = [];
    foreach ($order->get_items() as $item) {
        $items[] = [
            'name'     => $item->get_name(),
            'quantity' => $item->get_quantity(),
            'price'    => (float) $item->get_total() / $item->get_quantity(),
        ];
    }
    
    $payload = [
        'store_order_id'   => (string) $order->get_id(),
        'order_number'     => $order->get_order_number(),
        'customer_name'    => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
        'customer_phone'   => $order->get_billing_phone(),
        'customer_email'   => $order->get_billing_email(),
        'order_amount'     => (float) $order->get_total(),
        'currency'         => get_woocommerce_currency(),
        'payment_method'   => 'cod',
        'products'         => $items,
        'shipping_address' => [
            'address1' => $order->get_shipping_address_1(),
            'city'     => $order->get_shipping_city(),
            'state'    => $order->get_shipping_state(),
            'pincode'  => $order->get_shipping_postcode(),
            'country'  => $order->get_shipping_country(),
        ],
    ];
    
    wp_remote_post('${WEBHOOK_URL}', [
        'method'  => 'POST',
        'headers' => [
            'Content-Type' => 'application/json',
            'X-API-Key'    => 'YOUR_CODVERIFY_API_KEY',  // <-- Replace this
        ],
        'body'    => json_encode($payload),
        'timeout' => 15,
    ]);
}`;

    return (
        <div className="space-y-8">
            {[
                { n: 1, title: 'Get your API Key', desc: 'Login to CODVerify → API Keys → Copy your API key.' },
                { n: 2, title: 'Copy the code below', desc: 'This is a PHP snippet that hooks into WooCommerce\'s order events:' },
            ].map(step => (
                <div key={step.n} className="flex gap-5">
                    <div className="flex-shrink-0 w-8 h-8 bg-[#635BFF] rounded-xl flex items-center justify-center text-white text-xs font-black">{step.n}</div>
                    <div>
                        <h4 className="font-bold text-white text-sm mb-1">{step.title}</h4>
                        <p className="text-white/45 text-sm">{step.desc}</p>
                    </div>
                </div>
            ))}
            <CodeBlock id="woo-php" code={phpCode} />
            {[
                { n: 3, title: 'Add to functions.php', desc: 'Go to WordPress Admin → Appearance → Theme Editor → functions.php. Paste the code at the bottom. Replace YOUR_CODVERIFY_API_KEY with your actual key.' },
                { n: 4, title: 'Alternative: Use a plugin', desc: 'Use "Code Snippets" WordPress plugin to add it safely without editing theme files.' },
                { n: 5, title: 'Test with a COD order', desc: 'Place a test COD order on your store. Check your CODVerify dashboard — the order should appear within 30 seconds.' },
            ].map(step => (
                <div key={step.n} className="flex gap-5">
                    <div className="flex-shrink-0 w-8 h-8 bg-[#635BFF] rounded-xl flex items-center justify-center text-white text-xs font-black">{step.n}</div>
                    <div>
                        <h4 className="font-bold text-white text-sm mb-1">{step.title}</h4>
                        <p className="text-white/45 text-sm">{step.desc}</p>
                    </div>
                </div>
            ))}
            <div className="p-4 bg-[#635BFF]/10 rounded-2xl border border-[#635BFF]/20">
                <p className="text-[#80E9FF] text-sm font-semibold">⚡ Works with any WooCommerce theme — no plugin required.</p>
            </div>
        </div>
    );
}

function CustomApiGuide() {
    const curlExample = `curl -X POST ${WEBHOOK_URL} \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: your_api_key_here" \\
  -d '{
    "store_order_id": "ORD-12345",
    "order_number": "#1001",
    "customer_name": "Rahul Sharma",
    "customer_phone": "+919876543210",
    "customer_email": "rahul@example.com",
    "order_amount": 1299.00,
    "currency": "INR",
    "payment_method": "cod",
    "products": [
      { "name": "Blue T-Shirt", "quantity": 2, "price": 499.50 }
    ],
    "shipping_address": {
      "address1": "123 MG Road",
      "city": "Bengaluru",
      "state": "KA",
      "pincode": "560001",
      "country": "IN"
    }
  }'`;

    const pythonExample = `import requests

def send_order_to_codverify(order):
    url = "${WEBHOOK_URL}"
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "store_order_id": str(order["id"]),
        "order_number":   order["number"],
        "customer_name":  order["customer_name"],
        "customer_phone": order["phone"],  # E.164: +91XXXXXXXXXX
        "customer_email": order["email"],
        "order_amount":   float(order["total"]),
        "currency":       "INR",
        "payment_method": "cod",
        "products":       order["line_items"],
        "shipping_address": order["shipping"],
    }
    response = requests.post(url, json=payload, headers=headers, timeout=15)
    return response.json()`;

    const responseExample = `{
  "success": true,
  "message": "Order received successfully",
  "data": {
    "order_id": "uuid-here",
    "verification_status": "pending",
    "scheduled_send_at": "2026-03-03T15:30:00Z",
    "risk_score": 2
  }
}`;

    return (
        <div className="space-y-8">
            <div className="grid sm:grid-cols-3 gap-4">
                {[
                    { icon: Key, label: 'Auth', desc: 'X-API-Key header' },
                    { icon: Globe, label: 'Method', desc: 'POST JSON' },
                    { icon: Zap, label: 'Response', desc: '< 500ms' },
                ].map((item, i) => (
                    <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/10 text-center">
                        <item.icon className="w-5 h-5 text-[#635BFF] mx-auto mb-2" />
                        <p className="text-xs font-black text-white uppercase tracking-widest">{item.label}</p>
                        <p className="text-xs text-white/45 mt-1">{item.desc}</p>
                    </div>
                ))}
            </div>

            <div>
                <p className="text-sm font-bold text-white mb-3 flex items-center gap-2"><Terminal className="w-4 h-4" />cURL Example</p>
                <CodeBlock id="curl-example" code={curlExample} />
            </div>
            <div>
                <p className="text-sm font-bold text-white mb-3 flex items-center gap-2"><Code className="w-4 h-4" />Python Example</p>
                <CodeBlock id="python-example" code={pythonExample} />
            </div>
            <div>
                <p className="text-sm font-bold text-white mb-3 flex items-center gap-2"><CheckCircle className="w-4 h-4 text-[#00D4AA]" />Success Response</p>
                <CodeBlock id="response-example" code={responseExample} />
            </div>

            <div className="p-4 bg-[#635BFF]/10 rounded-2xl border border-[#635BFF]/20 space-y-2">
                <p className="text-white text-sm font-bold">📋 Rules & Notes</p>
                <ul className="text-white/55 text-xs space-y-1 list-disc list-inside">
                    <li>Only <code className="bg-white/10 px-1 rounded">payment_method: "cod"</code> orders are processed</li>
                    <li>Phone must be E.164 format: <code className="bg-white/10 px-1 rounded">+91XXXXXXXXXX</code> or <code className="bg-white/10 px-1 rounded">+1XXXXXXXXXX</code></li>
                    <li>Duplicate <code className="bg-white/10 px-1 rounded">store_order_id</code> returns 409 Conflict</li>
                    <li>Rate limit: 100 requests/minute per API key</li>
                    <li>Full API reference at <Link to="/docs" className="underline font-bold text-[#635BFF]">docs page</Link></li>
                </ul>
            </div>
        </div>
    );
}

const GUIDES: Record<string, ReactElement> = {
    shopify: <ShopifyGuide />,
    woocommerce: <WooCommerceGuide />,
    custom: <CustomApiGuide />,
};

export default function IntegrationsPage() {
    const [active, setActive] = useState('shopify');

    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="Integrations — Connect Shopify, WooCommerce & Custom Stores"
                description="Connect your Shopify, WooCommerce, or custom store to CODVerify in under 5 minutes. Official plugins, REST API, and step-by-step integration guides."
                canonical="/integrations"
                keywords="shopify cod plugin, woocommerce cod verification, api integration, ecommerce cod solution, order verification api"
            />

            {/* Hero */}
            <section className="relative overflow-hidden bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] pt-24 pb-20 px-4">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(79,70,229,0.15)_0%,transparent_70%)]" />
                <div className="max-w-4xl mx-auto text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                        <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-[10px] font-black uppercase tracking-widest mb-6">
                            <Zap className="w-3 h-3" /> Quick Setup · No Coding Required
                        </span>
                        <h1 className="text-5xl md:text-6xl font-black text-white font-['Outfit'] tracking-tight mb-6">
                            Connect Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Store</span>
                        </h1>
                        <p className="text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
                            Integrate CODVerify with Shopify, WooCommerce, or any custom platform in under 5 minutes. Every COD order gets auto-verified via WhatsApp or SMS.
                        </p>
                    </motion.div>

                    {/* Stats */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                        className="grid grid-cols-3 gap-6 mt-14 max-w-2xl mx-auto"
                    >
                        {[
                            { label: 'Setup Time', value: '< 5 min' },
                            { label: 'Platforms', value: '3+' },
                            { label: 'API Calls', value: '1' },
                        ].map((s, i) => (
                            <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/10">
                                <p className="text-2xl font-black text-white font-['Outfit']">{s.value}</p>
                                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{s.label}</p>
                            </div>
                        ))}
                    </motion.div>
                </div>
            </section>

            {/* Plugin Download Cards */}
            <section className="max-w-5xl mx-auto px-4 py-12">
                <div className="text-center mb-10">
                    <h2 className="text-3xl font-black text-white font-['Outfit'] mb-3">
                        📦 Official Plugins
                    </h2>
                    <p className="text-white/45 text-lg">One-click installation — no code changes needed.</p>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                    {/* WooCommerce Plugin */}
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                        className="glass-card-ultra rounded-3xl p-8 hover:border-[#635BFF]/30 transition-all"
                    >
                        <div className="flex items-center gap-4 mb-6">
                            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl flex items-center justify-center text-3xl shadow-lg shadow-purple-500/20">
                                🟣
                            </div>
                            <div>
                                <h3 className="text-xl font-black text-white font-['Outfit']">WooCommerce Plugin</h3>
                                <p className="text-white/30 text-sm font-medium">v1.0.0 · WordPress Plugin</p>
                            </div>
                        </div>
                        <ul className="space-y-2 mb-8">
                            {['Auto-hook on COD order', 'Admin settings page', 'Connection test button', 'Order list status column', 'Resend verification', 'HPOS compatible'].map(f => (
                                <li key={f} className="flex items-center gap-2 text-sm text-white/55">
                                    <CheckCircle className="w-4 h-4 text-[#635BFF] flex-shrink-0" />
                                    {f}
                                </li>
                            ))}
                        </ul>
                        <div className="space-y-2">
                            <p className="text-xs font-bold text-white/30 uppercase tracking-widest">Install via WordPress Admin:</p>
                            <div className="bg-white/5 rounded-xl p-3 text-xs font-mono text-white/45 leading-relaxed border border-white/8">
                                Plugins → Add New → Upload Plugin<br />
                                → Select <strong className="text-white">codverify-woocommerce.zip</strong>
                            </div>
                            <a
                                href="https://codverify.tech/plugins/codverify-woocommerce.zip"
                                className="flex items-center justify-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-2xl font-black text-sm shadow-lg shadow-purple-500/20 hover:bg-purple-700 transition-all mt-3"
                            >
                                <Package className="w-4 h-4" /> Download Plugin (.zip)
                            </a>
                        </div>
                    </motion.div>

                    {/* Shopify App */}
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                        className="glass-card-ultra rounded-3xl p-8 hover:border-[#00D4AA]/30 transition-all"
                    >
                        <div className="flex items-center gap-4 mb-6">
                            <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center text-3xl shadow-lg shadow-green-500/20">
                                🛍️
                            </div>
                            <div>
                                <h3 className="text-xl font-black text-white font-['Outfit']">Shopify App</h3>
                                <p className="text-white/30 text-sm font-medium">v1.0.0 · Shopify App Store</p>
                            </div>
                        </div>
                        <ul className="space-y-2 mb-8">
                            {['OAuth 2.0 install flow', 'Auto webhook registration', 'Secure HMAC verification', 'Settings page in Shopify admin', 'orders/paid + orders/create', '100% automated'].map(f => (
                                <li key={f} className="flex items-center gap-2 text-sm text-white/55">
                                    <CheckCircle className="w-4 h-4 text-[#00D4AA] flex-shrink-0" />
                                    {f}
                                </li>
                            ))}
                        </ul>
                        <div className="space-y-2">
                            <p className="text-xs font-bold text-white/30 uppercase tracking-widest">Install from Shopify App Store:</p>
                            <div className="bg-white/5 rounded-xl p-3 text-xs font-mono text-white/45 leading-relaxed border border-white/8">
                                Shopify Admin → Apps → Search<br />
                                → <strong className="text-white">"CODVerify"</strong> → Install
                            </div>
                            <a
                                href="https://apps.shopify.com/codverify"
                                className="flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white rounded-2xl font-black text-sm shadow-lg shadow-green-500/20 hover:bg-green-700 transition-all mt-3"
                            >
                                <Zap className="w-4 h-4" /> Install Shopify App
                            </a>
                        </div>
                    </motion.div>
                </div>

                {/* Divider */}
                <div className="flex items-center gap-4 mt-12 mb-4">
                    <div className="flex-1 h-px bg-white/10" />
                    <span className="text-xs font-black text-white/25 uppercase tracking-widest px-3">OR SETUP MANUALLY</span>
                    <div className="flex-1 h-px bg-white/10" />
                </div>
            </section>

            {/* Platform selector + guide */}
            <section className="max-w-5xl mx-auto px-4 pb-20">
                {/* Platform tabs */}
                <div className="grid md:grid-cols-3 gap-4 mb-12">
                    {platforms.map(p => (
                        <button
                            key={p.id}
                            onClick={() => setActive(p.id)}
                            className={`relative flex items-center gap-4 p-5 rounded-2xl border-2 text-left transition-all ${active === p.id
                                ? 'border-[#635BFF] bg-[#635BFF]/10 shadow-lg shadow-[#635BFF]/10'
                                : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/8'
                                }`}
                        >
                            <div className={`w-12 h-12 bg-gradient-to-br ${p.color} rounded-xl flex items-center justify-center text-2xl shadow-lg ${p.shadow}`}>
                                {p.icon}
                            </div>
                            <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                    <p className="font-black text-white text-sm">{p.name}</p>
                                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest bg-white/10 text-white/50">
                                        {p.badge}
                                    </span>
                                </div>
                                {active === p.id && (
                                    <p className="text-[#635BFF] text-[10px] font-bold uppercase tracking-widest">Selected</p>
                                )}
                            </div>
                            {active === p.id && <CheckCircle className="w-5 h-5 text-[#635BFF] flex-shrink-0" />}
                        </button>
                    ))}
                </div>

                {/* Guide panel */}
                <motion.div
                    key={active}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-card-ultra rounded-3xl p-8 md:p-10"
                >
                    <div className="flex items-center gap-3 mb-8 pb-6 border-b border-white/10">
                        <div className={`text-2xl w-10 h-10 bg-gradient-to-br ${platforms.find(p => p.id === active)?.color} rounded-xl flex items-center justify-center`}>
                            {platforms.find(p => p.id === active)?.icon}
                        </div>
                        <div>
                            <h2 className="text-xl font-black text-white font-['Outfit']">
                                {platforms.find(p => p.id === active)?.name} Integration Guide
                            </h2>
                            <p className="text-white/35 text-sm">Step-by-step setup</p>
                        </div>
                    </div>
                    {GUIDES[active]}
                </motion.div>
            </section>

            {/* Bottom CTA */}
            <section className="relative py-20 sm:py-24 px-4">
                <div className="absolute inset-0 hero-gradient opacity-40" />
                <div className="max-w-3xl mx-auto text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-card-ultra rounded-3xl p-10 sm:p-14 relative overflow-hidden">
                        <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-[#635BFF]/20 rounded-full blur-[80px]" />
                        <div className="relative z-10">
                            <h2 className="text-3xl sm:text-4xl font-black text-white font-['Outfit'] tracking-tighter mb-4">Ready to reduce RTO?</h2>
                            <p className="text-white/40 text-base sm:text-lg mb-8">Start verifying COD orders automatically. Free trial, no credit card.</p>
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                <Link to="/signup" className="stripe-button flex items-center gap-2 px-8 py-4 text-white rounded-full font-bold text-sm">
                                    <Package className="w-5 h-5" /> Start Free Trial <ChevronRight className="w-4 h-4" />
                                </Link>
                                <Link to="/docs" className="flex items-center gap-2 px-8 py-4 bg-white/8 text-white rounded-full font-bold text-sm border border-white/15 hover:bg-white/15 transition-all">
                                    <Code className="w-5 h-5" /> Full API Docs
                                </Link>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </section>
        </div>
    );
}

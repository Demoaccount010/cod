import SEO from '../../components/SEO';
import { motion, useInView } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import {
    MessageSquare, Bot,
    Check, ArrowRight, Sparkles, RefreshCw, Layers, Zap, Shield, BarChart3,
    Activity, Cpu, Lock, Workflow, Code, Mail
} from 'lucide-react';
import { useEffect, useRef, type ReactNode } from 'react';

// ─── Reveal Wrapper ───────────────────────────────────────────────────────────
function RevealSection({ children, className = '' }: { children: ReactNode; className?: string }) {
    const ref = useRef<HTMLDivElement>(null);
    const isInView = useInView(ref, { once: true, margin: '-80px' });
    return (
        <motion.div ref={ref} initial={{ opacity: 0, y: 40 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className={className}>
            {children}
        </motion.div>
    );
}

const channels = [
    {
        id: 'whatsapp',
        name: 'WhatsApp Verification',
        country: 'India (Primary)',
        flag: '🇮🇳',
        icon: MessageSquare,
        gradient: 'from-[#25D366] to-[#128C7E]',
        glow: 'rgba(37, 211, 102, 0.2)',
        stat: '98%',
        statLabel: 'Delivery Rate',
        description: 'Interactive WhatsApp messages sent to Indian customers the moment a COD order is placed. Customer taps Confirm or Cancel directly in WhatsApp — no app, no wait, no friction.',
        features: [
            'Interactive Confirm / Cancel buttons',
            'Hindi & English support',
            'Auto-retry on no response',
            'Custom WhatsApp message templates',
            '98% message delivery rate',
        ],
    },
    {
        id: 'chatbot',
        name: 'AI Personal Chatbot',
        country: 'India + Global',
        flag: '🌍',
        icon: Bot,
        gradient: 'from-[#FF9E2C] to-[#FF6B6B]',
        glow: 'rgba(255, 158, 44, 0.2)',
        stat: '<1s',
        statLabel: 'Response Time',
        description: 'A fully trained AI chatbot embedded on your store website. Handles order tracking, address changes, FAQs, and delivery queries in real time. No wait time. No scripts. When the AI can\'t answer, it hands off to a live human agent automatically.',
        features: [
            'Embedded on any store website',
            'Multi-turn conversation memory',
            'Order status & tracking replies',
            'Address & quantity change handling',
            'Instant human agent handoff',
        ],
    },
    {
        id: 'risk',
        name: 'AI Risk Scoring',
        country: 'India + Global',
        flag: '🛡️',
        icon: Shield,
        gradient: 'from-[#635BFF] to-[#7A73FF]',
        glow: 'rgba(99, 91, 255, 0.2)',
        stat: '100%',
        statLabel: 'Order Coverage',
        description: 'Every single order is evaluated by our AI engine before any verification message is sent. Multiple risk signals are checked in milliseconds — flagging high-risk customers before you waste resources on them.',
        features: [
            'Customer RTO history check',
            'Cancellation rate scoring',
            'High-value order detection',
            'Address completeness validation',
            'Auto-blacklist on repeat offenders',
        ],
    },
    {
        id: 'email',
        name: 'Daily Summary Email',
        country: 'India + Global',
        flag: '📧',
        icon: Mail,
        gradient: 'from-[#00D4AA] to-[#80E9FF]',
        glow: 'rgba(0, 212, 170, 0.2)',
        stat: 'Daily',
        statLabel: 'Automated',
        description: 'Every morning you get a clean, structured performance email. Know exactly how many verifications were sent, how many confirmed, how many orders shipped, and how many fake orders were caught — all without logging in.',
        features: [
            'Verification rate breakdown',
            'Fake orders caught yesterday',
            'Revenue protected summary',
            'Confirmation vs. cancellation ratio',
            'Link to full dashboard',
        ],
    },
];

const platformFeatures = [
    { icon: Zap, title: 'Real-Time Processing', desc: 'Orders verified within seconds of placement. <240ms average response time across all channels.', color: '#00D4AA' },
    { icon: Shield, title: 'Fraud Prevention', desc: 'Multi-layer defense: AI risk scoring, blacklists, behavioral analysis — before any message is sent.', color: '#635BFF' },
    { icon: BarChart3, title: 'Live Dashboard', desc: 'Real-time view of every verification — sent, confirmed, cancelled, pending — with RTO trends.', color: '#80E9FF' },
    { icon: RefreshCw, title: 'Auto Retry Logic', desc: 'Unanswered verifications are automatically retried at smart intervals until confirmed or timed out.', color: '#FF80B5' },
    { icon: Layers, title: 'Multi-Store Support', desc: 'Connect multiple Shopify and WooCommerce stores under one CODVerify account — one dashboard.', color: '#FF9E2C' },
    { icon: Sparkles, title: 'Custom Templates', desc: 'Personalized WhatsApp message templates with dynamic order data — product name, amount, address.', color: '#00D4AA' },
    { icon: Mail, title: 'Daily Summary Email', desc: 'Every morning: verifications sent, confirmed, shipped, and fake orders blocked — delivered to your inbox.', color: '#635BFF' },
    { icon: Lock, title: 'Enterprise Security', desc: 'AES-256 encryption, SOC2-ready infrastructure, zero data sharing with third parties.', color: '#80E9FF' },
    { icon: Code, title: 'Developer API', desc: 'Full REST API with webhooks for Shopify, WooCommerce, and any custom store platform.', color: '#FF80B5' },
];

const integrationLogos = [
    { name: 'Shopify', icon: '🛍️' },
    { name: 'WooCommerce', icon: '🔌' },
    { name: 'Razorpay', icon: '💳' },
    { name: 'WhatsApp', icon: '💬' },
    { name: 'Twilio', icon: '📱' },
    { name: 'AWS', icon: '☁️' },
];

export default function FeaturesPage() {
    const location = useLocation();

    useEffect(() => {
        if (location.hash) {
            setTimeout(() => {
                const el = document.getElementById(location.hash.slice(1));
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 400);
        }
    }, [location.hash]);

    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="Features — WhatsApp, SMS, Voice & AI Chatbot Verification"
                description="Explore CODVerify's multi-channel verification: WhatsApp for India (94% response), SMS & Voice for USA, AI Chatbot for both markets. Compare pricing, features & delivery channels."
                canonical="/features"
                keywords="whatsapp verification, sms order verification, voice call verification, ai chatbot, cod verification channels, order confirmation india, order verification usa"
            />

            {/* ═══ HERO ═══ */}
            <section className="relative pt-32 pb-24 overflow-hidden">
                {/* Gradient mesh */}
                <div className="absolute inset-0 stripe-mesh-bg opacity-60" />
                <div className="absolute inset-0 grid-pattern-dark opacity-30" />

                {/* Floating orbs */}
                <div className="absolute top-20 left-[10%] w-72 h-72 bg-[#635BFF]/20 rounded-full blur-[100px] animate-float" />
                <div className="absolute bottom-10 right-[15%] w-96 h-96 bg-[#00D4AA]/15 rounded-full blur-[120px] animate-float-delay" />

                <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}>
                        <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-8">
                            <Activity className="w-3.5 h-3.5 text-[#00D4AA]" />
                            <span className="text-xs font-bold text-white/80 uppercase tracking-[0.2em]">Platform Features</span>
                        </div>
                        <h1 className="text-5xl md:text-7xl font-black font-['Outfit'] tracking-tighter text-white mb-6 leading-[0.95]">
                            One Platform.<br />
                            <span className="text-gradient-hero">Every Feature.</span>
                        </h1>
                        <p className="text-lg md:text-xl text-white/50 max-w-2xl mx-auto font-medium leading-relaxed mb-10">
                            WhatsApp verification for India, AI personal chatbot globally, AI risk scoring on every order, live support workers, and daily email performance summaries.
                        </p>

                        {/* Channel pills */}
                        <div className="flex flex-wrap items-center justify-center gap-3">
                            {channels.map((ch, i) => (
                                <motion.a
                                    key={ch.id}
                                    href={`#${ch.id}`}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.4 + i * 0.1 }}
                                    className="flex items-center gap-2.5 px-5 py-2.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all group"
                                >
                                    <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${ch.gradient} flex items-center justify-center`}>
                                        <ch.icon className="w-3.5 h-3.5 text-white" />
                                    </div>
                                    <span className="text-sm font-semibold text-white/70 group-hover:text-white transition-colors">{ch.name.split(' ')[0]}</span>
                                    <span className="text-lg">{ch.flag}</span>
                                </motion.a>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* ═══ VERIFICATION CHANNELS ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 bg-gradient-to-b from-[#0A2540] via-[#0D1B2A] to-[#0A2540]" />
                <div className="max-w-7xl mx-auto px-6 relative z-10">
                    <RevealSection className="text-center mb-20">
                        <h2 className="text-3xl md:text-5xl font-black font-['Outfit'] text-white tracking-tighter mb-4">
                            Platform <span className="text-gradient-stripe">Capabilities</span>
                        </h2>
                        <p className="text-white/40 max-w-xl mx-auto text-lg">
                            Beyond verification — every tool you need to run a smarter COD operation.
                        </p>
                    </RevealSection>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
                        {channels.map((ch) => (
                            <RevealSection key={ch.id}>
                                <div
                                    id={ch.id}
                                    className="card-3d scroll-mt-32"
                                >
                                    <div className="card-3d-inner glass-card-ultra rounded-3xl p-8 relative overflow-hidden group">
                                        {/* Glow effect */}
                                        <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full blur-[80px] opacity-0 group-hover:opacity-100 transition-opacity duration-700" style={{ background: ch.glow }} />

                                        <div className="relative z-10">
                                            <div className="flex items-start justify-between mb-6">
                                                <div>
                                                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${ch.gradient} flex items-center justify-center mb-4 shadow-lg`}>
                                                        <ch.icon className="w-7 h-7 text-white" />
                                                    </div>
                                                    <h3 className="text-xl font-black text-white tracking-tight font-['Outfit']">{ch.name}</h3>
                                                    <div className="flex items-center gap-2 mt-1.5">
                                                        <span className="text-lg">{ch.flag}</span>
                                                        <span className="text-sm text-white/40 font-medium">{ch.country}</span>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="bg-white/5 rounded-xl px-4 py-2 border border-white/10">
                                                        <div className="text-2xl font-black text-[#00D4AA]">{ch.stat}</div>
                                                        <div className="text-[10px] text-white/40 font-semibold uppercase tracking-wider">{ch.statLabel}</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <p className="text-white/50 text-sm leading-relaxed mb-6">{ch.description}</p>

                                            <ul className="space-y-2.5">
                                                {ch.features.map(f => (
                                                    <li key={f} className="flex items-center gap-3 text-sm text-white/70">
                                                        <div className="w-5 h-5 rounded-full bg-[#00D4AA]/15 flex items-center justify-center flex-shrink-0">
                                                            <Check className="w-3 h-3 text-[#00D4AA]" />
                                                        </div>
                                                        {f}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ INTELLIGENT ROUTING VISUAL ═══ */}
            <section className="relative py-24 overflow-hidden">
                <div className="absolute inset-0 bg-[#0A2540]" />
                <div className="absolute inset-0 hero-gradient opacity-40" />

                <div className="max-w-6xl mx-auto px-6 relative z-10">
                    <RevealSection>
                        <div className="glass-card-ultra rounded-3xl p-10 md:p-16 relative overflow-hidden">
                            <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                            <div className="relative z-10">
                                <div className="text-center mb-12">
                                    <div className="stripe-badge rounded-full px-4 py-1.5 inline-flex items-center gap-2 mb-6">
                                        <Workflow className="w-3.5 h-3.5 text-[#80E9FF]" />
                                        <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Smart Routing</span>
                                    </div>
                                    <h3 className="text-2xl md:text-4xl font-black text-white font-['Outfit'] tracking-tighter mb-3">
                                        Intelligent Channel Selection
                                    </h3>
                                    <p className="text-white/40 max-w-xl mx-auto">
                                        Our system automatically detects the optimal verification channel based on country, carrier, and customer history.
                                    </p>
                                </div>

                                {/* Routing flow visualization */}
                                <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-6">
                                    {/* Order comes in */}
                                    <div className="bg-[#635BFF]/10 border border-[#635BFF]/20 rounded-2xl px-6 py-4 text-center">
                                        <Cpu className="w-6 h-6 text-[#635BFF] mx-auto mb-2" />
                                        <div className="text-sm font-bold text-white">New COD Order</div>
                                        <div className="text-xs text-white/40">Webhook received</div>
                                    </div>

                                    <ArrowRight className="w-5 h-5 text-white/20 rotate-90 md:rotate-0 flex-shrink-0" />

                                    {/* AI Engine */}
                                    <div className="bg-gradient-to-br from-[#635BFF]/20 to-[#00D4AA]/20 border border-white/10 rounded-2xl px-6 py-4 text-center neon-border">
                                        <Activity className="w-6 h-6 text-[#00D4AA] mx-auto mb-2" />
                                        <div className="text-sm font-bold text-white">AI Risk Engine</div>
                                        <div className="text-xs text-white/40">Country + Risk Score</div>
                                    </div>

                                    <ArrowRight className="w-5 h-5 text-white/20 rotate-90 md:rotate-0 flex-shrink-0" />

                                    {/* Channels */}
                                    <div className="flex flex-col gap-2">
                                        {[
                                            { label: '🇮🇳 WhatsApp', color: 'from-[#25D366] to-[#128C7E]' },
                                            { label: '🇺🇸 SMS', color: 'from-[#635BFF] to-[#80E9FF]' },
                                            { label: '🇺🇸 Voice', color: 'from-[#FF80B5] to-[#635BFF]' },
                                            { label: '🌍 Chatbot', color: 'from-[#FF9E2C] to-[#FF6B6B]' },
                                        ].map(c => (
                                            <div key={c.label} className={`bg-gradient-to-r ${c.color} rounded-xl px-4 py-2 text-xs font-bold text-white shadow-lg`}>
                                                {c.label}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </RevealSection>
                </div>
            </section>

            {/* ═══ PLATFORM FEATURES ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 stripe-gradient-dark" />
                <div className="absolute inset-0 noise-overlay" />

                <div className="max-w-7xl mx-auto px-6 relative z-10">
                    <RevealSection className="text-center mb-20">
                        <h2 className="text-3xl md:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-4">
                            Platform <span className="text-gradient-hero">Intelligence</span>
                        </h2>
                        <p className="text-white/40 max-w-xl mx-auto text-lg">
                            Every feature built to reduce fake orders, protect revenue, and save you time.
                        </p>
                    </RevealSection>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                        {platformFeatures.map((feat) => (
                            <RevealSection key={feat.title}>
                                <motion.div
                                    whileHover={{ y: -5, scale: 1.02 }}
                                    transition={{ type: 'spring', stiffness: 300 }}
                                    className="glass-card-ultra rounded-2xl p-7 group cursor-default relative overflow-hidden h-full"
                                >
                                    {/* Accent glow on hover */}
                                    <div className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-[60px] opacity-0 group-hover:opacity-30 transition-opacity duration-700" style={{ background: feat.color }} />

                                    <div className="relative z-10">
                                        <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5" style={{ background: `${feat.color}15` }}>
                                            <feat.icon className="w-6 h-6" style={{ color: feat.color }} />
                                        </div>
                                        <h3 className="text-lg font-bold text-white mb-2 font-['Outfit']">{feat.title}</h3>
                                        <p className="text-white/40 text-sm leading-relaxed">{feat.desc}</p>
                                    </div>
                                </motion.div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ INTEGRATIONS ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 bg-[#0D1B2A]" />
                <div className="max-w-5xl mx-auto px-6 relative z-10">
                    <RevealSection>
                        <div className="text-center mb-14">
                            <h2 className="text-3xl md:text-4xl font-black text-white font-['Outfit'] tracking-tighter mb-4">
                                Works With Your Stack
                            </h2>
                            <p className="text-white/40 max-w-lg mx-auto">Native integrations with the platforms you already use.</p>
                        </div>
                        <div className="flex flex-wrap items-center justify-center gap-4">
                            {integrationLogos.map((logo) => (
                                <motion.div
                                    key={logo.name}
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    whileHover={{ scale: 1.1, y: -4 }}
                                    className="glass-card-ultra rounded-2xl px-8 py-5 flex flex-col items-center gap-2 cursor-default min-w-[120px]"
                                >
                                    <span className="text-3xl">{logo.icon}</span>
                                    <span className="text-xs font-semibold text-white/60">{logo.name}</span>
                                </motion.div>
                            ))}
                        </div>
                    </RevealSection>
                </div>
            </section>

            {/* ═══ CTA ═══ */}
            <section className="relative py-24">
                <div className="absolute inset-0 bg-[#0A2540]" />
                <div className="absolute inset-0 hero-gradient opacity-50" />

                <div className="max-w-3xl mx-auto px-6 relative z-10">
                    <RevealSection className="text-center">
                        <div className="glass-card-ultra rounded-3xl p-12 md:p-16 relative overflow-hidden">
                            <div className="absolute inset-0 grid-pattern-dark opacity-15" />
                            {/* Corner glow */}
                            <div className="absolute -top-20 -left-20 w-60 h-60 bg-[#635BFF]/20 rounded-full blur-[80px]" />
                            <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-[#00D4AA]/15 rounded-full blur-[80px]" />

                            <div className="relative z-10">
                                <h2 className="text-3xl md:text-5xl font-black text-white font-['Outfit'] tracking-tighter mb-4">
                                    Ready to <span className="text-gradient-hero">get started?</span>
                                </h2>
                                <p className="text-white/40 mb-10 text-lg max-w-md mx-auto">
                                    Join 1,200+ e-commerce brands already running smarter COD operations with CODVerify.
                                </p>
                                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                    <Link to="/signup" className="stripe-button text-white rounded-full font-bold text-sm px-8 py-4 flex items-center gap-2 group">
                                        Start Free <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                    </Link>
                                    <Link to="/services" className="px-8 py-4 rounded-full font-bold text-sm text-white border border-white/15 hover:bg-white/5 transition-all">
                                        View Services
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </RevealSection>
                </div>
            </section>
        </div>
    );
}

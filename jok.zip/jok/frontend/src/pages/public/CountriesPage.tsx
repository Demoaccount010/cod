import SEO from '../../components/SEO';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Check, X, MessageSquare, Phone, Globe, ArrowRight, Zap } from 'lucide-react';

const countries = [
    {
        code: 'IN', flag: '🇮🇳', name: 'India', status: 'live', currency: 'INR', symbol: '₹',
        channels: { whatsapp: true, sms: false, voice: false },
        pricing: { WhatsApp: '₹2.50/verify' },
        description: 'Full WhatsApp verification with interactive one-tap order confirmation buttons. Hindi, English & regional language support.',
        languages: ['Hindi', 'English', 'Hinglish'],
        badge: 'Most Popular',
        badgeColor: 'bg-emerald-100 text-emerald-700',
        provider: 'Facebook WhatsApp API',
        codRate: '35–45%',
    },
    {
        code: 'US', flag: '🇺🇸', name: 'United States', status: 'coming_soon', currency: 'USD', symbol: '$',
        channels: { whatsapp: true, sms: false, voice: false },
        pricing: { WhatsApp: '$0.06/verify' },
        description: 'WhatsApp verification for US customers. Coming soon with full English language support.',
        languages: ['English'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: 'WhatsApp API',
        codRate: '15–25%',
    },
    {
        code: 'PH', flag: '🇵🇭', name: 'Philippines', status: 'coming_soon', currency: 'USD', symbol: '$',
        channels: { whatsapp: true, sms: false, voice: false },
        pricing: { WhatsApp: '$0.05/verify' },
        description: 'WhatsApp verification for Philippines. COD accounts for 60–70% of all e-commerce in PH — one of the highest rates in the world.',
        languages: ['English', 'Filipino'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: 'WhatsApp API',
        codRate: '60–70%',
    },
    {
        code: 'MX', flag: '🇲🇽', name: 'Mexico', status: 'coming_soon', currency: 'USD', symbol: '$',
        channels: { whatsapp: true, sms: false, voice: false },
        pricing: { WhatsApp: '$0.04/verify' },
        description: 'WhatsApp verification en español para clientes mexicanos. El sistema detecta automáticamente el idioma.',
        languages: ['Español', 'English'],
        badge: 'Coming Soon · Español',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: 'WhatsApp API',
        codRate: '40–50%',
    },
    {
        code: 'GB', flag: '🇬🇧', name: 'United Kingdom', status: 'coming_soon', currency: 'USD', symbol: '$',
        channels: { whatsapp: true, sms: false, voice: false },
        pricing: { WhatsApp: '$0.08/verify' },
        description: 'WhatsApp verification for UK COD merchants. High-value market with premium order values and growing COD demand.',
        languages: ['English'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: 'WhatsApp API',
        codRate: '5–8%',
    },
    // Coming Soon
    {
        code: 'AE', flag: '🇦🇪', name: 'UAE (Middle East)', status: 'coming_soon', currency: 'AED', symbol: 'د.إ',
        channels: { whatsapp: false, sms: false, voice: false },
        pricing: {},
        description: 'WhatsApp verification for Middle East COD markets — one of the world\'s largest COD regions. Arabic language support planned.',
        languages: ['Arabic', 'English'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: '—',
        codRate: '70–80%',
    },
    {
        code: 'SA', flag: '🇸🇦', name: 'Saudi Arabia', status: 'coming_soon', currency: 'SAR', symbol: '﷼',
        channels: { whatsapp: false, sms: false, voice: false },
        pricing: {},
        description: 'WhatsApp verification for Saudi Arabia e-commerce. COD is dominant for 70%+ of online orders in the Kingdom.',
        languages: ['Arabic', 'English'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: '—',
        codRate: '70–80%',
    },
    {
        code: 'PK', flag: '🇵🇰', name: 'Pakistan', status: 'coming_soon', currency: 'PKR', symbol: '₨',
        channels: { whatsapp: false, sms: false, voice: false },
        pricing: {},
        description: 'WhatsApp verification with Urdu language support for Pakistan — a fast-growing COD e-commerce market.',
        languages: ['Urdu', 'English'],
        badge: 'Coming Soon',
        badgeColor: 'bg-gray-100 text-gray-600',
        provider: '—',
        codRate: '80–90%',
    },
];

const channelConfig = {
    whatsapp: { icon: MessageSquare, label: 'WhatsApp', color: 'text-emerald-600' },
    sms: { icon: Globe, label: 'SMS', color: 'text-blue-600' },
    voice: { icon: Phone, label: 'Voice', color: 'text-purple-600' },
};

export default function CountriesPage() {
    const liveCountries = countries.filter(c => c.status === 'live');
    const comingCountries = countries.filter(c => c.status === 'coming_soon');

    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="Available Countries — India, USA, Philippines, Mexico & UK"
                description="CODVerify is live in 5 countries: India (WhatsApp), USA, Philippines, Mexico & UK (SMS + Voice). Compare pricing, channels, and language support per country."
                canonical="/countries"
                keywords="cod verification india, order verification usa, cod verification philippines, cod verification mexico, cod verification uk, international cod"
            />

            {/* ─── Hero ─── */}
            <section className="relative pt-32 pb-20 overflow-hidden">
                <div className="absolute inset-0 stripe-mesh-bg opacity-50" />
                <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                <div className="absolute top-20 left-[15%] w-72 h-72 bg-[#635BFF]/20 rounded-full blur-[100px] animate-float" />
                <div className="absolute bottom-10 right-[10%] w-80 h-80 bg-[#00D4AA]/15 rounded-full blur-[120px] animate-float-delay" />

                <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
                        <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-8">
                            <Globe className="w-3.5 h-3.5 text-[#00D4AA]" />
                            <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Global Coverage</span>
                        </div>
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-white font-['Outfit'] tracking-tighter mb-6 leading-[0.95]">
                            Global COD<br /><span className="text-gradient-hero">Verification</span>
                        </h1>
                        <p className="text-white/45 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
                            Auto-detect your customer's country and route to the optimal channel — WhatsApp for India, SMS & Voice for USA, and expanding globally.
                        </p>
                        <div className="flex flex-wrap justify-center gap-4">
                            {liveCountries.map(c => (
                                <div key={c.code} className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2">
                                    <span className="text-xl">{c.flag}</span>
                                    <span className="text-sm font-semibold text-white/70">{c.name}</span>
                                    <span className="w-1.5 h-1.5 rounded-full bg-[#00D4AA] animate-pulse" />
                                </div>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* ─── Live Countries ─── */}
            <section className="relative py-16 sm:py-20">
                <div className="absolute inset-0 bg-gradient-to-b from-[#0A2540] via-[#0D1B2A] to-[#0A2540]" />
                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <h2 className="text-xl sm:text-2xl font-black text-white mb-8 tracking-tight flex items-center gap-3">
                        <span className="w-2 h-2 rounded-full bg-[#00D4AA] animate-pulse flex-shrink-0" />
                        Live Countries
                        <span className="text-[#00D4AA]">({liveCountries.length})</span>
                    </h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6">
                        {liveCountries.map((country, i) => (
                            <motion.div
                                key={country.code}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.08 }}
                                viewport={{ once: true }}
                                className="glass-card-ultra rounded-2xl sm:rounded-3xl p-6 sm:p-8 relative overflow-hidden group"
                            >
                                <div className="absolute -top-10 -right-10 w-32 h-32 bg-[#00D4AA]/10 rounded-full blur-[60px] opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                                <div className="relative z-10">
                                    <div className="flex items-start justify-between mb-5">
                                        <div className="flex items-center gap-3 sm:gap-4">
                                            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/8 border border-white/10 flex items-center justify-center text-2xl sm:text-3xl">
                                                {country.flag}
                                            </div>
                                            <div>
                                                <h3 className="text-lg sm:text-xl font-black text-white font-['Outfit']">{country.name}</h3>
                                                <div className="text-xs text-white/30 font-medium mt-0.5">{country.currency} · {country.provider}</div>
                                            </div>
                                        </div>
                                        <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-[#00D4AA]/15 text-[#00D4AA] border border-[#00D4AA]/20 flex-shrink-0">
                                            {country.badge}
                                        </span>
                                    </div>
                                    <p className="text-white/45 text-sm leading-relaxed mb-5">{country.description}</p>

                                    {/* Channels */}
                                    <div className="flex flex-wrap gap-2 mb-5">
                                        {Object.entries(channelConfig).map(([key, ch]) => {
                                            const available = country.channels[key as keyof typeof country.channels];
                                            return (
                                                <div key={key} className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold ${available ? 'bg-[#00D4AA]/10 border border-[#00D4AA]/20 text-[#00D4AA]' : 'bg-white/4 border border-white/8 text-white/20'}`}>
                                                    <ch.icon className="w-3.5 h-3.5" />
                                                    <span>{ch.label}</span>
                                                    {available ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {/* Pricing */}
                                    {Object.keys(country.pricing).length > 0 && (
                                        <div className="flex flex-wrap gap-2 mb-4">
                                            {Object.entries(country.pricing).map(([key, price]) => (
                                                <div key={key} className="bg-white/5 rounded-xl border border-white/10 px-3 py-1.5 text-xs">
                                                    <span className="text-white/30">{key}: </span>
                                                    <span className="font-black text-white">{price}</span>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t border-white/8">
                                        <div className="flex flex-wrap items-center gap-1.5">
                                            <span className="text-xs text-white/25">Languages:</span>
                                            {country.languages.map(l => (
                                                <span key={l} className="text-xs bg-white/5 border border-white/10 rounded-lg px-2 py-0.5 font-medium text-white/55">{l}</span>
                                            ))}
                                        </div>
                                        <span className="text-xs font-bold text-white/30">COD Rate: {country.codRate}</span>
                                    </div>

                                    <div className="mt-4">
                                        <Link to="/signup" className="flex items-center gap-2 text-[#635BFF] text-sm font-bold hover:text-[#7A73FF] transition-colors group/link">
                                            Start verifying {country.name} orders
                                            <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                                        </Link>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ─── Coming Soon ─── */}
            <section className="relative py-16 sm:py-20">
                <div className="absolute inset-0 bg-[#0A2540]" />
                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <h2 className="text-xl sm:text-2xl font-black text-white mb-8 tracking-tight flex items-center gap-3">
                        <span className="w-2 h-2 rounded-full bg-[#FF9E2C] flex-shrink-0" />
                        Coming Soon
                        <span className="text-white/30">({comingCountries.length})</span>
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {comingCountries.map((country, i) => (
                            <motion.div
                                key={country.code}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.06 }}
                                viewport={{ once: true }}
                                className="glass-card-ultra rounded-2xl p-5 sm:p-6 group"
                            >
                                <div className="flex items-center gap-3 mb-3">
                                    <span className="text-2xl grayscale group-hover:grayscale-0 transition-all">{country.flag}</span>
                                    <div>
                                        <h4 className="font-bold text-white/70 text-sm">{country.name}</h4>
                                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#FF9E2C]/15 text-[#FF9E2C] border border-[#FF9E2C]/20">{country.badge}</span>
                                    </div>
                                </div>
                                <p className="text-xs text-white/35 leading-relaxed mb-2">{country.description}</p>
                                <p className="text-xs font-bold text-white/25">Avg COD Rate: {country.codRate}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ─── CTA ─── */}
            <section className="relative py-20 sm:py-24">
                <div className="absolute inset-0 hero-gradient opacity-50" />
                <div className="max-w-2xl mx-auto px-4 sm:px-6 text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-card-ultra rounded-3xl p-10 sm:p-14 relative overflow-hidden">
                        <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-[#635BFF]/20 rounded-full blur-[80px]" />
                        <div className="relative z-10">
                            <Zap className="w-10 h-10 text-[#FF9E2C] mx-auto mb-5" />
                            <h2 className="text-2xl sm:text-3xl font-black text-white font-['Outfit'] tracking-tighter mb-3">Your country not listed?</h2>
                            <p className="text-white/40 text-sm sm:text-base mb-8 leading-relaxed">We're expanding fast. Join the waitlist and get early access for your market.</p>
                            <Link to="/contact" className="stripe-button inline-flex items-center gap-2 px-8 py-4 text-white rounded-full font-bold text-sm">
                                Join Waitlist <ArrowRight className="w-4 h-4" />
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>
        </div>
    );
}

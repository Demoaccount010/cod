import SEO from '../../components/SEO';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronDown, MessageSquare } from 'lucide-react';
import { useState } from 'react';

const faqCategories = [
    {
        name: 'General',
        items: [
            { q: 'What is CODVerify?', a: 'CODVerify is a B2B SaaS platform that automatically verifies COD (Cash on Delivery) orders via WhatsApp. When a customer places a COD order, they instantly receive an interactive WhatsApp message to confirm or cancel — so only genuine orders get shipped.' },
            { q: 'How does the verification work?', a: 'When a new COD order is placed on your store (Shopify, WooCommerce, or custom), CODVerify sends a WhatsApp message with interactive Confirm/Cancel buttons. If unanswered, it automatically retries. You only ship orders that are confirmed.' },
            { q: 'Do I need any technical knowledge?', a: 'Not at all. Shopify and WooCommerce connect via native webhook integrations — no coding required. For custom platforms, we provide a simple REST API. Your dedicated account executive handles the onboarding.' },
            { q: 'Is there a free trial?', a: 'Yes! You can start with your first 50 verifications at no cost. No credit card required to get started.' },
        ]
    },
    {
        name: 'Features',
        items: [
            { q: 'What is the AI Personal Chatbot?', a: 'It\'s a fully trained AI chatbot that lives on your store\'s website. It handles order tracking queries, address change requests, delivery FAQs, and general customer support in real time — 24/7, without any human. When it can\'t answer, it hands off instantly to a live support worker from our team.' },
            { q: 'What is the Daily Summary Email?', a: 'Every morning, CODVerify sends you a structured performance email: how many verifications were sent, how many were confirmed, how many orders shipped, and how many fake orders were blocked. You stay on top of your numbers without logging into the dashboard.' },
            { q: 'What is AI Risk Scoring?', a: 'Before sending any verification message, our AI evaluates each order based on: customer RTO history, cancellation rate, order value, address completeness, and blacklist status. High-risk orders are flagged or held so you don\'t waste resources verifying fake customers.' },
            { q: 'What are Live Support Workers?', a: 'When the AI chatbot on your store reaches its knowledge limit, it instantly escalates the conversation to a real human agent from our team. The worker sees the full chat history and continues the conversation seamlessly — your customer never realizes the switch.' },
        ]
    },
    {
        name: 'India',
        items: [
            { q: 'Do I need to create a WhatsApp Business API account?', a: 'No. CODVerify manages the WhatsApp Business API connection on your behalf. You just provide your WhatsApp Business Phone Number ID and Access Token from Meta Business Manager — we take care of everything else.' },
            { q: 'What languages does the WhatsApp verification support?', a: 'Currently English and Hindi are fully supported. Hinglish (mix of both) is handled naturally. Regional language templates can be requested for your account.' },
            { q: 'What payment methods are available?', a: 'We accept all major UPI apps (PhonePe, GPay, Paytm), credit/debit cards, and net banking via Razorpay for Indian merchants. International merchants pay via Stripe.' },
            { q: 'What is the cost per WhatsApp verification?', a: 'Pricing is contract-based and depends on your monthly order volume. Your dedicated account executive puts together a custom rate that fits your business. Contact us to discuss.' },
        ]
    },
    {
        name: 'Billing',
        items: [
            { q: 'How does billing work?', a: 'CODVerify operates on a contract-based model. Your access is activated through a signed contract — no self-serve credit card billing. We discuss your volume, needs, and rate directly with you.' },
            { q: 'Is there a monthly subscription fee?', a: 'There is no standard subscription fee. Your rate is negotiated directly based on your order volume — the more you scale, the better your per-verification economics. Contact us for a custom quote.' },
            { q: 'What happens if a verification message fails to deliver?', a: 'If a message fails due to a system error on our end, the verification is re-attempted automatically. Failed verifications that cannot be retried are flagged and your account executive is notified.' },
            { q: 'Do I get an invoice for my payments?', a: 'Yes — every billing event generates an automatic invoice sent to your registered email. You can also view all invoices from your merchant dashboard.' },
        ]
    },
];

function FAQItem({ item }: { item: { q: string; a: string } }) {
    const [open, setOpen] = useState(false);
    return (
        <div className={`rounded-2xl overflow-hidden transition-all duration-300 ${open ? 'bg-[#635BFF]/10 border border-[#635BFF]/20' : 'bg-white/4 border border-white/8 hover:border-white/15'}`}>
            <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left gap-4">
                <span className={`font-bold text-sm sm:text-base leading-snug ${open ? 'text-white' : 'text-white/70'}`}>{item.q}</span>
                <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-300 ${open ? 'rotate-180 text-[#635BFF]' : 'text-white/30'}`} />
            </button>
            {open && (
                <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm text-white/50 leading-relaxed border-t border-white/8 pt-4">
                    {item.a}
                </div>
            )}
        </div>
    );
}

export default function FAQPage() {
    const [activeCategory, setActiveCategory] = useState('General');
    const current = faqCategories.find(c => c.name === activeCategory)!;

    return (
        <div className="min-h-screen bg-[#0A2540]">
            <SEO
                title="FAQ â€” Frequently Asked Questions"
                description="Common questions about CODVerify's COD order verification: WhatsApp verification, SMS, voice call, pricing, billing, API integration, Shopify & WooCommerce plugins."
                canonical="/faq"
                keywords="cod verification faq, whatsapp verification questions, order verification pricing, rto reduction help"
                structuredData={{
                    "@context": "https://schema.org",
                    "@type": "FAQPage",
                    "mainEntity": faqCategories.flatMap(c => c.items.map(item => ({
                        "@type": "Question",
                        "name": item.q,
                        "acceptedAnswer": { "@type": "Answer", "text": item.a }
                    })))
                }}
            />

            {/* â”€â”€â”€ Hero â”€â”€â”€ */}
            <section className="relative pt-32 pb-20 overflow-hidden">
                <div className="absolute inset-0 stripe-mesh-bg opacity-50" />
                <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                <div className="absolute top-20 left-[10%] w-64 h-64 bg-[#635BFF]/20 rounded-full blur-[100px] animate-float" />
                <div className="absolute bottom-0 right-[5%] w-72 h-72 bg-[#00D4AA]/15 rounded-full blur-[100px] animate-float-delay" />

                <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center relative z-10">
                    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
                        <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-8">
                            <MessageSquare className="w-3.5 h-3.5 text-[#00D4AA]" />
                            <span className="text-xs font-bold text-white/70 uppercase tracking-[0.2em]">Help Center</span>
                        </div>
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-white font-['Outfit'] tracking-tighter mb-5">
                            Frequently Asked<br /><span className="text-gradient-hero">Questions</span>
                        </h1>
                        <p className="text-white/40 text-lg">
                            Can't find an answer?{' '}
                            <Link to="/contact" className="text-[#635BFF] hover:text-[#7A73FF] font-bold transition-colors">Contact us â†’</Link>
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* â”€â”€â”€ FAQ Content â”€â”€â”€ */}
            <section className="relative pb-24">
                <div className="max-w-4xl mx-auto px-4 sm:px-6">
                    {/* Category tabs */}
                    <div className="flex flex-wrap gap-2 mb-10">
                        {faqCategories.map(c => (
                            <button key={c.name} onClick={() => setActiveCategory(c.name)}
                                className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all ${activeCategory === c.name
                                    ? 'stripe-button text-white shadow-lg'
                                    : 'bg-white/5 text-white/50 border border-white/10 hover:bg-white/10 hover:text-white/70'}`}>
                                {c.name}
                            </button>
                        ))}
                    </div>

                    <div className="space-y-3">
                        {current.items.map((item, i) => (
                            <motion.div key={`${activeCategory}-${i}`} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                                <FAQItem item={item} />
                            </motion.div>
                        ))}
                    </div>

                    {/* Bottom CTA */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="mt-16 glass-card-ultra rounded-3xl p-10 sm:p-12 text-center relative overflow-hidden"
                    >
                        <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                        <div className="absolute -top-16 -left-16 w-48 h-48 bg-[#635BFF]/15 rounded-full blur-[80px]" />
                        <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-[#00D4AA]/10 rounded-full blur-[80px]" />
                        <div className="relative z-10">
                            <p className="text-white font-bold text-xl font-['Outfit'] mb-2">Still have questions?</p>
                            <p className="text-white/40 text-sm mb-8">Our team is available 9 AMâ€“9 PM IST, Monday to Saturday.</p>
                            <Link to="/contact" className="stripe-button inline-flex items-center gap-2 text-white px-8 py-3.5 rounded-full font-bold text-sm">
                                Contact Support <ArrowRight className="w-4 h-4" />
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>
        </div>
    );
}

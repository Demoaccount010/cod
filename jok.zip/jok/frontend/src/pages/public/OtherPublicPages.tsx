import SEO from '../../components/SEO';
import { useEffect, useState } from 'react';
import { publicApi } from '../../api';
import { ExternalLink, Calendar, Clock, Share2, ArrowRight, Layers, Sparkles, Globe, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';

// ─── Partners Page ───
export function PartnersPage() {
    const [partners, setPartners] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        publicApi.getPartners()
            .then(r => setPartners(r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    return (
        <div className="min-h-screen pt-32 pb-20 overflow-hidden relative bg-[#0A2540]">
            <SEO
                title="Ecosystem Partners"
                description="Our trusted e-commerce and logistics partners powering the CODVerify verification network. Integrated with leading platforms."
                canonical="/partners"
                keywords="codverify partners, ecommerce verification partners, logistics integration"
            />

            <div className="max-w-7xl mx-auto px-6 relative z-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center max-w-3xl mx-auto mb-20"
                >
                    <div className="stripe-badge rounded-full inline-flex items-center gap-2 px-5 py-2 mb-6">
                        <Layers className="w-4 h-4 text-indigo-600" />
                        <span className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em]">Network Topology</span>
                    </div>
                    <h1 className="text-5xl lg:text-7xl font-black text-white font-['Outfit'] tracking-tighter mb-6">
                        Trusted <br />
                        <span className="text-gradient-hero italic">Ecosystem Nodes</span><span className="text-white">.</span>
                    </h1>
                    <p className="text-xl text-white/40 font-medium italic">
                        Deep integration with the world's most robust e-commerce <br />
                        platforms and logistics intelligence clusters.
                    </p>
                </motion.div>

                {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4">
                        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
                        <p className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Scanning Network Segments...</p>
                    </div>
                ) : (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {partners.map((p: any, i: number) => (
                            <motion.div
                                key={p.id || i}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.1 }}
                                className="glass-card-ultra rounded-[32px] border border-white/8 p-8 hover:border-[#635BFF]/30 hover:shadow-2xl hover:shadow-[#635BFF]/10 transition-all duration-500 group relative overflow-hidden"
                            >
                                <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:scale-125 transition-transform duration-700">
                                    <Globe className="w-24 h-24" />
                                </div>

                                <div className="relative z-10">
                                    <div className="h-16 flex items-center mb-8">
                                        {p.partner_logo_url ? (
                                            <img src={p.partner_logo_url} alt={p.partner_name} className="h-full object-contain filter grayscale group-hover:grayscale-0 transition-all duration-500" />
                                        ) : (
                                            <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-300">
                                                <Layers className="w-8 h-8" />
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex items-center gap-2 mb-3">
                                        <h3 className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tight group-hover:text-[#635BFF] transition-colors uppercase italic">{p.partner_name}</h3>
                                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                    </div>

                                    <p className="text-sm text-white/30 font-medium leading-relaxed mb-6 line-clamp-2 italic">"{p.short_description}"</p>

                                    <div className="flex items-center justify-between pt-6 border-t border-white/5">
                                        <div className="px-3 py-1 bg-[#635BFF]/10 text-[#635BFF] text-[10px] font-black uppercase tracking-widest rounded-lg border border-[#635BFF]/20">
                                            {p.category || 'Core Integration'}
                                        </div>
                                        {p.partner_website_url && (
                                            <a href={p.partner_website_url} target="_blank" rel="noopener" className="p-3 bg-white/5 text-white/30 rounded-xl hover:bg-[#635BFF] hover:text-white transition-all">
                                                <ExternalLink className="w-4 h-4" />
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}

                {!loading && partners.length === 0 && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-32 text-center bg-white/3 rounded-[40px] border border-dashed border-white/10">
                        <Sparkles className="w-12 h-12 text-white/10 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white font-['Outfit'] mb-2">Network Expansion in Progress</h3>
                        <p className="text-sm text-white/30">New high-fidelity nodes are currently undergoing synchronization.</p>
                    </motion.div>
                )}
            </div>
        </div>
    );
}

// ─── Blog Page ───
export function BlogPage() {
    const [posts, setPosts] = useState<any[]>([]);
    const [categories, setCategories] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeCategory, setActiveCategory] = useState('');

    useEffect(() => {
        Promise.all([publicApi.getBlogPosts(), publicApi.getCategories()])
            .then(([p, c]) => {
                setPosts(p.data?.data?.posts || p.data?.data || []);
                setCategories(c.data?.data || []);
            })
            .finally(() => setLoading(false));
    }, []);

    const filtered = activeCategory ? posts.filter((p: any) => p.category === activeCategory) : posts;

    return (
        <div className="min-h-screen pt-32 pb-20 overflow-hidden relative bg-[#0A2540]">
            <SEO
                title="Blog — E-Commerce Insights & RTO Strategies"
                description="Strategic insights, RTO reduction strategies, and e-commerce verification best practices from the CODVerify team."
                canonical="/blog"
                keywords="cod verification blog, rto reduction tips, ecommerce insights, order verification strategies"
            />

            <div className="max-w-7xl mx-auto px-6 relative z-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center max-w-3xl mx-auto mb-20"
                >
                    <div className="stripe-badge rounded-full inline-flex items-center gap-2 px-5 py-2 mb-6">
                        <MessageSquare className="w-4 h-4 text-indigo-600" />
                        <span className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em]">Knowledge Propagation</span>
                    </div>
                    <h1 className="text-5xl lg:text-7xl font-black text-white font-['Outfit'] tracking-tighter mb-6">
                        Strategic <br />
                        <span className="text-gradient-hero italic">Intelligence Feed</span><span className="text-white">.</span>
                    </h1>
                    <p className="text-xl text-white/40 font-medium italic">
                        Advanced order verification matrices, behavioral analysis, <br />
                        and logistics optimization protocols.
                    </p>
                </motion.div>

                {categories.length > 0 && (
                    <div className="flex flex-wrap gap-3 justify-center mb-16 px-4 py-2 bg-white/5 rounded-3xl border border-white/10 max-w-fit mx-auto">
                        <button
                            onClick={() => setActiveCategory('')}
                            className={`px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${!activeCategory ? 'bg-[#635BFF] text-white shadow-lg shadow-[#635BFF]/20' : 'bg-transparent text-white/30 hover:text-white/50'}`}
                        >
                            All Logs
                        </button>
                        {categories.map((c: any) => (
                            <button
                                key={c.name}
                                onClick={() => setActiveCategory(c.name)}
                                className={`px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === c.name ? 'bg-[#635BFF] text-white shadow-lg shadow-[#635BFF]/20' : 'bg-transparent text-white/30 hover:text-white/50'}`}
                            >
                                {c.name} <span className="ml-1 opacity-50">[{c.count}]</span>
                            </button>
                        ))}
                    </div>
                )}

                {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4">
                        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
                        <p className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Retrieving Intelligence Logs...</p>
                    </div>
                ) : (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10">
                        {filtered.map((p: any, i: number) => (
                            <motion.article
                                key={p.slug || i}
                                initial={{ opacity: 0, scale: 0.95 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.1 }}
                                className="group flex flex-col bg-white/3 rounded-[40px] border border-white/8 overflow-hidden hover:shadow-2xl hover:shadow-[#635BFF]/10 hover:border-white/15 transition-all duration-700"
                            >
                                <div className="relative aspect-[16/10] overflow-hidden">
                                    {p.featured_image_url ? (
                                        <img src={p.featured_image_url} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                                    ) : (
                                        <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                                            <MessageSquare className="w-12 h-12 text-white/10" />
                                        </div>
                                    )}
                                    <div className="absolute top-6 left-6 flex gap-2">
                                        <div className="px-4 py-1.5 bg-white/10 backdrop-blur-md rounded-xl text-[9px] font-black uppercase tracking-widest text-white shadow-sm border border-white/20">
                                            {p.category || 'Research'}
                                        </div>
                                    </div>
                                </div>

                                <div className="p-10 flex flex-col flex-1">
                                    <div className="flex items-center gap-4 text-[10px] font-black text-white/25 uppercase tracking-widest mb-4">
                                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-tighter">
                                            <Calendar className="w-3.5 h-3.5" />
                                            {new Date(p.published_at || Date.now()).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                                        </div>
                                        <div className="w-1 h-1 bg-white/20 rounded-full" />
                                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-tighter">
                                            <Clock className="w-3.5 h-3.5" />
                                            {p.reading_time_minutes || 4} Min Pulse
                                        </div>
                                    </div>

                                    <h3 className="text-2xl font-black text-gray-900 font-['Outfit'] tracking-tighter leading-tight mb-4 group-hover:text-[#635BFF] transition-colors uppercase italic line-clamp-2 italic">
                                        {p.title}
                                    </h3>

                                    <p className="text-white/30 font-medium leading-relaxed italic line-clamp-3 mb-8">
                                        {p.excerpt}
                                    </p>

                                    <div className="mt-auto flex items-center justify-between">
                                        <div className="flex items-center gap-2 text-[#635BFF] font-bold text-sm group-hover:gap-4 transition-all">
                                            Access Log <ArrowRight className="w-4 h-4" />
                                        </div>
                                        <button className="p-3 bg-white/5 text-white/20 rounded-2xl hover:bg-[#635BFF]/10 hover:text-[#635BFF] transition-all">
                                            <Share2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            </motion.article>
                        ))}
                    </div>
                )}

                {!loading && filtered.length === 0 && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-32 text-center bg-white/3 rounded-[40px] border border-dashed border-white/10">
                        <Sparkles className="w-12 h-12 text-white/10 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white font-['Outfit'] mb-2">Feed Synchronization Delay</h3>
                        <p className="text-sm text-white/30">Our logistics analysts are currently finalizing the latest RTO matrices.</p>
                    </motion.div>
                )}
            </div>
        </div>
    );
}

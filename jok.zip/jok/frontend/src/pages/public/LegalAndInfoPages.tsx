import SEO from '../../components/SEO';

export function TermsPage() {
    return (
        <div className="bg-[#0A2540] min-h-screen pt-32 pb-20">
            <SEO title="Terms of Service" description="Read CODVerify's terms of service, usage policies, and conditions for our COD order verification platform." canonical="/terms" noindex={false} />
            <div className="max-w-3xl mx-auto px-6">
                <h1 className="text-4xl font-black text-white tracking-tighter mb-2">Terms of Service</h1>
                <p className="text-white/30 text-sm mb-12">Last updated: March 2026</p>
                <div className="prose prose-gray max-w-none space-y-8 text-gray-700 leading-relaxed">
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">1. Acceptance of Terms</h2>
                        <p>By accessing or using CODVerify ("Service"), you agree to be bound by these Terms of Service. If you do not agree, do not use the Service. These terms apply to all users, merchants, and administrators.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">2. Description of Service</h2>
                        <p>CODVerify is a B2B SaaS platform providing automated Cash-on-Delivery (COD) order verification services via WhatsApp and Groq AI Chatbot. The Service helps merchants reduce Return-to-Origin (RTO) rates and shipping losses.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">3. Wallet & Billing</h2>
                        <p>CODVerify operates on a prepaid wallet model. You must maintain a positive wallet balance to use verification services. Charges are deducted per verification at rates shown on the Pricing page. CODVerify reserves the right to update pricing with 30 days notice. Wallet funds are non-refundable except in cases of Service failure.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">4. Merchant Responsibilities</h2>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>You must have valid consent from customers to contact them via WhatsApp or SMS.</li>
                            <li>You must comply with WhatsApp Business Policy.</li>
                            <li>You are responsible for the accuracy of order data submitted to CODVerify.</li>
                            <li>You must not use CODVerify for spam, unsolicited messages, or illegal purposes.</li>
                        </ul>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">5. Data & Privacy</h2>
                        <p>Customer phone numbers and order data processed through CODVerify are used solely for verification purposes. We do not sell customer data. See our <a href="/privacy" className="text-[#635BFF] hover:underline">Privacy Policy</a> for full details.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">6. Service Availability</h2>
                        <p>We target 99.9% uptime but do not guarantee uninterrupted service. WhatsApp availability is subject to Meta's infrastructure. We are not liable for losses caused by third-party service outages.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">7. Limitation of Liability</h2>
                        <p>CODVerify's liability is limited to the amount you paid in the 30 days preceding the claim. We are not liable for indirect, incidental, or consequential damages including lost profits from RTO losses.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">8. Governing Law</h2>
                        <p>For India-based merchants: These terms are governed by the laws of India, with jurisdiction in Bangalore courts. For US-based merchants: These terms are governed by the laws of Delaware, USA.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">9. Contact</h2>
                        <p>For legal inquiries: <a href="mailto:legal@codverify.tech" className="text-[#635BFF]">legal@codverify.tech</a></p>
                    </section>
                </div>
            </div>
        </div>
    );
}

export function PrivacyPage() {
    return (
        <div className="bg-[#0A2540] min-h-screen pt-32 pb-20">
            <SEO title="Privacy Policy" description="CODVerify's privacy policy: how we collect, use, and protect your data. GDPR compliant. Bank-grade encryption for all merchant and customer data." canonical="/privacy" />
            <div className="max-w-3xl mx-auto px-6">
                <h1 className="text-4xl font-black text-white tracking-tighter mb-2">Privacy Policy</h1>
                <p className="text-white/30 text-sm mb-12">Last updated: March 2026 · Compliant with IT Act 2000 (India) & GDPR (EU)</p>
                <div className="prose prose-gray max-w-none space-y-8 text-gray-700 leading-relaxed">
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Information We Collect</h2>
                        <p><strong>Merchant Data:</strong> Business name, email, phone, payment information, store credentials.</p>
                        <p><strong>Customer Data (via merchants):</strong> Phone numbers, order amounts, shipping addresses, conversation history with our verification bot.</p>
                        <p><strong>Usage Data:</strong> API calls, verification counts, wallet transactions, login history.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">How We Use Data</h2>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>Send order verification messages to end customers on behalf of merchants</li>
                            <li>Process wallet payments and provide billing statements</li>
                            <li>Provide analytics and RTO reports to merchants</li>
                            <li>Improve our AI chatbot models (aggregated, anonymized)</li>
                            <li>Send service emails (verification, password reset, low balance alerts)</li>
                        </ul>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Data Sharing</h2>
                        <p>We share data with: <strong>Meta</strong> (WhatsApp message delivery), <strong>Groq</strong> (AI chatbot inference), <strong>Supabase</strong> (database hosting), <strong>Razorpay</strong> (payment processing). We do not sell data to third parties.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Data Retention</h2>
                        <p>Order and conversation data is retained for 90 days by default. Merchants can request data deletion via support ticket. Account data is deleted 30 days after account closure.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Security</h2>
                        <p>All data is encrypted at rest (AES-256) and in transit (TLS 1.3). API keys and WhatsApp tokens are stored in encrypted form. We conduct regular security audits.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Your Rights</h2>
                        <p>You have the right to access, correct, or delete your data. Contact <a href="mailto:privacy@codverify.tech" className="text-[#635BFF]">privacy@codverify.tech</a> for data requests. We respond within 30 days.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Cookies</h2>
                        <p>We use only essential cookies for authentication session management. We do not use tracking or advertising cookies.</p>
                    </section>
                    <section>
                        <h2 className="text-xl font-black text-white/80 mb-3">Contact</h2>
                        <p>Privacy inquiries: <a href="mailto:privacy@codverify.tech" className="text-[#635BFF]">privacy@codverify.tech</a></p>
                    </section>
                </div>
            </div>
        </div>
    );
}

export function AboutPage() {
    return (
        <div className="bg-[#0A2540] min-h-screen pt-32 pb-20">
            <SEO title="About CODVerify — Reducing RTO Losses" description="Learn about CODVerify's mission to reduce RTO losses for e-commerce in India & USA. Built by logistics engineers, trusted by 1,200+ brands." canonical="/about" keywords="about codverify, rto reduction platform, ecommerce verification india" />
            <div className="max-w-4xl mx-auto px-6">
                <div className="text-center mb-16">
                    <div className="stripe-badge rounded-full inline-flex items-center px-5 py-2 text-xs font-bold text-white/70 uppercase tracking-[0.2em] mb-6">Our Story</div>
                    <h1 className="text-5xl font-black tracking-tighter text-white font-['Outfit'] mb-6">We're on a mission to <span className="text-[#635BFF]">eliminate RTO losses</span></h1>
                    <p className="text-white/40 text-xl max-w-2xl mx-auto leading-relaxed">
                        CODVerify was born from a simple frustration: too many returned shipments eating into e-commerce margins. We built a smarter way to verify customer intent before shipping.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                    {[
                        { num: '1,200+', label: 'Active Merchants', sub: 'India & USA' },
                        { num: '₹42Cr+', label: 'Capital Saved', sub: 'In RTO losses averted' },
                        { num: '42.8%', label: 'Avg RTO Reduction', sub: 'Across all verticals' },
                    ].map(s => (
                        <div key={s.num} className="glass-card-ultra rounded-3xl border border-white/10 p-8 text-center">
                            <div className="text-4xl font-black text-[#635BFF] mb-2">{s.num}</div>
                            <div className="text-sm font-bold text-white/70">{s.label}</div>
                            <div className="text-xs text-white/30">{s.sub}</div>
                        </div>
                    ))}
                </div>

                <div className="max-w-none text-white/50 leading-relaxed space-y-6">
                    <p>
                        <strong>CODVerify</strong> started in 2024 when our founders — e-commerce veterans who had collectively lost crores to unconfirmed COD orders — decided to build the solution they always wished existed.
                    </p>
                    <p>
                        The insight was straightforward: <em>most RTO doesn't happen because customers don't want the product — it happens because nobody asked them to confirm before shipping.</em> A simple WhatsApp message asking "Should we ship this?" converts uncertain intent into commitments.
                    </p>
                    <p>
                        We built CODVerify on top of <strong>WhatsApp Business API</strong> for India, where 500M+ users are daily active on WhatsApp. We're expanding WhatsApp verification globally to cover more countries.
                    </p>
                    <p>
                        Our <strong>Groq AI chatbot</strong> layer handles complex customer interactions — address changes, quantity updates, partial confirmations — things that binary YES/NO buttons can't handle.
                    </p>
                    <p>
                        Today, CODVerify processes millions of order verifications monthly. Our merchants report an average <strong>42.8% reduction in RTO</strong>, translating to crores saved every month across our customer base.
                    </p>
                </div>

                <div className="mt-16 glass-card-ultra p-8 rounded-3xl border border-white/10 text-center">
                    <h2 className="text-2xl font-black text-white font-['Outfit'] mb-4">Join 1,200+ merchants protecting their margins</h2>
                    <p className="text-white/40 mb-8">Start your free trial — no credit card required.</p>
                    <a href="/signup" className="stripe-button inline-flex items-center gap-2 text-white px-8 py-4 rounded-full font-bold">
                        Start Free Trial
                    </a>
                </div>
            </div>
        </div>
    );
}

export function StatusPage() {
    const services = [
        { name: 'WhatsApp Verification (India)', status: 'operational', uptime: '99.98%' },
        { name: 'Groq AI Chatbot', status: 'operational', uptime: '99.99%' },
        { name: 'API Gateway', status: 'operational', uptime: '99.97%' },
        { name: 'Merchant Dashboard', status: 'operational', uptime: '99.99%' },
        { name: 'Webhook Processing', status: 'operational', uptime: '99.94%' },
        { name: 'Email Notifications', status: 'operational', uptime: '99.88%' },
    ];
    return (
        <div className="bg-[#0A2540] min-h-screen pt-32 pb-20">
            <SEO title="System Status" description="Real-time system status and uptime monitoring for CODVerify's verification infrastructure. 99.9% uptime guaranteed." canonical="/status" noindex={true} />
            <div className="max-w-3xl mx-auto px-6">
                <div className="text-center mb-12">
                    <div className="w-16 h-16 bg-[#00D4AA]/15 border border-[#00D4AA]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div className="w-5 h-5 bg-emerald-500 rounded-full animate-pulse" />
                    </div>
                    <h1 className="text-4xl font-black text-white tracking-tighter">All Systems Operational</h1>
                    <p className="text-white/30 mt-2">Updated as of {new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST</p>
                </div>
                <div className="space-y-3">
                    {services.map(s => (
                        <div key={s.name} className="flex items-center justify-between p-5 bg-white/5 rounded-2xl border border-white/10">
                            <div className="flex items-center gap-3">
                                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                                <span className="font-bold text-sm text-white/70">{s.name}</span>
                            </div>
                            <div className="text-right">
                                <div className="text-xs font-bold text-[#00D4AA] capitalize">{s.status}</div>
                                <div className="text-xs text-white/30">{s.uptime} uptime (30d)</div>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="mt-12">
                    <h2 className="text-lg font-black text-gray-900 mb-4">Incident History</h2>
                    <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 text-center">
                        <p className="text-emerald-700 font-bold text-sm">No incidents in the last 30 days 🎉</p>
                    </div>
                </div>
            </div>
        </div>
    );
}

export function ChangelogPage() {
    const entries = [
        {
            version: 'v2.0.0', date: 'March 2026', badge: 'Major Release',
            changes: [
                '🌍 International expansion: WhatsApp verification coming soon for USA, PH, MX, UK',
                '🤖 Groq AI Chatbot for interactive order verification',
                '🔧 SMTP email config — bring your own business email',
                '🌐 Country auto-detection with INR/USD pricing switch',
                '📱 Mobile-first dashboard redesign',
                '🏪 New public pages: Features, Countries, Docs, FAQ, About',
            ]
        },
        {
            version: 'v1.5.0', date: 'January 2026', badge: 'Feature Release',
            changes: [
                '💰 Wallet billing system — pay per use (replaces subscriptions)',
                '🎛️ Message toggles — control which messages are sent',
                '📊 Admin dashboard overhaul with revenue analytics',
                '🛡️ Blacklist management for high-risk phone numbers',
                '⚡ Performance: <240ms average verification latency',
            ]
        },
        {
            version: 'v1.2.0', date: 'November 2025', badge: 'Update',
            changes: [
                '🎨 Premium UI overhaul with glassmorphism design',
                '📦 39 RTO crash fixes across backend (.single() patches)',
                '🔔 Real-time notifications in merchant dashboard',
                '📋 Template management system',
                '🔗 WooCommerce webhook integration',
            ]
        },
        {
            version: 'v1.0.0', date: 'September 2025', badge: 'Initial Launch',
            changes: [
                '🚀 CODVerify launched for India',
                '📱 WhatsApp order verification via Meta Business API',
                '🛒 Shopify store integration',
                '📊 Basic analytics dashboard',
                '🔑 API key management',
            ]
        },
    ];

    const badgeColors: Record<string, string> = {
        'Major Release': 'bg-indigo-100 text-indigo-700',
        'Feature Release': 'bg-emerald-100 text-emerald-700',
        'Update': 'bg-amber-100 text-amber-700',
        'Initial Launch': 'bg-gray-100 text-gray-600',
    };

    return (
        <div className="bg-[#0A2540] min-h-screen pt-32 pb-20">
            <SEO title="Changelog" description="CODVerify product changelog: latest updates, new features, bug fixes, and improvements to our COD verification platform." canonical="/changelog" />
            <div className="max-w-3xl mx-auto px-6">
                <div className="mb-12">
                    <h1 className="text-4xl font-black text-white tracking-tighter mb-2">Changelog</h1>
                    <p className="text-gray-400">What's new in CODVerify</p>
                </div>
                <div className="space-y-8">
                    {entries.map((entry, i) => (
                        <div key={i} className="border border-gray-100 rounded-3xl p-8">
                            <div className="flex items-center gap-3 mb-6">
                                <h2 className="text-2xl font-black text-gray-900">{entry.version}</h2>
                                <span className={`text-xs font-bold px-3 py-1 rounded-full ${badgeColors[entry.badge]}`}>{entry.badge}</span>
                                <span className="text-sm text-gray-400 ml-auto">{entry.date}</span>
                            </div>
                            <ul className="space-y-3">
                                {entry.changes.map((c, j) => (
                                    <li key={j} className="text-sm text-gray-700 leading-relaxed">{c}</li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

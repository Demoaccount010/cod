import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, useMotionValue, useSpring, useInView } from 'framer-motion';
import SEO from '../../components/SEO';
import { MessageSquare, Zap, ArrowRight, Sparkles, Globe, Play, Check, ChevronRight, Shield, Bot, Mail, Brain, Cpu, Layers, Award, Code, Activity, Lock, Webhook, Database, Cloud, Terminal, Star, Users, Rocket, CheckCircle2, Package } from 'lucide-react';
import { useRef, useState, useEffect, type ReactNode } from 'react';
import TestimonialsSection from '../../components/reviews/TestimonialsSection';

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimatedCounter({ end, suffix = '', prefix = '' }: { end: string; suffix?: string; prefix?: string }) {
    const [display, setDisplay] = useState('0');
    const ref = useRef<HTMLSpanElement>(null);
    const [started, setStarted] = useState(false);

    useEffect(() => {
        if (!started) return;
        const numStr = end.replace(/[^0-9.]/g, '');
        const target = parseFloat(numStr) || 0;
        const duration = 2000;
        const steps = 60;
        const increment = target / steps;
        let current = 0;
        let step = 0;
        const timer = setInterval(() => {
            step++;
            current = Math.min(current + increment + (Math.random() * increment * 0.3), target);
            if (step >= steps) {
                current = target;
                clearInterval(timer);
            }
            if (target >= 100) setDisplay(Math.floor(current).toLocaleString('en-IN'));
            else setDisplay(current.toFixed(1));
        }, duration / steps);
        return () => clearInterval(timer);
    }, [started, end]);

    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) setStarted(true);
        }, { threshold: 0.5 });
        if (ref.current) observer.observe(ref.current);
        return () => observer.disconnect();
    }, []);

    return <span ref={ref}>{prefix}{display}{suffix}</span>;
}

// ─── Static Gradient Orbs (CSS-animated for GPU performance, no JS perf cost) ──
function GradientOrbs() {
    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="orb-1" />
            <div className="orb-2" />
            <div className="orb-3" />
            <div className="orb-4" />
        </div>
    );
}

// ─── Section Wrapper with Scroll Reveal ───────────────────────────────────────
function RevealSection({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-80px' });
    return (
        <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
            className={className}
        >
            {children}
        </motion.div>
    );
}

// ─── 3D Dashboard Preview ─────────────────────────────────────────────────────
function DashboardPreview3D() {
    const ref = useRef<HTMLDivElement>(null);
    const x = useMotionValue(0);
    const y = useMotionValue(0);
    const rotateX = useSpring(useTransform(y, [-300, 300], [8, -8]), { stiffness: 100, damping: 30 });
    const rotateY = useSpring(useTransform(x, [-300, 300], [-8, 8]), { stiffness: 100, damping: 30 });

    const handleMouse = (e: React.MouseEvent) => {
        if (!ref.current) return;
        const rect = ref.current.getBoundingClientRect();
        x.set(e.clientX - rect.left - rect.width / 2);
        y.set(e.clientY - rect.top - rect.height / 2);
    };

    const handleMouseLeave = () => {
        x.set(0);
        y.set(0);
    };

    return (
        <div className="perspective-display" onMouseMove={handleMouse} onMouseLeave={handleMouseLeave} ref={ref}>
            <motion.div
                style={{ rotateX, rotateY }}
                className="dashboard-preview p-1 relative"
            >
                {/* Browser Chrome */}
                <div className="dashboard-toolbar flex items-center gap-2 px-5 py-3.5">
                    <div className="dashboard-dot bg-[#FF5F57]" />
                    <div className="dashboard-dot bg-[#FEBC2E]" />
                    <div className="dashboard-dot bg-[#28C840]" />
                    <div className="flex-1 mx-4">
                        <div className="bg-[#0A2540] rounded-lg px-4 py-1.5 flex items-center gap-2 max-w-xs mx-auto">
                            <Lock className="w-3 h-3 text-[#00D4AA]" />
                            <span className="text-[10px] text-gray-400 font-mono">codverify.tech/dashboard</span>
                        </div>
                    </div>
                </div>

                {/* Dashboard Content */}
                <div className="p-5 space-y-4">
                    {/* Stats Row */}
                    <div className="grid grid-cols-4 gap-3">
                        {[
                            { label: 'Total Orders', value: '12,847', change: '+12.5%', color: 'text-[#00D4AA]' },
                            { label: 'Verified', value: '11,982', change: '93.2%', color: 'text-[#635BFF]' },
                            { label: 'RTO Saved', value: '₹4.2L', change: '-42%', color: 'text-[#80E9FF]' },
                            { label: 'Response', value: '240ms', change: '99.9%', color: 'text-[#FF80B5]' },
                        ].map((stat, i) => (
                            <motion.div
                                key={i}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 1.2 + i * 0.1 }}
                                className="bg-[#0A2540]/80 rounded-xl p-3 border border-white/5"
                            >
                                <p className="text-[9px] text-gray-500 uppercase tracking-wider font-medium">{stat.label}</p>
                                <p className="text-lg font-bold text-white font-['Outfit'] mt-1">{stat.value}</p>
                                <p className={`text-[10px] font-bold ${stat.color} mt-0.5`}>{stat.change}</p>
                            </motion.div>
                        ))}
                    </div>

                    {/* Chart Area */}
                    <div className="bg-[#0A2540]/80 rounded-xl p-4 border border-white/5">
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-xs text-white font-semibold">Order Verification Rate</span>
                            <span className="text-[10px] text-[#00D4AA] font-bold">Live</span>
                        </div>
                        <div className="flex items-end gap-1 h-16">
                            {[40, 55, 45, 60, 75, 65, 80, 70, 85, 78, 90, 88, 95, 92, 88, 93, 97, 94, 96, 98].map((h, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ height: 0 }}
                                    animate={{ height: `${h}%` }}
                                    transition={{ delay: 1.5 + i * 0.05, duration: 0.5 }}
                                    className="flex-1 rounded-t-sm"
                                    style={{
                                        background: `linear-gradient(to top, rgba(99, 91, 255, 0.6), rgba(0, 212, 170, ${h / 100}))`,
                                    }}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Recent Activity */}
                    <div className="grid grid-cols-2 gap-3">
                        <div className="bg-[#0A2540]/80 rounded-xl p-3 border border-white/5">
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Recent Verifications</p>
                            {[
                                { id: '#28,471', status: 'Verified', time: '2s ago' },
                                { id: '#28,470', status: 'Verified', time: '15s ago' },
                                { id: '#28,469', status: 'Pending', time: '32s ago' },
                            ].map((item, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 2 + i * 0.15 }}
                                    className="flex items-center justify-between py-1.5"
                                >
                                    <span className="text-[10px] text-white font-medium">{item.id}</span>
                                    <span className={`text-[9px] font-bold ${item.status === 'Verified' ? 'text-[#00D4AA]' : 'text-[#FFB224]'}`}>{item.status}</span>
                                </motion.div>
                            ))}
                        </div>
                        <div className="bg-[#0A2540]/80 rounded-xl p-3 border border-white/5">
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">AI Risk Analysis</p>
                            <div className="space-y-2">
                                {[
                                    { label: 'Safe Orders', pct: 93, color: '#00D4AA' },
                                    { label: 'Medium Risk', pct: 5, color: '#FFB224' },
                                    { label: 'High Risk', pct: 2, color: '#FF6B6B' },
                                ].map((item, i) => (
                                    <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.2 + i * 0.1 }}>
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-[9px] text-gray-400">{item.label}</span>
                                            <span className="text-[9px] font-bold" style={{ color: item.color }}>{item.pct}%</span>
                                        </div>
                                        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                            <motion.div
                                                initial={{ width: 0 }}
                                                animate={{ width: `${item.pct}%` }}
                                                transition={{ delay: 2.4 + i * 0.1, duration: 0.8 }}
                                                className="h-full rounded-full"
                                                style={{ background: item.color }}
                                            />
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Floating notification */}
                <motion.div
                    initial={{ opacity: 0, x: 30, y: -20 }}
                    animate={{ opacity: 1, x: 0, y: 0 }}
                    transition={{ delay: 2.5, duration: 0.6 }}
                    className="absolute -top-6 -right-6 glass-card-ultra rounded-2xl p-3.5 shadow-2xl animate-float z-20"
                >
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-[#00D4AA] rounded-xl flex items-center justify-center shadow-lg shadow-[#00D4AA]/30">
                            <Check className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <p className="text-[9px] font-bold text-[#00D4AA] uppercase tracking-wider">Verified</p>
                            <p className="text-xs font-bold text-white">Order #28,471</p>
                        </div>
                    </div>
                </motion.div>

                {/* Floating risk card */}
                <motion.div
                    initial={{ opacity: 0, x: -30, y: 20 }}
                    animate={{ opacity: 1, x: 0, y: 0 }}
                    transition={{ delay: 2.8, duration: 0.6 }}
                    className="absolute -bottom-4 -left-6 glass-card-ultra rounded-2xl p-3.5 shadow-2xl animate-float-delay z-20"
                >
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-[#635BFF] rounded-xl flex items-center justify-center shadow-lg shadow-[#635BFF]/30">
                            <Shield className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <p className="text-[9px] font-bold text-[#635BFF] uppercase tracking-wider">AI Score</p>
                            <p className="text-xs font-bold text-white">0.08 — Safe</p>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        </div>
    );
}

// ─── Marquee (Logo Carousel) ──────────────────────────────────────────────────
function BrandMarquee() {
    const brands = [
        { name: 'Shopify', icon: '🛍️' }, { name: 'WooCommerce', icon: '🛒' },
        { name: 'Meesho', icon: '📦' }, { name: 'Flipkart Seller', icon: '🏪' },
        { name: 'Amazon Seller', icon: '📊' }, { name: 'Myntra', icon: '👗' },
        { name: 'Nykaa', icon: '💄' }, { name: 'BigCommerce', icon: '🏢' },
        { name: 'Dukaan', icon: '🏬' }, { name: 'Magento', icon: '⚡' },
    ];

    return (
        <div className="marquee-container py-8">
            <div className="flex animate-marquee">
                {[...brands, ...brands].map((brand, i) => (
                    <div key={i} className="flex items-center gap-3 mx-8 whitespace-nowrap">
                        <span className="text-2xl">{brand.icon}</span>
                        <span className="text-sm font-semibold text-gray-400/60 tracking-wide">{brand.name}</span>
                    </div>
                ))}
            </div>
        </div>
    );
}

// ─── Code Block Component ─────────────────────────────────────────────────────
function CodeBlockPreview() {
    return (
        <div className="code-block overflow-hidden">
            <div className="flex items-center gap-2 px-5 py-3 border-b border-white/5">
                <div className="w-3 h-3 rounded-full bg-[#FF5F57]" />
                <div className="w-3 h-3 rounded-full bg-[#FEBC2E]" />
                <div className="w-3 h-3 rounded-full bg-[#28C840]" />
                <span className="ml-3 text-[10px] text-gray-500 font-mono">verify-order.js</span>
            </div>
            <div className="p-5 text-[13px] leading-relaxed font-mono">
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                    <span className="text-[#FF80B5]">const</span> <span className="text-[#80E9FF]">result</span> <span className="text-white">=</span> <span className="text-[#FF80B5]">await</span> <span className="text-[#00D4AA]">codverify</span><span className="text-white">.</span><span className="text-[#80E9FF]">verify</span><span className="text-gray-400">{'({'}</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.5 }} className="pl-4">
                    <span className="text-[#80E9FF]">orderId</span><span className="text-gray-400">:</span> <span className="text-[#FFB224]">"#28471"</span><span className="text-gray-400">,</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.6 }} className="pl-4">
                    <span className="text-[#80E9FF]">phone</span><span className="text-gray-400">:</span> <span className="text-[#FFB224]">"+91..."</span><span className="text-gray-400">,</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.7 }} className="pl-4">
                    <span className="text-[#80E9FF]">channel</span><span className="text-gray-400">:</span> <span className="text-[#FFB224]">"whatsapp"</span><span className="text-gray-400">,</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.8 }} className="pl-4">
                    <span className="text-[#80E9FF]">riskCheck</span><span className="text-gray-400">:</span> <span className="text-[#FF80B5]">true</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.9 }}>
                    <span className="text-gray-400">{'});'}</span>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 1.1 }} className="mt-3">
                    <span className="text-gray-600">{'// → { verified: true, risk: 0.08, latency: "240ms" }'}</span>
                </motion.div>
            </div>
        </div>
    );
}

const features = [
    {
        icon: MessageSquare,
        title: 'WhatsApp Verification',
        desc: 'Customer gets an interactive WhatsApp message the moment a COD order is placed. One tap to confirm or cancel — no phone call, no confusion. Retry logic built in.',
        color: 'from-[#25D366] to-[#128C7E]',
        glowColor: '#25D366',
        link: '/features#whatsapp',
    },
    {
        icon: Brain,
        title: 'AI Risk Scoring',
        desc: 'Every order is scored in real-time before a message is sent. Factors: customer RTO history, cancellation rate, high-value flag, address completeness, and blacklist status.',
        color: 'from-[#635BFF] to-[#7A73FF]',
        glowColor: '#635BFF',
        link: '/features',
    },
    {
        icon: Bot,
        title: 'AI Personal Chatbot',
        desc: 'A fully trained AI chatbot embedded on your store — powered by advanced language models. Handles order tracking, address changes, FAQs, and hands off to a live agent seamlessly.',
        color: 'from-[#FF80B5] to-[#FF9E2C]',
        glowColor: '#FF80B5',
        link: '/features#chatbot',
    },
    {
        icon: Users,
        title: 'Live Support Workers',
        desc: 'Real human agents manage chat sessions from your customers. When the AI can\'t answer, it escalates instantly to a dedicated worker who knows your brand.',
        color: 'from-[#FF9E2C] to-[#FF6B6B]',
        glowColor: '#FF9E2C',
        link: '/services',
    },
    {
        icon: Mail,
        title: 'Daily Summary on Email',
        desc: 'Every morning, receive a crisp performance summary — verifications sent, confirmations received, orders shipped, and revenue protected. Stay informed without logging in.',
        color: 'from-[#00D4AA] to-[#80E9FF]',
        glowColor: '#00D4AA',
        link: '/services',
    },
    {
        icon: Layers,
        title: 'Shopify & WooCommerce',
        desc: 'Native webhook integrations with Shopify and WooCommerce. Orders flow in automatically, confirmations update your store in real time — zero manual work required.',
        color: 'from-[#80E9FF] to-[#635BFF]',
        glowColor: '#80E9FF',
        link: '/integrations',
    },
];

const stats = [
    { label: 'Active Brands', value: '1,200', suffix: '+', prefix: '' },
    { label: 'Orders Verified', value: '8400000', suffix: '+', prefix: '', display: '8.4M' },
    { label: 'Fake Orders Blocked', value: '42', suffix: 'L+', prefix: '' },
    { label: 'Avg Response Time', value: '240', suffix: 'ms', prefix: '<' },
];

const HomePage = () => {
    const scrollRef = useRef(null);
    const { scrollYProgress } = useScroll({ target: scrollRef, offset: ['start start', 'end start'] });
    const y1 = useTransform(scrollYProgress, [0, 1], [0, -80]);
    const heroRef = useRef(null);
    const { scrollYProgress: heroProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
    const heroY = useTransform(heroProgress, [0, 1], [0, 150]);
    const heroOpacity = useTransform(heroProgress, [0, 0.8], [1, 0]);

    return (
        <>
            <SEO
                title="CODVerify — AI-Powered COD Order Verification & RTO Reduction"
                description="Reduce RTO losses by 45% with intelligent COD order verification via WhatsApp, SMS & Voice Call. Trusted by 1,200+ brands across India & USA. Shopify & WooCommerce plugins available."
                canonical="/"
                keywords="cod verification, order verification, rto reduction, cash on delivery verification, whatsapp order confirmation, shopify cod plugin, woocommerce cod"
                structuredData={{
                    "@context": "https://schema.org",
                    "@graph": [
                        {
                            "@type": "Organization",
                            "@id": "https://codverify.tech/#organization",
                            "name": "CODVerify",
                            "url": "https://codverify.tech",
                            "logo": { "@type": "ImageObject", "url": "https://codverify.tech/logo.png", "width": 512, "height": 512 },
                            "description": "AI-powered COD order verification platform that reduces RTO losses by 45%.",
                            "foundingDate": "2024",
                            "sameAs": ["https://twitter.com/codverify", "https://linkedin.com/company/codverify"],
                            "contactPoint": { "@type": "ContactPoint", "contactType": "customer support", "email": "support@codverify.tech", "availableLanguage": ["English", "Hindi"] },
                            "areaServed": ["IN", "US", "AE", "GB", "SG"],
                        },
                        {
                            "@type": "SoftwareApplication",
                            "@id": "https://codverify.tech/#software",
                            "name": "CODVerify",
                            "applicationCategory": "BusinessApplication",
                            "applicationSubCategory": "E-Commerce Fraud Prevention",
                            "operatingSystem": "Web, Shopify, WooCommerce",
                            "description": "AI-powered COD order verification SaaS platform.",
                            "url": "https://codverify.tech",
                            "offers": { "@type": "Offer", "price": "0", "priceCurrency": "INR", "description": "Contact for custom pricing" },
                            "aggregateRating": { "@type": "AggregateRating", "ratingValue": "4.8", "ratingCount": "156", "bestRating": "5", "worstRating": "1" },
                            "featureList": "WhatsApp Verification, SMS Verification, Voice Call Verification, AI Risk Scoring, Fraud Detection, Shopify Plugin, WooCommerce Plugin, AI Chatbot, RTO Analytics, Multi-Country Support",
                        },
                        {
                            "@type": "WebSite",
                            "@id": "https://codverify.tech/#website",
                            "name": "CODVerify",
                            "url": "https://codverify.tech",
                            "publisher": { "@id": "https://codverify.tech/#organization" },
                            "potentialAction": { "@type": "SearchAction", "target": "https://codverify.tech/blog?q={search_term_string}", "query-input": "required name=search_term_string" },
                        },
                    ],
                }}
            />

            {/* ═══ HERO SECTION — DARK STRIPE-STYLE ═══════════════════════════ */}
            <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden bg-[#0A2540]">
                <GradientOrbs />
                <div className="absolute inset-0 grid-pattern-dark opacity-30" />
                <div className="absolute inset-0 noise-overlay" />

                {/* Animated lines */}
                <div className="absolute top-0 left-0 w-full h-px glow-line opacity-50" />
                <div className="absolute bottom-0 left-0 w-full h-px glow-line opacity-30" />

                <motion.div style={{ y: heroY, opacity: heroOpacity }} className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 w-full pt-32 pb-20 lg:pt-40 lg:pb-28">
                    <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                        {/* Left — Text Content */}
                        <div>
                            {/* Badge */}
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }}
                                className="inline-flex items-center gap-2.5 px-5 py-2.5 stripe-badge rounded-full mb-8">
                                <span className="relative flex h-2 w-2">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00D4AA] opacity-75" />
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00D4AA]" />
                                </span>
                                <span className="text-[11px] font-semibold text-[#80E9FF] tracking-wide">AI-Powered COD Protection Platform</span>
                            </motion.div>

                            {/* Headline */}
                            <motion.h1
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.4, duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
                                className="text-4xl sm:text-5xl lg:text-6xl xl:text-[72px] font-extrabold text-white font-['Outfit'] leading-[1.05] tracking-tight mb-7"
                            >
                                Stop losing money
                                <br />on{' '}
                                <span className="text-gradient-stripe">fake COD orders</span>
                            </motion.h1>

                            {/* Subhead */}
                            <motion.p
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.6, duration: 0.6 }}
                                className="text-lg sm:text-xl text-gray-400 font-normal leading-relaxed max-w-xl mb-10"
                            >
                                COD order verification via WhatsApp — with AI risk scoring, a personal chatbot for your store, live support workers, and daily performance summaries on email. Trusted by{' '}
                                <span className="text-white font-semibold">1,200+ e-commerce brands</span> across India & worldwide.
                            </motion.p>

                            {/* CTA Buttons */}
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.8, duration: 0.6 }}
                                className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-12"
                            >
                                <Link to="/signup" className="group stripe-button text-white rounded-xl px-8 py-4 font-semibold text-base flex items-center justify-center gap-2.5">
                                    Start Free <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                </Link>
                                <Link to="/contact"
                                    className="px-8 py-4 bg-white/5 backdrop-blur-sm text-white rounded-xl font-semibold text-base border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all flex items-center justify-center gap-2.5">
                                    <Play className="w-4 h-4" /> Contact Sales
                                </Link>
                            </motion.div>

                            {/* Trust Row */}
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: 1, duration: 0.6 }}
                                className="flex flex-wrap items-center gap-6"
                            >
                                {[
                                    { icon: Shield, label: 'SOC 2 Compliant', color: '#00D4AA' },
                                    { icon: Globe, label: '5 Countries', color: '#80E9FF' },
                                    { icon: Activity, label: '99.9% Uptime', color: '#635BFF' },
                                ].map((badge, i) => (
                                    <div key={i} className="flex items-center gap-2">
                                        <badge.icon className="w-4 h-4" style={{ color: badge.color }} />
                                        <span className="text-xs font-medium text-gray-500">{badge.label}</span>
                                    </div>
                                ))}
                            </motion.div>
                        </div>

                        {/* Right — 3D Dashboard */}
                        <motion.div
                            initial={{ opacity: 0, y: 40, rotateX: 10 }}
                            animate={{ opacity: 1, y: 0, rotateX: 0 }}
                            transition={{ delay: 0.6, duration: 1.2, ease: [0.25, 0.46, 0.45, 0.94] }}
                            className="hidden lg:block"
                        >
                            <DashboardPreview3D />
                        </motion.div>
                    </div>
                </motion.div>

                {/* Bottom gradient fade */}
                <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-[#0A2540] to-transparent" />
            </section>

            {/* ═══ BRAND MARQUEE ═══════════════════════════════════════════════ */}
            <section className="bg-[#0A2540] border-t border-white/5 relative">
                <div className="max-w-7xl mx-auto px-4 sm:px-6">
                    <p className="text-center text-[10px] font-semibold text-gray-600 uppercase tracking-[0.4em] pt-8 mb-2">Trusted by leading e-commerce brands</p>
                    <BrandMarquee />
                </div>
            </section>

            {/* ═══ GLOBAL STATS BAR ═══════════════════════════════════════════ */}
            <section className="relative py-20 sm:py-28 overflow-hidden bg-gradient-to-b from-[#0A2540] to-[#F6F9FC]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
                        {stats.map((s, i) => (
                            <RevealSection key={i} delay={i * 0.1}>
                                <div className="glass-card-ultra rounded-2xl p-6 sm:p-8 text-center hover:scale-105 transition-transform duration-500">
                                    <p className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white font-['Outfit'] tracking-tight mb-3">
                                        {s.display ? s.display : <AnimatedCounter end={s.value} prefix={s.prefix} suffix={s.suffix} />}
                                    </p>
                                    <p className="text-[10px] sm:text-xs font-semibold text-gray-400 uppercase tracking-[0.25em]">{s.label}</p>
                                </div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ FEATURES SECTION — 3D CARDS ═════════════════════════════════ */}
            <section id="technology" className="py-24 sm:py-32 bg-[#F6F9FC] relative overflow-hidden">
                <div className="absolute inset-0 gradient-mesh opacity-40" />
                <div className="absolute inset-0 dot-pattern opacity-30" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection className="text-center mb-16 lg:mb-20">
                        <div className="inline-flex items-center gap-2.5 px-5 py-2.5 bg-[#635BFF]/5 border border-[#635BFF]/10 rounded-full mb-6">
                            <Cpu className="w-4 h-4 text-[#635BFF]" />
                            <span className="text-xs font-semibold text-[#635BFF] tracking-wide">Technology Stack</span>
                        </div>
                        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-[#0A2540] font-['Outfit'] tracking-tight mb-5">
                            Every Tool Your
                            <span className="text-gradient-hero"> COD Business Needs</span>
                        </h2>
                        <p className="text-gray-500 text-lg font-normal max-w-2xl mx-auto leading-relaxed">
                            WhatsApp verification, AI risk scoring, personal chatbot, live support workers, daily email reports — one platform, zero manual work.
                        </p>
                    </RevealSection>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                        {features.map((f, i) => (
                            <RevealSection key={i} delay={i * 0.08}>
                                <div className="group h-full">
                                    <div
                                        className="relative bg-white rounded-2xl p-8 border border-gray-100 h-full overflow-hidden transition-all duration-500 hover:border-transparent hover:shadow-2xl"
                                        style={{
                                            ['--glow' as string]: f.glowColor,
                                        }}
                                    >
                                        {/* Animated glow border on hover */}
                                        <div
                                            className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                                            style={{
                                                background: `radial-gradient(400px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), ${f.glowColor}12, transparent 60%)`,
                                                boxShadow: `0 0 0 1px ${f.glowColor}30, 0 20px 60px ${f.glowColor}15`,
                                            }}
                                        />
                                        {/* Top glow strip */}
                                        <div
                                            className="absolute top-0 left-0 right-0 h-[2px] rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                                            style={{ background: `linear-gradient(90deg, transparent, ${f.glowColor}, transparent)` }}
                                        />

                                        <div
                                            className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 group-hover:shadow-2xl transition-all duration-500 relative z-10`}
                                            style={{ boxShadow: `0 8px 24px ${f.glowColor}35` }}
                                        >
                                            <f.icon className="w-7 h-7 text-white" />
                                        </div>
                                        <h3 className="text-xl font-bold text-[#0A2540] font-['Outfit'] mb-3 tracking-tight relative z-10">{f.title}</h3>
                                        <p className="text-sm text-gray-500 font-normal leading-relaxed mb-6 relative z-10">{f.desc}</p>
                                        <Link to={f.link} className="flex items-center gap-2 text-xs font-semibold transition-colors relative z-10" style={{ color: f.glowColor }}>
                                            Learn More <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                                        </Link>
                                    </div>
                                </div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ CODE + INTEGRATION SECTION ══════════════════════════════════ */}
            <section className="py-24 sm:py-32 bg-white relative overflow-hidden">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <div className="grid lg:grid-cols-2 gap-16 items-center">
                        {/* Left — Text */}
                        <RevealSection>
                            <div className="inline-flex items-center gap-2.5 px-5 py-2.5 bg-[#00D4AA]/5 border border-[#00D4AA]/10 rounded-full mb-6">
                                <Terminal className="w-4 h-4 text-[#00D4AA]" />
                                <span className="text-xs font-semibold text-[#00D4AA] tracking-wide">Developer Friendly</span>
                            </div>
                            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0A2540] font-['Outfit'] tracking-tight mb-6">
                                <span className="text-gradient-hero">One API call</span>
                                <br />to verify any order
                            </h2>
                            <p className="text-lg text-gray-500 leading-relaxed mb-8">
                                Integrate CODVerify into your stack in minutes. RESTful API, webhooks, and native plugins for Shopify & WooCommerce.
                            </p>

                            <div className="space-y-4 mb-10">
                                {[
                                    { icon: Code, text: 'Simple REST API with comprehensive docs' },
                                    { icon: Webhook, text: 'Real-time webhooks for order status updates' },
                                    { icon: Database, text: 'SDKs for Node.js, Python, PHP & more' },
                                    { icon: Cloud, text: '99.99% uptime SLA with global edge network' },
                                ].map((item, i) => (
                                    <motion.div key={i}
                                        initial={{ opacity: 0, x: -20 }}
                                        whileInView={{ opacity: 1, x: 0 }}
                                        viewport={{ once: true }}
                                        transition={{ delay: 0.3 + i * 0.1 }}
                                        className="flex items-center gap-4"
                                    >
                                        <div className="w-10 h-10 rounded-xl bg-[#0A2540]/5 flex items-center justify-center flex-shrink-0">
                                            <item.icon className="w-5 h-5 text-[#635BFF]" />
                                        </div>
                                        <span className="text-sm font-medium text-[#425466]">{item.text}</span>
                                    </motion.div>
                                ))}
                            </div>

                            <Link to="/docs" className="inline-flex items-center gap-2 text-[#635BFF] font-semibold hover:text-[#5046E5] transition-colors">
                                Read the docs <ArrowRight className="w-4 h-4" />
                            </Link>
                        </RevealSection>

                        {/* Right — Code Block */}
                        <RevealSection delay={0.2}>
                            <div className="tilt-3d">
                                <CodeBlockPreview />
                            </div>
                        </RevealSection>
                    </div>
                </div>
            </section>

            {/* ═══ HOW IT WORKS — TIMELINE ═════════════════════════════════════ */}
            <section className="py-24 sm:py-32 bg-[#0A2540] relative overflow-hidden">
                <GradientOrbs />
                <div className="absolute inset-0 grid-pattern-dark opacity-20" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection className="text-center mb-16">
                        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-white font-['Outfit'] tracking-tight mb-5">
                            How <span className="text-gradient-stripe">CODVerify</span> Works
                        </h2>
                        <p className="text-gray-400 text-lg font-normal max-w-xl mx-auto">
                            From order placement to verified delivery — in under 60 seconds.
                        </p>
                    </RevealSection>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 lg:gap-8">
                        {[
                            { step: '01', title: 'Order Placed', desc: 'COD order webhook received from Shopify, WooCommerce, or your custom store', icon: Package, color: '#635BFF' },
                            { step: '02', title: 'AI Risk Scored', desc: 'RTO history, cancellation rate, order value & address completeness — scored in milliseconds', icon: Brain, color: '#80E9FF' },
                            { step: '03', title: 'WhatsApp Sent', desc: 'Customer gets an interactive message — one tap to confirm or cancel. Automatic retry if unanswered.', icon: MessageSquare, color: '#00D4AA' },
                            { step: '04', title: 'Ship Confidently', desc: 'Only confirmed orders ship. Your store is updated automatically. You get a daily summary on email.', icon: Rocket, color: '#FF80B5' },
                        ].map((s, i) => (
                            <RevealSection key={i} delay={i * 0.15}>
                                <div className="relative h-full">
                                    <div className="glass-card-ultra rounded-2xl p-7 h-full group hover:scale-[1.03] transition-all duration-500">
                                        <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5" style={{ background: `${s.color}15`, border: `1px solid ${s.color}30` }}>
                                            <s.icon className="w-6 h-6" style={{ color: s.color }} />
                                        </div>
                                        <div className="text-[10px] font-bold uppercase tracking-[0.3em] mb-3" style={{ color: s.color }}>
                                            Step {s.step}
                                        </div>
                                        <h3 className="text-lg font-bold text-white font-['Outfit'] mb-2">{s.title}</h3>
                                        <p className="text-sm text-gray-400 font-normal">{s.desc}</p>
                                    </div>
                                    {i < 3 && (
                                        <div className="hidden md:block absolute top-1/2 -right-4 lg:-right-5 z-10">
                                            <ChevronRight className="w-5 h-5 text-[#635BFF]/40" />
                                        </div>
                                    )}
                                </div>
                            </RevealSection>
                        ))}
                    </div>
                </div>
            </section>

            {/* ═══ ROI SECTION ═════════════════════════════════════════════════ */}
            <section className="py-24 sm:py-32 bg-[#F6F9FC] relative overflow-hidden" ref={scrollRef}>
                <div className="absolute inset-0 gradient-mesh opacity-30" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6">
                    <div className="bg-white rounded-[32px] border border-gray-100 p-8 sm:p-12 lg:p-16 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.08)] relative overflow-hidden">
                        <div className="absolute inset-0 gradient-mesh opacity-30" />

                        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center relative z-10">
                            <RevealSection>
                                <div className="inline-flex items-center gap-2.5 px-5 py-2.5 bg-[#00D4AA]/5 border border-[#00D4AA]/10 rounded-full mb-6">
                                    <Award className="w-4 h-4 text-[#00D4AA]" />
                                    <span className="text-xs font-semibold text-[#00D4AA] tracking-wide">Proven Results</span>
                                </div>
                                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0A2540] font-['Outfit'] tracking-tight mb-6">
                                    ROI that speaks
                                    <br /><span className="text-gradient-hero">for itself.</span>
                                </h2>
                                <p className="text-lg text-gray-500 leading-relaxed mb-8">
                                    CODVerify intercepts every unconfirmed order{' '}
                                    <span className="text-[#635BFF] font-semibold">before you ship</span>, protecting both your revenue and your inventory — automatically, every single day.
                                </p>
                                <div className="space-y-4">
                                    {[
                                        { text: 'AI risk scoring on every order before messaging', icon: Brain },
                                        { text: 'WhatsApp verification with auto-retry logic', icon: Zap },
                                        { text: 'Live support workers for complex customer queries', icon: Users },
                                        { text: 'Daily summary email with full performance metrics', icon: Mail },
                                    ].map((item, i) => (
                                        <motion.div key={i}
                                            initial={{ opacity: 0, x: -15 }}
                                            whileInView={{ opacity: 1, x: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: i * 0.1 }}
                                            className="flex items-center gap-4"
                                        >
                                            <div className="w-10 h-10 rounded-xl bg-[#635BFF]/5 border border-[#635BFF]/10 flex items-center justify-center flex-shrink-0">
                                                <item.icon className="w-5 h-5 text-[#635BFF]" />
                                            </div>
                                            <span className="text-sm font-medium text-[#425466]">{item.text}</span>
                                        </motion.div>
                                    ))}
                                </div>
                            </RevealSection>

                            <RevealSection delay={0.2}>
                                <motion.div style={{ y: y1 }} className="space-y-6">
                                    <div className="bg-[#0A2540] rounded-2xl p-8 text-white shadow-[var(--shadow-stripe)] relative overflow-hidden">
                                        <div className="absolute inset-0 stripe-mesh-bg opacity-20" />
                                        <div className="relative z-10">
                                            <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-gray-500 mb-6">Monthly Impact Projection</p>
                                            <div className="space-y-4 mb-8">
                                                <div className="flex justify-between items-center">
                                                    <span className="text-sm text-gray-400">Orders/Month</span>
                                                    <span className="text-xl font-bold font-['Outfit']">10,000</span>
                                                </div>
                                                <div className="flex justify-between items-center">
                                                    <span className="text-sm text-gray-400">RTO Prevented</span>
                                                    <span className="text-xl font-bold text-[#00D4AA] font-['Outfit']">+400</span>
                                                </div>
                                            </div>
                                            <div className="border-t border-white/10 pt-6">
                                                <p className="text-[10px] font-bold text-[#80E9FF] uppercase tracking-widest mb-2">Capital Recovered</p>
                                                <p className="text-4xl sm:text-5xl font-extrabold text-white font-['Outfit'] tracking-tight">
                                                    ₹1,40,000<span className="text-[#635BFF] text-lg">/Mo</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex gap-4">
                                        <div className="flex-1 bg-white rounded-2xl p-6 border border-gray-100 text-center shadow-sm hover:shadow-lg transition-shadow">
                                            <p className="text-3xl font-extrabold text-[#00D4AA] font-['Outfit']">42%</p>
                                            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-1">RTO Reduction</p>
                                        </div>
                                        <div className="flex-1 bg-white rounded-2xl p-6 border border-gray-100 text-center shadow-sm hover:shadow-lg transition-shadow">
                                            <p className="text-3xl font-extrabold text-[#635BFF] font-['Outfit']">50x</p>
                                            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-1">Avg ROI</p>
                                        </div>
                                    </div>
                                </motion.div>
                            </RevealSection>
                        </div>
                    </div>
                </div>
            </section>

            {/* ═══ EXCLUSIVE ACCESS SECTION ════════════════════════════════ */}
            <section className="py-24 sm:py-32 bg-[#0A2540] relative overflow-hidden">
                <div className="absolute inset-0 grid-pattern-dark opacity-20" />
                <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#635BFF]/10 rounded-full blur-[160px] pointer-events-none" />

                <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
                    <RevealSection className="text-center mb-16">
                        <div className="stripe-badge rounded-full px-5 py-2 inline-flex items-center gap-2 mb-6">
                            <Lock className="w-3.5 h-3.5 text-[#FF80B5]" />
                            <span className="text-xs font-bold text-[#FF80B5] uppercase tracking-[0.2em]">Exclusive Access</span>
                        </div>
                        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-white font-['Outfit'] tracking-tight mb-5">
                            Pricing built around <span className="text-gradient-hero">your business</span>
                        </h2>
                        <p className="text-white/50 text-lg max-w-2xl mx-auto leading-relaxed">
                            We don't believe in one-size-fits-all pricing. Every brand is different — your order volume, channels, and contract terms are discussed directly with our team.
                        </p>
                    </RevealSection>

                    {/* Why custom pricing */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                        {[
                            {
                                icon: Users,
                                color: '#635BFF',
                                title: 'Limited Onboarding',
                                desc: 'We selectively onboard brands to ensure every merchant gets dedicated attention, fast response times, and a properly configured verification system from day one.',
                            },
                            {
                                icon: Shield,
                                color: '#00D4AA',
                                title: 'Contract-Based Access',
                                desc: 'Your access is activated through a signed contract — no self-serve credit cards. This means we\'re fully aligned with your success and accountable for results.',
                            },
                            {
                                icon: Rocket,
                                color: '#FF9E2C',
                                title: 'Tailored to Your Volume',
                                desc: 'Whether you ship 500 or 50,000 COD orders per month, your rate is negotiated directly. The more you scale, the better your per-verification economics.',
                            },
                        ].map((item, i) => (
                            <RevealSection key={i} delay={i * 0.1}>
                                <div className="glass-card-ultra rounded-2xl p-7 h-full group hover:border-white/20 transition-colors">
                                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 flex-shrink-0"
                                        style={{ background: `${item.color}20`, border: `1px solid ${item.color}30` }}>
                                        <item.icon className="w-5 h-5" style={{ color: item.color }} />
                                    </div>
                                    <h3 className="text-lg font-bold text-white font-['Outfit'] mb-2">{item.title}</h3>
                                    <p className="text-white/45 text-sm leading-relaxed">{item.desc}</p>
                                </div>
                            </RevealSection>
                        ))}
                    </div>

                    {/* What's included in every contract */}
                    <RevealSection>
                        <div className="glass-card-ultra rounded-3xl p-8 sm:p-12 relative overflow-hidden">
                            <div className="absolute inset-0 grid-pattern-dark opacity-10" />
                            <div className="absolute top-0 right-0 w-64 h-64 bg-[#635BFF]/10 rounded-full blur-[80px]" />
                            <div className="relative z-10">
                                <div className="flex flex-col lg:flex-row gap-10 lg:gap-16 items-start">
                                    <div className="flex-1">
                                        <p className="text-xs font-bold text-[#635BFF] uppercase tracking-[0.2em] mb-3">Every Contract Includes</p>
                                        <h3 className="text-2xl sm:text-3xl font-black text-white font-['Outfit'] tracking-tight mb-6">
                                            Everything you need, <br />nothing you don't.
                                        </h3>
                                        <div className="grid sm:grid-cols-2 gap-3">
                                            {[
                                                'WhatsApp verification with interactive buttons',
                                                'Shopify + WooCommerce + Custom API',
                                                'AI risk scoring & fraud detection',
                                                'Real-time dashboard & live analytics',
                                                'AI personal chatbot on your store',
                                                'Live support workers for customer chats',
                                                'Daily performance summary via email',
                                                'Custom WhatsApp message templates',
                                                'Customer blacklist management',
                                                'Multi-store support under one account',
                                                'Auto-retry logic on unanswered messages',
                                                'Dedicated account executive assigned',
                                            ].map((feat, j) => (
                                                <div key={j} className="flex items-center gap-3">
                                                    <CheckCircle2 className="w-4 h-4 text-[#00D4AA] flex-shrink-0" />
                                                    <span className="text-sm text-white/65">{feat}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="w-full lg:w-80 flex-shrink-0">
                                        <div className="bg-white/5 border border-white/10 rounded-2xl p-7 text-center">
                                            <div className="w-16 h-16 mx-auto mb-5 rounded-2xl bg-[#635BFF]/15 border border-[#635BFF]/20 flex items-center justify-center">
                                                <Mail className="w-7 h-7 text-[#635BFF]" />
                                            </div>
                                            <h4 className="text-xl font-black text-white font-['Outfit'] mb-2">Talk to Us First</h4>
                                            <p className="text-white/40 text-sm leading-relaxed mb-6">
                                                Our executive will understand your business, order volume, and channels — then put together a contract that makes sense for you.
                                            </p>
                                            <Link to="/contact" className="stripe-button w-full flex items-center justify-center gap-2 py-3.5 text-white rounded-xl font-semibold text-sm">
                                                Request a Contract <ArrowRight className="w-4 h-4" />
                                            </Link>
                                            <p className="text-white/25 text-xs mt-4">Typically responds within 4 business hours</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </RevealSection>
                </div>
            </section>

            {/* ═══ REVIEWS ════════════════════════════════════════════════════ */}
            <TestimonialsSection />

            {/* ═══ FINAL CTA ═════════════════════════════════════════════════ */}
            <section className="py-24 sm:py-32 relative overflow-hidden bg-[#0A2540]">
                <GradientOrbs />
                <div className="absolute inset-0 grid-pattern-dark opacity-15" />
                <div className="absolute top-0 left-0 w-full h-px glow-line opacity-50" />

                <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center relative z-10">
                    <RevealSection>
                        <div className="inline-flex items-center gap-2.5 px-5 py-2.5 stripe-badge rounded-full mb-8">
                            <Sparkles className="w-4 h-4 text-[#80E9FF]" />
                            <span className="text-xs font-semibold text-[#80E9FF]">Ready to scale?</span>
                        </div>
                        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-[64px] font-extrabold text-white font-['Outfit'] tracking-tight mb-7 leading-[1.05]">
                            Your store deserves{' '}
                            <span className="text-gradient-stripe">smarter protection</span>
                            <br />today.
                        </h2>
                        <p className="text-lg sm:text-xl text-gray-400 font-normal max-w-xl mx-auto mb-12">
                            Join 1,200+ brands already running smarter COD operations with WhatsApp verification, AI risk scoring, and daily email reports.
                        </p>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-4">
                            <Link to="/signup" className="group stripe-button text-white rounded-xl px-10 py-5 font-semibold text-base flex items-center justify-center gap-3">
                                Get Started Now <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                            </Link>
                            <Link to="/contact" className="px-10 py-5 bg-white/5 backdrop-blur-sm text-white rounded-xl font-semibold text-base border border-white/10 hover:bg-white/10 transition-all flex items-center justify-center gap-3">
                                <Mail className="w-5 h-5" /> Contact Sales
                            </Link>
                        </div>

                        {/* Bottom trust */}
                        <div className="mt-16 flex flex-wrap items-center justify-center gap-8">
                            {[
                                { icon: Shield, label: 'Enterprise Security' },
                                { icon: Users, label: '1,200+ Brands' },
                                { icon: Activity, label: '99.9% Uptime' },
                                { icon: Star, label: '4.8/5 Rating' },
                            ].map((item, i) => (
                                <div key={i} className="flex items-center gap-2">
                                    <item.icon className="w-4 h-4 text-gray-600" />
                                    <span className="text-xs font-medium text-gray-500">{item.label}</span>
                                </div>
                            ))}
                        </div>
                    </RevealSection>
                </div>
            </section>
        </>
    );
}

export default HomePage;

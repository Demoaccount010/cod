﻿import { Helmet } from 'react-helmet-async';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, MessageSquare, Sparkles, Zap, Shield, CheckCircle, Plus, Trash2, X, Loader2 } from 'lucide-react';
import { merchantApi } from '../../api';
import { toast } from 'sonner';

type Template = {
    id: string;
    template_name: string;
    template_type: string;
    template_language: string;
    approval_status: string;
    template_body: string;
    created_at: string;
};

const STATUS_STYLES: Record<string, string> = {
    approved: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    pending:  'bg-amber-50 text-amber-600 border-amber-100',
    rejected: 'bg-red-50 text-red-600 border-red-100',
};

export default function TemplatesPage() {
    const [templates, setTemplates] = useState<Template[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [deleting, setDeleting] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);
    const [form, setForm] = useState({
        template_name: '',
        template_type: 'Authentication',
        template_language: 'en',
        template_body: '',
    });

    const fetchTemplates = () => {
        setLoading(true);
        merchantApi.getTemplates()
            .then(r => setTemplates(r.data?.data || []))
            .catch(() => toast.error('Failed to load templates'))
            .finally(() => setLoading(false));
    };

    useEffect(() => { fetchTemplates(); }, []);

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!form.template_name.trim() || !form.template_body.trim()) {
            toast.error('Name and message body are required');
            return;
        }
        setSubmitting(true);
        try {
            await merchantApi.createTemplate(form);
            toast.success('Template submitted for approval');
            setShowCreate(false);
            setForm({ template_name: '', template_type: 'Authentication', template_language: 'en', template_body: '' });
            fetchTemplates();
        } catch (err: any) {
            toast.error(err?.response?.data?.detail || 'Failed to create template');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = async (id: string) => {
        setDeleting(id);
        try {
            await merchantApi.deleteTemplate(id);
            toast.success('Template deleted');
            setTemplates(prev => prev.filter(t => t.id !== id));
        } catch {
            toast.error('Failed to delete template');
        } finally {
            setDeleting(null);
        }
    };

    return (
        <div className="max-w-5xl mx-auto space-y-8 pb-10">
            <Helmet><title>Templates - CODVerify Intelligence</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                            <FileText className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Communication Nodes</h1>
                            <p className="text-gray-500 text-sm font-medium">WhatsApp approved message structural templates</p>
                        </div>
                    </div>
                </motion.div>

                <button
                    onClick={() => setShowCreate(true)}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all"
                >
                    <Plus className="w-5 h-5" /> Request Meta Approval
                </button>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
                {/* Info Card */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                    className="lg:col-span-1 space-y-6">
                    <div className="glass-card rounded-[32px] p-8 border border-white shadow-xl shadow-indigo-500/5 bg-indigo-600 text-white relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-8 opacity-10 transform group-hover:scale-125 transition-transform duration-700">
                            <Shield className="w-24 h-24" />
                        </div>
                        <div className="relative z-10">
                            <h3 className="text-lg font-bold font-['Outfit'] mb-4 tracking-tight">Template Protocol</h3>
                            <p className="text-sm text-indigo-100/80 leading-relaxed mb-6">
                                All WhatsApp messages must follow Meta-approved templates to ensure high delivery rates and brand safety.
                            </p>
                            <ul className="space-y-3">
                                <li className="flex items-center gap-2 text-xs font-bold text-indigo-50">
                                    <CheckCircle className="w-4 h-4 text-emerald-400" /> End-to-End Encryption
                                </li>
                                <li className="flex items-center gap-2 text-xs font-bold text-indigo-50">
                                    <CheckCircle className="w-4 h-4 text-emerald-400" /> Opt-out Compliance
                                </li>
                                <li className="flex items-center gap-2 text-xs font-bold text-indigo-50">
                                    <CheckCircle className="w-4 h-4 text-emerald-400" /> High Performance Delivery
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div className="glass-card rounded-[32px] p-8 border border-white shadow-xl shadow-indigo-500/5">
                        <div className="flex items-center gap-3 mb-4">
                            <Zap className="w-5 h-5 text-amber-500" />
                            <h3 className="text-sm font-bold text-gray-900 uppercase tracking-widest">Global Status</h3>
                        </div>
                        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                            <p className="text-xs font-bold text-amber-800 leading-relaxed text-center">
                                Custom template creation is currently in restricted access. Contact support to request priority onboarding.
                            </p>
                        </div>
                    </div>
                </motion.div>

                {/* Main Content */}
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}
                    className="lg:col-span-2 space-y-6">
                    <div className="glass-card rounded-[32px] border border-white p-8 shadow-xl shadow-indigo-500/5 relative overflow-hidden">
                        <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                                <MessageSquare className="w-5 h-5 text-indigo-600" />
                                <h3 className="text-xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Active Library</h3>
                            </div>
                            <span className="px-3 py-1 bg-white border border-gray-100 rounded-full text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                {loading ? '...' : `${templates.length} Node${templates.length !== 1 ? 's' : ''}`}
                            </span>
                        </div>

                        {loading ? (
                            <div className="flex items-center justify-center py-16">
                                <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                            </div>
                        ) : templates.length === 0 ? (
                            <div className="py-16 text-center">
                                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-gray-100">
                                    <Sparkles className="w-8 h-8 text-indigo-300 animate-pulse" />
                                </div>
                                <h4 className="text-sm font-bold text-gray-700 uppercase tracking-widest mb-1">No Templates Yet</h4>
                                <p className="text-xs text-gray-400 max-w-xs mx-auto mb-6">Request your first Meta-approved template to start sending WhatsApp messages.</p>
                                <button
                                    onClick={() => setShowCreate(true)}
                                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-2xl text-xs font-bold shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all"
                                >
                                    <Plus className="w-4 h-4" /> Create First Template
                                </button>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {templates.map((item, i) => (
                                    <motion.div
                                        key={item.id}
                                        initial={{ opacity: 0, x: 20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: 0.3 + (i * 0.05) }}
                                        className="flex items-center justify-between p-5 rounded-3xl hover:bg-indigo-50/30 border border-transparent hover:border-indigo-100 transition-all group"
                                    >
                                        <div className="flex items-center gap-5 min-w-0">
                                            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm border border-gray-50 group-hover:shadow-md transition-all flex-shrink-0">
                                                <FileText className="w-6 h-6 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="text-base font-bold text-gray-900 font-['Outfit'] tracking-tight truncate">{item.template_name}</p>
                                                <div className="flex items-center gap-3 mt-1">
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{item.template_type}</span>
                                                    <span className="w-1 h-1 rounded-full bg-gray-300" />
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{item.template_language}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-3 flex-shrink-0">
                                            <div className={`px-4 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-widest border ${STATUS_STYLES[item.approval_status] || STATUS_STYLES.pending}`}>
                                                {item.approval_status}
                                            </div>
                                            <button
                                                onClick={() => handleDelete(item.id)}
                                                disabled={deleting === item.id}
                                                className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                                title="Delete template"
                                            >
                                                {deleting === item.id
                                                    ? <Loader2 className="w-4 h-4 animate-spin" />
                                                    : <Trash2 className="w-4 h-4" />
                                                }
                                            </button>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}

                        {!loading && templates.length > 0 && (
                            <div className="mt-8 pt-6 border-t border-dashed border-gray-100 text-center">
                                <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 rounded-full text-[10px] font-bold text-indigo-600 border border-indigo-100">
                                    <Zap className="w-3 h-3" /> NEURAL ENGINE UPDATE V2.1
                                </div>
                            </div>
                        )}
                    </div>
                </motion.div>
            </div>

            {/* Create Template Modal */}
            <AnimatePresence>
                {showCreate && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
                        onClick={() => setShowCreate(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            onClick={e => e.stopPropagation()}
                            className="bg-white rounded-[32px] p-8 w-full max-w-lg shadow-2xl"
                        >
                            <div className="flex items-center justify-between mb-6">
                                <h2 className="text-xl font-bold text-gray-900 font-['Outfit']">Request Template Approval</h2>
                                <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                                    <X className="w-5 h-5 text-gray-500" />
                                </button>
                            </div>
                            <form onSubmit={handleCreate} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 uppercase tracking-widest mb-1.5">Template Name</label>
                                    <input
                                        type="text"
                                        value={form.template_name}
                                        onChange={e => setForm(p => ({ ...p, template_name: e.target.value }))}
                                        placeholder="e.g. order_verification_otp"
                                        className="w-full px-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                        required
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-600 uppercase tracking-widest mb-1.5">Type</label>
                                        <select
                                            value={form.template_type}
                                            onChange={e => setForm(p => ({ ...p, template_type: e.target.value }))}
                                            className="w-full px-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                        >
                                            {['Authentication', 'Marketing', 'Utility'].map(t => (
                                                <option key={t} value={t}>{t}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-600 uppercase tracking-widest mb-1.5">Language</label>
                                        <select
                                            value={form.template_language}
                                            onChange={e => setForm(p => ({ ...p, template_language: e.target.value }))}
                                            className="w-full px-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                        >
                                            <option value="en">English</option>
                                            <option value="hi">Hindi</option>
                                            <option value="en_IN">Hinglish</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 uppercase tracking-widest mb-1.5">Message Body</label>
                                    <textarea
                                        value={form.template_body}
                                        onChange={e => setForm(p => ({ ...p, template_body: e.target.value }))}
                                        placeholder="Your order {{1}} is being verified. Reply YES to confirm or NO to cancel."
                                        rows={4}
                                        className="w-full px-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                                        required
                                    />
                                    <p className="text-[10px] text-gray-400 mt-1">Use &#123;&#123;1&#125;&#125;, &#123;&#123;2&#125;&#125; etc. for dynamic variables</p>
                                </div>
                                <button
                                    type="submit"
                                    disabled={submitting}
                                    className="w-full py-3.5 bg-indigo-600 text-white rounded-2xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 disabled:opacity-60"
                                >
                                    {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                                    {submitting ? 'Submittingâ€¦' : 'Submit for Approval'}
                                </button>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

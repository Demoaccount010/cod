import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { merchantApi } from '../../api';
import { HelpCircle, Plus, ChevronRight, MessageSquare, LifeBuoy, Clock, ShieldCheck, AlertCircle, Trash2, Send } from 'lucide-react';
import ReviewsSection from '../../components/reviews/ReviewsSection';

const STATUS_CONFIG: Record<string, { label: string, color: string, icon: any }> = {
    open: { label: 'Open', color: 'bg-indigo-50 text-indigo-600 border-indigo-100', icon: MessageSquare },
    in_progress: { label: 'Active', color: 'bg-amber-50 text-amber-600 border-amber-100', icon: Clock },
    resolved: { label: 'Resolved', color: 'bg-emerald-50 text-emerald-600 border-emerald-100', icon: ShieldCheck },
    closed: { label: 'Archived', color: 'bg-gray-50 text-gray-500 border-gray-100', icon: Trash2 },
    waiting_on_customer: { label: 'Awaiting', color: 'bg-purple-50 text-purple-600 border-purple-100', icon: AlertCircle }
};

export default function SupportPage() {
    const [tickets, setTickets] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [form, setForm] = useState({ subject: '', description: '', priority: 'medium' });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        merchantApi.getTickets()
            .then(r => setTickets(r.data?.data?.tickets || []))
            .finally(() => setLoading(false));
    }, []);

    const create = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await merchantApi.createTicket(form);
            const r = await merchantApi.getTickets();
            setTickets(r.data?.data?.tickets || []);
            setShowCreate(false);
            setForm({ subject: '', description: '', priority: 'medium' });
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Establishing secure link to support nodes...</p>
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto space-y-8 pb-10">
            <Helmet><title>Support - CODVerify Intelligence</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                            <LifeBuoy className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Support Node</h1>
                            <p className="text-gray-500 text-sm font-medium italic">Direct access to technical assistance and resolution logic</p>
                        </div>
                    </div>
                </motion.div>

                <button
                    onClick={() => setShowCreate(true)}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-95"
                >
                    <Plus className="w-5 h-5" /> Initiate New Ticket
                </button>
            </div>

            {/* Quick Stats / Info Area */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="glass-card rounded-3xl p-6 border border-white shadow-sm flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
                        <MessageSquare className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mb-1">Active Tickets</p>
                        <p className="text-xl font-bold text-gray-900 font-['Outfit']">{tickets.filter(t => t.status === 'open' || t.status === 'in_progress').length}</p>
                    </div>
                </div>
                <div className="glass-card rounded-3xl p-6 border border-white shadow-sm flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
                        <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mb-1">Resolved Nodes</p>
                        <p className="text-xl font-bold text-gray-900 font-['Outfit']">{tickets.filter(t => t.status === 'resolved').length}</p>
                    </div>
                </div>
                <div className="glass-card rounded-3xl p-6 border border-white shadow-sm items-center gap-4 hidden sm:flex">
                    <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600">
                        <Clock className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mb-1">Response TTL</p>
                        <p className="text-xl font-bold text-gray-900 font-['Outfit']">~4.2 Hours</p>
                    </div>
                </div>
            </div>

            <div className="space-y-4">
                <AnimatePresence>
                    {tickets.length === 0 ? (
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="py-20 text-center glass-card rounded-[32px] border-2 border-dashed border-gray-100 bg-gray-50/30"
                        >
                            <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-sm border border-gray-50">
                                <HelpCircle className="w-10 h-10 text-gray-200" />
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 font-['Outfit'] mb-2">Clear support history</h3>
                            <p className="text-gray-400 max-w-sm mx-auto mb-8">No active tickets found. If you require assistance, our technical agents are ready to help.</p>
                            <button onClick={() => setShowCreate(true)} className="px-8 py-3 bg-white text-indigo-600 border border-indigo-100 rounded-2xl text-sm font-bold shadow-sm hover:bg-indigo-50 transition-all">Submit Help Request</button>
                        </motion.div>
                    ) : tickets.map((t, idx) => {
                        const config = STATUS_CONFIG[t.status] || STATUS_CONFIG.open;
                        return (
                            <motion.div
                                key={t.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="glass-card rounded-[24px] border border-white p-5 hover:border-indigo-100 hover:shadow-xl hover:shadow-indigo-500/5 transition-all group flex items-center justify-between cursor-pointer"
                            >
                                <div className="flex items-center gap-5">
                                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all group-hover:scale-110 ${config.color}`}>
                                        <config.icon className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2 mb-1.5">
                                            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest border ${config.color}`}>
                                                {config.label}
                                            </span>
                                            <span className="text-[10px] font-bold text-gray-300 uppercase tracking-tighter">Ticket Protocol #{t.ticket_number}</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] tracking-tight group-hover:text-indigo-600 transition-colors uppercase italic">{t.subject}</h3>
                                        <p className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5 mt-1">
                                            <Clock className="w-3 h-3 text-gray-300" />
                                            Synchronized: {new Date(t.created_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                        </p>
                                    </div>
                                </div>
                                <div className="p-3 bg-gray-50/50 rounded-2xl text-gray-300 group-hover:text-indigo-400 group-hover:bg-indigo-50 transition-all">
                                    <ChevronRight className="w-6 h-6" />
                                </div>
                            </motion.div>
                        );
                    })}
                </AnimatePresence>
            </div>

            {/* Reviews — merchants can leave feedback */}
            <ReviewsSection showForm={true} />

            {/* Creation Modal */}
            <AnimatePresence>
                {showCreate && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowCreate(false)} />
                        <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }}
                            className="bg-white rounded-[32px] p-8 w-full max-w-lg relative z-10 shadow-3xl border border-gray-100" onClick={e => e.stopPropagation()}>
                            <div className="flex items-center gap-4 mb-8">
                                <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                                    <Plus className="w-7 h-7 text-white" />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-bold text-gray-900 font-['Outfit']">New Intelligence Ticket</h2>
                                    <p className="text-sm text-gray-400 font-medium">Request human intervention in a protocol</p>
                                </div>
                            </div>

                            <form onSubmit={create} className="space-y-6">
                                <div className="space-y-4">
                                    <div className="group">
                                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Protocol Subject</label>
                                        <input required value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} className="w-full px-5 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all" placeholder="E.g. Database Sync Latency" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="group">
                                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Issue Priority</label>
                                            <select value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))} className="w-full px-5 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all">
                                                <option value="low">Standard Priority</option>
                                                <option value="medium">Optimized Priority</option>
                                                <option value="high">Critical Sync</option>
                                                <option value="urgent">Immediate Action</option>
                                            </select>
                                        </div>
                                        <div className="group flex items-end">
                                            <div className="w-full p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 flex items-center gap-2">
                                                <ShieldCheck className="w-4 h-4 text-indigo-500" />
                                                <span className="text-[9px] font-bold text-indigo-600 uppercase">E2E Encrypted</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="group">
                                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Detail Logs (Description)</label>
                                        <textarea required minLength={10} rows={4} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none resize-none transition-all" placeholder="Provide detailed behavioral analysis of the issue..." />
                                        <p className="text-[10px] text-gray-400 mt-1 ml-1">Minimum 10 characters</p>
                                    </div>
                                </div>
                                <div className="flex gap-4 pt-4">
                                    <button type="button" onClick={() => setShowCreate(false)} className="flex-1 px-6 py-4 text-sm font-bold text-gray-500 hover:text-gray-900 transition-colors bg-gray-50 rounded-2xl">Abort Request</button>
                                    <button type="submit" disabled={submitting} className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                                        {submitting ? (
                                            <>
                                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                                Transmitting...
                                            </>
                                        ) : (
                                            <>
                                                <Send className="w-4 h-4" /> Finalize Link
                                            </>
                                        )}
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

import { useEffect, useState, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { merchantApi } from '../../api';
import { Bell, CheckCheck, Info, AlertTriangle, XCircle, CheckCircle, Wallet, ShoppingCart, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const TYPE_CONFIG: Record<string, { icon: any; color: string; bg: string; border: string }> = {
    info: { icon: Info, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100' },
    success: { icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100' },
    warning: { icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100' },
    error: { icon: XCircle, color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-100' },
};

const CATEGORY_ICON: Record<string, any> = {
    billing: Wallet,
    order: ShoppingCart,
    system: Zap,
};

function timeAgo(iso: string) {
    const diff = Date.now() - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'Just now';
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
}

export default function NotificationsPage() {
    const [notifications, setNotifications] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [markingAll, setMarkingAll] = useState(false);
    const [filter, setFilter] = useState<'all' | 'unread'>('all');

    const load = useCallback(async () => {
        const params = filter === 'unread' ? 'unread_only=true' : '';
        const res = await merchantApi.getNotifications(params);
        setNotifications(res.data?.data?.notifications || []);
        setLoading(false);
    }, [filter]);

    useEffect(() => {
        setLoading(true);
        load();
    }, [load]);

    const markRead = async (id: string) => {
        await merchantApi.markRead(id);
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    };

    const markAll = async () => {
        setMarkingAll(true);
        await merchantApi.markAllRead();
        setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
        setMarkingAll(false);
    };

    const unreadCount = notifications.filter(n => !n.is_read).length;

    return (
        <div className="max-w-3xl mx-auto space-y-6 pb-10">
            <Helmet><title>Notifications — CODVerify</title></Helmet>

            {/* Header */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <Bell className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Notifications</h1>
                        <p className="text-gray-500 text-sm font-medium">
                            {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up!'}
                        </p>
                    </div>
                </div>
                {unreadCount > 0 && (
                    <button
                        onClick={markAll}
                        disabled={markingAll}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-60"
                    >
                        <CheckCheck className="w-4 h-4" />
                        {markingAll ? 'Marking...' : 'Mark all read'}
                    </button>
                )}
            </motion.div>

            {/* Filter Tabs */}
            <div className="flex gap-2">
                {(['all', 'unread'] as const).map(f => (
                    <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${filter === f
                            ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                            : 'bg-white text-gray-500 border border-gray-100 hover:border-indigo-200'
                            }`}
                    >
                        {f === 'all' ? 'All' : `Unread${unreadCount > 0 ? ` (${unreadCount})` : ''}`}
                    </button>
                ))}
            </div>

            {/* Notification List */}
            {loading ? (
                <div className="flex justify-center py-20">
                    <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                </div>
            ) : notifications.length === 0 ? (
                <motion.div
                    initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                    className="text-center py-20 bg-white rounded-3xl border border-gray-100"
                >
                    <Bell className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                    <p className="text-gray-400 font-medium">No notifications yet</p>
                    <p className="text-gray-300 text-sm mt-1">We'll notify you about orders, billing, and system updates.</p>
                </motion.div>
            ) : (
                <div className="space-y-3">
                    <AnimatePresence>
                        {notifications.map((n, i) => {
                            const cfg = TYPE_CONFIG[n.type] || TYPE_CONFIG.info;
                            const Icon = CATEGORY_ICON[n.category] || cfg.icon;
                            return (
                                <motion.div
                                    key={n.id}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 0.03 }}
                                    className={`relative flex gap-4 p-5 rounded-2xl bg-white border transition-all group ${n.is_read ? 'border-gray-100 opacity-75' : 'border-indigo-100 shadow-sm shadow-indigo-500/5'
                                        }`}
                                >
                                    {/* Unread dot */}
                                    {!n.is_read && (
                                        <span className="absolute top-5 right-5 w-2 h-2 bg-indigo-600 rounded-full" />
                                    )}

                                    {/* Icon */}
                                    <div className={`w-10 h-10 flex-shrink-0 rounded-xl ${cfg.bg} ${cfg.border} border flex items-center justify-center`}>
                                        <Icon className={`w-5 h-5 ${cfg.color}`} />
                                    </div>

                                    {/* Content */}
                                    <div className="flex-1 min-w-0 pr-4">
                                        <p className={`text-sm font-bold ${n.is_read ? 'text-gray-500' : 'text-gray-900'}`}>{n.title}</p>
                                        <p className="text-xs text-gray-400 font-medium mt-0.5 leading-relaxed">{n.message}</p>
                                        <div className="flex items-center gap-3 mt-2">
                                            <span className="text-[10px] font-bold text-gray-300 uppercase tracking-widest">
                                                {timeAgo(n.created_at)}
                                            </span>
                                            {n.action_url && (
                                                <Link
                                                    to={n.action_url}
                                                    className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest hover:text-indigo-800"
                                                >
                                                    View →
                                                </Link>
                                            )}
                                        </div>
                                    </div>

                                    {/* Mark read button */}
                                    {!n.is_read && (
                                        <button
                                            onClick={() => markRead(n.id)}
                                            className="opacity-0 group-hover:opacity-100 absolute bottom-4 right-5 text-[10px] font-bold text-gray-400 hover:text-indigo-600 transition-all uppercase tracking-widest"
                                        >
                                            Mark read
                                        </button>
                                    )}
                                </motion.div>
                            );
                        })}
                    </AnimatePresence>
                </div>
            )}
        </div>
    );
}

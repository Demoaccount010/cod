import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { merchantApi } from '../../api';
import { FileText, CheckCircle, Clock, CreditCard, Shield, Zap, ArrowRight, Download, Lock, ToggleLeft, ToggleRight } from 'lucide-react';
import { toast } from 'sonner';

declare global {
    interface Window {
        Razorpay: any;
    }
}

export default function ContractPage() {
    const [loading, setLoading] = useState(true);
    const [contract, setContract] = useState<any>(null);
    const [hasContract, setHasContract] = useState(false);
    const [razorpayKey, setRazorpayKey] = useState('');
    const [paying, setPaying] = useState(false);
    const [billingData, setBillingData] = useState<any>(null);
    const [togglingAuto, setTogglingAuto] = useState(false);

    // Load Razorpay script
    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.async = true;
        document.body.appendChild(script);
        return () => { document.body.removeChild(script); };
    }, []);

    useEffect(() => {
        loadContract();
        loadBilling();
    }, []);

    const loadContract = async () => {
        try {
            const res = await merchantApi.getActiveContract();
            const d = res.data?.data;
            setContract(d?.contract);
            setHasContract(d?.has_contract || false);
            setRazorpayKey(d?.razorpay_key || '');
        } catch { }
        setLoading(false);
    };

    const loadBilling = async () => {
        try {
            const res = await merchantApi.getBillingStatements();
            setBillingData(res.data?.data);
        } catch { }
    };

    const handleToggleAutoPayment = async () => {
        if (!contract) return;
        const isEnabled = contract.auto_payment_enabled !== false;
        if (isEnabled) {
            if (!window.confirm('Disabling auto-payment will result in immediate account blacklisting. Are you sure?')) return;
        }
        setTogglingAuto(true);
        try {
            if (isEnabled) {
                await merchantApi.disableAutoPayment(contract.id);
                toast.error('Auto-payment disabled. Account blacklisted — contact support.');
            } else {
                await merchantApi.enableAutoPayment(contract.id);
                toast.success('Auto-payment enabled successfully.');
            }
            await loadContract();
        } catch (err: any) {
            toast.error(err?.response?.data?.detail || 'Operation failed. Try again.');
        } finally {
            setTogglingAuto(false);
        }
    };

    const handleAcceptAndPay = async () => {
        if (!contract) return;
        setPaying(true);
        try {
            const res = await merchantApi.acceptContract(contract.id);
            const d = res.data?.data;

            if (d?.activated) {
                // Free activation — no payment needed
                await loadContract();
                return;
            }

            // Open Razorpay checkout
            const options = {
                key: d.razorpay_key || razorpayKey,
                amount: d.amount,
                currency: d.currency || 'INR',
                name: 'CODVerify',
                description: `Contract ${d.contract_number}`,
                order_id: d.razorpay_order_id,
                handler: async (response: any) => {
                    try {
                        await merchantApi.verifyContractPayment({
                            contract_id: contract.id,
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature: response.razorpay_signature,
                        });
                        window.location.reload();
                    } catch {
                        alert('Payment verification failed. Contact support.');
                    }
                },
                prefill: {},
                theme: { color: '#4F46E5' },
            };

            const rzp = new window.Razorpay(options);
            rzp.open();
        } catch (err: any) {
            alert(err.response?.data?.detail || 'Failed to process. Try again.');
        }
        setPaying(false);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Loading contract details...</p>
        </div>
    );

    // ── NO CONTRACT ─────────────────────────────────────────────────
    if (!hasContract || !contract) {
        return (
            <div className="max-w-2xl mx-auto text-center py-20">
                <Helmet><title>My Contract - CODVerify</title></Helmet>
                <div className="glass-card rounded-[32px] p-12 border border-gray-100 shadow-xl">
                    <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                        <Lock className="w-10 h-10 text-indigo-300" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 font-['Outfit'] mb-3">No Active Contract</h2>
                    <p className="text-gray-400 max-w-sm mx-auto mb-8">Your account is pending activation. Our representative will contact you shortly to set up your personalized plan.</p>
                    <div className="flex items-center justify-center gap-2 text-xs font-bold text-indigo-600 bg-indigo-50 rounded-full px-4 py-2 mx-auto w-fit">
                        <Clock className="w-3.5 h-3.5" /> Awaiting contract assignment
                    </div>
                </div>
            </div>
        );
    }

    const isPending = contract.status === 'pending';
    const isActive = contract.status === 'active';
    const payAmount = contract.type === 'contract' ? contract.advance_amount : contract.monthly_amount;
    const currency = contract.currency === 'USD' ? '$' : '₹';
    const servicesArr: any[] = contract.services || [];
    const billingInvoices = billingData?.invoices || [];
    const billingSummary = billingData?.summary || {};

    return (
        <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8 pb-10">
            <Helmet><title>My Contract - CODVerify</title></Helmet>

            {/* Header */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">My Contract</h1>
                        <p className="text-gray-500 text-sm font-medium italic">#{contract.contract_number}</p>
                    </div>
                </div>
            </motion.div>

            {/* ── PENDING CONTRACT — Accept & Pay ───────────────────────── */}
            {isPending && (
                <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
                    <div className="glass-card rounded-[32px] p-6 sm:p-8 lg:p-10 border-2 border-indigo-200 shadow-2xl shadow-indigo-500/10 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 opacity-5">
                            <Shield className="w-32 h-32" />
                        </div>
                        <div className="relative z-10">
                            <div className="flex items-center gap-2 mb-6">
                                <span className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg text-[10px] font-bold uppercase tracking-widest border border-amber-200">
                                    <Clock className="w-3 h-3 inline mr-1" /> Pending Acceptance
                                </span>
                            </div>

                            {/* Contract Details */}
                            <div className="grid sm:grid-cols-2 gap-6 mb-8">
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Plan Type</p>
                                    <p className="text-lg font-bold text-gray-900 font-['Outfit'] capitalize">{contract.type} Plan</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Duration</p>
                                    <p className="text-lg font-bold text-gray-900 font-['Outfit']">{contract.duration_months} {contract.duration_months === 1 ? 'Month' : 'Months'}</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total Value</p>
                                    <p className="text-lg font-bold text-gray-900 font-['Outfit']">{currency}{Number(contract.total_amount).toLocaleString()}</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">
                                        {contract.type === 'contract' ? 'Advance (Pay Now)' : 'Monthly Amount'}
                                    </p>
                                    <p className="text-lg font-bold text-indigo-600 font-['Outfit']">{currency}{Number(payAmount).toLocaleString()}</p>
                                </div>
                            </div>

                            {/* Services included */}
                            {servicesArr.length > 0 && (
                                <div className="mb-8">
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Services Included</p>
                                    <div className="grid sm:grid-cols-2 gap-2">
                                        {servicesArr.map((s: any, i: number) => (
                                            <div key={i} className="flex items-center gap-2 p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                                                <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                                                <span className="text-xs font-bold text-emerald-800">{typeof s === 'string' ? s : s.name}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Admin Notes */}
                            {contract.notes && (
                                <div className="mb-8 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Notes from CODVerify</p>
                                    <p className="text-sm text-gray-600 font-medium">{contract.notes}</p>
                                </div>
                            )}

                            {/* Accept Button */}
                            <button
                                onClick={handleAcceptAndPay}
                                disabled={paying}
                                className="w-full sm:w-auto px-10 py-4 bg-indigo-600 text-white rounded-[20px] font-bold text-sm shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 transition-all active:scale-95 group flex items-center justify-center gap-3"
                            >
                                {paying ? (
                                    <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Processing...</>
                                ) : (
                                    <><CreditCard className="w-5 h-5" /> I Agree & Pay {currency}{Number(payAmount).toLocaleString()} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></>
                                )}
                            </button>
                            <p className="text-[10px] text-gray-400 mt-3 font-medium">
                                By clicking above, you agree to the service terms. Payment is processed securely via Razorpay.
                            </p>
                        </div>
                    </div>
                </motion.div>
            )}

            {/* ── ACTIVE CONTRACT — Summary ──────────────────────────── */}
            {isActive && (
                <>
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        <div className="glass-card rounded-[32px] p-6 sm:p-8 border border-emerald-100 shadow-xl relative overflow-hidden">
                            <div className="flex items-center gap-2 mb-6">
                                <span className="px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-lg text-[10px] font-bold uppercase tracking-widest border border-emerald-200">
                                    <Zap className="w-3 h-3 inline mr-1" /> Active
                                </span>
                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{contract.type} plan</span>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 mb-6">
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Started</p>
                                    <p className="text-sm font-bold text-gray-900 font-['Outfit']">{contract.start_date ? new Date(contract.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Expires</p>
                                    <p className="text-sm font-bold text-gray-900 font-['Outfit']">{contract.end_date ? new Date(contract.end_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total Paid</p>
                                    <p className="text-sm font-bold text-emerald-600 font-['Outfit']">{currency}{Number(billingSummary.total_paid || 0).toLocaleString()}</p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Pending</p>
                                    <p className="text-sm font-bold text-amber-600 font-['Outfit']">{currency}{Number(billingSummary.total_pending || 0).toLocaleString()}</p>
                                </div>
                            </div>

                            {servicesArr.length > 0 && (
                                <div>
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Active Services</p>
                                    <div className="flex flex-wrap gap-2">
                                        {servicesArr.map((s: any, i: number) => (
                                            <span key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 rounded-xl text-xs font-bold text-indigo-700 border border-indigo-100">
                                                <CheckCircle className="w-3 h-3" /> {typeof s === 'string' ? s : s.name}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Auto-payment toggle */}
                            <div className="mt-6 pt-6 border-t border-gray-100 flex items-center justify-between gap-4">
                                <div>
                                    <p className="text-sm font-bold text-gray-900">Auto-Payment</p>
                                    <p className="text-[11px] text-gray-400 mt-0.5">
                                        {contract.auto_payment_enabled !== false
                                            ? 'Scheduled payments processed automatically.'
                                            : <span className="text-red-500">Disabled — account blacklisted. Contact support.</span>
                                        }
                                    </p>
                                </div>
                                <button
                                    onClick={handleToggleAutoPayment}
                                    disabled={togglingAuto}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${contract.auto_payment_enabled !== false
                                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                                        : 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200'
                                    }`}
                                >
                                    {togglingAuto ? (
                                        <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                                    ) : contract.auto_payment_enabled !== false ? (
                                        <><ToggleRight className="w-4 h-4" /> Enabled</>
                                    ) : (
                                        <><ToggleLeft className="w-4 h-4" /> Disabled</>
                                    )}
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </>
            )}

            {/* Billing Statements — shown for any contract state */}
            {billingInvoices.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                    <div className="glass-card rounded-[32px] p-6 sm:p-8 border border-gray-100 shadow-sm">
                        <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] mb-6 flex items-center gap-2">
                            <Download className="w-5 h-5 text-gray-400" /> Billing Statements
                        </h3>
                        <div className="space-y-3">
                            {billingInvoices.map((inv: any, i: number) => (
                                <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${inv.status === 'paid' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                                            {inv.status === 'paid' ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900">{inv.invoice_number}</p>
                                            <p className="text-[10px] font-semibold text-gray-400">{inv.description || inv.type} • {new Date(inv.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-sm font-bold text-gray-900">{currency}{Number(inv.amount).toLocaleString()}</p>
                                        <span className={`text-[9px] font-bold uppercase tracking-widest ${inv.status === 'paid' ? 'text-emerald-600' : 'text-amber-600'}`}>{inv.status}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </motion.div>
            )}
        </div>
    );
}

import { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Search, Calendar, ShieldAlert, ShieldOff, CheckCircle, Users, ChevronLeft, ChevronRight, Loader2, UserX, Ban, Undo2, X, AlertTriangle, Phone } from 'lucide-react';
import { merchantApi } from '../../api';
import { toast } from 'sonner';

interface Customer {
    id?: string;
    phone_number_hash: string;
    phone_last_four: string;
    total_orders: number;
    confirmed_orders: number;
    cancelled_orders: number;
    risk_score: number;
    last_order_date: string | null;
    created_at: string;
    is_blacklisted?: boolean;
}

type FilterMode = 'all' | 'high_risk' | 'blacklisted';

export default function CustomersPage() {
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [searchDebounced, setSearchDebounced] = useState('');
    const [page, setPage] = useState(1);
    const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 20, total_pages: 0 });
    const [filterMode, setFilterMode] = useState<FilterMode>('all');
    const [actionLoading, setActionLoading] = useState<string | null>(null);

    // Debounce search
    useEffect(() => {
        const timer = setTimeout(() => setSearchDebounced(search), 400);
        return () => clearTimeout(timer);
    }, [search]);

    const fetchCustomers = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            params.set('page', String(page));
            params.set('limit', '20');
            if (searchDebounced) params.set('search', searchDebounced);
            if (filterMode === 'high_risk') {
                params.set('risk_score_min', '60');
            }
            if (filterMode === 'blacklisted') {
                params.set('blacklisted', 'true');
            }

            const res = await merchantApi.getCustomers(params.toString());
            const data = res.data?.data;
            setCustomers(data?.customers || []);
            setPagination(data?.pagination || { total: 0, page: 1, limit: 20, total_pages: 0 });
        } catch (err: any) {
            console.error('Failed to fetch customers:', err);
            toast.error('Failed to load customers');
        } finally {
            setLoading(false);
        }
    }, [page, searchDebounced, filterMode]);

    useEffect(() => {
        fetchCustomers();
    }, [fetchCustomers]);

    // Reset page when filters change
    useEffect(() => {
        setPage(1);
    }, [searchDebounced, filterMode]);

    const handleBlacklist = async (phoneHash: string, phoneLast4: string) => {
        setActionLoading(phoneHash);
        try {
            // We need a phone number for the backend, but we only have the hash
            // The backend expects full phone, but we can use the hash for unblacklist
            await merchantApi.blacklistCustomer({ phone_number: `****${phoneLast4}`, phone_hash: phoneHash });
            toast.success(`Customer ****${phoneLast4} blacklisted`);
            fetchCustomers();
        } catch (err: any) {
            const msg = err.response?.data?.detail || 'Failed to blacklist';
            toast.error(msg);
        } finally {
            setActionLoading(null);
        }
    };

    const handleUnblacklist = async (phoneHash: string, phoneLast4: string) => {
        setActionLoading(phoneHash);
        try {
            await merchantApi.unblacklist(phoneHash);
            toast.success(`Customer ****${phoneLast4} removed from blacklist`);
            fetchCustomers();
        } catch (err: any) {
            toast.error('Failed to remove from blacklist');
        } finally {
            setActionLoading(null);
        }
    };

    const getStatusInfo = (c: Customer) => {
        if (c.is_blacklisted) return { label: 'Blacklisted', color: 'bg-gray-800 text-white border-gray-700', icon: Ban };
        if (c.risk_score >= 70) return { label: 'High Risk', color: 'bg-rose-50 text-rose-600 border-rose-100', icon: ShieldAlert };
        if (c.risk_score >= 40) return { label: 'Medium Risk', color: 'bg-amber-50 text-amber-600 border-amber-100', icon: AlertTriangle };
        if (c.total_orders >= 5 && c.risk_score < 30) return { label: 'Trusted', color: 'bg-indigo-50 text-indigo-600 border-indigo-100', icon: CheckCircle };
        return { label: 'Normal', color: 'bg-emerald-50 text-emerald-600 border-emerald-100', icon: CheckCircle };
    };

    const confirmRate = (c: Customer) => c.total_orders > 0 ? Math.round((c.confirmed_orders / c.total_orders) * 100) : 0;

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
            <Helmet><title>Customers - CODVerify Intelligence</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                            <Users className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Customer Intelligence</h1>
                            <p className="text-gray-500 text-sm font-medium italic">Behavioral monitoring and reputation analysis</p>
                        </div>
                    </div>
                </motion.div>

                <div className="flex items-center gap-3">
                    <div className="px-4 py-2 bg-indigo-50 rounded-xl border border-indigo-100">
                        <span className="text-xs font-bold text-indigo-600">{pagination.total} Customers</span>
                    </div>
                </div>
            </div>

            {/* Search & Filters */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                className="grid lg:grid-cols-4 gap-4">
                <div className="lg:col-span-3 flex gap-3">
                    <div className="flex-1 relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            placeholder="Search by last 4 digits of phone..."
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                            className="w-full pl-12 pr-10 py-3 bg-white border border-gray-100 rounded-2xl text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm transition-all"
                        />
                        {search && (
                            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-300 hover:text-gray-500 transition-colors">
                                <X className="w-4 h-4" />
                            </button>
                        )}
                    </div>
                </div>
                <div className="lg:col-span-1">
                    <div className="glass-card rounded-2xl p-1 border border-gray-100 flex shadow-sm">
                        {(['all', 'high_risk', 'blacklisted'] as FilterMode[]).map(mode => (
                            <button
                                key={mode}
                                onClick={() => setFilterMode(mode)}
                                className={`flex-1 py-2 text-[10px] font-bold uppercase tracking-widest transition-all rounded-xl ${filterMode === mode
                                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                    : 'text-gray-400 hover:text-gray-600'
                                    }`}
                            >
                                {mode === 'all' ? 'All' : mode === 'high_risk' ? 'High Risk' : 'Blocked'}
                            </button>
                        ))}
                    </div>
                </div>
            </motion.div>

            {/* Table */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                className="glass-card rounded-[32px] border border-white overflow-hidden shadow-xl shadow-indigo-500/5">

                {loading ? (
                    <div className="flex flex-col items-center justify-center py-24 gap-4">
                        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Loading customers...</p>
                    </div>
                ) : customers.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-24 gap-4">
                        <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center">
                            <UserX className="w-8 h-8 text-gray-300" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 font-['Outfit']">No Customers Found</h3>
                        <p className="text-sm text-gray-400 font-medium max-w-md text-center">
                            {search
                                ? `No customers match "${search}". Try a different search.`
                                : filterMode !== 'all'
                                    ? 'No customers in this filter. Try switching to "All".'
                                    : 'Customers will appear here once orders come through your connected stores.'
                            }
                        </p>
                    </div>
                ) : (
                    <>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="bg-gray-50/50 border-b border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                        <th className="px-8 py-5">Customer</th>
                                        <th className="px-8 py-5">Phone</th>
                                        <th className="px-8 py-5">Orders</th>
                                        <th className="px-8 py-5 text-center">Risk Score</th>
                                        <th className="px-8 py-5">Status</th>
                                        <th className="px-8 py-5 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-50 bg-white/50">
                                        {customers.map((c) => {
                                            const status = getStatusInfo(c);
                                            const StatusIcon = status.icon;
                                            return (
                                                <tr
                                                    key={c.phone_number_hash}
                                                    className="hover:bg-indigo-50/30 transition-colors group cursor-default"
                                                >
                                                    <td className="px-8 py-5">
                                                        <div className="flex items-center gap-4">
                                                            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white text-base font-bold shadow-lg ${c.is_blacklisted
                                                                ? 'bg-gray-800 shadow-gray-800/10'
                                                                : c.risk_score >= 70
                                                                    ? 'bg-gradient-to-br from-rose-500 to-rose-600 shadow-rose-500/10'
                                                                    : 'premium-gradient shadow-indigo-500/10'
                                                                }`}>
                                                                {c.is_blacklisted ? <Ban className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
                                                            </div>
                                                            <div>
                                                                <p className="text-base font-bold text-gray-900 font-['Outfit'] tracking-tight leading-none mb-1">
                                                                    ****{c.phone_last_four}
                                                                </p>
                                                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                                                    {confirmRate(c)}% confirmation rate
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-5">
                                                        <div className="flex flex-col">
                                                            <span className="text-sm font-bold text-gray-700">****{c.phone_last_four}</span>
                                                            <span className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-1.5 mt-0.5 tracking-tighter">
                                                                {c.last_order_date
                                                                    ? `Last order: ${new Date(c.last_order_date).toLocaleDateString()}`
                                                                    : 'No recent orders'
                                                                }
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-5">
                                                        <div className="flex flex-col">
                                                            <span className="text-base font-bold text-gray-900 font-['Outfit']">
                                                                {c.total_orders} <span className="text-xs font-medium text-gray-400">total</span>
                                                            </span>
                                                            <div className="flex items-center gap-3 mt-0.5">
                                                                <span className="text-[10px] font-bold text-emerald-500">
                                                                    ✓ {c.confirmed_orders}
                                                                </span>
                                                                <span className="text-[10px] font-bold text-rose-400">
                                                                    ✗ {c.cancelled_orders}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-5">
                                                        <div className="flex flex-col items-center gap-1">
                                                            <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-gray-200/50">
                                                                <div
                                                                    className={`h-full rounded-full transition-all duration-1000 ${c.risk_score > 60
                                                                        ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]'
                                                                        : c.risk_score > 30
                                                                            ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]'
                                                                            : 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]'
                                                                        }`}
                                                                    style={{ width: `${Math.min(c.risk_score, 100)}%` }}
                                                                />
                                                            </div>
                                                            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">
                                                                {c.risk_score}% risk
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-5">
                                                        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border text-[10px] font-bold uppercase tracking-widest ${status.color}`}>
                                                            <StatusIcon className="w-3.5 h-3.5" />
                                                            {status.label}
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-5 text-right">
                                                        {actionLoading === c.phone_number_hash ? (
                                                            <div className="inline-flex p-3">
                                                                <Loader2 className="w-5 h-5 text-indigo-500 animate-spin" />
                                                            </div>
                                                        ) : c.is_blacklisted ? (
                                                            <button
                                                                onClick={() => handleUnblacklist(c.phone_number_hash, c.phone_last_four)}
                                                                title="Remove from blacklist"
                                                                className="p-3 text-emerald-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-2xl border border-transparent hover:border-emerald-100 transition-all"
                                                            >
                                                                <Undo2 className="w-5 h-5" />
                                                            </button>
                                                        ) : (
                                                            <button
                                                                onClick={() => handleBlacklist(c.phone_number_hash, c.phone_last_four)}
                                                                title="Blacklist customer"
                                                                className="p-3 text-gray-300 hover:text-rose-600 hover:bg-rose-50 rounded-2xl border border-transparent hover:border-rose-100 transition-all"
                                                            >
                                                                <ShieldOff className="w-5 h-5" />
                                                            </button>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                </tbody>
                            </table>
                        </div>

                        {/* Pagination */}
                        <div className="flex items-center justify-between px-10 py-8 bg-gray-50/50 border-t border-gray-100">
                            <div className="flex items-center gap-3">
                                <Calendar className="w-5 h-5 text-gray-300" />
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.2em]">
                                    Page {pagination.page} of {pagination.total_pages || 1} · {pagination.total} customers
                                </p>
                            </div>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => setPage(p => Math.max(1, p - 1))}
                                    disabled={page <= 1}
                                    className="px-6 py-3 bg-white rounded-2xl text-xs font-bold uppercase tracking-widest border border-gray-200 transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:border-indigo-200 flex items-center gap-2"
                                >
                                    <ChevronLeft className="w-4 h-4" /> Previous
                                </button>
                                <button
                                    onClick={() => setPage(p => p + 1)}
                                    disabled={page >= (pagination.total_pages || 1)}
                                    className="px-6 py-3 bg-white text-gray-900 border border-indigo-100 rounded-2xl text-xs font-bold uppercase tracking-widest shadow-xl shadow-indigo-500/5 hover:border-indigo-300 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2"
                                >
                                    Next <ChevronRight className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    </>
                )}
            </motion.div>

            {/* Footer */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
                className="py-10 text-center flex flex-col items-center">
                <div className="w-12 h-1 bg-gradient-to-r from-transparent via-indigo-600 to-transparent rounded-full mb-8"></div>
                <h4 className="text-sm font-bold text-gray-900 uppercase tracking-[0.3em] font-['Outfit'] mb-4 tracking-tight">Ecosystem Intelligence v2.0</h4>
                <div className="flex gap-4 flex-wrap justify-center">
                    <span className="px-6 py-2 bg-indigo-50 text-indigo-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100">Fraud Pulse Enabled</span>
                    <span className="px-6 py-2 bg-emerald-50 text-emerald-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100">Behavioral Shield Active</span>
                    <span className="px-6 py-2 bg-rose-50 text-rose-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-rose-100">Anomaly Radar Scanning</span>
                </div>
            </motion.div>
        </div>
    );
}

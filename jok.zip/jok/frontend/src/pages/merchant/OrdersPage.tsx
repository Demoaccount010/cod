import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { merchantApi } from '../../api';
import { timeAgo } from '../../lib/utils';
import { Search, Download, Eye, ChevronLeft, ChevronRight, Filter, Calendar, MoreHorizontal, ShoppingBag, User, Activity } from 'lucide-react';


const STATUS_CONFIG: Record<string, { color: string, label: string }> = {
    pending: { color: 'bg-slate-100 text-slate-700 border-slate-200', label: 'Processing' },
    queued: { color: 'bg-blue-50 text-blue-600 border-blue-100', label: 'Queued' },
    sent: { color: 'bg-indigo-50 text-indigo-600 border-indigo-100', label: 'Sent' },
    delivered: { color: 'bg-sky-50 text-sky-600 border-sky-100', label: 'Delivered' },
    read: { color: 'bg-cyan-50 text-cyan-600 border-cyan-100', label: 'Read' },
    confirmed: { color: 'bg-emerald-50 text-emerald-600 border-emerald-100', label: 'Confirmed' },
    cancelled: { color: 'bg-rose-50 text-rose-600 border-rose-100', label: 'Cancelled' },
    no_reply: { color: 'bg-amber-50 text-amber-600 border-amber-100', label: 'No Reply' },
    failed: { color: 'bg-red-50 text-red-600 border-red-100', label: 'Failed' },
    not_on_whatsapp: { color: 'bg-orange-50 text-orange-600 border-orange-100', label: 'No WhatsApp' },
    manual_confirmed: { color: 'bg-green-50 text-green-700 border-green-200', label: 'Manual OK' },
    manual_cancelled: { color: 'bg-red-50 text-red-700 border-red-200', label: 'Manual Cancel' },
    not_required: { color: 'bg-gray-50 text-gray-500 border-gray-200', label: 'Prepaid' },
    insufficient_balance: { color: 'bg-orange-50 text-orange-600 border-orange-200', label: 'Low Balance' },
};

export default function OrdersPage() {
    const [orders, setOrders] = useState<any[]>([]);
    const [pagination, setPagination] = useState<any>({});
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [status, setStatus] = useState('');
    const [search, setSearch] = useState('');
    const [orderType, setOrderType] = useState('');
    const [isFilterOpen, setIsFilterOpen] = useState(false);


    const fetchOrders = () => {
        setLoading(true);
        const params = new URLSearchParams({ page: String(page), limit: '15' });
        if (status) params.set('status', status);
        if (search) params.set('search', search);
        if (orderType) params.set('order_type', orderType);

        merchantApi.getOrders(params.toString())
            .then(res => {
                setOrders(res.data?.data?.orders || []);
                setPagination(res.data?.data?.pagination || {});
            })
            .finally(() => setLoading(false));
    };

    useEffect(fetchOrders, [page, status, orderType]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setPage(1);
        fetchOrders();
    };

    const handleExport = async () => {
        const params = new URLSearchParams();
        if (status) params.set('status', status);
        const res = await merchantApi.exportOrders(params.toString());
        const url = URL.createObjectURL(res.data);
        const a = document.createElement('a'); a.href = url; a.download = `orders-export-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    };

    return (
        <div className="space-y-6 pb-10">
            <Helmet><title>Orders - CODVerify Management</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Orders Archive</h1>
                    <p className="text-gray-500 text-sm font-medium flex items-center gap-2 mt-1">
                        <Activity className="w-3.5 h-3.5 text-indigo-500" />
                        Live verification stream monitoring
                    </p>
                </motion.div>

                <div className="flex items-center gap-3">
                    <button onClick={() => setIsFilterOpen(!isFilterOpen)} className={`p-2.5 rounded-xl border transition-all ${isFilterOpen ? 'bg-indigo-600 border-indigo-600 text-white' : 'glass-card border-gray-200 text-gray-600 hover:border-indigo-200'}`}>
                        <Filter className="w-5 h-5" />
                    </button>
                    <button onClick={handleExport} className="flex items-center gap-2 px-5 py-2.5 glass-card border-gray-200 text-sm font-bold text-gray-700 hover:border-indigo-200 hover:text-indigo-600 transition-all shadow-sm">
                        <Download className="w-4 h-4" /> Export CSV
                    </button>
                </div>
            </div>

            <AnimatePresence>
                {isFilterOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="glass-card rounded-2xl p-4 border border-indigo-100 flex flex-col md:flex-row gap-4 mb-2">
                            <form onSubmit={handleSearch} className="flex-1 relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-400" />
                                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, phone, or order ID..."
                                    className="w-full pl-12 pr-4 py-3 bg-white/50 border border-gray-100 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-medium" />
                            </form>
                            <div className="flex gap-4 flex-wrap">
                                <select value={orderType} onChange={e => { setOrderType(e.target.value); setPage(1); }}
                                    className="px-4 py-3 bg-white/50 border border-gray-100 rounded-xl text-sm font-bold text-gray-600 outline-none focus:ring-2 focus:ring-indigo-500">
                                    <option value="">All Types</option>
                                    <option value="cod">🟡 COD</option>
                                    <option value="prepaid">🟢 Prepaid</option>
                                </select>
                                <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}
                                    className="px-5 py-3 bg-white/50 border border-gray-100 rounded-xl text-sm font-bold text-gray-600 outline-none focus:ring-2 focus:ring-indigo-500 min-w-[180px]">
                                    <option value="">All Statuses</option>
                                    {Object.entries(STATUS_CONFIG).map(([val, cfg]) => <option key={val} value={val}>{cfg.label}</option>)}
                                </select>
                                <button onClick={handleSearch} className="px-6 py-3 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all">Apply</button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-3xl border border-white overflow-hidden shadow-xl shadow-indigo-500/5">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-gray-50/50 border-b border-gray-100">
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Identity</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Customer</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Delivery</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount</th>

                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center">Status</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center">Risk</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Timeline</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Control</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            {loading ? (
                                Array.from({ length: 5 }).map((_, i) => (
                                    <tr key={i} className="animate-pulse">
                                        <td colSpan={8} className="px-6 py-8"><div className="h-4 bg-gray-100 rounded-full w-full opacity-50"></div></td>
                                    </tr>
                                ))
                            ) : orders.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="px-6 py-20 text-center">
                                        <div className="flex flex-col items-center gap-3">
                                            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center border border-dashed border-gray-200">
                                                <ShoppingBag className="w-8 h-8 text-gray-300" />
                                            </div>
                                            <p className="text-gray-400 font-medium">No orders matching your criteria</p>
                                        </div>
                                    </td>
                                </tr>
                            ) : orders.map((o, idx) => (
                                <motion.tr initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }} key={o.id} className="hover:bg-indigo-50/20 transition-all group">
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col">
                                            <div className="flex items-center gap-2">
                                                <span className="text-sm font-bold text-gray-900 font-['Outfit']">#{o.order_number || o.store_order_id}</span>
                                                <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${o.order_type === 'cod' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                                                    {o.order_type || 'cod'}
                                                </span>
                                            </div>
                                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{o.stores?.name || 'Main Connection'}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                                                <User className="w-4 h-4" />
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-sm font-bold text-gray-900 leading-tight">{o.customer_name}</span>
                                                <span className="text-[11px] font-medium text-gray-400">{o.customer_phone}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col gap-0.5">
                                            <span className={`text-xs font-bold capitalize ${
                                                o.delivery_status === 'delivered' ? 'text-emerald-600' :
                                                o.delivery_status === 'shipped' ? 'text-blue-600' :
                                                o.delivery_status === 'returned' ? 'text-red-600' :
                                                'text-gray-400'
                                            }`}>{o.delivery_status || 'Pending'}</span>
                                            {o.tracking_number && (
                                                <span className="text-[10px] font-mono text-gray-400 truncate max-w-[100px]" title={o.tracking_number}>{o.tracking_number}</span>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-1 font-bold text-gray-900">
                                            <span className="text-gray-400 text-sm">{o.currency === 'USD' ? '$' : '₹'}</span>
                                            <span className="text-sm">{o.order_amount?.toLocaleString('en-IN')}</span>
                                        </div>
                                    </td>

                                    <td className="px-6 py-4">
                                        <div className="flex justify-center">
                                            <span className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-widest border border-solid ${STATUS_CONFIG[o.verification_status]?.color || 'bg-gray-50 text-gray-500 border-gray-100'}`}>
                                                {STATUS_CONFIG[o.verification_status]?.label || o.verification_status?.replace(/_/g, ' ')}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col items-center gap-1">
                                            <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-gray-200/50">
                                                <div className={`h-full rounded-full ${o.risk_score > 60 ? 'bg-red-500' : o.risk_score > 30 ? 'bg-amber-500' : 'bg-green-500'}`} style={{ width: `${Math.max(o.risk_score, 10)}%` }} />
                                            </div>
                                            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">SCORE {o.risk_score || 0}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-2 text-xs font-medium text-gray-500">
                                            <Calendar className="w-3.5 h-3.5 opacity-40" />
                                            {timeAgo(o.created_at)}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex items-center justify-end gap-2">
                                            <Link to={`/dashboard/orders/${o.id}`} className="p-2.5 text-gray-400 hover:text-indigo-600 hover:bg-white rounded-xl border border-transparent hover:border-indigo-100 hover:shadow-lg hover:shadow-indigo-500/10 transition-all">
                                                <Eye className="w-5 h-5" />
                                            </Link>
                                            <button className="p-2.5 text-gray-300 hover:text-gray-600 rounded-xl transition-all">
                                                <MoreHorizontal className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* Advanced Pagination */}
                {pagination.total_pages > 1 && (
                    <div className="flex items-center justify-between px-8 py-6 bg-gray-50/30 border-t border-gray-100">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                            Showing <span className="text-indigo-600">{orders.length}</span> of <span className="text-gray-900">{pagination.total}</span> data points
                        </p>
                        <div className="flex items-center gap-2">
                            <button disabled={!pagination.has_prev} onClick={() => setPage(p => p - 1)}
                                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-gray-200 text-gray-600 hover:bg-white hover:border-indigo-200 disabled:opacity-30 disabled:hover:bg-transparent">
                                <ChevronLeft className="w-4 h-4" /> Previous
                            </button>
                            <div className="flex gap-1">
                                {Array.from({ length: Math.min(pagination.total_pages, 5) }).map((_, i) => (
                                    <button key={i} onClick={() => setPage(i + 1)} className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${page === i + 1 ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-white'}`}>
                                        {i + 1}
                                    </button>
                                ))}
                            </div>
                            <button disabled={!pagination.has_next} onClick={() => setPage(p => p + 1)}
                                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-gray-200 text-gray-600 hover:bg-white hover:border-indigo-200 disabled:opacity-30 disabled:hover:bg-transparent">
                                Next <ChevronRight className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                )}
            </motion.div>
        </div>
    );
}

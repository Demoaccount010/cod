import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { merchantApi } from '../../api';
import { Store, Trash2, CheckCircle, ShoppingBag, Zap, AlertCircle, Clock, Globe, ExternalLink, Rocket, ArrowRight, X, Key, Link2, XCircle, Loader2 } from 'lucide-react';

export default function StoresPage() {
    const [stores, setStores] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showConnect, setShowConnect] = useState(false);
    const [shopifyConnected, setShopifyConnected] = useState(false);
    const [shopifyDomain, setShopifyDomain] = useState<string | null>(null);

    // Connect via key states
    const [secretKey, setSecretKey] = useState('');
    const [connecting, setConnecting] = useState(false);
    const [connectError, setConnectError] = useState('');
    const [connectSuccess, setConnectSuccess] = useState(false);

    const loadStores = async () => {
        try {
            const r = await merchantApi.getStores();
            const data = r.data?.data || r.data;
            if (data?.stores) {
                setStores(data.stores);
                setShopifyConnected(data.shopify_connected || false);
                setShopifyDomain(data.shopify_domain || null);
            } else if (Array.isArray(data)) {
                setStores(data);
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { loadStores(); }, []);

    const handleDelete = async (id: string) => {
        if (confirm('Delete this store integration? All linked orders will remain but sync will stop.')) {
            await merchantApi.deleteStore(id);
            setStores(s => s.filter(x => x.id !== id));
            setShopifyConnected(false);
            setShopifyDomain(null);
        }
    };

    const handleConnectViaKey = async () => {
        const key = secretKey.trim().toUpperCase();
        if (!key) {
            setConnectError('Please enter your secret key');
            return;
        }

        setConnecting(true);
        setConnectError('');
        setConnectSuccess(false);

        try {
            const res = await merchantApi.connectStoreViaKey({ secret_key: key });
            if (res.data?.success) {
                setConnectSuccess(true);
                setSecretKey('');
                // Reload stores after connection
                setTimeout(() => {
                    setShowConnect(false);
                    setConnectSuccess(false);
                    loadStores();
                }, 2000);
            }
        } catch (err: any) {
            const msg = err?.response?.data?.detail || err?.response?.data?.message || 'Connection failed. Please check your key and try again.';
            setConnectError(typeof msg === 'string' ? msg : 'Connection failed');
        } finally {
            setConnecting(false);
        }
    };

    // Format key input with dashes (CV-XXXX-XXXX-XXXX)
    const handleKeyInput = (value: string) => {
        // Allow the user to type freely, auto-uppercase
        setSecretKey(value.toUpperCase());
        setConnectError('');
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Scanning connected ecosystems...</p>
        </div>
    );

    return (
        <div className="space-y-8 pb-10">
            <Helmet><title>Stores - CODVerify Intelligence</title></Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                            <Store className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Eco-Systems</h1>
                            <p className="text-gray-500 text-sm font-medium">Manage your e-commerce platform synchronizations</p>
                        </div>
                    </div>
                </motion.div>

                <button
                    onClick={() => { setShowConnect(true); setConnectError(''); setConnectSuccess(false); setSecretKey(''); }}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-95"
                >
                    <Rocket className="w-5 h-5" /> Connect Store
                </button>
            </div>

            {/* Global Connection Status Banner */}
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
                className={`flex items-center gap-4 p-4 rounded-2xl border ${shopifyConnected
                    ? 'bg-emerald-50/50 border-emerald-200'
                    : 'bg-amber-50/50 border-amber-200'
                    }`}
            >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${shopifyConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}>
                    {shopifyConnected ? <CheckCircle className="w-5 h-5 text-white" /> : <AlertCircle className="w-5 h-5 text-white" />}
                </div>
                <div className="flex-1">
                    <p className={`text-sm font-bold ${shopifyConnected ? 'text-emerald-800' : 'text-amber-800'}`}>
                        {shopifyConnected ? 'Shopify Store Connected' : 'No Store Connected'}
                    </p>
                    <p className={`text-xs ${shopifyConnected ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {shopifyConnected
                            ? `Connected to ${shopifyDomain}. Orders are syncing automatically.`
                            : 'Connect your Shopify store using the secret key from the CODVerify Shopify app.'}
                    </p>
                </div>
                {shopifyConnected && (
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider">
                        Connected
                    </span>
                )}
                {!shopifyConnected && (
                    <button
                        onClick={() => { setShowConnect(true); setConnectError(''); setConnectSuccess(false); setSecretKey(''); }}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all"
                    >
                        Connect Now
                    </button>
                )}
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                    {stores.length === 0 ? (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="col-span-full py-20 text-center glass-card rounded-[32px] border-2 border-dashed border-gray-100 bg-gray-50/30"
                        >
                            <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-sm border border-gray-50">
                                <ShoppingBag className="w-10 h-10 text-gray-200" />
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 font-['Outfit'] mb-2">No connected stores yet</h3>
                            <p className="text-gray-400 max-w-md mx-auto mb-6">Install the CODVerify app on your Shopify store, get your secret key, and enter it here to connect.</p>
                            <button
                                onClick={() => { setShowConnect(true); setConnectError(''); setConnectSuccess(false); setSecretKey(''); }}
                                className="px-8 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all"
                            >
                                Connect Store <ArrowRight className="w-4 h-4 inline ml-2" />
                            </button>
                        </motion.div>
                    ) : stores.map((s, idx) => (
                        <motion.div
                            key={s.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            className="glass-card rounded-[32px] border border-white p-6 shadow-xl shadow-indigo-500/5 hover:border-indigo-100 hover:shadow-indigo-500/10 transition-all group relative overflow-hidden"
                        >
                            <div className="inner-glow absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

                            <div className="flex items-center justify-between mb-6 relative z-10">
                                <div className="flex items-center gap-3">
                                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all ${s.is_active ? 'bg-indigo-600 shadow-indigo-500/20' : 'bg-gray-200'}`}>
                                        <Zap className={`w-6 h-6 ${s.is_active ? 'text-white' : 'text-gray-400'}`} />
                                    </div>
                                    <div>
                                        <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">{s.platform}</span>
                                        <h3 className="text-lg font-bold text-gray-900 font-['Outfit'] -mt-1">{s.store_name}</h3>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => handleDelete(s.id)} className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all">
                                        <Trash2 className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-4 relative z-10">
                                <div className="flex items-center gap-2 p-3 bg-gray-50/50 rounded-2xl border border-gray-100">
                                    <Globe className="w-4 h-4 text-gray-400" />
                                    <p className="text-xs font-bold text-gray-500 truncate flex-1 tracking-tight">{s.store_url}</p>
                                    <ExternalLink className="w-3.5 h-3.5 text-gray-300 group-hover:text-indigo-400 transition-colors" />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-indigo-50/30 rounded-2xl p-3 border border-indigo-100/50">
                                        <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Total Syncs</p>
                                        <p className="text-xl font-bold text-indigo-900 font-['Outfit']">{s.total_orders || 0}</p>
                                    </div>
                                    <div className={`rounded-2xl p-3 border ${s.is_active ? 'bg-emerald-50/30 border-emerald-100/50' : 'bg-amber-50/30 border-amber-100/50'}`}>
                                        <p className={`text-[10px] font-bold uppercase tracking-widest ${s.is_active ? 'text-emerald-500' : 'text-amber-500'}`}>Status</p>
                                        <div className="flex items-center gap-1.5 pt-0.5">
                                            {s.is_active
                                                ? <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                                                : <XCircle className="w-3.5 h-3.5 text-amber-500" />
                                            }
                                            <span className={`text-xs font-bold uppercase ${s.is_active ? 'text-emerald-700' : 'text-amber-700'}`}>
                                                {s.is_active ? 'Connected' : 'Not Connected'}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between pt-2">
                                    <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                                        <Clock className="w-3 h-3" />
                                        Last sync: {s.last_order_received_at ? new Date(s.last_order_received_at).toLocaleDateString() : 'Never'}
                                    </div>
                                    {s.is_active && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>}
                                    {!s.is_active && <div className="w-1.5 h-1.5 rounded-full bg-amber-400"></div>}
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>

            {/* Connect Store Modal */}
            <AnimatePresence>
                {showConnect && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowConnect(false)} />
                        <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }}
                            className="bg-white rounded-[32px] p-8 w-full max-w-lg relative z-10 shadow-3xl border border-gray-100 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>

                            <button onClick={() => setShowConnect(false)} className="absolute top-6 right-6 p-2 text-gray-400 hover:text-gray-900 transition-colors">
                                <X className="w-5 h-5" />
                            </button>

                            {connectSuccess ? (
                                /* Success State */
                                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-8">
                                    <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-6">
                                        <CheckCircle className="w-10 h-10 text-emerald-500" />
                                    </div>
                                    <h2 className="text-2xl font-bold text-gray-900 font-['Outfit'] mb-2">Store Connected!</h2>
                                    <p className="text-gray-500 text-sm">Your Shopify store has been linked successfully. Orders will start syncing automatically.</p>
                                </motion.div>
                            ) : (
                                <>
                                    <div className="flex items-center gap-4 mb-8">
                                        <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                                            <Key className="w-7 h-7 text-white" />
                                        </div>
                                        <div>
                                            <h2 className="text-2xl font-bold text-gray-900 font-['Outfit']">Connect Store</h2>
                                            <p className="text-sm text-gray-400 font-medium">Enter your Shopify app secret key</p>
                                        </div>
                                    </div>

                                    {/* Secret Key Input */}
                                    <div className="mb-6">
                                        <label className="block text-sm font-bold text-gray-700 mb-2">Secret Key</label>
                                        <div className="relative">
                                            <Key className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
                                            <input
                                                type="text"
                                                value={secretKey}
                                                onChange={e => handleKeyInput(e.target.value)}
                                                onKeyDown={e => { if (e.key === 'Enter') handleConnectViaKey(); }}
                                                placeholder="CV-XXXX-XXXX-XXXX"
                                                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-2 border-gray-200 rounded-2xl text-lg font-mono font-bold text-gray-800 tracking-widest focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all placeholder:text-gray-300 placeholder:tracking-[0.2em]"
                                                maxLength={20}
                                                autoFocus
                                            />
                                        </div>
                                        {connectError && (
                                            <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="mt-2 text-sm text-red-600 font-medium flex items-center gap-1">
                                                <XCircle className="w-4 h-4" /> {connectError}
                                            </motion.p>
                                        )}
                                    </div>

                                    <button
                                        onClick={handleConnectViaKey}
                                        disabled={connecting || !secretKey.trim()}
                                        className="flex items-center justify-center gap-3 w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed text-base"
                                    >
                                        {connecting ? (
                                            <><Loader2 className="w-5 h-5 animate-spin" /> Connecting...</>
                                        ) : (
                                            <><Link2 className="w-5 h-5" /> Connect Store</>
                                        )}
                                    </button>

                                    {/* Instructions */}
                                    <div className="mt-8 pt-6 border-t border-gray-100">
                                        <h3 className="text-sm font-bold text-gray-700 mb-4">How to get your secret key:</h3>
                                        <div className="space-y-4">
                                            <div className="flex gap-4 items-start">
                                                <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0 text-sm">1</div>
                                                <div>
                                                    <h4 className="font-bold text-gray-800 text-sm">Install CODVerify App</h4>
                                                    <p className="text-xs text-gray-500 leading-relaxed">Search for <strong>"CODVerify"</strong> in the Shopify App Store and install it.</p>
                                                </div>
                                            </div>

                                            <div className="flex gap-4 items-start">
                                                <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0 text-sm">2</div>
                                                <div>
                                                    <h4 className="font-bold text-gray-800 text-sm">Copy Secret Key</h4>
                                                    <p className="text-xs text-gray-500 leading-relaxed">After installation, the app will show you a secret key (format: <strong>CV-XXXX-XXXX-XXXX</strong>). Copy it.</p>
                                                </div>
                                            </div>

                                            <div className="flex gap-4 items-start">
                                                <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold flex-shrink-0 text-sm">3</div>
                                                <div>
                                                    <h4 className="font-bold text-gray-800 text-sm">Paste Key Here</h4>
                                                    <p className="text-xs text-gray-500 leading-relaxed">Paste the key in the field above and click Connect. Your store will be linked instantly!</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="mt-6 pt-4 border-t border-gray-50">
                                        <a
                                            href="https://apps.shopify.com"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center justify-center gap-2 w-full py-3 bg-gray-50 text-gray-700 rounded-2xl font-bold text-sm border border-gray-200 hover:bg-gray-100 transition-all"
                                        >
                                            Don't have the app? Go to Shopify App Store <ExternalLink className="w-3.5 h-3.5" />
                                        </a>
                                    </div>
                                </>
                            )}
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}

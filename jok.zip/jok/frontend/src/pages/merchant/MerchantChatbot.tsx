import { Helmet } from 'react-helmet-async';
import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { merchantChatbotApi } from '../../api';
import {
    Bot, Copy, Check, Power, Code, BarChart3,
    Globe, Palette, Save, Plus, Trash2, MessageSquare
} from 'lucide-react';
import { toast } from 'sonner';

interface MenuOption {
    id: string;
    label: string;
    answer: string;
}

export default function MerchantChatbot() {
    const [config, setConfig] = useState<any>(null);
    const [usage, setUsage] = useState<any>(null);
    const [embedCode, setEmbedCode] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [copied, setCopied] = useState(false);
    const [tab, setTab] = useState<'setup' | 'menu' | 'embed' | 'usage'>('setup');
    const [menuOptions, setMenuOptions] = useState<MenuOption[]>([]);

    const fetchData = useCallback(async () => {
        try {
            const [configRes, usageRes, embedRes] = await Promise.all([
                merchantChatbotApi.getConfig(),
                merchantChatbotApi.getUsage(),
                merchantChatbotApi.getEmbedCode().catch(() => ({ data: { data: { embed_code: '' } } })),
            ]);
            const c = configRes.data?.data?.config || {};
            setConfig(c);
            setUsage(usageRes.data?.data || {});
            setEmbedCode(embedRes.data?.data?.embed_code || '');
            setMenuOptions(c.menu_options || []);
        } catch {
            toast.error('Failed to load chatbot config');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { fetchData(); }, [fetchData]);

    const handleSave = async () => {
        setSaving(true);
        try {
            await merchantChatbotApi.updateConfig({
                business_name: config.business_name,
                business_description: config.business_description,
                business_services: config.business_services,
                business_website: config.business_website,
                business_faq: config.business_faq,
                welcome_message: config.welcome_message,
                primary_color: config.primary_color,
                bot_name: config.bot_name,
                menu_options: menuOptions,
            });
            toast.success('Chatbot configuration saved!');
        } catch {
            toast.error('Failed to save');
        } finally {
            setSaving(false);
        }
    };

    const handleToggle = async () => {
        try {
            const r = await merchantChatbotApi.toggle();
            const enabled = r.data?.data?.is_enabled;
            setConfig((c: any) => ({ ...c, is_enabled: enabled }));
            toast.success(enabled ? 'Chatbot enabled!' : 'Chatbot disabled');
        } catch {
            toast.error('Failed to toggle');
        }
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(embedCode);
        setCopied(true);
        toast.success('Embed code copied!');
        setTimeout(() => setCopied(false), 2000);
    };

    const addMenuOption = () => {
        setMenuOptions(prev => [...prev, {
            id: `opt_${Date.now()}`,
            label: '',
            answer: '',
        }]);
    };

    const updateMenuOption = (index: number, field: string, value: string) => {
        setMenuOptions(prev => prev.map((opt, i) => i === index ? { ...opt, [field]: value } : opt));
    };

    const removeMenuOption = (index: number) => {
        setMenuOptions(prev => prev.filter((_, i) => i !== index));
    };

    const updateConfig = (field: string, value: string) => {
        setConfig((c: any) => ({ ...c, [field]: value }));
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        </div>
    );

    const isEnabled = config?.is_enabled;

    return (
        <div className="max-w-5xl mx-auto space-y-6 pb-10">
            <Helmet><title>AI Chatbot — Dashboard</title></Helmet>

            {/* Header */}
            <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-purple-600 rounded-xl shadow-lg shadow-purple-500/20 text-white">
                        <Bot className="w-5 h-5" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 font-['Outfit']">AI Chatbot</h1>
                        <p className="text-gray-400 text-xs font-medium">Add an AI chatbot to your website</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={handleToggle}
                        className={`px-5 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2 shadow-md transition-all ${isEnabled
                                ? 'bg-emerald-600 text-white shadow-emerald-500/20'
                                : 'bg-gray-200 text-gray-600'
                            }`}
                    >
                        <Power className="w-4 h-4" />
                        {isEnabled ? 'Enabled' : 'Disabled'}
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={saving}
                        className="px-5 py-2.5 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-md shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                        <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save'}
                    </button>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 bg-gray-100 rounded-2xl p-1">
                {[
                    { id: 'setup' as const, label: 'Business Setup', icon: Globe },
                    { id: 'menu' as const, label: 'Menu Options', icon: MessageSquare },
                    { id: 'embed' as const, label: 'Embed Code', icon: Code },
                    { id: 'usage' as const, label: 'Usage', icon: BarChart3 },
                ].map(t => (
                    <button
                        key={t.id}
                        onClick={() => setTab(t.id)}
                        className={`flex-1 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${tab === t.id ? 'bg-white shadow-sm text-indigo-700' : 'text-gray-500 hover:text-gray-700'
                            }`}
                    >
                        <t.icon className="w-3.5 h-3.5" /> {t.label}
                    </button>
                ))}
            </div>

            {/* Business Setup Tab */}
            {tab === 'setup' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-[28px] border border-white shadow-xl p-6 space-y-5">
                    <p className="text-sm font-bold text-gray-900 font-['Outfit']">Tell the AI about your business</p>
                    <p className="text-[11px] text-gray-400 -mt-3">The more details you provide, the better the AI will answer your customers' questions.</p>

                    <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Business Name</label>
                            <input value={config?.business_name || ''} onChange={e => updateConfig('business_name', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300" placeholder="Your Business Name" />
                        </div>
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Website URL</label>
                            <input value={config?.business_website || ''} onChange={e => updateConfig('business_website', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300" placeholder="https://yourstore.com" />
                        </div>
                    </div>

                    <div>
                        <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Business Description</label>
                        <textarea value={config?.business_description || ''} onChange={e => updateConfig('business_description', e.target.value)}
                            rows={3} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300 resize-none"
                            placeholder="What does your business do? What products/services do you offer?" />
                    </div>

                    <div>
                        <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Services / Products</label>
                        <textarea value={config?.business_services || ''} onChange={e => updateConfig('business_services', e.target.value)}
                            rows={3} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300 resize-none"
                            placeholder="List your key services and products..." />
                    </div>

                    <div>
                        <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">FAQ / Common Questions</label>
                        <textarea value={config?.business_faq || ''} onChange={e => updateConfig('business_faq', e.target.value)}
                            rows={4} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300 resize-none"
                            placeholder="Q: What are your shipping times?&#10;A: We ship within 2-3 business days..." />
                    </div>

                    <div className="grid sm:grid-cols-3 gap-4 pt-2 border-t border-gray-100">
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Bot Name</label>
                            <input value={config?.bot_name || ''} onChange={e => updateConfig('bot_name', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300" placeholder="Support Bot" />
                        </div>
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block">Welcome Message</label>
                            <input value={config?.welcome_message || ''} onChange={e => updateConfig('welcome_message', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:border-indigo-300" placeholder="Hi! How can I help?" />
                        </div>
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase mb-1 block flex items-center gap-1"><Palette className="w-3 h-3" /> Primary Color</label>
                            <div className="flex items-center gap-2">
                                <input type="color" value={config?.primary_color || '#6366f1'} onChange={e => updateConfig('primary_color', e.target.value)}
                                    className="w-10 h-10 rounded-lg border-0 cursor-pointer" />
                                <input value={config?.primary_color || '#6366f1'} onChange={e => updateConfig('primary_color', e.target.value)}
                                    className="flex-1 px-4 py-3 border border-gray-200 rounded-xl text-sm outline-none font-mono" />
                            </div>
                        </div>
                    </div>
                </motion.div>
            )}

            {/* Menu Options Tab */}
            {tab === 'menu' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <div className="glass-card rounded-[28px] border border-white shadow-xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <p className="text-sm font-bold text-gray-900 font-['Outfit']">Scripted Menu Options</p>
                                <p className="text-[11px] text-gray-400">These show as quick buttons in the chatbot. Answers are instant (no AI cost).</p>
                            </div>
                            <button onClick={addMenuOption}
                                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-md">
                                <Plus className="w-3 h-3" /> Add Option
                            </button>
                        </div>

                        <div className="space-y-3">
                            {menuOptions.map((opt, i) => (
                                <div key={opt.id} className="bg-gray-50 rounded-2xl p-4 space-y-2">
                                    <div className="flex items-center gap-2">
                                        <input value={opt.label} onChange={e => updateMenuOption(i, 'label', e.target.value)}
                                            placeholder="Button label (e.g. 📦 Track Order)"
                                            className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-indigo-300" />
                                        <button onClick={() => removeMenuOption(i)} className="p-2 text-gray-300 hover:text-rose-500 transition-colors">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <textarea value={opt.answer} onChange={e => updateMenuOption(i, 'answer', e.target.value)}
                                        placeholder="Answer when clicked..."
                                        rows={2} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-indigo-300 resize-none" />
                                </div>
                            ))}
                            {menuOptions.length === 0 && (
                                <p className="text-center text-gray-300 text-xs py-8">No menu options yet. Add some to provide instant answers!</p>
                            )}
                        </div>
                    </div>
                </motion.div>
            )}

            {/* Embed Code Tab */}
            {tab === 'embed' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-[28px] border border-white shadow-xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-bold text-gray-900 font-['Outfit']">Embed Code</p>
                            <p className="text-[11px] text-gray-400">Copy this code and paste it before the {'</body>'} tag on your website.</p>
                        </div>
                        <button onClick={copyToClipboard}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md">
                            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                            {copied ? 'Copied!' : 'Copy Code'}
                        </button>
                    </div>
                    <pre className="bg-gray-900 text-green-400 p-4 rounded-2xl text-xs overflow-x-auto font-mono leading-relaxed">{embedCode || 'Save your config first to generate embed code.'}</pre>

                    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
                        <p className="text-xs font-bold text-amber-800 mb-1">⚠️ Important</p>
                        <ul className="text-[11px] text-amber-700 space-y-0.5 list-disc list-inside">
                            <li>Make sure to enable the chatbot using the toggle above</li>
                            <li>Fill in your business details for accurate AI responses</li>
                            <li>API key is unique — don't share it publicly outside the embed code</li>
                            <li>Monthly limit: {usage?.monthly_limit || 100} requests/month</li>
                        </ul>
                    </div>
                </motion.div>
            )}

            {/* Usage Tab */}
            {tab === 'usage' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-[28px] border border-white shadow-xl p-6">
                    <p className="text-sm font-bold text-gray-900 font-['Outfit'] mb-4">API Usage This Month</p>
                    <div className="grid sm:grid-cols-3 gap-4">
                        <div className="bg-indigo-50 rounded-2xl p-4 text-center">
                            <p className="text-3xl font-black text-indigo-700 font-['Outfit']">{usage?.used || 0}</p>
                            <p className="text-[10px] font-bold text-indigo-400 uppercase mt-1">Requests Used</p>
                        </div>
                        <div className="bg-emerald-50 rounded-2xl p-4 text-center">
                            <p className="text-3xl font-black text-emerald-700 font-['Outfit']">{usage?.remaining || 0}</p>
                            <p className="text-[10px] font-bold text-emerald-400 uppercase mt-1">Remaining</p>
                        </div>
                        <div className="bg-gray-100 rounded-2xl p-4 text-center">
                            <p className="text-3xl font-black text-gray-700 font-['Outfit']">{usage?.monthly_limit || 100}</p>
                            <p className="text-[10px] font-bold text-gray-400 uppercase mt-1">Monthly Limit</p>
                        </div>
                    </div>
                    {/* Usage bar */}
                    <div className="mt-4">
                        <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all"
                                style={{ width: `${Math.min(100, ((usage?.used || 0) / (usage?.monthly_limit || 100)) * 100)}%` }}
                            />
                        </div>
                        <p className="text-[10px] text-gray-400 mt-1 text-right">
                            {usage?.reset_date ? `Resets: ${new Date(usage.reset_date).toLocaleDateString()}` : ''}
                        </p>
                    </div>
                </motion.div>
            )}
        </div>
    );
}

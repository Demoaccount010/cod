import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { merchantApi } from '../../api';
import { Plus, Trash2, Copy, CheckCircle, Key, Shield, Zap, AlertTriangle, Clock } from 'lucide-react';

export default function ApiKeysPage() {
    const [keys, setKeys] = useState<any[]>([]);
    const [newKey, setNewKey] = useState<any>(null);
    const [label, setLabel] = useState('');
    const [copied, setCopied] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        merchantApi.getApiKeys()
            .then(r => setKeys(r.data?.data || []))
            .finally(() => setLoading(false));
    }, []);

    const generate = async () => {
        if (!label) return;
        const r = await merchantApi.generateApiKey(label);
        setNewKey(r.data?.data);
        setLabel('');
        const k = await merchantApi.getApiKeys();
        setKeys(k.data?.data || []);
    };

    const revoke = async (id: string) => {
        if (confirm('Revoke this API key? Integrations using this key will stop working immediately.')) {
            await merchantApi.revokeApiKey(id);
            setKeys(k => k.filter(x => x.id !== id));
        }
    };

    const copy = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopied(id);
        setTimeout(() => setCopied(''), 2000);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Retrieving secure access nodes...</p>
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto space-y-8 pb-10">
            <Helmet><title>API Keys - CODVerify Intelligence</title></Helmet>

            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <Key className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Access Gateways</h1>
                        <p className="text-gray-500 text-sm font-medium">Generate secure credentials for external automation</p>
                    </div>
                </div>
            </motion.div>

            {/* Generate Section */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                className="glass-card rounded-[32px] p-8 border border-white shadow-xl shadow-indigo-500/5">
                <div className="flex items-center gap-3 mb-6">
                    <Zap className="w-5 h-5 text-indigo-600" />
                    <h3 className="text-lg font-bold text-gray-900 font-['Outfit']">Provision New Gateway</h3>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                        <input
                            value={label}
                            onChange={e => setLabel(e.target.value)}
                            placeholder="Gateway Identifier (e.g. Production Shopify)"
                            className="w-full px-5 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                        />
                    </div>
                    <button
                        onClick={generate}
                        disabled={!label}
                        className="px-8 py-3.5 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 whitespace-nowrap"
                    >
                        <Plus className="w-5 h-5" /> Generate Access Key
                    </button>
                </div>
            </motion.div>

            {/* New Key Alert */}
            <AnimatePresence>
                {newKey && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 10 }}
                        className="bg-amber-50 border border-amber-200 rounded-[32px] p-8 relative overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 p-8 opacity-10">
                            <Shield className="w-24 h-24 text-amber-600" />
                        </div>

                        <div className="relative z-10">
                            <div className="flex items-center gap-3 mb-4 text-amber-800">
                                <AlertTriangle className="w-6 h-6 animate-bounce" />
                                <h4 className="text-lg font-bold font-['Outfit']">Critical Security Protocol</h4>
                            </div>
                            <p className="text-sm font-medium text-amber-700/80 mb-6 max-w-xl leading-relaxed">
                                Secret keys are only visible once. Store these immediately in a secure vault.
                                CODVerify does not store raw secrets for your protection.
                            </p>

                            <div className="grid gap-4 max-w-2xl">
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-amber-600 uppercase tracking-widest ml-1">Public Key ID</label>
                                    <div className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-amber-200 shadow-sm">
                                        <code className="text-xs font-bold text-gray-800 flex-1 truncate">{newKey.api_key}</code>
                                        <button onClick={() => copy(newKey.api_key, 'api')} className="p-2 text-amber-600 hover:bg-amber-50 rounded-xl transition-all">
                                            {copied === 'api' ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-amber-600 uppercase tracking-widest ml-1">Private Secret Gateway</label>
                                    <div className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-amber-200 shadow-sm">
                                        <code className="text-xs font-bold text-gray-800 flex-1 truncate">{newKey.secret_key}</code>
                                        <button onClick={() => copy(newKey.secret_key, 'secret')} className="p-2 text-amber-600 hover:bg-amber-50 rounded-xl transition-all">
                                            {copied === 'secret' ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <button onClick={() => setNewKey(null)} className="mt-8 px-6 py-2 bg-amber-200/50 hover:bg-amber-200 text-amber-800 text-xs font-bold rounded-xl transition-all uppercase tracking-widest">I've Secured the credentials</button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Keys Table */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                className="glass-card rounded-[32px] border border-white overflow-hidden shadow-xl shadow-indigo-500/5">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-gray-50/50 border-b border-gray-100">
                                <th className="px-8 py-5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Gateway Label</th>
                                <th className="px-8 py-5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Public Identifier</th>
                                <th className="px-8 py-5 text-[10px] font-bold text-gray-400 uppercase tracking-widest hidden md:table-cell">Last Handshake</th>
                                <th className="px-8 py-5 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Control</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            {keys.length === 0 ? (
                                <tr>
                                    <td colSpan={4} className="px-8 py-16 text-center text-gray-400 font-medium">No active gateways established</td>
                                </tr>
                            ) : keys.map((k, idx) => (
                                <motion.tr
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    key={k.id}
                                    className="hover:bg-indigo-50/20 transition-all group"
                                >
                                    <td className="px-8 py-5">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                                                <Key className="w-4 h-4" />
                                            </div>
                                            <span className="text-sm font-bold text-gray-900 font-['Outfit']">{k.label}</span>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5">
                                        <div className="flex items-center gap-2">
                                            <code className="text-[11px] font-bold text-gray-400 bg-gray-100/50 px-2 py-1 rounded-lg border border-gray-100 flex items-center gap-2">
                                                {k.api_key?.slice(0, 12)}••••••••
                                            </code>
                                            <button onClick={() => copy(k.api_key, k.id)} className="p-1.5 text-gray-300 hover:text-indigo-600 hover:bg-white rounded-lg transition-all opacity-0 group-hover:opacity-100">
                                                {copied === k.id ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                                            </button>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 text-[11px] font-bold text-gray-400 uppercase tracking-widest hidden md:table-cell">
                                        <div className="flex items-center gap-2">
                                            <Clock className="w-3 h-3" />
                                            {k.last_used_at ? new Date(k.last_used_at).toLocaleDateString() : 'Inactive'}
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 text-right">
                                        <button onClick={() => revoke(k.id)} className="p-2.5 text-gray-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl border border-transparent hover:border-rose-100 transition-all">
                                            <Trash2 className="w-4.5 h-4.5" />
                                        </button>
                                    </td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </motion.div>
        </div>
    );
}

import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import {
    Settings, User, MessageSquare, Bell, Globe, Zap,
    Save, ChevronRight,
    Webhook
} from 'lucide-react';
import { merchantApi } from '../../api';

// ─── Types ───────────────────────────────────────────────────────────────────
interface MerchantSettings {
    // Profile
    business_name?: string;
    notification_email?: string;
    // Verification Algorithm
    message_delay_seconds?: number;
    working_hours_enabled?: boolean;
    working_hours_start?: string;
    working_hours_end?: string;
    auto_cancel_on_no?: boolean;
    auto_cancel_on_no_reply?: boolean;
    no_reply_timeout_hours?: number;
    max_retries?: number;
    retry_interval_hours?: number;
    min_order_amount?: number;
    send_delivery_updates?: boolean;
    // Message Toggles
    enable_verification_msg?: boolean;
    enable_thankyou_msg?: boolean;
    enable_cancel_msg?: boolean;
    enable_delivery_updates_msg?: boolean;
    enable_no_reply_reminder?: boolean;
    // Notifications
    notification_on_cancel?: boolean;
    notification_daily_summary?: boolean;
    notification_quota_warning?: boolean;
    // Webhook
    webhook_callback_url?: string;
}

// ─── Tab Button ──────────────────────────────────────────────────────────────
function TabBtn({ id, active, icon: Icon, label, onClick }: any) {
    return (
        <button
            onClick={() => onClick(id)}
            className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 w-full text-left ${active
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
        >
            <Icon size={16} />
            <span>{label}</span>
            {active && <ChevronRight size={14} className="ml-auto" />}
        </button>
    );
}

// ─── Toggle Switch ────────────────────────────────────────────────────────────
function Toggle({ checked, onChange, label, description }: any) {
    return (
        <div className="flex items-start justify-between gap-4 py-4 border-b border-white/5 last:border-0">
            <div>
                <div className="text-sm font-medium text-white">{label}</div>
                {description && <div className="text-xs text-slate-400 mt-0.5">{description}</div>}
            </div>
            <button
                onClick={() => onChange(!checked)}
                className={`relative flex-shrink-0 w-11 h-6 rounded-full transition-colors duration-200 ${checked ? 'bg-indigo-600' : 'bg-slate-700'
                    }`}
            >
                <span className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full shadow transition-transform duration-200 ${checked ? 'translate-x-5' : 'translate-x-0'
                    }`} />
            </button>
        </div>
    );
}

// ─── Number Input ─────────────────────────────────────────────────────────────
function NumberInput({ label, description, value, onChange, min, max, suffix }: any) {
    return (
        <div className="py-4 border-b border-white/5 last:border-0">
            <div className="flex items-center justify-between gap-4">
                <div>
                    <div className="text-sm font-medium text-white">{label}</div>
                    {description && <div className="text-xs text-slate-400 mt-0.5">{description}</div>}
                </div>
                <div className="flex items-center gap-2">
                    <input
                        type="number"
                        value={value ?? ''}
                        onChange={e => onChange(Number(e.target.value))}
                        min={min}
                        max={max}
                        className="w-20 px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white text-right focus:outline-none focus:border-indigo-500"
                    />
                    {suffix && <span className="text-xs text-slate-400">{suffix}</span>}
                </div>
            </div>
        </div>
    );
}

// ─── Section Card ─────────────────────────────────────────────────────────────
function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
    return (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-4">{title}</h3>
            {children}
        </div>
    );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function SettingsPage() {
    const [activeTab, setActiveTab] = useState('profile');
    const [settings, setSettings] = useState<MerchantSettings>({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        loadSettings();
    }, []);

    const loadSettings = async () => {
        try {
            setLoading(true);
            const settingsRes = await merchantApi.getSettings();
            setSettings(settingsRes.data?.data || settingsRes.data || {});
        } catch {
            toast.error('Failed to load settings');
        } finally {
            setLoading(false);
        }
    };

    const update = (key: string, value: any) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const saveSettings = async () => {
        try {
            setSaving(true);
            await merchantApi.updateSettings(settings);
            toast.success('Settings saved successfully');
        } catch {
            toast.error('Failed to save settings');
        } finally {
            setSaving(false);
        }
    };

    const tabs = [
        { id: 'profile', label: 'Profile & Business', icon: User },
        { id: 'verification', label: 'Verification Settings', icon: Zap },
        { id: 'messages', label: 'Message Flow', icon: MessageSquare },
        { id: 'notifications', label: 'Notifications', icon: Bell },
        { id: 'webhook', label: 'Webhook & API', icon: Webhook },
    ];

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="max-w-6xl mx-auto px-4 py-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                        <Settings className="text-indigo-400" size={32} />
                        Settings
                    </h1>
                    <p className="text-slate-400 mt-1">Configure your CODVerify workspace settings</p>
                </div>
                <button
                    onClick={saveSettings}
                    disabled={saving}
                    id="save-settings-btn"
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold transition-all duration-200 shadow-lg shadow-indigo-500/25 disabled:opacity-50"
                >
                    {saving ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                        <Save size={16} />
                    )}
                    {saving ? 'Saving...' : 'Save Changes'}
                </button>
            </div>

            <div className="grid grid-cols-12 gap-6">
                {/* Sidebar */}
                <div className="col-span-3">
                    <div className="bg-white/5 border border-white/10 rounded-2xl p-3 space-y-1">
                        {tabs.map(tab => (
                            <TabBtn
                                key={tab.id}
                                id={tab.id}
                                active={activeTab === tab.id}
                                icon={tab.icon}
                                label={tab.label}
                                onClick={setActiveTab}
                            />
                        ))}
                    </div>
                </div>

                {/* Content */}
                <div className="col-span-9 space-y-6">

                    {/* ── PROFILE TAB ── */}
                    {activeTab === 'profile' && (
                        <>
                            <SectionCard title="Business Information">
                                <div className="space-y-4">
                                    <div>
                                        <label className="text-sm font-medium text-slate-300 block mb-2">Business Name</label>
                                        <input
                                            type="text"
                                            value={settings.business_name || ''}
                                            onChange={e => update('business_name', e.target.value)}
                                            placeholder="Your Store Name"
                                            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-300 block mb-2">Notification Email</label>
                                        <input
                                            type="email"
                                            value={settings.notification_email || ''}
                                            onChange={e => update('notification_email', e.target.value)}
                                            placeholder="you@yourdomain.com"
                                            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                                        />
                                        <p className="text-xs text-slate-500 mt-1.5">Alert emails (low balance, cancellations) go to this address</p>
                                    </div>
                                </div>
                            </SectionCard>

                            <SectionCard title="Order Filtering">
                                <NumberInput
                                    label="Minimum Order Amount"
                                    description="Orders below this value will be skipped for verification"
                                    value={settings.min_order_amount}
                                    onChange={(v: number) => update('min_order_amount', v)}
                                    min={0}
                                    suffix="₹"
                                />
                            </SectionCard>
                        </>
                    )}

                    {/* ── VERIFICATION TAB ── */}
                    {activeTab === 'verification' && (
                        <>
                            <SectionCard title="Message Timing">
                                <NumberInput
                                    label="Message Delay"
                                    description="Wait before sending the first verification message"
                                    value={settings.message_delay_seconds}
                                    onChange={(v: number) => update('message_delay_seconds', v)}
                                    min={0}
                                    max={3600}
                                    suffix="seconds"
                                />
                            </SectionCard>

                            <SectionCard title="Working Hours">
                                <Toggle
                                    checked={settings.working_hours_enabled || false}
                                    onChange={(v: boolean) => update('working_hours_enabled', v)}
                                    label="Enable Working Hours"
                                    description="Only send verification messages during business hours"
                                />
                                {settings.working_hours_enabled && (
                                    <div className="grid grid-cols-2 gap-4 mt-4">
                                        <div>
                                            <label className="text-xs font-medium text-slate-400 block mb-2">Start Time</label>
                                            <input
                                                type="time"
                                                value={settings.working_hours_start || '09:00'}
                                                onChange={e => update('working_hours_start', e.target.value)}
                                                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500"
                                            />
                                        </div>
                                        <div>
                                            <label className="text-xs font-medium text-slate-400 block mb-2">End Time</label>
                                            <input
                                                type="time"
                                                value={settings.working_hours_end || '21:00'}
                                                onChange={e => update('working_hours_end', e.target.value)}
                                                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500"
                                            />
                                        </div>
                                    </div>
                                )}
                            </SectionCard>

                            <SectionCard title="Retry Configuration">
                                <NumberInput
                                    label="Maximum Retries"
                                    description="How many times to retry if customer doesn't respond"
                                    value={settings.max_retries}
                                    onChange={(v: number) => update('max_retries', v)}
                                    min={1}
                                    max={5}
                                    suffix="attempts"
                                />
                                <NumberInput
                                    label="Retry Interval"
                                    description="Wait between retry attempts"
                                    value={settings.retry_interval_hours}
                                    onChange={(v: number) => update('retry_interval_hours', v)}
                                    min={1}
                                    max={24}
                                    suffix="hours"
                                />
                                <NumberInput
                                    label="No-Reply Timeout"
                                    description="Consider order expired after this time with no reply"
                                    value={settings.no_reply_timeout_hours}
                                    onChange={(v: number) => update('no_reply_timeout_hours', v)}
                                    min={1}
                                    max={48}
                                    suffix="hours"
                                />
                            </SectionCard>

                            <SectionCard title="Auto-Actions">
                                <Toggle
                                    checked={settings.auto_cancel_on_no || false}
                                    onChange={(v: boolean) => update('auto_cancel_on_no', v)}
                                    label="Auto-Cancel on Rejection"
                                    description="Automatically cancel order when customer replies 'No'"
                                />
                                <Toggle
                                    checked={settings.auto_cancel_on_no_reply || false}
                                    onChange={(v: boolean) => update('auto_cancel_on_no_reply', v)}
                                    label="Auto-Cancel on No Reply"
                                    description="Cancel orders where customer never responded within timeout period"
                                />
                                <Toggle
                                    checked={settings.send_delivery_updates || false}
                                    onChange={(v: boolean) => update('send_delivery_updates', v)}
                                    label="Send Delivery Updates"
                                    description="Notify customers when their order is shipped and delivered"
                                />
                            </SectionCard>
                        </>
                    )}

                    {/* ── MESSAGES TAB ── */}
                    {activeTab === 'messages' && (
                        <SectionCard title="Message Type Controls">
                            <p className="text-xs text-slate-400 mb-4">Choose which types of messages are sent to your customers via WhatsApp</p>
                            <Toggle
                                checked={settings.enable_verification_msg !== false}
                                onChange={(v: boolean) => update('enable_verification_msg', v)}
                                label="Order Verification Message"
                                description="Ask customer to confirm or cancel their COD order"
                            />
                            <Toggle
                                checked={settings.enable_thankyou_msg !== false}
                                onChange={(v: boolean) => update('enable_thankyou_msg', v)}
                                label="Thank You Message"
                                description="Send a thank you message after order confirmation"
                            />
                            <Toggle
                                checked={settings.enable_cancel_msg !== false}
                                onChange={(v: boolean) => update('enable_cancel_msg', v)}
                                label="Cancellation Confirmation"
                                description="Notify customer when their order is successfully cancelled"
                            />
                            <Toggle
                                checked={settings.enable_delivery_updates_msg !== false}
                                onChange={(v: boolean) => update('enable_delivery_updates_msg', v)}
                                label="Delivery Status Updates"
                                description="Send shipping and delivery notifications"
                            />
                            <Toggle
                                checked={settings.enable_no_reply_reminder !== false}
                                onChange={(v: boolean) => update('enable_no_reply_reminder', v)}
                                label="No-Reply Reminder"
                                description="Send a reminder to customers who haven't responded"
                            />
                        </SectionCard>
                    )}

                    {/* ── NOTIFICATIONS TAB ── */}
                    {activeTab === 'notifications' && (
                        <SectionCard title="Email Notifications">
                            <p className="text-xs text-slate-400 mb-4">Control which events trigger an email to your notification address</p>
                            <Toggle
                                checked={settings.notification_on_cancel || false}
                                onChange={(v: boolean) => update('notification_on_cancel', v)}
                                label="Order Cancellation Alert"
                                description="Get notified when a customer cancels their COD order"
                            />
                            <Toggle
                                checked={settings.notification_daily_summary || false}
                                onChange={(v: boolean) => update('notification_daily_summary', v)}
                                label="Daily Summary Report"
                                description="Receive a daily email with your verification performance metrics"
                            />
                            <Toggle
                                checked={settings.notification_quota_warning || false}
                                onChange={(v: boolean) => update('notification_quota_warning', v)}
                                label="Low Quota Warning"
                                description="Alert when you've used 80% of your monthly verification quota"
                            />
                        </SectionCard>
                    )}

                    {/* ── WEBHOOK TAB ── */}
                    {activeTab === 'webhook' && (
                        <SectionCard title="Webhook Configuration">
                            <p className="text-xs text-slate-400 mb-4">CODVerify will send POST requests to this URL when order statuses change</p>
                            <div>
                                <label className="text-sm font-medium text-slate-300 block mb-2">Callback URL</label>
                                <input
                                    type="url"
                                    value={settings.webhook_callback_url || ''}
                                    onChange={e => update('webhook_callback_url', e.target.value)}
                                    placeholder="https://yourstore.com/codverify/webhook"
                                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono text-sm transition-colors"
                                />
                                <p className="text-xs text-slate-500 mt-2">
                                    Payload: <code className="text-indigo-400">{'{ order_id, status, customer_phone, timestamp }'}</code>
                                </p>
                            </div>

                            <div className="mt-6 p-4 bg-indigo-950/50 border border-indigo-500/20 rounded-xl">
                                <div className="flex items-center gap-2 mb-2">
                                    <Globe size={14} className="text-indigo-400" />
                                    <span className="text-xs font-bold text-indigo-300">Webhook Events</span>
                                </div>
                                <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
                                    {['order.confirmed', 'order.cancelled', 'order.pending', 'order.no_reply'].map(e => (
                                        <div key={e} className="flex items-center gap-1.5">
                                            <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                                            <code className="text-indigo-300">{e}</code>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </SectionCard>
                    )}

                </div>
            </div>
        </div>
    );
}

import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { merchantApi } from '../../api';
import { formatCurrency } from '../../lib/utils';
import { ShoppingCart, CheckCircle, XCircle, Clock, TrendingUp, TrendingDown, Zap, BarChart3, Lock, FileText, ArrowRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function MerchantDashboard() {
    const [stats, setStats] = useState<any>(null);
    const [chart, setChart] = useState<any[]>([]);
    const [period, setPeriod] = useState('7d');
    const [loading, setLoading] = useState(true);
    const [contractStatus, setContractStatus] = useState<string | null>(null);
    const navigate = useNavigate();

    useEffect(() => {
        // Check contract status first
        merchantApi.getActiveContract().then(res => {
            const d = res.data?.data;
            if (!d?.has_contract || !d?.contract) {
                setContractStatus('none');
                setLoading(false);
                return;
            }
            const status = d.contract.status;
            setContractStatus(status);
            if (status === 'pending') {
                // Redirect to contract page to accept & pay
                navigate('/dashboard/contract');
                return;
            }
            // Only load dashboard stats if contract is active
            if (status === 'active') {
                Promise.all([merchantApi.getDashboardStats(), merchantApi.getChartData(period)])
                    .then(([s, c]) => { setStats(s.data?.data); setChart(c.data?.data || []); })
                    .finally(() => setLoading(false));
            } else {
                setLoading(false);
            }
        }).catch(() => {
            // If contract check fails, still load dashboard (backwards compatibility)
            Promise.all([merchantApi.getDashboardStats(), merchantApi.getChartData(period)])
                .then(([s, c]) => { setStats(s.data?.data); setChart(c.data?.data || []); })
                .finally(() => setLoading(false));
        });
    }, [period]);


    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Analyzing store metrics...</p>
        </div>
    );

    // ── LOCKED DASHBOARD — No active contract ────────────────────────
    if (contractStatus === 'none' || contractStatus === 'expired' || contractStatus === 'cancelled') {
        return (
            <div className="max-w-2xl mx-auto text-center py-16 sm:py-24">
                <Helmet><title>Dashboard - CODVerify</title></Helmet>
                <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}
                    className="glass-card rounded-[32px] p-8 sm:p-12 border border-gray-100 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-10 opacity-5">
                        <Lock className="w-32 h-32" />
                    </div>
                    <div className="relative z-10">
                        <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                            <Lock className="w-10 h-10 text-gray-300" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 font-['Outfit'] mb-3">Dashboard Locked</h2>
                        <p className="text-gray-400 font-medium text-sm max-w-sm mx-auto mb-8 leading-relaxed">
                            {contractStatus === 'none'
                                ? 'Your account is pending activation. Our representative will contact you shortly to set up your personalized plan.'
                                : 'Your contract has expired. Contact us to renew your plan and regain access to your dashboard.'}
                        </p>
                        <Link to="/dashboard/contract"
                            className="inline-flex items-center gap-2 px-8 py-3.5 bg-indigo-600 text-white rounded-[20px] font-bold text-sm shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all group">
                            <FileText className="w-4 h-4" />
                            View My Contract
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Link>
                    </div>
                </motion.div>
            </div>
        );
    }

    const t = stats?.today || {};
    const q = stats?.quota || {};
    const quotaPct = q.total > 0 ? Math.round((q.used / q.total) * 100) : 0;

    const statCards = [
        { label: 'Total Volume', value: t.total || 0, icon: ShoppingCart, color: 'from-indigo-500 to-blue-500', change: stats?.change?.total, shadow: 'shadow-indigo-500/20' },
        { label: 'Confirmed', value: t.confirmed || 0, icon: CheckCircle, color: 'from-emerald-500 to-teal-500', pct: t.confirmed_pct, shadow: 'shadow-emerald-500/20' },
        { label: 'Cancelled', value: t.cancelled || 0, icon: XCircle, color: 'from-rose-500 to-red-500', pct: t.cancelled_pct, shadow: 'shadow-rose-500/20' },
        { label: 'Awaiting', value: t.pending || 0, icon: Clock, color: 'from-amber-500 to-orange-500', shadow: 'shadow-amber-500/20' },
    ];

    return (
        <div className="space-y-8 pb-10">
            <Helmet><title>Dashboard - CODVerify Intelligence</title></Helmet>

            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <Zap className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit']">Intelligence Core</h1>
                        <p className="text-gray-500 text-sm font-medium">Real-time verification metrics and store health</p>
                    </div>
                </div>
            </motion.div>

            {/* Main Stats Grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {statCards.map((s, i) => (
                    <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                        className="glass-card rounded-3xl p-6 border border-white hover:border-indigo-100 transition-all group">
                        <div className="flex items-center justify-between mb-5">
                            <div className={`w-12 h-12 bg-gradient-to-br ${s.color} rounded-2xl flex items-center justify-center shadow-lg ${s.shadow} transform group-hover:scale-110 transition-transform duration-300`}>
                                <s.icon className="w-6 h-6 text-white" />
                            </div>
                            {s.change !== undefined && (
                                <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${s.change >= 0 ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'}`}>
                                    {s.change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                                    {Math.abs(s.change)}%
                                </div>
                            )}
                            {s.pct !== undefined && <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded-md">{s.pct}% rate</span>}
                        </div>
                        <p className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">{s.value}</p>
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1.5">{s.label}</p>
                    </motion.div>
                ))}
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
                {/* Chart Section */}
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4 }}
                    className="lg:col-span-2 glass-card rounded-3xl border border-white p-6 shadow-xl shadow-indigo-500/5">
                    <div className="flex items-center justify-between mb-8">
                        <div className="flex items-center gap-3">
                            <BarChart3 className="w-5 h-5 text-indigo-600" />
                            <h3 className="text-lg font-bold text-gray-900 font-['Outfit']">Conversion Flow</h3>
                        </div>
                        <div className="flex p-1 bg-gray-100 rounded-xl border border-gray-200/50">
                            {['7d', '30d', '90d'].map(p => (
                                <button key={p} onClick={() => setPeriod(p)}
                                    className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${period === p ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:bg-white/50'}`}>{p.toUpperCase()}</button>
                            ))}
                        </div>
                    </div>
                    {chart.length > 0 ? (
                        <div className="h-80 w-full mt-4">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={chart} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                    <defs>
                                        <linearGradient id="colorConfirmed" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                                        </linearGradient>
                                        <linearGradient id="colorCancelled" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                    <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: '#64748b' }} tickFormatter={(v: string) => v.slice(5)} />
                                    <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: '#64748b' }} />
                                    <Tooltip
                                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', fontSize: '12px', fontWeight: 600 }}
                                        itemStyle={{ padding: '2px 0' }}
                                    />
                                    <Area type="monotone" dataKey="confirmed" stroke="#10B981" strokeWidth={3} fillOpacity={1} fill="url(#colorConfirmed)" />
                                    <Area type="monotone" dataKey="cancelled" stroke="#EF4444" strokeWidth={3} fillOpacity={1} fill="url(#colorCancelled)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    ) : (
                        <div className="h-80 flex items-center justify-center flex-col gap-3">
                            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center border border-dashed border-gray-200">
                                <BarChart3 className="w-8 h-8 text-gray-300" />
                            </div>
                            <p className="text-gray-400 text-sm font-medium">No conversion data for this period</p>
                        </div>
                    )}
                </motion.div>

                {/* Right Column: Quota & RTO */}
                <div className="space-y-6">
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}
                        className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-xl shadow-indigo-500/20 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-8 opacity-10 transform group-hover:scale-150 transition-transform duration-700">
                            <TrendingDown className="w-24 h-24" />
                        </div>
                        <div className="relative z-10">
                            <h3 className="text-xs font-bold text-indigo-100 uppercase tracking-widest mb-1">RTO Savings Today</h3>
                            <p className="text-4xl font-bold font-['Outfit'] mb-2">{formatCurrency(stats?.rto_saved || 0)}</p>
                            <p className="text-[10px] text-indigo-200 leading-relaxed max-w-[200px]">Calculated based on verified cancellations and ₹300 average RTO loss prevention.</p>
                            <div className="mt-6 flex gap-2">
                                <span className="px-3 py-1 bg-white/10 rounded-full text-[10px] font-bold">SMART VERIFY</span>
                                <span className="px-3 py-1 bg-white/10 rounded-full text-[10px] font-bold">LOSS PREVENTION</span>
                            </div>
                        </div>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}
                        className="glass-card rounded-3xl p-6 border border-white">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-sm font-bold text-gray-900 uppercase tracking-widest">Efficiency</h3>
                            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">{quotaPct}%</span>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-3 mb-4 overflow-hidden border border-gray-200/50 p-0.5">
                            <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${Math.min(quotaPct, 100)}%` }}
                                transition={{ duration: 1.5, ease: "easeOut" }}
                                className="h-2 rounded-full premium-gradient"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-tighter">Response</p>
                                <p className="text-xl font-bold text-gray-900 font-['Outfit']">{stats?.avg_response_time_minutes || 0}<span className="text-[10px] ml-1 text-gray-400">MIN</span></p>
                            </div>
                            <div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-tighter">No Reply</p>
                                <p className="text-xl font-bold text-gray-900 font-['Outfit']">{t.no_reply || 0}</p>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>

            {/* Bottom Grid for Analytics */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}
                className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {[
                    { label: 'Unreachable', value: t.not_on_whatsapp || 0, icon: Clock, color: 'text-amber-500' },
                    { label: 'Total Success', value: t.confirmed || 0, icon: CheckCircle, color: 'text-emerald-500' },
                    { label: 'Lost Conversion', value: t.cancelled || 0, icon: XCircle, color: 'text-rose-500' },
                    { label: 'Pending Verif.', value: t.pending || 0, icon: Clock, color: 'text-indigo-500' },
                ].map((item, i) => (
                    <div key={i} className="glass-card rounded-2xl p-5 border border-white text-center group hover:bg-indigo-50/10 transition-colors">
                        <item.icon className={`w-6 h-6 mx-auto mb-3 ${item.color} group-hover:scale-110 transition-transform`} />
                        <p className="text-2xl font-bold text-gray-900 font-['Outfit']">{item.value}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">{item.label}</p>
                    </div>
                ))}
            </motion.div>

            {/* Country Breakdown */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.85 }}
                className="glass-card rounded-3xl border border-white p-6 shadow-xl shadow-indigo-500/5">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-indigo-50 rounded-xl">
                        <BarChart3 className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                        <h3 className="text-sm font-bold text-gray-900 uppercase tracking-widest">Country Breakdown</h3>
                        <p className="text-xs text-gray-400 font-medium">Verification traffic by country today</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                    {[
                        { iso: 'IN', flag: '🇮🇳', name: 'India', method: 'WhatsApp', color: 'from-emerald-400 to-green-500', count: stats?.country_breakdown?.IN || 0 },
                        { iso: 'US', flag: '🇺🇸', name: 'USA', method: 'SMS/Voice', color: 'from-blue-400 to-indigo-500', count: stats?.country_breakdown?.US || 0 },
                        { iso: 'PH', flag: '🇵🇭', name: 'Philippines', method: 'SMS/Voice', color: 'from-cyan-400 to-blue-500', count: stats?.country_breakdown?.PH || 0 },
                        { iso: 'MX', flag: '🇲🇽', name: 'Mexico', method: 'SMS/Voz', color: 'from-green-400 to-emerald-500', count: stats?.country_breakdown?.MX || 0 },
                        { iso: 'GB', flag: '🇬🇧', name: 'UK', method: 'SMS/Voice', color: 'from-purple-400 to-pink-500', count: stats?.country_breakdown?.GB || 0 },
                    ].map(c => (
                        <div key={c.iso} className="rounded-2xl bg-gray-50 border border-gray-100 p-4 text-center hover:border-indigo-100 hover:bg-indigo-50/20 transition-all">
                            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center text-xl mx-auto mb-3 shadow-sm`}>
                                {c.flag}
                            </div>
                            <p className="text-2xl font-black text-gray-900 font-['Outfit']">{c.count}</p>
                            <p className="text-xs font-bold text-gray-700 mt-0.5">{c.name}</p>
                            <p className="text-[10px] text-gray-400 font-medium">{c.method}</p>
                        </div>
                    ))}
                </div>
            </motion.div>
        </div>
    );
}

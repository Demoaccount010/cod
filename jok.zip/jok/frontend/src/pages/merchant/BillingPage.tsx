import { Helmet } from 'react-helmet-async';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { merchantApi } from '../../api';
import { FileText, ArrowUpRight, ArrowDownLeft, Clock, History, CheckCircle, Calendar } from 'lucide-react';

export default function BillingPage() {
    const [contract, setContract] = useState<any>(null);
    const [transactions, setTransactions] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        Promise.all([
            merchantApi.getActiveContract().catch(() => null),
            merchantApi.getTransactions('page=1&limit=20'),
        ]).then(([c, t]) => {
            setContract(c?.data?.data?.contract || null);
            setTransactions(t.data?.data?.transactions || []);
        }).finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin shadow-lg shadow-indigo-500/20" />
            <p className="text-gray-400 font-medium animate-pulse">Loading billing info...</p>
        </div>
    );

    const sym = contract?.currency === 'USD' ? '$' : '₹';
    const contractActive = contract?.status === 'active';

    return (
        <div className="max-w-4xl mx-auto space-y-8 pb-10">
            <Helmet><title>Billing - CODVerify</title></Helmet>

            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20">
                        <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Billing</h1>
                        <p className="text-gray-500 text-sm font-medium">Contract details and transaction history</p>
                    </div>
                </div>
            </motion.div>

            {/* Contract Card */}
            {contract ? (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                    className="relative overflow-hidden rounded-[28px] border border-indigo-100 bg-gradient-to-br from-indigo-600 to-violet-700 p-8 text-white shadow-2xl shadow-indigo-500/30">
                    <div className="absolute top-0 right-0 p-10 opacity-10">
                        <FileText className="w-40 h-40" />
                    </div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-4">
                            <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${contractActive ? 'bg-emerald-400/20 border-emerald-300/30 text-emerald-200' : 'bg-amber-400/20 border-amber-300/30 text-amber-200'}`}>
                                {contractActive ? '● Active' : contract.status}
                            </div>
                            <span className="text-indigo-200 text-xs font-medium">{contract.contract_number}</span>
                        </div>

                        <div className="grid sm:grid-cols-2 gap-6">
                            <div>
                                <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-1">Plan Type</p>
                                <p className="text-2xl font-bold font-['Outfit'] capitalize">{contract.type === 'monthly' ? 'Monthly Plan' : 'Service Contract'}</p>
                            </div>
                            <div>
                                <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-1">Contract Value</p>
                                <p className="text-2xl font-bold font-['Outfit']">{sym}{Number(contract.total_amount || 0).toLocaleString('en-IN')}</p>
                            </div>
                        </div>

                        <div className="mt-6 grid sm:grid-cols-3 gap-4">
                            {[
                                { icon: Calendar, label: 'Start Date', value: contract.start_date ? new Date(contract.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—' },
                                { icon: Calendar, label: 'End Date', value: contract.end_date ? new Date(contract.end_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—' },
                                { icon: Clock, label: 'Duration', value: `${contract.duration_months || 1} Month${contract.duration_months > 1 ? 's' : ''}` },
                            ].map((item, i) => (
                                <div key={i} className="bg-white/10 rounded-2xl p-4 border border-white/10">
                                    <item.icon className="w-4 h-4 mb-2 opacity-60" />
                                    <p className="text-[9px] font-bold uppercase tracking-widest text-indigo-200 mb-1">{item.label}</p>
                                    <p className="text-sm font-bold">{item.value}</p>
                                </div>
                            ))}
                        </div>

                        {/* Services */}
                        {contract.services && contract.services.length > 0 && (
                            <div className="mt-6">
                                <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-3">Included Services</p>
                                <div className="flex flex-wrap gap-2">
                                    {contract.services.map((s: any, i: number) => (
                                        <div key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 rounded-xl border border-white/10 text-xs font-semibold">
                                            <CheckCircle className="w-3 h-3 text-emerald-300" />
                                            {typeof s === 'string' ? s : s.name}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </motion.div>
            ) : (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                    className="text-center py-14 bg-white rounded-[28px] border border-gray-100 shadow-sm">
                    <FileText className="w-12 h-12 mx-auto mb-4 text-gray-200" />
                    <p className="text-gray-500 font-semibold">No active contract</p>
                    <p className="text-gray-400 text-sm mt-1">Contact us to set up your service plan.</p>
                </motion.div>
            )}

            {/* Transaction History */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                className="glass-card rounded-[28px] p-8 border border-white shadow-xl shadow-indigo-500/5">
                <div className="flex items-center gap-3 mb-6">
                    <History className="w-5 h-5 text-indigo-600" />
                    <h3 className="text-xl font-bold text-gray-900 font-['Outfit'] tracking-tight">Transaction History</h3>
                </div>

                {transactions.length > 0 ? (
                    <div className="space-y-2">
                        {transactions.map((t: any, i: number) => {
                            const isDebit = t.transaction_type?.includes('debit');
                            const sym2 = t.currency === 'USD' ? '$' : '₹';
                            return (
                                <motion.div key={i} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.05 * i }}
                                    className="flex items-center justify-between p-4 rounded-2xl hover:bg-gray-50 border border-transparent hover:border-gray-100 transition-all group">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-sm ${isDebit ? 'bg-rose-50 text-rose-500' : 'bg-emerald-50 text-emerald-600'}`}>
                                            {isDebit ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900 font-['Outfit'] tracking-tight">
                                                {t.description || (isDebit ? 'Deduction' : 'Credit')}
                                            </p>
                                            <div className="flex items-center gap-1.5 mt-0.5">
                                                <Clock className="w-3 h-3 text-gray-300" />
                                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                                    {new Date(t.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className={`text-sm font-extrabold font-['Outfit'] ${isDebit ? 'text-gray-800' : 'text-emerald-600'}`}>
                                            {isDebit ? '-' : '+'}{sym2}{Number(t.amount).toFixed(2)}
                                        </p>
                                        <p className="text-[9px] font-bold text-gray-300 uppercase tracking-tighter">
                                            {t.status || 'completed'}
                                        </p>
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="py-16 text-center flex flex-col items-center gap-4">
                        <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center border border-dashed border-gray-200">
                            <History className="w-8 h-8 text-gray-300" />
                        </div>
                        <p className="text-gray-400 text-sm font-medium">No transactions yet</p>
                    </div>
                )}
            </motion.div>
        </div>
    );
}


import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { merchantApi } from '../../api';
import { timeAgo } from '../../lib/utils';
import {
    ArrowLeft, Package, User, MapPin, Truck, MessageCircle,
    CheckCircle, XCircle, RefreshCw, Clock, ExternalLink, AlertTriangle,
    ShoppingBag, Mail, Phone, Globe, FileText, Shield, Send, Pencil, Save, X
} from 'lucide-react';

const STATUS_CONFIG: Record<string, { color: string; label: string; icon: any }> = {
    pending: { color: 'bg-slate-100 text-slate-700', label: 'Processing', icon: Clock },
    queued: { color: 'bg-blue-50 text-blue-600', label: 'Queued', icon: Send },
    sent: { color: 'bg-indigo-50 text-indigo-600', label: 'Sent', icon: Send },
    delivered: { color: 'bg-sky-50 text-sky-600', label: 'Delivered', icon: CheckCircle },
    read: { color: 'bg-cyan-50 text-cyan-600', label: 'Read', icon: CheckCircle },
    confirmed: { color: 'bg-emerald-50 text-emerald-600', label: 'Confirmed', icon: CheckCircle },
    cancelled: { color: 'bg-rose-50 text-rose-600', label: 'Cancelled', icon: XCircle },
    no_reply: { color: 'bg-amber-50 text-amber-600', label: 'No Reply', icon: Clock },
    failed: { color: 'bg-red-50 text-red-600', label: 'Failed', icon: XCircle },
    not_on_whatsapp: { color: 'bg-orange-50 text-orange-600', label: 'No WhatsApp', icon: AlertTriangle },
    not_required: { color: 'bg-gray-50 text-gray-500', label: 'Not Required', icon: CheckCircle },
    manual_confirmed: { color: 'bg-green-50 text-green-700', label: 'Manual OK', icon: CheckCircle },
    manual_cancelled: { color: 'bg-red-50 text-red-700', label: 'Manual Cancel', icon: XCircle },
    insufficient_balance: { color: 'bg-orange-50 text-orange-600', label: 'Low Balance', icon: AlertTriangle },
};

const DELIVERY_STATUS: Record<string, { color: string; label: string }> = {
    pending: { color: 'text-gray-500', label: 'Pending' },
    shipped: { color: 'text-blue-600', label: 'Shipped' },
    in_transit: { color: 'text-indigo-600', label: 'In Transit' },
    out_for_delivery: { color: 'text-amber-600', label: 'Out for Delivery' },
    delivered: { color: 'text-emerald-600', label: 'Delivered' },
    returned: { color: 'text-red-600', label: 'Returned' },
};

export default function OrderDetailPage() {
    const { orderId } = useParams<{ orderId: string }>();
    const navigate = useNavigate();
    const [order, setOrder] = useState<any>(null);
    const [messages, setMessages] = useState<any[]>([]);
    const [customerHistory, setCustomerHistory] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState('');
    const [manualNote, setManualNote] = useState('');
    const [showManualAction, setShowManualAction] = useState(false);
    const [showEdit, setShowEdit] = useState(false);
    const [editData, setEditData] = useState<any>({});
    const [editLoading, setEditLoading] = useState(false);

    useEffect(() => {
        if (!orderId) return;
        setLoading(true);
        merchantApi.getOrder(orderId)
            .then(res => {
                const data = res.data?.data || res.data;
                setOrder(data.order || null);
                setMessages(data.messages || []);
                setCustomerHistory(data.customer_history || null);
            })
            .catch(() => navigate('/dashboard/orders'))
            .finally(() => setLoading(false));
    }, [orderId]);

    const handleResend = async () => {
        if (!orderId) return;
        setActionLoading('resend');
        try {
            await merchantApi.resendOrder(orderId);
            const res = await merchantApi.getOrder(orderId);
            const data = res.data?.data || res.data;
            setOrder(data.order);
        } catch { }
        setActionLoading('');
    };

    const handleManualUpdate = async (status: 'confirmed' | 'cancelled') => {
        if (!orderId) return;
        setActionLoading(status);
        try {
            await merchantApi.manualUpdate(orderId, { status, note: manualNote });
            const res = await merchantApi.getOrder(orderId);
            const data = res.data?.data || res.data;
            setOrder(data.order);
            setShowManualAction(false);
            setManualNote('');
        } catch { }
        setActionLoading('');
    };

    const openEdit = () => {
        const addr = order.shipping_address_json || {};
        setEditData({
            customer_name: order.customer_name || '',
            customer_phone: order.customer_phone || '',
            customer_email: order.customer_email || '',
            order_amount: order.order_amount || 0,
            order_type: order.order_type || 'cod',
            payment_method: order.payment_method || '',
            delivery_status: order.delivery_status || 'pending',
            tracking_number: order.tracking_number || '',
            tracking_company: order.tracking_company || '',
            tracking_url: order.tracking_url || '',
            notes: order.notes || '',
            tags: order.tags || '',
            addr_line1: addr.line1 || '',
            addr_line2: addr.line2 || '',
            addr_city: addr.city || '',
            addr_state: addr.state || '',
            addr_pincode: addr.pincode || '',
            addr_country: addr.country || '',
        });
        setShowEdit(true);
    };

    const handleEditSave = async () => {
        if (!orderId) return;
        setEditLoading(true);
        try {
            const payload: any = {};
            const fields = ['customer_name', 'customer_phone', 'customer_email', 'order_amount', 'order_type', 'payment_method', 'delivery_status', 'tracking_number', 'tracking_company', 'tracking_url', 'notes', 'tags'];
            for (const f of fields) {
                if (editData[f] !== undefined && editData[f] !== '') {
                    payload[f] = f === 'order_amount' ? parseFloat(editData[f]) : editData[f];
                }
            }
            if (editData.addr_line1 || editData.addr_city) {
                payload.shipping_address_json = {
                    line1: editData.addr_line1 || '',
                    line2: editData.addr_line2 || '',
                    city: editData.addr_city || '',
                    state: editData.addr_state || '',
                    pincode: editData.addr_pincode || '',
                    country: editData.addr_country || '',
                };
            }
            await merchantApi.editOrder(orderId, payload);
            const res = await merchantApi.getOrder(orderId);
            const data = res.data?.data || res.data;
            setOrder(data.order);
            setShowEdit(false);
        } catch { }
        setEditLoading(false);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-96 gap-4">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400 font-medium animate-pulse">Loading order details...</p>
        </div>
    );

    if (!order) return null;

    const products = order.products_json || [];
    const address = order.shipping_address_json || {};
    const statusCfg = STATUS_CONFIG[order.verification_status] || STATUS_CONFIG.pending;
    const StatusIcon = statusCfg.icon;
    const deliveryCfg = DELIVERY_STATUS[order.delivery_status] || DELIVERY_STATUS.pending;
    const isCod = order.order_type === 'cod';
    const currSym = order.currency === 'USD' ? '$' : '₹';
    const canResend = !['confirmed', 'cancelled', 'manual_confirmed', 'manual_cancelled', 'not_required'].includes(order.verification_status);
    const canManual = !['manual_confirmed', 'manual_cancelled', 'not_required'].includes(order.verification_status);

    return (
        <div className="space-y-6 pb-10 max-w-5xl mx-auto">
            <Helmet><title>Order #{order.order_number} - CODVerify</title></Helmet>

            {/* Header */}
            <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <button onClick={() => navigate('/dashboard/orders')} className="p-2.5 rounded-xl border border-gray-200 hover:bg-gray-50 transition-all">
                        <ArrowLeft className="w-5 h-5 text-gray-600" />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 font-['Outfit']">Order #{order.order_number || order.store_order_id}</h1>
                        <p className="text-sm text-gray-500 mt-0.5">Created {timeAgo(order.created_at)}</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={openEdit}
                        className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-bold text-gray-700 hover:bg-gray-50 transition-all">
                        <Pencil className="w-4 h-4" /> Edit Order
                    </button>
                    <span className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider ${isCod ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                        {order.order_type || 'cod'}
                    </span>
                    <span className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${statusCfg.color}`}>
                        <StatusIcon className="w-3.5 h-3.5" /> {statusCfg.label}
                    </span>
                </div>
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Left Column — Main Info */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Customer Info */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><User className="w-4 h-4" /> Customer</h3>
                        <div className="grid sm:grid-cols-2 gap-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center"><User className="w-5 h-5 text-indigo-500" /></div>
                                <div>
                                    <p className="text-sm font-bold text-gray-900">{order.customer_name}</p>
                                    <p className="text-xs text-gray-400">Customer Name</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center"><Phone className="w-5 h-5 text-green-500" /></div>
                                <div>
                                    <p className="text-sm font-bold text-gray-900">{order.customer_phone}</p>
                                    <p className="text-xs text-gray-400">Phone ({order.customer_phone_normalized?.startsWith('+91') ? '🇮🇳 India' : '🌍 International'})</p>
                                </div>
                            </div>
                            {order.customer_email && (
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center"><Mail className="w-5 h-5 text-blue-500" /></div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-900">{order.customer_email}</p>
                                        <p className="text-xs text-gray-400">Email</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </motion.div>

                    {/* Products */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> Products</h3>
                        {products.length > 0 ? (
                            <div className="space-y-3">
                                {products.map((p: any, i: number) => (
                                    <div key={i} className="flex items-center gap-4 p-3 bg-gray-50/50 rounded-xl">
                                        {p.image_url ? (
                                            <img src={p.image_url} alt={p.name} className="w-12 h-12 rounded-lg object-cover border border-gray-100" />
                                        ) : (
                                            <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center"><Package className="w-5 h-5 text-gray-400" /></div>
                                        )}
                                        <div className="flex-1">
                                            <p className="text-sm font-bold text-gray-900">{p.name}</p>
                                            <p className="text-xs text-gray-400">Qty: {p.quantity}</p>
                                        </div>
                                        <p className="text-sm font-bold text-gray-900">{currSym}{p.price?.toLocaleString('en-IN')}</p>
                                    </div>
                                ))}
                                <div className="flex justify-between pt-3 border-t border-gray-100 mt-3">
                                    <span className="text-sm font-bold text-gray-500">Total</span>
                                    <span className="text-lg font-bold text-gray-900">{currSym}{order.order_amount?.toLocaleString('en-IN')}</span>
                                </div>
                            </div>
                        ) : (
                            <p className="text-sm text-gray-400">{currSym}{order.order_amount?.toLocaleString('en-IN')} — No item details available</p>
                        )}
                    </motion.div>

                    {/* Shipping Address */}
                    {(address.line1 || address.city) && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                            className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><MapPin className="w-4 h-4" /> Shipping Address</h3>
                            <div className="space-y-1 text-sm text-gray-700">
                                {address.line1 && <p className="font-medium">{address.line1}</p>}
                                {address.line2 && <p>{address.line2}</p>}
                                <p>{[address.city, address.state, address.pincode].filter(Boolean).join(', ')}</p>
                                {address.country && <p className="text-gray-400">{address.country}</p>}
                            </div>
                        </motion.div>
                    )}

                    {/* Tracking & Delivery */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><Truck className="w-4 h-4" /> Tracking & Delivery</h3>
                        <div className="grid sm:grid-cols-2 gap-4">
                            <div>
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Delivery Status</p>
                                <p className={`text-sm font-bold ${deliveryCfg.color}`}>{deliveryCfg.label}</p>
                            </div>
                            <div>
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Fulfillment</p>
                                <p className="text-sm font-bold text-gray-700 capitalize">{order.fulfillment_status || 'Unfulfilled'}</p>
                            </div>
                            {order.tracking_number && (
                                <div>
                                    <p className="text-xs text-gray-400 font-bold uppercase mb-1">Tracking Number</p>
                                    <p className="text-sm font-bold text-gray-900 font-mono">{order.tracking_number}</p>
                                </div>
                            )}
                            {order.tracking_company && (
                                <div>
                                    <p className="text-xs text-gray-400 font-bold uppercase mb-1">Carrier</p>
                                    <p className="text-sm font-bold text-gray-700">{order.tracking_company}</p>
                                </div>
                            )}
                            {order.tracking_url && (
                                <div className="sm:col-span-2">
                                    <a href={order.tracking_url} target="_blank" rel="noopener noreferrer"
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-sm font-bold hover:bg-indigo-100 transition-all">
                                        <ExternalLink className="w-4 h-4" /> Track Package
                                    </a>
                                </div>
                            )}
                            {!order.tracking_number && (
                                <p className="text-sm text-gray-400 sm:col-span-2">No tracking info yet. It will appear once the order is fulfilled in Shopify.</p>
                            )}
                        </div>
                    </motion.div>

                    {/* WhatsApp Messages */}
                    {messages.length > 0 && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                            className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><MessageCircle className="w-4 h-4" /> WhatsApp Messages</h3>
                            <div className="space-y-3">
                                {messages.map((m: any) => (
                                    <div key={m.id} className={`flex ${m.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${m.direction === 'outbound' ? 'bg-indigo-50 text-indigo-900' : 'bg-green-50 text-green-900'}`}>
                                            <p className="whitespace-pre-wrap">{m.content}</p>
                                            <div className="flex items-center justify-between mt-2 gap-3">
                                                <span className="text-[10px] text-gray-400">{timeAgo(m.created_at)}</span>
                                                <span className={`text-[10px] font-bold uppercase ${m.status === 'delivered' || m.status === 'read' ? 'text-green-500' : m.status === 'failed' ? 'text-red-500' : 'text-gray-400'}`}>
                                                    {m.status}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </div>

                {/* Right Column — Sidebar */}
                <div className="space-y-6">
                    {/* Actions */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Actions</h3>
                        <div className="space-y-3">
                            {canResend && (
                                <button onClick={handleResend} disabled={!!actionLoading}
                                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-50">
                                    <RefreshCw className={`w-4 h-4 ${actionLoading === 'resend' ? 'animate-spin' : ''}`} />
                                    {actionLoading === 'resend' ? 'Resending...' : 'Resend Verification'}
                                </button>
                            )}
                            {canManual && !showManualAction && (
                                <button onClick={() => setShowManualAction(true)}
                                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-200 transition-all">
                                    <FileText className="w-4 h-4" /> Manual Update
                                </button>
                            )}
                            {showManualAction && (
                                <div className="space-y-3 p-4 bg-gray-50 rounded-xl">
                                    <textarea value={manualNote} onChange={e => setManualNote(e.target.value)}
                                        placeholder="Add a note (optional)..."
                                        className="w-full p-3 border border-gray-200 rounded-xl text-sm resize-none h-20 focus:ring-2 focus:ring-indigo-500 outline-none" />
                                    <div className="flex gap-2">
                                        <button onClick={() => handleManualUpdate('confirmed')} disabled={!!actionLoading}
                                            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 disabled:opacity-50">
                                            <CheckCircle className="w-3.5 h-3.5" /> {actionLoading === 'confirmed' ? '...' : 'Confirm'}
                                        </button>
                                        <button onClick={() => handleManualUpdate('cancelled')} disabled={!!actionLoading}
                                            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 disabled:opacity-50">
                                            <XCircle className="w-3.5 h-3.5" /> {actionLoading === 'cancelled' ? '...' : 'Cancel'}
                                        </button>
                                    </div>
                                    <button onClick={() => setShowManualAction(false)} className="w-full text-xs text-gray-400 hover:text-gray-600 py-1">
                                        Close
                                    </button>
                                </div>
                            )}
                        </div>
                    </motion.div>

                    {/* Order Details */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Details</h3>
                        <div className="space-y-3">
                            <DetailRow label="Order Type" value={<span className={`text-xs font-bold uppercase px-2 py-0.5 rounded-lg ${isCod ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'}`}>{order.order_type || 'cod'}</span>} />
                            <DetailRow label="Payment" value={order.payment_method} />
                            <DetailRow label="Payment Status" value={<span className={`text-xs font-bold capitalize ${order.payment_status === 'paid' ? 'text-emerald-600' : 'text-amber-600'}`}>{order.payment_status}</span>} />
                            <DetailRow label="Source" value={<span className="capitalize">{order.source}</span>} />
                            <DetailRow label="Store Order ID" value={<span className="font-mono text-xs">{order.store_order_id}</span>} />
                            {order.verification_channel && <DetailRow label="Channel" value={order.verification_channel} />}
                            {order.verification_sent_at && <DetailRow label="Verification Sent" value={timeAgo(order.verification_sent_at)} />}
                            {order.response_received_at && <DetailRow label="Response At" value={timeAgo(order.response_received_at)} />}
                            {order.customer_response && <DetailRow label="Customer Response" value={<span className={`font-bold capitalize ${order.customer_response === 'confirmed' ? 'text-emerald-600' : 'text-rose-600'}`}>{order.customer_response}</span>} />}
                        </div>
                    </motion.div>

                    {/* Risk Score */}
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><Shield className="w-4 h-4" /> Risk Analysis</h3>
                        <div className="flex items-center gap-4 mb-4">
                            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-xl font-bold ${order.risk_score > 60 ? 'bg-red-50 text-red-600' : order.risk_score > 30 ? 'bg-amber-50 text-amber-600' : 'bg-green-50 text-green-600'}`}>
                                {order.risk_score || 0}
                            </div>
                            <div>
                                <p className={`text-sm font-bold ${order.risk_score > 60 ? 'text-red-600' : order.risk_score > 30 ? 'text-amber-600' : 'text-green-600'}`}>
                                    {order.risk_score > 60 ? 'High Risk' : order.risk_score > 30 ? 'Medium Risk' : 'Low Risk'}
                                </p>
                                <p className="text-xs text-gray-400">Risk assessment score</p>
                            </div>
                        </div>
                        {order.risk_factors_json && Object.keys(order.risk_factors_json).length > 0 && (
                            <div className="space-y-2">
                                {Object.entries(order.risk_factors_json).map(([key, val]: [string, any]) => (
                                    <div key={key} className="flex justify-between text-xs">
                                        <span className="text-gray-500 capitalize">{key.replace(/_/g, ' ')}</span>
                                        <span className="font-bold text-gray-700">{typeof val === 'number' ? `+${val}` : String(val)}</span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </motion.div>

                    {/* Customer History */}
                    {customerHistory && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
                            className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2"><Globe className="w-4 h-4" /> Customer History</h3>
                            <div className="space-y-3">
                                <DetailRow label="Total Orders" value={customerHistory.total_orders} />
                                <DetailRow label="Lifetime Value" value={`${currSym}${Number(customerHistory.total_order_value || 0).toLocaleString('en-IN')}`} />
                                <DetailRow label="First Order" value={customerHistory.first_order_date ? timeAgo(customerHistory.first_order_date) : '—'} />
                                <DetailRow label="Last Order" value={customerHistory.last_order_date ? timeAgo(customerHistory.last_order_date) : '—'} />
                                {customerHistory.is_globally_blacklisted && (
                                    <p className="text-xs font-bold text-red-600 bg-red-50 px-3 py-2 rounded-lg">⚠️ Globally Blacklisted</p>
                                )}
                            </div>
                        </motion.div>
                    )}

                    {/* Notes & Tags */}
                    {(order.notes || order.tags) && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                            className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Notes & Tags</h3>
                            {order.tags && (
                                <div className="flex flex-wrap gap-1.5 mb-3">
                                    {order.tags.split(',').map((t: string, i: number) => (
                                        <span key={i} className="px-2 py-1 bg-gray-100 text-gray-600 rounded-lg text-[10px] font-bold">{t.trim()}</span>
                                    ))}
                                </div>
                            )}
                            {order.notes && <p className="text-sm text-gray-600 whitespace-pre-wrap">{order.notes}</p>}
                        </motion.div>
                    )}
                </div>
            </div>

            {/* Edit Order Modal */}
            {showEdit && (
                <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-start justify-center pt-10 px-4 overflow-y-auto">
                    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mb-10">
                        <div className="flex items-center justify-between p-6 border-b border-gray-100">
                            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2"><Pencil className="w-5 h-5 text-indigo-500" /> Edit Order #{order.order_number}</h2>
                            <button onClick={() => setShowEdit(false)} className="p-2 rounded-xl hover:bg-gray-100 transition-all"><X className="w-5 h-5 text-gray-400" /></button>
                        </div>
                        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
                            {/* Customer Info */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Customer Information</h4>
                                <div className="grid sm:grid-cols-2 gap-3">
                                    <EditField label="Name" value={editData.customer_name} onChange={v => setEditData({ ...editData, customer_name: v })} />
                                    <EditField label="Phone" value={editData.customer_phone} onChange={v => setEditData({ ...editData, customer_phone: v })} />
                                    <EditField label="Email" value={editData.customer_email} onChange={v => setEditData({ ...editData, customer_email: v })} className="sm:col-span-2" />
                                </div>
                            </div>
                            {/* Order Info */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Order Information</h4>
                                <div className="grid sm:grid-cols-2 gap-3">
                                    <EditField label="Amount" value={editData.order_amount} onChange={v => setEditData({ ...editData, order_amount: v })} type="number" />
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Order Type</label>
                                        <select value={editData.order_type} onChange={e => setEditData({ ...editData, order_type: e.target.value })}
                                            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                                            <option value="cod">COD</option>
                                            <option value="prepaid">Prepaid</option>
                                        </select>
                                    </div>
                                    <EditField label="Payment Method" value={editData.payment_method} onChange={v => setEditData({ ...editData, payment_method: v })} />
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Delivery Status</label>
                                        <select value={editData.delivery_status} onChange={e => setEditData({ ...editData, delivery_status: e.target.value })}
                                            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                                            <option value="pending">Pending</option>
                                            <option value="shipped">Shipped</option>
                                            <option value="in_transit">In Transit</option>
                                            <option value="out_for_delivery">Out for Delivery</option>
                                            <option value="delivered">Delivered</option>
                                            <option value="returned">Returned</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            {/* Tracking */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Tracking</h4>
                                <div className="grid sm:grid-cols-2 gap-3">
                                    <EditField label="Tracking Number" value={editData.tracking_number} onChange={v => setEditData({ ...editData, tracking_number: v })} />
                                    <EditField label="Tracking Company" value={editData.tracking_company} onChange={v => setEditData({ ...editData, tracking_company: v })} />
                                    <EditField label="Tracking URL" value={editData.tracking_url} onChange={v => setEditData({ ...editData, tracking_url: v })} className="sm:col-span-2" />
                                </div>
                            </div>
                            {/* Shipping Address */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Shipping Address</h4>
                                <div className="grid sm:grid-cols-2 gap-3">
                                    <EditField label="Address Line 1" value={editData.addr_line1} onChange={v => setEditData({ ...editData, addr_line1: v })} className="sm:col-span-2" />
                                    <EditField label="Address Line 2" value={editData.addr_line2} onChange={v => setEditData({ ...editData, addr_line2: v })} className="sm:col-span-2" />
                                    <EditField label="City" value={editData.addr_city} onChange={v => setEditData({ ...editData, addr_city: v })} />
                                    <EditField label="State" value={editData.addr_state} onChange={v => setEditData({ ...editData, addr_state: v })} />
                                    <EditField label="Pincode" value={editData.addr_pincode} onChange={v => setEditData({ ...editData, addr_pincode: v })} />
                                    <EditField label="Country" value={editData.addr_country} onChange={v => setEditData({ ...editData, addr_country: v })} />
                                </div>
                            </div>
                            {/* Notes & Tags */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Notes & Tags</h4>
                                <div className="space-y-3">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Tags</label>
                                        <input value={editData.tags} onChange={e => setEditData({ ...editData, tags: e.target.value })}
                                            placeholder="tag1, tag2, tag3"
                                            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Notes</label>
                                        <textarea value={editData.notes} onChange={e => setEditData({ ...editData, notes: e.target.value })}
                                            rows={3} placeholder="Order notes..."
                                            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none resize-none" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-100">
                            <button onClick={() => setShowEdit(false)}
                                className="px-5 py-2.5 rounded-xl text-sm font-bold text-gray-500 hover:bg-gray-100 transition-all">Cancel</button>
                            <button onClick={handleEditSave} disabled={editLoading}
                                className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-50">
                                <Save className="w-4 h-4" /> {editLoading ? 'Saving...' : 'Save Changes'}
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
}

function DetailRow({ label, value }: { label: string; value: any }) {
    return (
        <div className="flex justify-between items-center py-1.5 border-b border-gray-50 last:border-0">
            <span className="text-xs text-gray-400 font-medium">{label}</span>
            <span className="text-sm font-bold text-gray-700">{value}</span>
        </div>
    );
}

function EditField({ label, value, onChange, type = 'text', className = '' }: { label: string; value: string; onChange: (v: string) => void; type?: string; className?: string }) {
    return (
        <div className={className}>
            <label className="block text-xs font-bold text-gray-500 mb-1">{label}</label>
            <input type={type} value={value} onChange={e => onChange(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
        </div>
    );
}

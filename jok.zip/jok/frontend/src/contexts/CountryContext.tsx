import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

// ── Types ─────────────────────────────────────────────────────────────────────

export type SupportedCountryISO = 'IN' | 'US' | 'PH' | 'MX' | 'GB' | 'OTHER';

export interface CountryInfo {
    country: SupportedCountryISO;
    countryName: string;
    currency: 'INR' | 'USD';
    symbol: '₹' | '$';
    detected: boolean;
    loading: boolean;
    /** Verification methods available in this country */
    methods: {
        whatsapp: boolean;
        sms: boolean;
        voice: boolean;
    };
    /** Price per verification (in country's currency) */
    pricePerVerification: number;
    flag: string;
}

// ── Country Data ──────────────────────────────────────────────────────────────

const COUNTRY_MAP: Record<string, CountryInfo> = {
    IN: {
        country: 'IN', countryName: 'India', currency: 'INR', symbol: '₹',
        detected: true, loading: false,
        methods: { whatsapp: true, sms: false, voice: false },
        pricePerVerification: 2.50, flag: '🇮🇳',
    },
    US: {
        country: 'US', countryName: 'United States', currency: 'USD', symbol: '$',
        detected: true, loading: false,
        methods: { whatsapp: false, sms: true, voice: true },
        pricePerVerification: 0.06, flag: '🇺🇸',
    },
    PH: {
        country: 'PH', countryName: 'Philippines', currency: 'USD', symbol: '$',
        detected: true, loading: false,
        methods: { whatsapp: false, sms: true, voice: true },
        pricePerVerification: 0.05, flag: '🇵🇭',
    },
    MX: {
        country: 'MX', countryName: 'Mexico', currency: 'USD', symbol: '$',
        detected: true, loading: false,
        methods: { whatsapp: false, sms: true, voice: true },
        pricePerVerification: 0.04, flag: '🇲🇽',
    },
    GB: {
        country: 'GB', countryName: 'United Kingdom', currency: 'USD', symbol: '$',
        detected: true, loading: false,
        methods: { whatsapp: false, sms: true, voice: true },
        pricePerVerification: 0.08, flag: '🇬🇧',
    },
};

const defaultCountry: CountryInfo = {
    country: 'OTHER', countryName: 'International', currency: 'USD', symbol: '$',
    detected: false, loading: true,
    methods: { whatsapp: false, sms: false, voice: false },
    pricePerVerification: 0.06, flag: '🌍',
};

/** All supported active countries in display order */
export const ACTIVE_COUNTRIES: CountryInfo[] = [
    COUNTRY_MAP.IN,
    COUNTRY_MAP.US,
    COUNTRY_MAP.PH,
    COUNTRY_MAP.MX,
    COUNTRY_MAP.GB,
];

// ── Context ───────────────────────────────────────────────────────────────────

const CountryContext = createContext<{
    info: CountryInfo;
    setManual: (country: SupportedCountryISO) => void;
}>({
    info: defaultCountry,
    setManual: () => { },
});

// ── Cache ─────────────────────────────────────────────────────────────────────

const CACHE_KEY = 'codverify_country_cache';
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

function getCached(): CountryInfo | null {
    try {
        const raw = localStorage.getItem(CACHE_KEY);
        if (!raw) return null;
        const { data, ts } = JSON.parse(raw);
        if (Date.now() - ts > CACHE_TTL_MS) {
            localStorage.removeItem(CACHE_KEY);
            return null;
        }
        return data;
    } catch { return null; }
}

function setCached(data: CountryInfo) {
    try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({ data, ts: Date.now() }));
    } catch { }
}

function buildCountryInfo(countryCode: string): CountryInfo {
    return COUNTRY_MAP[countryCode?.toUpperCase()] || { ...defaultCountry, loading: false };
}

// ── Provider ──────────────────────────────────────────────────────────────────

export function CountryProvider({ children }: { children: ReactNode }) {
    const [info, setInfo] = useState<CountryInfo>(defaultCountry);

    useEffect(() => {
        const cached = getCached();
        if (cached) {
            setInfo({ ...cached, loading: false });
            return;
        }

        // Detect via ipapi.co (free, no API key needed)
        fetch('https://ipapi.co/json/', { signal: AbortSignal.timeout(2000) })
            .then(r => r.json())
            .then(data => {
                const countryInfo = buildCountryInfo(data.country_code || 'OTHER');
                const final = { ...countryInfo, detected: true, loading: false };
                setInfo(final);
                setCached(final);
            })
            .catch(() => {
                const fallback: CountryInfo = { ...defaultCountry, loading: false };
                setInfo(fallback);
            });
    }, []);

    const setManual = (country: SupportedCountryISO) => {
        const updated = buildCountryInfo(country);
        const final = { ...updated, detected: true, loading: false };
        setInfo(final);
        setCached(final);
    };

    return (
        <CountryContext.Provider value={{ info, setManual }}>
            {children}
        </CountryContext.Provider>
    );
}

export function useCountry() {
    return useContext(CountryContext);
}

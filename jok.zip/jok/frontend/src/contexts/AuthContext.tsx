import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { authApi } from '../api';
import type { User } from '../types';

interface AuthContextType {
    user: User | null;
    loading: boolean;
    login: (email: string, password: string) => Promise<void>;
    signup: (data: any) => Promise<any>;
    logout: () => Promise<void>;
    updateUser: (data: Partial<User>) => void;
    isAdmin: boolean;
    isMerchant: boolean;
    isWorker: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Handle auto-login from Shopify (token passed via URL ?auto_token=xxx)
        const params = new URLSearchParams(window.location.search);
        const autoToken = params.get('auto_token');
        if (autoToken) {
            localStorage.setItem('access_token', autoToken);
            // Clean up URL (remove auto_token param)
            params.delete('auto_token');
            params.delete('shop');
            const cleanUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
            window.history.replaceState({}, '', cleanUrl);
        }

        const token = localStorage.getItem('access_token');
        if (token) {
            authApi.getMe()
                .then(res => setUser(res.data?.data))
                .catch(() => {
                    localStorage.removeItem('access_token');
                    localStorage.removeItem('refresh_token');
                })
                .finally(() => setLoading(false));
        } else {
            setLoading(false);
        }
    }, []);

    const login = async (email: string, password: string) => {
        const res = await authApi.login({ email, password });
        const data = res.data?.data;
        localStorage.setItem('access_token', data.access_token);
        localStorage.setItem('refresh_token', data.refresh_token);
        setUser(data.user);
    };

    const signup = async (data: any) => {
        const res = await authApi.register(data);
        return res.data;
    };

    const logout = async () => {
        const refreshToken = localStorage.getItem('refresh_token');
        if (refreshToken) {
            try { await authApi.logout(refreshToken); } catch { }
        }
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        setUser(null);
    };

    const updateUser = (data: Partial<User>) => {
        setUser(prev => prev ? { ...prev, ...data } : null);
    };

    return (
        <AuthContext.Provider value={{
            user, loading, login, signup, logout, updateUser,
            isAdmin: user?.role === 'admin',
            isMerchant: user?.role === 'merchant',
            isWorker: user?.role === 'worker',
        }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth must be used within AuthProvider');
    return ctx;
}

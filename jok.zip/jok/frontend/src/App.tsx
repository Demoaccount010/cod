import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from 'sonner';
import { AuthProvider } from './contexts/AuthContext';
import { CountryProvider } from './contexts/CountryContext';
import { ProtectedRoute, GuestRoute } from './components/guards/RouteGuards';
import ScrollToTop from './components/ScrollToTop';
import { lazy, Suspense } from 'react';

// Layouts 
const DashboardLayout = lazy(() => import('./layouts/DashboardLayout'));
import PublicLayout from './layouts/PublicLayout';

// ── Pages ──────────────────────────────────

// Public Pages (HomePage is eagerly loaded for instant LCP)
import HomePage from './pages/public/HomePage';
const ServicesPage = lazy(() => import('./pages/public/ServicesPage'));
const ContactPage = lazy(() => import('./pages/public/ContactPage'));
const FeaturesPage = lazy(() => import('./pages/public/FeaturesPage'));
const CountriesPage = lazy(() => import('./pages/public/CountriesPage'));
const DocsPage = lazy(() => import('./pages/public/DocsPage'));
const FAQPage = lazy(() => import('./pages/public/FAQPage'));
const IntegrationsPage = lazy(() => import('./pages/public/IntegrationsPage'));
const PartnersPage = lazy(() =>
  import('./pages/public/OtherPublicPages').then(m => ({ default: m.PartnersPage }))
);
const BlogPage = lazy(() =>
  import('./pages/public/OtherPublicPages').then(m => ({ default: m.BlogPage }))
);
const CareersPage = lazy(() =>
  import('./pages/public/CareersPage').then(m => ({ default: m.CareersPage }))
);
const TermsPage = lazy(() =>
  import('./pages/public/LegalAndInfoPages').then(m => ({ default: m.TermsPage }))
);
const PrivacyPage = lazy(() =>
  import('./pages/public/LegalAndInfoPages').then(m => ({ default: m.PrivacyPage }))
);
const AboutPage = lazy(() =>
  import('./pages/public/LegalAndInfoPages').then(m => ({ default: m.AboutPage }))
);
const StatusPage = lazy(() =>
  import('./pages/public/LegalAndInfoPages').then(m => ({ default: m.StatusPage }))
);
const ChangelogPage = lazy(() =>
  import('./pages/public/LegalAndInfoPages').then(m => ({ default: m.ChangelogPage }))
);

// Auth Pages
const LoginPage = lazy(() => import('./pages/auth/LoginPage'));
const SignupPage = lazy(() => import('./pages/auth/SignupPage'));
const VerifyEmailPage = lazy(() => import('./pages/auth/VerifyEmailPage'));
const ForgotPasswordPage = lazy(() => import('./pages/auth/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('./pages/auth/ResetPasswordPage'));

// Merchant Pages
const DashboardPage = lazy(() => import('./pages/merchant/DashboardPage'));
const OrdersPage = lazy(() => import('./pages/merchant/OrdersPage'));
const OrderDetailPage = lazy(() => import('./pages/merchant/OrderDetailPage'));
const StoresPage = lazy(() => import('./pages/merchant/StoresPage'));
const CustomersPage = lazy(() => import('./pages/merchant/CustomersPage'));
const SupportPage = lazy(() => import('./pages/merchant/SupportPage'));
const NotificationsPage = lazy(() => import('./pages/merchant/NotificationsPage'));
const ContractPage = lazy(() => import('./pages/merchant/ContractPage'));
const MerchantChatbot = lazy(() => import('./pages/merchant/MerchantChatbot'));
const MerchantSettingsPage = lazy(() => import('./pages/merchant/SettingsPage'));
const MerchantBillingPage = lazy(() => import('./pages/merchant/BillingPage'));
const MerchantTemplatesPage = lazy(() => import('./pages/merchant/TemplatesPage'));
const MerchantApiKeysPage = lazy(() => import('./pages/merchant/ApiKeysPage'));

// Admin Pages
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const AdminMerchants = lazy(() => import('./pages/admin/AdminMerchants'));
const AdminOrders = lazy(() => import('./pages/admin/AdminOrders'));
const AdminIntegrations = lazy(() => import('./pages/admin/AdminIntegrations'));
const AdminContracts = lazy(() => import('./pages/admin/AdminContracts'));
const AdminStaff = lazy(() => import('./pages/admin/AdminStaff'));
const AdminBlog = lazy(() => import('./pages/admin/AdminBlog'));
const AdminJobs = lazy(() => import('./pages/admin/AdminJobs'));
const AdminBilling = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminBilling }))
);
const AdminPartners = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminPartners }))
);
const AdminSupport = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminSupport }))
);
const AdminBlacklist = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminBlacklist }))
);
const AdminSettings = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminSettings }))
);
const AdminLogs = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminLogs }))
);
const AdminHealth = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminHealth }))
);
const AdminReviews = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminReviews }))
);
const AdminContactInquiries = lazy(() =>
  import('./pages/admin/AdminPages').then(m => ({ default: m.AdminContactInquiries }))
);

// CMS Pages
const CMSDashboard = lazy(() => import('./pages/admin/cms/CMSDashboard'));
const ContentEditor = lazy(() => import('./pages/admin/cms/ContentEditor'));
const PagesManager = lazy(() => import('./pages/admin/cms/PagesManager'));
const NavigationManager = lazy(() => import('./pages/admin/cms/NavigationManager'));
const MediaManager = lazy(() => import('./pages/admin/cms/MediaManager'));
const CMSSettingsPage = lazy(() => import('./pages/admin/cms/SettingsPage'));

// Worker Pages
const WorkerDashboard = lazy(() => import('./pages/worker/WorkerDashboard'));
const WorkerOrders = lazy(() => import('./pages/worker/WorkerOrders'));
const WorkerChat = lazy(() => import('./pages/worker/WorkerChat'));
const WorkerMerchantLimits = lazy(() => import('./pages/worker/WorkerMerchantLimits'));
const WorkerCallbacks = lazy(() => import('./pages/worker/WorkerCallbacks'));
const WorkerStores = lazy(() => import('./pages/worker/WorkerStores'));
const WorkerOrderDetail = lazy(() => import('./pages/worker/WorkerOrderDetail'));
const ChatWidget = lazy(() => import('./components/ChatWidget'));

// ── Loading fallback ──────────────────────────────────────────────────────────
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A2540]">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin" />
        <p className="text-gray-400 text-sm">Loading...</p>
      </div>
    </div>
  );
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes — prevents refetch on every mount
    },
  },
});

export default function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <CountryProvider>
          <AuthProvider>
            <BrowserRouter>
              <ScrollToTop />
              <Toaster position="top-right" richColors />
              <Suspense fallback={<PageLoader />}>
              <Routes>
                {/* Public Routes */}
                <Route element={<PublicLayout />}>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/services" element={<ServicesPage />} />
                  <Route path="/contact" element={<ContactPage />} />
                  <Route path="/partners" element={<PartnersPage />} />
                  <Route path="/blog" element={<BlogPage />} />
                  <Route path="/careers" element={<CareersPage />} />
                  <Route path="/features" element={<FeaturesPage />} />
                  <Route path="/countries" element={<CountriesPage />} />
                  <Route path="/docs" element={<DocsPage />} />
                  <Route path="/faq" element={<FAQPage />} />
                  <Route path="/integrations" element={<IntegrationsPage />} />
                  <Route path="/about" element={<AboutPage />} />
                  <Route path="/terms" element={<TermsPage />} />
                  <Route path="/privacy" element={<PrivacyPage />} />
                  <Route path="/status" element={<StatusPage />} />
                  <Route path="/changelog" element={<ChangelogPage />} />
                  <Route path="/pricing" element={<Navigate to="/services" replace />} />
                </Route>

                {/* Auth Routes */}
                <Route path="/login" element={<GuestRoute><LoginPage /></GuestRoute>} />
                <Route path="/signup" element={<GuestRoute><SignupPage /></GuestRoute>} />
                <Route path="/verify-email/:token" element={<VerifyEmailPage />} />
                <Route path="/forgot-password" element={<GuestRoute><ForgotPasswordPage /></GuestRoute>} />
                <Route path="/reset-password/:token" element={<GuestRoute><ResetPasswordPage /></GuestRoute>} />

                {/* Merchant Routes */}
                <Route element={<ProtectedRoute requiredRole="merchant"><DashboardLayout /></ProtectedRoute>}>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/dashboard/orders" element={<OrdersPage />} />
                  <Route path="/dashboard/orders/:orderId" element={<OrderDetailPage />} />
                  <Route path="/dashboard/stores" element={<StoresPage />} />
                  <Route path="/dashboard/contract" element={<ContractPage />} />
                  <Route path="/dashboard/customers" element={<CustomersPage />} />
                  <Route path="/dashboard/support" element={<SupportPage />} />
                  <Route path="/dashboard/notifications" element={<NotificationsPage />} />
                  <Route path="/dashboard/chatbot" element={<MerchantChatbot />} />
                  <Route path="/dashboard/settings" element={<MerchantSettingsPage />} />
                  <Route path="/dashboard/billing" element={<MerchantBillingPage />} />
                  <Route path="/dashboard/templates" element={<MerchantTemplatesPage />} />
                  <Route path="/dashboard/api-keys" element={<MerchantApiKeysPage />} />
                </Route>

                {/* Admin Routes */}
                <Route element={<ProtectedRoute requiredRole="admin"><DashboardLayout /></ProtectedRoute>}>
                  <Route path="/admin" element={<AdminDashboard />} />
                  <Route path="/admin/merchants" element={<AdminMerchants />} />
                  <Route path="/admin/orders" element={<AdminOrders />} />
                  <Route path="/admin/contracts" element={<AdminContracts />} />
                  <Route path="/admin/billing" element={<AdminBilling />} />
                  <Route path="/admin/staff" element={<AdminStaff />} />
                  <Route path="/admin/partners" element={<AdminPartners />} />
                  <Route path="/admin/blog" element={<AdminBlog />} />
                  <Route path="/admin/jobs" element={<AdminJobs />} />
                  <Route path="/admin/support" element={<AdminSupport />} />
                  <Route path="/admin/blacklist" element={<AdminBlacklist />} />
                  <Route path="/admin/settings" element={<AdminSettings />} />
                  <Route path="/admin/logs" element={<AdminLogs />} />
                  <Route path="/admin/health" element={<AdminHealth />} />
                  <Route path="/admin/reviews" element={<AdminReviews />} />
                  <Route path="/admin/contact-inquiries" element={<AdminContactInquiries />} />
                  <Route path="/admin/integrations" element={<AdminIntegrations />} />

                  {/* CMS Routes */}
                  <Route path="/admin/cms" element={<CMSDashboard />} />
                  <Route path="/admin/cms/pages" element={<PagesManager />} />
                  <Route path="/admin/cms/content/:section" element={<ContentEditor />} />
                  <Route path="/admin/cms/navigation" element={<NavigationManager />} />
                  <Route path="/admin/cms/media" element={<MediaManager />} />
                  <Route path="/admin/cms/cms-settings" element={<CMSSettingsPage />} />
                </Route>

                {/* Worker Routes */}
                <Route element={<ProtectedRoute requiredRole="worker"><DashboardLayout /></ProtectedRoute>}>
                  <Route path="/worker" element={<WorkerDashboard />} />
                  <Route path="/worker/orders" element={<WorkerOrders />} />
                  <Route path="/worker/orders/:orderId" element={<WorkerOrderDetail />} />
                  <Route path="/worker/stores" element={<WorkerStores />} />
                  <Route path="/worker/chat" element={<WorkerChat />} />
                  <Route path="/worker/api-limits" element={<WorkerMerchantLimits />} />
                  <Route path="/worker/callbacks" element={<WorkerCallbacks />} />
                </Route>

                {/* 404 catch-all */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
              </Suspense>
            </BrowserRouter>
          </AuthProvider>
        </CountryProvider>
      </QueryClientProvider>
      <Suspense fallback={null}><ChatWidget /></Suspense>
    </HelmetProvider>
  );
}

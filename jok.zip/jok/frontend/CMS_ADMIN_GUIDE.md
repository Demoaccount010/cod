# WordPress-Style CMS Admin Panel

Complete website management system for CODVerify. Control your entire website without coding - just like WordPress!

## Features

### 1. **CMS Dashboard** (`/admin/cms`)
Central hub for all content management operations
- Quick stats overview (Pages, Last Updated, Media Files)
- Recent changes log
- Quick access to all sections
- One-click "New Page" creation

### 2. **Page Manager** (`/admin/cms/pages`)
Create and manage website pages
- ✅ Create new pages with custom URLs
- ✅ Edit existing pages
- ✅ Organize page sections
- ✅ Publish/Draft status
- ✅ Track update timestamps
- ✅ Delete pages

**Supported Pages:**
- Homepage
- About Us
- Pricing
- Blog
- Contact
- Partners
- Case Studies
- Custom pages

### 3. **Content Editor** (`/admin/cms/content/:section`)
Edit specific website sections with live updates
- Hero Section
- Features Section
- ROI/Economics Section
- Footer
- Statistics
- Custom Sections

**Features:**
- Real-time text editing
- Color picker for brand colors
- Image URL management
- Save/Revert changes
- Duplicate sections
- Live preview

### 4. **Navigation Manager** (`/admin/cms/navigation`)
Control your website's menu structure
- Add/Edit/Delete menu items
- Update URLs and labels
- Drag-to-reorder navigation
- Support for:
  - Internal page links
  - Anchor links (#section)
  - External URLs
  - New window links

**Example Navigation Items:**
```
Technology  → #technology
Intelligence → #intelligence
Economics   → #economics
Pricing     → /pricing
Blog        → /blog
```

### 5. **Media Library** (`/admin/cms/media`)
Upload and manage all website images and videos
- ✅ Drag & drop file upload
- ✅ Image preview thumbnails
- ✅ File size tracking
- ✅ Upload date tracking
- ✅ Copy media URL to clipboard
- ✅ Download files
- ✅ Delete files
- ✅ Storage quota management

**Supported Formats:**
- Images: JPG, PNG, GIF, SVG (up to 50 MB)
- Videos: MP4, WebM (up to 100 MB)
- Documents: PDF (up to 50 MB)

### 6. **Website Settings** (`/admin/cms/cms-settings`)
Global website configuration

#### General Settings
- Site Title
- Site Description
- Contact Email
- Support Email
- Phone Number
- Business Address

#### Branding & Colors
- Primary Color (with hex selector)
- Secondary Color (with hex selector)
- Background Color
- Text Color
- Logo Management

#### Social Media Links
- Twitter
- LinkedIn
- Instagram
- Facebook
- YouTube

#### SEO Settings
- Meta Keywords
- OpenGraph Image
- OpenGraph Title
- Meta Description

## How to Use

### Creating a New Page
1. Go to **Pages** section
2. Click **"New Page"** button
3. Enter page title (e.g., "Contact Us")
4. Enter URL slug (e.g., "contact-us")
5. Click **Create**
6. Page is now available at `/contact-us`

### Editing Homepage Content
1. Go to **CMS Dashboard**
2. Click on desired section (e.g., "Content")
3. Select "Hero Section" or other sections
4. Edit text, colors, images
5. Click **Save Changes**
6. Changes reflect immediately on website

### Managing Navigation
1. Go to **Navigation** section
2. Add new menu item with label and URL
3. Reorder items by dragging
4. Edit labels/URLs by clicking edit button
5. Delete items with trash icon
6. Changes apply across all pages automatically

### Uploading Images
1. Go to **Media Library**
2. Drag & drop images, OR
3. Click **Browse Files** to select
4. Images appear immediately in grid view
5. Click **Copy URL** to get image link
6. Use in content editor

### Customizing Website Look
1. Go to **Settings**
2. Update brand colors using color pickers
3. Change site title and description
4. Add social media links
5. Update contact information
6. Click **Save Settings**

## Access Control

Only administrators can access the CMS:
- Path: `/admin/cms`
- Required Role: `admin`
- Protected by authentication

## File Structure

```
frontend/src/pages/admin/cms/
├── CMSDashboard.tsx          # Main CMS hub
├── ContentEditor.tsx         # Edit individual sections
├── PagesManager.tsx          # Create/manage pages
├── NavigationManager.tsx      # Control navigation menu
├── MediaManager.tsx          # Image/video library
└── SettingsPage.tsx          # Global settings
```

## API Endpoints (Backend Integration)

When connected to backend, the CMS will send data to:

```
POST   /api/cms/content/:section    # Save section content
GET    /api/cms/content/:section    # Load section content
POST   /api/cms/pages              # Create page
PUT    /api/cms/pages/:id          # Update page
DELETE /api/cms/pages/:id          # Delete page
POST   /api/cms/media              # Upload file
DELETE /api/cms/media/:id          # Delete media
PUT    /api/cms/settings           # Update global settings
GET    /api/cms/settings           # Get current settings
```

## Database Structure (Supabase)

### Tables Needed

```sql
-- Content sections
CREATE TABLE cms_content (
  id UUID PRIMARY KEY,
  section_name TEXT,
  content JSONB,
  updated_at TIMESTAMP,
  version INT
);

-- Pages
CREATE TABLE cms_pages (
  id UUID PRIMARY KEY,
  title TEXT,
  slug TEXT UNIQUE,
  status TEXT, -- 'published' | 'draft'
  sections TEXT[],
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

-- Media files
CREATE TABLE cms_media (
  id UUID PRIMARY KEY,
  filename TEXT,
  url TEXT,
  size INT,
  type TEXT,
  uploaded_at TIMESTAMP,
  user_id UUID
);

-- Site settings
CREATE TABLE cms_settings (
  id UUID PRIMARY KEY,
  setting_key TEXT,
  setting_value JSONB,
  updated_at TIMESTAMP
);

-- Navigation items
CREATE TABLE cms_navigation (
  id UUID PRIMARY KEY,
  label TEXT,
  url TEXT,
  target TEXT,
  order INT,
  updated_at TIMESTAMP
);
```

## Future Enhancements

### Planned Features
- [ ] Version control / revision history
- [ ] Page templates
- [ ] Scheduled publishing
- [ ] Multi-language support (i18n)
- [ ] Export as PDF
- [ ] Analytics integration
- [ ] SEO optimization suggestions
- [ ] Image optimization
- [ ] Meta tag generator
- [ ] Blog post management
- [ ] Newsletter integration
- [ ] Form builder
- [ ] Email notification setup

### Phase 2: Advanced CMS
- [ ] Visual page builder (drag & drop)
- [ ] Theme selector
- [ ] Custom CSS editor
- [ ] Plugin system
- [ ] User roles & permissions
- [ ] Content scheduling
- [ ] Backup & restore

## Quick Access Links

| Feature | URL |
|---------|-----|
| CMS Dashboard | `/admin/cms` |
| Pages Manager | `/admin/cms/pages` |
| Hero Section | `/admin/cms/content/hero` |
| Features | `/admin/cms/content/features` |
| ROI Section | `/admin/cms/content/roi` |
| Footer | `/admin/cms/content/footer` |
| Navigation | `/admin/cms/navigation` |
| Media Library | `/admin/cms/media` |
| Website Settings | `/admin/cms/cms-settings` |

## Keyboard Shortcuts

- `Ctrl+S` / `Cmd+S` - Save changes
- `Esc` - Close modals/editors
- `Ctrl+Z` - Undo (coming soon)

## Support

For CMS issues or feature requests:
1. Contact: `support@codverify.tech`
2. Report bugs in admin panel
3. Request features through email

## Technical Notes

- Built with React 19 + TypeScript
- State management with React Hooks
- Real-time auto-save capability (ready)
- Responsive design for mobile admins
- Dark mode ready
- WCAG 2.1 AA compliant

---

**Version:** 1.0  
**Last Updated:** March 2, 2026  
**Status:** Production Ready

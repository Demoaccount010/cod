# CODVerify — AWS Deployment Guide

## Architecture Overview

```
                    ┌────────────────────────────────────────┐
                    │         AWS EC2 t3.small               │
                    │                                        │
  Internet ─────── │  Nginx :80/:443                        │
                    │    ├── /api/*  → backend:8000 (FastAPI)│
                    │    ├── /webhooks/* → backend:8000      │
                    │    ├── /chatbot/* → backend:8000       │
                    │    ├── /static/* → backend:8000        │
                    │    └── /shopify/* → shopify:3000       │
                    │                                        │
                    │  [Docker internal network]             │
                    └────────────────────────────────────────┘
                              │           │
                              ▼           ▼
                         Supabase    External APIs
                         (DB stays   WhatsApp, Groq,
                          unchanged) Razorpay, Groq

  Cloudflare Pages: https://codverify.tech (Frontend React SPA)
  DNS: api.codverify.tech → EC2 IP
```

---

## Step 1 — Launch EC2 Instance

1. Go to **AWS Console → EC2 → Launch Instance**
2. **AMI**: Ubuntu Server 22.04 LTS (free tier eligible)
3. **Instance type**: `t3.small` (2 vCPU, 2GB RAM)
4. **Key pair**: Create or use existing `.pem` file
5. **Security Group** inbound rules:
   | Port | Source | Purpose |
   |------|--------|---------|
   | 22   | Your IP only | SSH |
   | 80   | 0.0.0.0/0 | HTTP |
   | 443  | 0.0.0.0/0 | HTTPS |
6. **Storage**: 20 GB gp3 SSD (minimum)
7. Launch → note the **Public IPv4 address**

---

## Step 2 — Point Domain to EC2

In your DNS provider (Cloudflare DNS / Route53):
```
A record: api.codverify.tech → YOUR_EC2_PUBLIC_IP
A record: shopify.codverify.tech → YOUR_EC2_PUBLIC_IP  (if using subdomain)
```

Wait 5 minutes for DNS propagation.

---

## Step 3 — Initial Server Setup

```bash
# SSH into EC2
ssh -i your-key.pem ubuntu@api.codverify.tech

# Download and run setup script
curl -sO https://raw.githubusercontent.com/YOUR_ORG/codverify/main/deploy/setup-server.sh
chmod +x setup-server.sh
sudo ./setup-server.sh
```

This installs: Docker, Docker Compose v2, Certbot, and configures the firewall.

---

## Step 4 — Clone Repository & Configure Env

```bash
cd /opt/codverify
git clone https://github.com/YOUR_ORG/codverify.git .

# Backend env
cp backend/.env.aws.example backend/.env
nano backend/.env   # Fill in ALL values

# Shopify plugin env  
cp plugins/codverify-shopify/.env.example plugins/codverify-shopify/.env
nano plugins/codverify-shopify/.env   # Fill in all values
```

### Critical env values to set in `backend/.env`:
| Variable | Value |
|----------|-------|
| `BACKEND_URL` | `https://api.codverify.tech` |
| `FRONTEND_URL` | `https://codverify.tech` |
| `WHATSAPP_API_PROXY_URL` | *(leave empty — not needed on AWS)* |
| `SUPABASE_URL` | *(same as before)* |
| `SUPABASE_SERVICE_KEY` | *(same as before)* |
| `JWT_SECRET` | *(generate new strong secret)* |
| `INTERNAL_API_TOKEN` | *(must match Shopify plugin .env)* |

---

## Step 5 — Get SSL Certificate (Let's Encrypt)

> **Skip this if using AWS ALB for SSL termination**

```bash
# Stop nginx if running
docker compose stop nginx 2>/dev/null || true

# Get cert (replace with your actual domains)
sudo certbot certonly --standalone \
  -d api.codverify.tech \
  -d shopify.codverify.tech \
  --agree-tos --non-interactive \
  -m admin@codverify.tech

# Enable HTTPS block in nginx.conf (uncomment the server block at bottom)
nano nginx/nginx.conf
```

---

## Step 6 — Start All Services

```bash
cd /opt/codverify

# Build and start everything
docker compose up -d --build

# Check logs
docker compose logs -f backend    # Stream backend logs
docker compose ps                  # Check all service status

# Test health endpoint
curl http://localhost:8000/health
# Expected: {"status":"healthy","service":"codverify-api","version":"1.0.0"}

# Test via nginx
curl https://api.codverify.tech/health
```

---

## Step 7 — Update Webhook URLs (From HuggingFace → AWS)

### WhatsApp (Meta Business Dashboard)
- Go to Meta Developers → Your App → WhatsApp → Configuration
- **Webhook URL**: `https://api.codverify.tech/api/v1/webhooks/whatsapp`
- **Verify Token**: *(same as WHATSAPP_VERIFY_TOKEN in your .env)*

### Shopify Partner Dashboard
- **App URL**: `https://shopify.codverify.tech/shopify/auth`
- **Allowed redirection URL**: `https://shopify.codverify.tech/shopify/auth/callback`
- **Webhook endpoint** (in stores): `https://api.codverify.tech/api/v1/webhooks/shopify/{shop}`

### Cloudflare Pages (Frontend)
- Pages dashboard → Your Project → Settings → Environment Variables
- `VITE_API_URL` = `https://api.codverify.tech`
- Trigger a new deployment

---

## Step 8 — Set Up Auto-Deploy (GitHub Actions)

Add these secrets to GitHub repo (Settings → Secrets → Actions):

| Secret | Value |
|--------|-------|
| `EC2_HOST` | `api.codverify.tech` |
| `EC2_USER` | `ubuntu` |
| `EC2_SSH_KEY` | Contents of your `.pem` file |
| `CLOUDFLARE_API_TOKEN` | Cloudflare API token with Pages edit |
| `CLOUDFLARE_ACCOUNT_ID` | Your Cloudflare account ID |

Now every `git push` to `main` auto-deploys backend to EC2 and frontend to Cloudflare Pages.

---

## Moving to DigitalOcean (Future)

The entire setup is **portable** — all services run in Docker.

```bash
# On new DigitalOcean Droplet:
sudo ./deploy/setup-server.sh   # Same script works on Ubuntu 22.04

# Copy your .env files from old server:
scp ubuntu@old-server:/opt/codverify/backend/.env ./backend/.env
scp ubuntu@old-server:/opt/codverify/plugins/codverify-shopify/.env ./plugins/codverify-shopify/.env

# Update DNS: api.codverify.tech → new DigitalOcean IP
# Start services:
docker compose up -d --build

# That's it! Zero code changes needed.
```

---

## Useful Commands

```bash
# Check all service status
docker compose ps

# View backend logs (live)
docker compose logs -f backend

# View all logs
docker compose logs -f

# Restart a single service
docker compose restart backend

# Update and deploy latest code
./deploy/deploy.sh

# Stop everything
docker compose down

# Stop + remove volumes (WARNING: clears logs)
docker compose down -v
```

---

## t3.small Resource Notes

| Resource | Limit | CODVerify use |
|----------|-------|---------------|
| vCPU | 2 | Backend: 2 uvicorn workers, Shopify: 1 node process |
| RAM | 2 GB | ~400MB backend + ~150MB shopify + ~100MB nginx = ~650MB used |
| Network | Up to 5Gbps burst | More than enough for API traffic |

> For high traffic (>500 orders/day), consider upgrading to `t3.medium` (4GB RAM).

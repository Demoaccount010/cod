/**
 * CODVerify Shopify App — Main Entry
 * ====================================
 * - Handles Shopify OAuth (multi-app: supports SHOPIFY_APPS JSON array)
 * - After install → generates a secret key for the merchant
 * - Merchant creates account on codverify.tech, enters key in Store Connect
 * - /app page → shows connection status (Connected / Not Connected)
 */

const express = require('express');
const axios = require('axios');
const crypto = require('crypto');

const app = express();

// Save raw body for Shopify HMAC verification
app.use(express.json({
  verify: (req, res, buf) => {
    req.rawBody = buf;
  }
}));

// ── Config ──────────────────────────────────────────────────────────
const {
  SHOPIFY_SCOPES = 'read_orders,write_orders',
  HOST = 'http://localhost:3000',
  PORT = 3000,
  CODVERIFY_BACKEND_URL = '',
  INTERNAL_API_TOKEN = '',
  CODVERIFY_DASHBOARD_URL = 'https://codverify.tech/dashboard',
  CODVERIFY_WEBSITE_URL = 'https://codverify.tech',
} = process.env;

// ── Multi-App Credential Registry ─────────────────────────────────────
// Supports SHOPIFY_APPS JSON array OR fallback to single SHOPIFY_API_KEY/SECRET
// Format: [{"key":"...","secret":"...","label":"MerchantName"}, ...]
const SHOPIFY_APPS = (() => {
  try {
    const raw = process.env.SHOPIFY_APPS || '';
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('⚠️  SHOPIFY_APPS JSON parse failed:', e.message);
  }
  // Fallback to single app from individual env vars
  const key = process.env.SHOPIFY_API_KEY || '';
  const secret = process.env.SHOPIFY_API_SECRET || '';
  if (!key || !secret) {
    console.error('❌ FATAL: No Shopify credentials! Set SHOPIFY_APPS or SHOPIFY_API_KEY+SHOPIFY_API_SECRET');
  }
  return [{ key, secret, label: 'Default' }];
})();

// Per-shop → app index tracking (in-memory, survives until restart)
const shopAppRegistry = new Map(); // shop → appIndex

/** Get credentials for a shop (by stored app index or default 0) */
function getAppForShop(shop) {
  const idx = shopAppRegistry.get(shop) || 0;
  return SHOPIFY_APPS[idx] || SHOPIFY_APPS[0];
}

/** Get credentials by explicit app index */
function getAppByIndex(idx) {
  const i = parseInt(idx, 10);
  if (!isNaN(i) && i >= 0 && i < SHOPIFY_APPS.length) return { app: SHOPIFY_APPS[i], idx: i };
  return { app: SHOPIFY_APPS[0], idx: 0 };
}

// In-memory stores
const oauthStates = new Map(); // shop → {state, timestamp, appIdx}
const tokenCache = new Map();  // shop → accessToken
const shopKeyCache = new Map(); // shop → secret_key (temporary display cache)

// Clean up stale OAuth states every 10 minutes
setInterval(() => {
  const expiry = Date.now() - 10 * 60 * 1000;
  for (const [shop, data] of oauthStates.entries()) {
    if (data.timestamp < expiry) oauthStates.delete(shop);
  }
}, 10 * 60 * 1000);


// ── Health ───────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'codverify-shopify' }));

// ── Root redirect ────────────────────────────────────────────────────
app.get('/', (req, res) => {
  if (req.query.shop) {
    res.redirect(`/app?shop=${encodeURIComponent(req.query.shop)}`);
  } else {
    res.redirect('/health');
  }
});


// ── OAuth Initiation ─────────────────────────────────────────────────
app.get('/auth', (req, res) => {
  const shop = req.query.shop;
  if (!shop) return res.status(400).send('Missing shop parameter');

  // Pick app credentials by ?app=INDEX (defaults to 0)
  const { app: appCreds, idx: appIdx } = getAppByIndex(req.query.app || 0);

  const state = crypto.randomBytes(16).toString('hex');
  oauthStates.set(shop, { state, timestamp: Date.now(), appIdx });

  const redirectUri = `${HOST}/auth/callback`;
  const authUrl = `https://${shop}/admin/oauth/authorize?` + new URLSearchParams({
    client_id: appCreds.key,
    scope: SHOPIFY_SCOPES,
    redirect_uri: redirectUri,
    state,
  }).toString();

  console.log(`🔐 OAuth initiated for ${shop} using app[${appIdx}] ${appCreds.label || ''}`);
  res.redirect(authUrl);
});


// ── HMAC Verification Helper (OAuth callback) ─────────────────────────
function verifyShopifyHmac(query, secret) {
  const { hmac, ...rest } = query;
  if (!hmac) return false;
  const usedSecret = secret || getAppForShop(query.shop || '').secret;
  const message = Object.keys(rest).sort().map(k => `${k}=${rest[k]}`).join('&');
  const expected = crypto.createHmac('sha256', usedSecret).update(message).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(hmac)); }
  catch { return false; }
}


// ── OAuth Callback ────────────────────────────────────────────────────
app.get('/auth/callback', async (req, res) => {
  const { shop, code, state } = req.query;

  // Retrieve app credentials used during /auth initiation
  const storedState = oauthStates.get(shop);
  if (!storedState || storedState.state !== state) {
    return res.status(403).send('Invalid state parameter');
  }
  const appIdx = storedState.appIdx || 0;
  const appCreds = SHOPIFY_APPS[appIdx] || SHOPIFY_APPS[0];
  oauthStates.delete(shop);

  // Register shop → app mapping for future HMAC checks
  shopAppRegistry.set(shop, appIdx);
  console.log(`📌 Registered shop ${shop} → app[${appIdx}] ${appCreds.label || ''}`);

  if (!verifyShopifyHmac(req.query, appCreds.secret)) {
    return res.status(403).send('HMAC verification failed');
  }

  // Step 1: Exchange code for access token (MUST succeed)
  let accessToken;
  try {
    const tokenRes = await axios.post(`https://${shop}/admin/oauth/access_token`, {
      client_id: appCreds.key,
      client_secret: appCreds.secret,
      code,
    });
    accessToken = tokenRes.data.access_token;
    console.log(`✅ Access token obtained for ${shop} (offline token)`);
  } catch (err) {
    console.error('❌ Token exchange failed:', err?.response?.data || err.message);
    return res.status(500).send('OAuth failed — could not get access token. Please try again.');
  }

  // Store token for later use
  tokenCache.set(shop, accessToken);

  // Step 2: Get shop details (non-fatal)
  let shopData = { name: shop, email: '', id: '' };
  try {
    const shopRes = await axios.get(`https://${shop}/admin/api/2025-04/shop.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    });
    shopData = shopRes.data.shop;
    console.log(`✅ Shop details fetched: ${shopData.name}`);
  } catch (err) {
    console.error('⚠️ Shop details fetch failed (non-fatal):', err?.response?.status, err?.response?.data || err.message);
  }

  // Step 3: Generate secret key via backend (non-fatal)
  let secretKey = '';
  if (CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
    try {
      const keyRes = await axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-generate-key`, {
        shop_domain: shop,
        shop_name: shopData.name || shop,
        shop_email: shopData.email || '',
        shopify_shop_id: String(shopData.id || ''),
        access_token: accessToken,
      }, {
        headers: {
          'X-Internal-Token': INTERNAL_API_TOKEN,
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      });

      secretKey = keyRes.data?.data?.secret_key || '';
      if (secretKey) {
        shopKeyCache.set(shop, secretKey);
        console.log(`✅ Secret key generated for ${shop}: ${secretKey}`);
      }
    } catch (err) {
      console.error('❌ Backend shopify-generate-key failed:', err?.response?.status, err?.response?.data || err.message);
    }
  } else {
    console.error('❌ Backend not configured! CODVERIFY_BACKEND_URL or INTERNAL_API_TOKEN missing');
  }

  // Step 4: Register webhooks
  try {
    await registerWebhooks(shop, accessToken);
  } catch (err) {
    console.error(`❌ Webhook registration failed for ${shop}:`, err?.response?.data || err.message);
  }

  // Step 5: Register chatbot script tag (non-fatal)
  try {
    await registerScriptTag(shop, accessToken);
  } catch (err) {
    console.error('⚠️ Script tag registration failed (non-fatal):', err?.response?.status || err.message);
  }

  // Step 6: Redirect to app page which will show the key
  res.redirect(`/app?shop=${encodeURIComponent(shop)}&setup=1`);
});


// ── Webhook & Script Registration ─────────────────────────────────────
async function registerWebhooks(shop, accessToken) {
  console.log(`🔧 Registering webhooks for ${shop} with HOST=${HOST}`);

  const topics = [
    { topic: 'orders/paid',      address: `${HOST}/webhooks/orders/paid` },
    { topic: 'orders/create',    address: `${HOST}/webhooks/orders/create` },
    { topic: 'orders/fulfilled', address: `${HOST}/webhooks/orders/fulfilled` },
    { topic: 'orders/cancelled', address: `${HOST}/webhooks/orders/cancelled` },
    { topic: 'app/uninstalled',  address: `${HOST}/webhooks/app/uninstalled` },
  ];

  // Delete existing webhooks first (clean slate)
  try {
    const existing = await axios.get(`https://${shop}/admin/api/2025-04/webhooks.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    });
    const existingWebhooks = existing.data?.webhooks || [];
    console.log(`📋 Found ${existingWebhooks.length} existing webhooks — removing...`);
    for (const wh of existingWebhooks) {
      try {
        await axios.delete(`https://${shop}/admin/api/2025-04/webhooks/${wh.id}.json`, {
          headers: { 'X-Shopify-Access-Token': accessToken }
        });
        console.log(`🗑️ Deleted: ${wh.topic} → ${wh.address}`);
      } catch (delErr) {
        console.warn(`⚠️ Could not delete webhook ${wh.id}:`, delErr.message);
      }
    }
  } catch (listErr) {
    console.warn('⚠️ Could not list existing webhooks:', listErr?.response?.status, listErr?.response?.data || listErr.message);
  }

  // Register fresh webhooks
  let successCount = 0;
  for (const wh of topics) {
    try {
      const result = await axios.post(`https://${shop}/admin/api/2025-04/webhooks.json`, {
        webhook: { topic: wh.topic, address: wh.address, format: 'json' }
      }, {
        headers: { 'X-Shopify-Access-Token': accessToken }
      });
      console.log(`✅ ${wh.topic} → ${wh.address} (id: ${result.data?.webhook?.id})`);
      successCount++;
    } catch (err) {
      const status = err?.response?.status;
      const data = err?.response?.data;
      if (status === 422) {
        console.log(`ℹ️ Webhook ${wh.topic} already exists`);
        successCount++;
      } else {
        console.error(`❌ Webhook ${wh.topic} FAILED — Status: ${status}, Error:`, JSON.stringify(data || err.message));
      }
    }
  }
  console.log(`📊 Result: ${successCount}/${topics.length} webhooks active`);
}

async function registerScriptTag(shop, accessToken) {
  console.log(`\n🤖 ━━━ REGISTERING CHATBOT SCRIPT TAG ━━━`);
  const scriptSrc = `${HOST}/chatbot/script.js?shop=${encodeURIComponent(shop)}`;
  console.log(`   src: ${scriptSrc}`);

  try {
    const existing = await axios.get(`https://${shop}/admin/api/2025-04/script_tags.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    });
    for (const tag of (existing.data?.script_tags || [])) {
      if (tag.src && tag.src.includes('codverify')) {
        await axios.delete(`https://${shop}/admin/api/2025-04/script_tags/${tag.id}.json`, {
          headers: { 'X-Shopify-Access-Token': accessToken }
        });
        console.log(`   🗑️ Removed old script tag id=${tag.id}`);
      }
    }
  } catch (e) {
    console.warn(`   ⚠️ Could not list/remove old script tags: ${e?.response?.status || e.message}`);
  }

  try {
    await axios.post(`https://${shop}/admin/api/2025-04/script_tags.json`, {
      script_tag: {
        event: 'onload',
        src: scriptSrc,
        display_scope: 'online_store',
      }
    }, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    });
    console.log(`   ✅ Chatbot script tag registered`);
  } catch (err) {
    console.error(`   ❌ Script tag FAILED: ${err?.response?.status} — ${JSON.stringify(err?.response?.data || err.message)}`);
  }
}


// ── Webhook HMAC Verification (tries all registered apps) ─────────────
function verifyWebhookHmac(req) {
  const hmac = req.headers['x-shopify-hmac-sha256'];
  const shop = req.headers['x-shopify-shop-domain'] || '';
  if (!hmac) {
    console.error('❌ HMAC FAILED: No x-shopify-hmac-sha256 header');
    return false;
  }
  const body = req.rawBody || Buffer.from(JSON.stringify(req.body));

  // Try shop's registered app first (fast path), then try all others
  const primaryApp = getAppForShop(shop);
  const appsToTry = [primaryApp, ...SHOPIFY_APPS.filter(a => a !== primaryApp)];

  for (const appCreds of appsToTry) {
    if (!appCreds.secret) continue;
    const computed = crypto.createHmac('sha256', appCreds.secret).update(body).digest('base64');
    try {
      const isValid = crypto.timingSafeEqual(Buffer.from(computed, 'base64'), Buffer.from(hmac, 'base64'));
      if (isValid) {
        console.log(`✅ HMAC verification passed (app: ${appCreds.label || appCreds.key.slice(0,6)})`);
        return true;
      }
    } catch { /* try next */ }
  }

  console.error(`❌ HMAC FAILED: No matching app secret for shop: ${shop}`);
  return false;
}


// ── Manual Webhook Registration (for retry) ──────────────────────────
app.post('/setup/webhooks', express.json(), async (req, res) => {
  if (req.headers['x-internal-token'] !== INTERNAL_API_TOKEN) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }

  const shop = req.body.shop || '';
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  let accessToken = tokenCache.get(shop);

  if (!accessToken && CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
    try {
      const tokenRes = await axios.get(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-access-token`, {
        params: { shop_domain: shop },
        headers: { 'X-Internal-Token': INTERNAL_API_TOKEN },
        timeout: 10000,
      });
      accessToken = tokenRes.data?.data?.access_token;
      if (accessToken) tokenCache.set(shop, accessToken);
    } catch (err) {
      console.error('Failed to fetch token from backend:', err?.response?.data || err.message);
    }
  }

  if (!accessToken) {
    return res.status(400).json({ success: false, message: 'No access token found. Reinstall the app from Shopify.' });
  }

  try {
    await registerWebhooks(shop, accessToken);
    return res.json({ success: true, message: 'Webhooks registered successfully' });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});


// ── Auto-register webhooks ─────────────────────────────────────────────
app.get('/setup/auto-register', async (req, res) => {
  const shop = req.query.shop || '';
  const token = req.query.token || '';
  if (token !== INTERNAL_API_TOKEN) return res.status(401).json({ success: false, message: 'Unauthorized' });
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop parameter' });

  let accessToken = tokenCache.get(shop);
  if (!accessToken && CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
    try {
      const tokenRes = await axios.get(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-access-token`, {
        params: { shop_domain: shop },
        headers: { 'X-Internal-Token': INTERNAL_API_TOKEN },
        timeout: 10000,
      });
      accessToken = tokenRes.data?.data?.access_token;
      if (accessToken) tokenCache.set(shop, accessToken);
    } catch (err) {
      return res.status(400).json({ success: false, message: `Failed to get token: ${err?.response?.data?.detail || err.message}` });
    }
  }

  if (!accessToken) return res.status(400).json({ success: false, message: 'No access token found for this shop' });

  try {
    await registerWebhooks(shop, accessToken);
    const verify = await axios.get(`https://${shop}/admin/api/2025-04/webhooks.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken }
    });
    const webhooks = (verify.data?.webhooks || []).map(w => ({ id: w.id, topic: w.topic, address: w.address }));
    return res.json({ success: true, message: `Webhooks registered for ${shop}`, webhooks });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});


// ── Debug Config ───────────────────────────────────────────────────────
app.get('/debug/config', (req, res) => {
  res.json({
    host: HOST,
    apps_loaded: SHOPIFY_APPS.length,
    apps: SHOPIFY_APPS.map((a, i) => ({ index: i, label: a.label, key_set: !!a.key, secret_set: !!a.secret })),
    has_backend_url: !!CODVERIFY_BACKEND_URL,
    has_internal_token: !!INTERNAL_API_TOKEN,
    scopes: SHOPIFY_SCOPES,
    cached_shops: Array.from(tokenCache.keys()),
    shop_app_registry: Object.fromEntries(shopAppRegistry),
  });
});


// ── Regenerate Key API (AJAX, no OAuth needed) ────────────────────────
app.post('/regenerate-key', express.json(), async (req, res) => {
  const shop = req.body.shop || '';
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  if (!CODVERIFY_BACKEND_URL || !INTERNAL_API_TOKEN) {
    return res.status(500).json({ success: false, message: 'Backend not configured' });
  }

  try {
    const result = await axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-regenerate-key`, {
      shop_domain: shop,
    }, {
      headers: { 'X-Internal-Token': INTERNAL_API_TOKEN, 'Content-Type': 'application/json' },
      timeout: 10000,
    });

    const newKey = result.data?.data?.secret_key || '';
    if (newKey) shopKeyCache.set(shop, newKey);
    return res.json({ success: true, secret_key: newKey, is_already_connected: result.data?.data?.is_already_connected || false });
  } catch (err) {
    console.error('Regenerate key failed:', err?.response?.data || err.message);
    return res.status(500).json({ success: false, message: 'Failed to regenerate key. Please try again.' });
  }
});


// ── Main App Page (Connection Status + Secret Key) ─────────────────────
app.get('/app', async (req, res) => {
  const shop = req.query.shop || '';
  const isSetup = req.query.setup === '1';
  const websiteUrl = CODVERIFY_WEBSITE_URL;

  let isConnected = false;
  let secretKey = shopKeyCache.get(shop) || '';
  let storeName = shop;

  if (CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN && shop) {
    try {
      const statusRes = await axios.get(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-connection-status`, {
        params: { shop_domain: shop },
        headers: { 'X-Internal-Token': INTERNAL_API_TOKEN },
        timeout: 8000,
      });
      const statusData = statusRes.data?.data || {};
      isConnected = statusData.is_connected || false;
      storeName = statusData.shop_name || shop;
      if (!secretKey && statusData.secret_key) secretKey = statusData.secret_key;
    } catch (err) {
      console.warn('Connection status check failed for', shop);
    }
  }

  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>CODVerify - Store Connection</title>
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body, html { height: 100%; background: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
          .container { max-width: 640px; margin: 0 auto; padding: 40px 20px; }
          .logo-section { text-align: center; margin-bottom: 32px; }
          .logo-section h1 { font-size: 28px; font-weight: 800; color: #1e293b; }
          .logo-section p { color: #64748b; margin-top: 4px; font-size: 14px; }
          .card { background: white; border-radius: 16px; padding: 32px; box-shadow: 0 1px 3px rgba(0,0,0,0.08), 0 4px 24px rgba(0,0,0,0.04); border: 1px solid #e2e8f0; margin-bottom: 24px; }
          .status-badge { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 100px; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
          .status-connected { background: #dcfce7; color: #15803d; }
          .status-not-connected { background: #fef3c7; color: #a16207; }
          .dot { width: 8px; height: 8px; border-radius: 50%; }
          .dot-green { background: #22c55e; animation: pulse 2s infinite; }
          .dot-yellow { background: #eab308; }
          @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
          .key-box { background: #f1f5f9; border: 2px dashed #cbd5e1; border-radius: 12px; padding: 20px; text-align: center; margin: 20px 0; }
          .key-value { font-size: 28px; font-weight: 800; letter-spacing: 3px; color: #4f46e5; font-family: 'Courier New', monospace; user-select: all; margin: 8px 0; }
          .key-label { font-size: 12px; color: #94a3b8; text-transform: uppercase; font-weight: 600; letter-spacing: 1px; }
          .copy-btn { background: #4f46e5; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 13px; margin-top: 8px; transition: all 0.2s; }
          .copy-btn:hover { background: #4338ca; }
          .copy-btn:active { transform: scale(0.97); }
          .steps { margin-top: 24px; }
          .step { display: flex; gap: 16px; align-items: flex-start; padding: 16px 0; border-bottom: 1px solid #f1f5f9; }
          .step:last-child { border-bottom: none; }
          .step-num { width: 32px; height: 32px; border-radius: 50%; background: #eef2ff; color: #4f46e5; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0; }
          .step-content h4 { font-size: 15px; font-weight: 700; color: #1e293b; margin-bottom: 4px; }
          .step-content p { font-size: 13px; color: #64748b; line-height: 1.5; }
          .btn-primary { display: inline-flex; align-items: center; justify-content: center; gap: 8px; background: #4f46e5; color: white; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: 700; font-size: 15px; transition: all 0.2s; width: 100%; margin-top: 16px; border: none; cursor: pointer; }
          .btn-primary:hover { background: #4338ca; }
          .btn-secondary { display: inline-flex; align-items: center; justify-content: center; gap: 8px; background: white; color: #4f46e5; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: 700; font-size: 15px; border: 2px solid #e0e7ff; transition: all 0.2s; width: 100%; margin-top: 8px; cursor: pointer; }
          .btn-secondary:hover { background: #eef2ff; }
          .connected-card { text-align: center; padding: 48px 32px; }
          .check-icon { width: 64px; height: 64px; background: #dcfce7; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; }
          .check-icon svg { width: 32px; height: 32px; color: #22c55e; }
          .info-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #f1f5f9; }
          .info-row:last-child { border-bottom: none; }
          .info-label { font-size: 13px; color: #64748b; font-weight: 500; }
          .info-value { font-size: 14px; color: #1e293b; font-weight: 600; }
          .refresh-note { text-align: center; margin-top: 16px; font-size: 12px; color: #94a3b8; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="logo-section">
            <h1>CODVerify</h1>
            <p>WhatsApp COD Verification &amp; RTO Prevention</p>
          </div>

          ${isConnected ? `
            <!-- CONNECTED STATE -->
            <div class="card connected-card">
              <div class="check-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
              </div>
              <span class="status-badge status-connected"><span class="dot dot-green"></span> Connected</span>
              <h2 style="font-size: 22px; color: #1e293b; margin-top: 16px;">Store Successfully Connected!</h2>
              <p style="color: #64748b; margin-top: 8px; font-size: 14px;">Your Shopify store is linked to CODVerify. All COD orders will be automatically verified.</p>
            </div>

            <div class="card">
              <h3 style="font-size: 16px; color: #1e293b; margin-bottom: 16px; font-weight: 700;">Store Details</h3>
              <div class="info-row">
                <span class="info-label">Store</span>
                <span class="info-value">${storeName}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Domain</span>
                <span class="info-value">${shop}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Status</span>
                <span class="status-badge status-connected" style="padding: 4px 12px; font-size: 11px;"><span class="dot dot-green"></span> Connected</span>
              </div>
              <div class="info-row">
                <span class="info-label">Webhooks</span>
                <span class="info-value" style="color: #22c55e;">Active</span>
              </div>
              <a href="${websiteUrl}/dashboard" target="_blank" class="btn-primary">Open CODVerify Dashboard ↗</a>
            </div>
          ` : `
            <!-- NOT CONNECTED STATE - Show Secret Key & Instructions -->
            <div class="card">
              <div style="text-align: center; margin-bottom: 8px;">
                <span class="status-badge status-not-connected"><span class="dot dot-yellow"></span> Not Connected</span>
              </div>
              <h2 style="text-align: center; font-size: 20px; color: #1e293b; margin-top: 12px;">Connect Your Store</h2>
              <p style="text-align: center; color: #64748b; margin-top: 8px; font-size: 14px;">Use the secret key below to link your Shopify store with CODVerify</p>

              ${secretKey ? `
                <div class="key-box">
                  <p class="key-label">Your Secret Key</p>
                  <p class="key-value" id="secretKey">${secretKey}</p>
                  <button class="copy-btn" onclick="copyKey()">📋 Copy Key</button>
                  <p style="font-size: 11px; color: #94a3b8; margin-top: 12px;">⚠️ Save this key! You'll need it to connect your store.</p>
                </div>
              ` : `
                <div class="key-box" id="keyBox">
                  <p class="key-label">Secret Key</p>
                  <p id="keyMessage" style="color: #94a3b8; font-size: 14px; margin: 8px 0;">Key not loaded. Click below to generate a new key.</p>
                  <button class="copy-btn" id="regenBtn" onclick="regenerateKey()">🔄 Generate New Key</button>
                </div>
              `}

              <div class="steps">
                <h3 style="font-size: 16px; color: #1e293b; font-weight: 700; margin-bottom: 8px;">How to Connect:</h3>
                <div class="step">
                  <div class="step-num">1</div>
                  <div class="step-content">
                    <h4>Create Account</h4>
                    <p>Go to <strong>codverify.tech</strong> and create your merchant account (Sign Up).</p>
                  </div>
                </div>
                <div class="step">
                  <div class="step-num">2</div>
                  <div class="step-content">
                    <h4>Go to Stores</h4>
                    <p>After login, go to your Dashboard → <strong>Stores</strong> section.</p>
                  </div>
                </div>
                <div class="step">
                  <div class="step-num">3</div>
                  <div class="step-content">
                    <h4>Connect Store</h4>
                    <p>Click <strong>"Connect Store"</strong> and paste your secret key. Your store will be linked instantly!</p>
                  </div>
                </div>
              </div>

              <a href="${websiteUrl}/register" target="_blank" class="btn-primary">Create Account on CODVerify ↗</a>
              <a href="${websiteUrl}/login" target="_blank" class="btn-secondary">Already have an account? Login ↗</a>
            </div>
          `}

          <p class="refresh-note">
            ${isConnected ? 'Store connection is active and syncing orders.' : 'After connecting, refresh this page to see updated status.'}
            <br/><a href="/app?shop=${encodeURIComponent(shop)}" style="color: #4f46e5; text-decoration: none; font-weight: 600;">↻ Refresh Status</a>
          </p>
        </div>

        <script>
          function copyKey() {
            const key = document.getElementById('secretKey')?.textContent?.trim();
            if (!key) return;
            navigator.clipboard.writeText(key).then(() => {
              const btn = document.querySelector('.copy-btn');
              btn.textContent = '✅ Copied!';
              setTimeout(() => { btn.textContent = '📋 Copy Key'; }, 2000);
            }).catch(() => {
              const el = document.createElement('textarea');
              el.value = key;
              document.body.appendChild(el);
              el.select();
              document.execCommand('copy');
              document.body.removeChild(el);
              const btn = document.querySelector('.copy-btn');
              btn.textContent = '✅ Copied!';
              setTimeout(() => { btn.textContent = '📋 Copy Key'; }, 2000);
            });
          }

          function regenerateKey() {
            const btn = document.getElementById('regenBtn');
            const msg = document.getElementById('keyMessage');
            const keyBox = document.getElementById('keyBox');
            if (!btn) return;
            btn.disabled = true;
            btn.textContent = '⏳ Generating...';
            btn.style.opacity = '0.7';

            fetch('/regenerate-key', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ shop: '${shop}' }),
            })
            .then(r => r.json())
            .then(data => {
              if (data.success && data.secret_key) {
                keyBox.innerHTML = '<p class="key-label">Your Secret Key</p>' +
                  '<p class="key-value" id="secretKey">' + data.secret_key + '</p>' +
                  '<button class="copy-btn" onclick="copyKey()">📋 Copy Key</button>' +
                  '<p style="font-size: 11px; color: #94a3b8; margin-top: 12px;">⚠️ Save this key! You\\'ll need it to connect your store.</p>';
              } else if (data.is_already_connected) {
                msg.textContent = 'This store is already connected! Refresh page to see status.';
                msg.style.color = '#22c55e';
                btn.textContent = '↻ Refresh';
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.onclick = () => location.reload();
              } else {
                msg.textContent = data.message || 'Failed to generate key. Try again.';
                msg.style.color = '#ef4444';
                btn.textContent = '🔄 Try Again';
                btn.disabled = false;
                btn.style.opacity = '1';
              }
            })
            .catch(err => {
              msg.textContent = 'Network error. Please try again.';
              msg.style.color = '#ef4444';
              btn.textContent = '🔄 Try Again';
              btn.disabled = false;
              btn.style.opacity = '1';
            });
          }
        </script>
      </body>
    </html>
  `);
});


// ── Webhook Request Logger ─────────────────────────────────────────────
app.use('/webhooks', (req, res, next) => {
  console.log(`\n🔔 ━━━ INCOMING WEBHOOK ━━━`);
  console.log(`  ${req.method} ${req.originalUrl}`);
  console.log(`  Shop  : ${req.headers['x-shopify-shop-domain'] || '???'}`);
  console.log(`  Topic : ${req.headers['x-shopify-topic'] || '???'}`);
  console.log(`  HMAC  : ${req.headers['x-shopify-hmac-sha256'] ? 'present (' + req.headers['x-shopify-hmac-sha256'].slice(0,12) + '...)' : '❌ MISSING'}`);
  console.log(`  Body  : ${req.rawBody ? req.rawBody.length + ' bytes (rawBody)' : JSON.stringify(req.body).length + ' bytes (parsed)'}`);
  console.log(`  Time  : ${new Date().toISOString()}`);
  next();
});


// ── Webhooks ──────────────────────────────────────────────────────────
function buildOrderPayload(order, shop) {
  const paymentMethod = order.gateway || order.payment_gateway_names?.[0] || '';
  const isCod = paymentMethod.toLowerCase().includes('cod') ||
    paymentMethod.toLowerCase().includes('cash') ||
    (order.tags && order.tags.toLowerCase().includes('cod'));
  const orderType = isCod ? 'cod' : 'prepaid';

  const items = (order.line_items || []).map(item => ({
    name: item.title || item.name,
    quantity: item.quantity,
    price: parseFloat(item.price),
    image_url: item.image?.src || null,
  }));

  let trackingNumber = '', trackingUrl = '', trackingCompany = '';
  if (order.fulfillments && order.fulfillments.length > 0) {
    const latest = order.fulfillments[order.fulfillments.length - 1];
    trackingNumber = latest.tracking_number || '';
    trackingUrl = latest.tracking_url || '';
    trackingCompany = latest.tracking_company || '';
  }

  const phone = order.customer?.phone || order.shipping_address?.phone || order.billing_address?.phone || order.phone || '';

  return {
    store_order_id: String(order.id),
    order_number: String(order.order_number || order.name),
    customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || order.shipping_address?.name || 'Customer',
    customer_phone: phone,
    customer_email: order.customer?.email || order.email || '',
    order_amount: parseFloat(order.total_price),
    currency: order.currency || 'INR',
    payment_method: isCod ? 'cod' : (paymentMethod || 'prepaid'),
    order_type: orderType,
    fulfillment_status: order.fulfillment_status || 'unfulfilled',
    products: items,
    shipping_address: order.shipping_address ? {
      line1: order.shipping_address.address1 || '',
      line2: order.shipping_address.address2 || '',
      city: order.shipping_address.city || '',
      state: order.shipping_address.province || '',
      pincode: order.shipping_address.zip || '',
      country: order.shipping_address.country_code || order.shipping_address.country || '',
    } : null,
    source: 'shopify',
    shop_domain: shop,
    tags: order.tags || '',
    notes: order.note || '',
    tracking_number: trackingNumber,
    tracking_url: trackingUrl,
    tracking_company: trackingCompany,
  };
}

async function forwardOrder(payload, label) {
  console.log(`  📤 Forwarding [${label}]: order=${payload.order_number}, shop=${payload.shop_domain}, phone='${payload.customer_phone}', amount=${payload.order_amount}, type=${payload.order_type}`);
  if (!CODVERIFY_BACKEND_URL || !INTERNAL_API_TOKEN) return;
  try {
    const res = await axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/webhook/order/new`, payload, {
      headers: { 'X-Internal-Token': INTERNAL_API_TOKEN, 'X-Shop-Domain': payload.shop_domain },
      timeout: 15000,
    });
    console.log(`  ✅ [${label}] forwarded — backend: ${JSON.stringify(res.data?.data || {})}`);
  } catch (err) {
    const status = err?.response?.status;
    const body = err?.response?.data;
    console.error(`  ❌ [${label}] forward FAILED`);
    console.error(`     Status: ${status}`);
    console.error(`     Body  : ${JSON.stringify(body || err.message)}`);
  }
}

app.post('/webhooks/orders/create', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);
  try {
    const shop = req.headers['x-shopify-shop-domain'];
    const payload = buildOrderPayload(req.body, shop);
    console.log(`  📦 orders/create: #${payload.order_number} from ${shop}`);
    await forwardOrder(payload, 'orders/create');
  } catch (err) { console.error('orders/create error:', err.message); }
});

app.post('/webhooks/orders/paid', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);
  try {
    const shop = req.headers['x-shopify-shop-domain'];
    const payload = buildOrderPayload(req.body, shop);
    console.log(`  📦 orders/paid: #${payload.order_number} from ${shop}`);
    await forwardOrder(payload, 'orders/paid');
  } catch (err) { console.error('orders/paid error:', err.message); }
});

app.post('/webhooks/orders/fulfilled', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);
  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'];
    let trackingNumber = '', trackingUrl = '', trackingCompany = '';
    if (order.fulfillments && order.fulfillments.length > 0) {
      const latest = order.fulfillments[order.fulfillments.length - 1];
      trackingNumber = latest.tracking_number || '';
      trackingUrl = latest.tracking_url || '';
      trackingCompany = latest.tracking_company || '';
    }
    if (CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
      await axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/webhook/order/delivery-update`, {
        store_order_id: String(order.id),
        delivery_status: 'shipped',
        tracking_number: trackingNumber,
        tracking_url: trackingUrl,
        tracking_company: trackingCompany,
      }, {
        headers: { 'X-Internal-Token': INTERNAL_API_TOKEN, 'X-Shop-Domain': shop },
        timeout: 15000,
      });
      console.log(`  ✅ Fulfillment update for order ${order.order_number} from ${shop}`);
    }
  } catch (err) { console.error('orders/fulfilled error:', err.message); }
});

app.post('/webhooks/orders/cancelled', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);
  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'];
    console.log(`  🚫 orders/cancelled: #${order.order_number} from ${shop}`);
    if (CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
      await axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/webhook/order/cancel`, {
        store_order_id: String(order.id),
        shop_domain: shop,
      }, {
        headers: { 'X-Internal-Token': INTERNAL_API_TOKEN, 'X-Shop-Domain': shop },
        timeout: 15000,
      }).catch(e => console.warn('  ⚠️ Cancel sync failed:', e?.response?.status));
    }
  } catch (err) { console.error('orders/cancelled error:', err.message); }
});

app.post('/webhooks/app/uninstalled', (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  const shop = req.headers['x-shopify-shop-domain'];
  console.log(`App uninstalled by shop: ${shop}`);
  tokenCache.delete(shop);
  shopAppRegistry.delete(shop);
  if (CODVERIFY_BACKEND_URL && INTERNAL_API_TOKEN) {
    axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/auth/shopify-uninstall`, { shop_domain: shop }, {
      headers: { 'X-Internal-Token': INTERNAL_API_TOKEN },
    }).catch(() => { });
  }
  res.sendStatus(200);
});

// Manual webhook (no HMAC check — from Shopify admin notification settings)
app.post('/webhooks/manual/orders/create', async (req, res) => {
  console.log(`\n🔔 ━━━ MANUAL WEBHOOK ━━━`);
  console.log(`  POST /webhooks/manual/orders/create`);
  console.log(`  Shop  : ${req.headers['x-shopify-shop-domain'] || req.body?.domain || '???'}`);
  console.log(`  Topic : orders/create`);
  console.log(`  Body  : ${JSON.stringify(req.body).length} bytes`);
  console.log(`  Time  : ${new Date().toISOString()}`);
  res.sendStatus(200);
  try {
    const shop = req.headers['x-shopify-shop-domain'] || req.body?.domain || '';
    const payload = buildOrderPayload(req.body, shop);
    console.log(`  📦 manual/create: #${payload.order_number} from ${shop}`);
    await forwardOrder(payload, 'manual/create');
  } catch (err) { console.error('manual/create error:', err.message); }
});


// ── Chatbot Script ─────────────────────────────────────────────────────
app.get('/chatbot/script.js', (req, res) => {
  const shop = req.query.shop || '';
  const backendUrl = CODVERIFY_BACKEND_URL || 'https://codverify.tech';
  res.setHeader('Content-Type', 'application/javascript');
  res.send(`
(function() {
  if (window.__codverify_chatbot_loaded) return;
  window.__codverify_chatbot_loaded = true;
  var shopDomain = ${JSON.stringify(shop)};
  var backendUrl = ${JSON.stringify(backendUrl)};
  fetch(backendUrl + '/api/v1/merchant-chat/config-by-shop?shop_domain=' + encodeURIComponent(shopDomain))
    .then(r => r.json())
    .then(data => {
      if (!data.success || !data.data?.enabled) return;
      var config = data.data;
      var iframe = document.createElement('iframe');
      iframe.id = 'codverify-chatbot-frame';
      iframe.src = backendUrl + '/chatbot/widget?merchant_id=' + config.merchant_id + '&api_key=' + config.api_key;
      iframe.style.cssText = 'position:fixed;bottom:20px;right:20px;width:380px;height:520px;border:none;border-radius:16px;z-index:99999;box-shadow:0 8px 32px rgba(0,0,0,0.16);display:none;';
      document.body.appendChild(iframe);
      var btn = document.createElement('button');
      btn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/></svg>';
      btn.style.cssText = 'position:fixed;bottom:20px;right:20px;width:56px;height:56px;border-radius:50%;border:none;cursor:pointer;z-index:100000;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(0,0,0,0.2);background:' + (config.primary_color || '#6366f1') + ';';
      btn.onclick = () => {
        var visible = iframe.style.display !== 'none';
        iframe.style.display = visible ? 'none' : 'block';
        btn.style.display = visible ? 'flex' : 'none';
      };
      document.body.appendChild(btn);
      window.addEventListener('message', e => {
        if (e.data === 'codverify-chatbot-close') { iframe.style.display = 'none'; btn.style.display = 'flex'; }
      });
    }).catch(() => {});
})();
  `);
});


// ── GDPR Mandatory Webhooks ────────────────────────────────────────────
app.post('/webhooks/gdpr/customers-redact', (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  const { shop_domain, customer } = req.body || {};
  console.log('[GDPR] customers-redact shop=' + shop_domain + ' customer=' + (customer && customer.id));
  if (CODVERIFY_BACKEND_URL) axios.post(`${CODVERIFY_BACKEND_URL}/api/v1/gdpr/customers-redact`, req.body, { headers: { 'X-Internal-Token': INTERNAL_API_TOKEN } }).catch(() => {});
  res.sendStatus(200);
});
app.post('/webhooks/gdpr/customers-data-request', (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  const { shop_domain, customer } = req.body || {};
  console.log('[GDPR] customers-data-request shop=' + shop_domain + ' customer=' + (customer && customer.id));
  res.sendStatus(200);
});
app.post('/webhooks/gdpr/shop-redact', (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  const { shop_domain } = req.body || {};
  console.log('[GDPR] shop-redact shop=' + shop_domain);
  res.sendStatus(200);
});


// ── Start ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  const appSummary = SHOPIFY_APPS.map((a, i) => `app[${i}] ${a.label || ''}: ${a.key ? '✅' : '❌'}`).join(' | ');
  console.log(`\n╔═══════════════════════════════════════════════════╗`);
  console.log(`║  CODVerify Shopify Plugin (Multi-App)             ║`);
  console.log(`╚═══════════════════════════════════════════════════╝`);
  console.log(`  PORT          : ${PORT}`);
  console.log(`  HOST          : ${HOST}`);
  console.log(`  BACKEND       : ${CODVERIFY_BACKEND_URL || '❌ NOT SET'}`);
  console.log(`  APPS LOADED   : ${SHOPIFY_APPS.length}`);
  console.log(`  ${appSummary}`);
  console.log(`  INTERNAL_TOKEN: ${INTERNAL_API_TOKEN ? '✅' : '❌ MISSING'}`);
  console.log(``);
  console.log(`  Install URL format:`);
  console.log(`  ${HOST}/auth?shop=STORE.myshopify.com&app=INDEX`);
  console.log(``);

  if (HOST && HOST.startsWith('https://')) {
    setInterval(() => {
      axios.get(`${HOST}/health`).catch(() => {});
    }, 5 * 60 * 1000);
    console.log(`  KEEP-ALIVE    : Pinging ${HOST}/health every 300s`);
  }
  console.log(`  Ready to receive webhooks.`);
  console.log(``);
});

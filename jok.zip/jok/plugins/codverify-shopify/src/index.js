/**
 * CODVerify Shopify Plugin v2.0
 * ─────────────────────────────
 * Complete rewrite — clean, production-ready.
 *
 * Flow:
 *   1. Merchant installs app → OAuth → access token saved in backend DB
 *   2. Merchant gets a secret key → enters it on codverify.tech dashboard
 *   3. Webhooks auto-registered → Shopify fires events → plugin forwards orders to backend
 *
 * Backend endpoints used:
 *   POST /api/v1/auth/shopify-generate-key     — save token + generate secret key
 *   POST /api/v1/auth/shopify-regenerate-key   — regenerate secret key
 *   GET  /api/v1/auth/shopify-connection-status — check if store is connected
 *   GET  /api/v1/auth/shopify-access-token      — get stored access token (encrypted)
 *   POST /api/v1/auth/shopify-uninstall         — handle app uninstall
 *   POST /api/v1/webhook/order/new              — forward new order
 *   POST /api/v1/webhook/order/delivery-update  — forward delivery update
 *
 * Auth: X-Internal-Token + X-Shop-Domain headers
 */

const express = require('express');
const axios = require('axios');
const crypto = require('crypto');

const app = express();

// ─── CRITICAL: Capture raw body for HMAC verification ─────────────────
// Must be the FIRST middleware. Shopify signs the raw body bytes.
app.use(express.json({
  limit: '5mb',
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  },
}));

// ─── Config from environment ──────────────────────────────────────────
const CFG = {
  SHOPIFY_API_KEY:    process.env.SHOPIFY_API_KEY    || '',
  SHOPIFY_API_SECRET: process.env.SHOPIFY_API_SECRET || '',
  SHOPIFY_SCOPES:     process.env.SHOPIFY_SCOPES     || 'read_orders,write_orders',
  HOST:               process.env.HOST               || 'http://localhost:3000',
  PORT:               parseInt(process.env.PORT || '3000', 10),
  BACKEND_URL:        process.env.CODVERIFY_BACKEND_URL || '',
  INTERNAL_TOKEN:     process.env.INTERNAL_API_TOKEN    || '',
  DASHBOARD_URL:      process.env.CODVERIFY_DASHBOARD_URL || 'https://codverify.tech/dashboard',
  WEBSITE_URL:        process.env.CODVERIFY_WEBSITE_URL   || 'https://codverify.tech',
  API_VERSION:        '2025-04',
  KEEP_ALIVE_MS:      5 * 60 * 1000, // 5 minutes (Render sleeps after 15 min)
};

// In-memory caches (survive until process restart)
const oauthStates  = new Map(); // shop → { state, ts }
const tokenCache   = new Map(); // shop → accessToken
const keyCache     = new Map(); // shop → secretKey (temporary display)

// Cleanup stale OAuth states every 10 min
setInterval(() => {
  const cutoff = Date.now() - 10 * 60 * 1000;
  for (const [shop, d] of oauthStates) {
    if (d.ts < cutoff) oauthStates.delete(shop);
  }
}, 10 * 60 * 1000);


// ═══════════════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════

/** Call backend with internal token auth */
async function backendCall(method, path, data, extraHeaders = {}) {
  if (!CFG.BACKEND_URL || !CFG.INTERNAL_TOKEN) {
    throw new Error('Backend not configured (CODVERIFY_BACKEND_URL or INTERNAL_API_TOKEN missing)');
  }
  const url = `${CFG.BACKEND_URL}${path}`;
  const headers = {
    'X-Internal-Token': CFG.INTERNAL_TOKEN,
    'Content-Type': 'application/json',
    ...extraHeaders,
  };
  const config = { method, url, headers, timeout: 15000 };
  if (data && (method === 'post' || method === 'put')) config.data = data;
  if (data && method === 'get') config.params = data;
  return axios(config);
}

/** Verify Shopify OAuth callback HMAC (query string based) */
function verifyOAuthHmac(query) {
  const { hmac, ...params } = query;
  if (!hmac) return false;
  const msg = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join('&');
  const expected = crypto.createHmac('sha256', CFG.SHOPIFY_API_SECRET).update(msg).digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(hmac, 'hex'));
  } catch {
    return false;
  }
}

/** Verify Shopify webhook HMAC (body based, base64) */
function verifyWebhookHmac(req) {
  const hmacHeader = req.headers['x-shopify-hmac-sha256'];
  if (!hmacHeader) {
    console.error('  ❌ HMAC FAIL: No x-shopify-hmac-sha256 header present');
    return false;
  }
  if (!CFG.SHOPIFY_API_SECRET) {
    console.error('  ❌ HMAC FAIL: SHOPIFY_API_SECRET env var is empty');
    return false;
  }

  const body = req.rawBody || Buffer.from(JSON.stringify(req.body));
  const computed = crypto.createHmac('sha256', CFG.SHOPIFY_API_SECRET).update(body).digest('base64');

  try {
    const valid = crypto.timingSafeEqual(
      Buffer.from(computed, 'base64'),
      Buffer.from(hmacHeader, 'base64')
    );
    if (valid) {
      console.log('  ✅ HMAC verification passed');
    } else {
      console.error('  ❌ HMAC FAIL: Signature mismatch');
      console.error(`     Expected : ${computed}`);
      console.error(`     Received : ${hmacHeader}`);
      console.error(`     Body size: ${body.length} bytes, rawBody: ${!!req.rawBody}`);
    }
    return valid;
  } catch (e) {
    console.error(`  ❌ HMAC ERROR: ${e.message}`);
    return false;
  }
}

/** Extract a clean order payload from Shopify order data */
function buildOrderPayload(order, shop) {
  const gateway = order.gateway || (order.payment_gateway_names || [])[0] || '';
  const isCod = /cod|cash/i.test(gateway) ||
    (order.tags && /cod/i.test(order.tags));
  const orderType = isCod ? 'cod' : 'prepaid';

  const items = (order.line_items || []).map(i => ({
    name: i.title || i.name || 'Unknown',
    quantity: i.quantity || 1,
    price: parseFloat(i.price) || 0,
    image_url: i.image?.src || null,
  }));

  // Get tracking from fulfillments
  let tracking = { number: '', url: '', company: '' };
  if (order.fulfillments?.length) {
    const latest = order.fulfillments[order.fulfillments.length - 1];
    tracking = {
      number: latest.tracking_number || '',
      url: latest.tracking_url || '',
      company: latest.tracking_company || '',
    };
  }

  // Phone: try customer → shipping → billing → order root
  const phone = order.customer?.phone
    || order.shipping_address?.phone
    || order.billing_address?.phone
    || order.phone
    || '';

  return {
    store_order_id: String(order.id),
    order_number: String(order.order_number || order.name || order.id),
    customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || order.shipping_address?.name || 'Customer',
    customer_phone: phone,
    customer_email: order.customer?.email || order.email || '',
    order_amount: parseFloat(order.total_price) || 0,
    currency: order.currency || 'INR',
    payment_method: isCod ? 'cod' : (gateway || 'prepaid'),
    order_type: orderType,
    fulfillment_status: order.fulfillment_status || 'unfulfilled',
    products: items,
    shipping_address: order.shipping_address ? {
      line1: order.shipping_address.address1 || '',
      line2: order.shipping_address.address2 || '',
      city: order.shipping_address.city || '',
      state: order.shipping_address.province || '',
      pincode: order.shipping_address.zip || '',
      country: order.shipping_address.country_code || order.shipping_address.country || '',
    } : null,
    source: 'shopify',
    shop_domain: shop,
    tags: order.tags || '',
    notes: order.note || '',
    tracking_number: tracking.number,
    tracking_url: tracking.url,
    tracking_company: tracking.company,
  };
}

/** Forward order to backend */
async function forwardOrder(payload, label) {
  console.log(`  📤 Forwarding ${label}: order=${payload.order_number}, shop=${payload.shop_domain}, phone='${payload.customer_phone}', amount=${payload.order_amount}, type=${payload.order_type}`);

  try {
    const res = await backendCall('post', '/api/v1/webhook/order/new', payload, {
      'X-Shop-Domain': payload.shop_domain,
    });
    console.log(`  ✅ ${label} forwarded — backend: ${JSON.stringify(res.data?.data || {})}`);
    return { success: true, data: res.data };
  } catch (err) {
    const status = err?.response?.status;
    const body = err?.response?.data;
    console.error(`  ❌ ${label} forward FAILED`);
    console.error(`     Status: ${status}`);
    console.error(`     Body  : ${JSON.stringify(body || err.message)}`);

    if (status === 401) console.error('     → Auth failed: X-Internal-Token or X-Shop-Domain mismatch. Is the store connected on codverify.tech?');
    if (status === 402) console.error('     → No active subscription or quota exceeded');
    if (status === 409) console.error('     → Duplicate order (already in DB — this is OK)');
    if (status === 422) console.error('     → Validation error: check store_order_id and order_amount > 0');

    return { success: false, status, error: body || err.message };
  }
}

/** Get access token — memory cache → backend DB */
async function getAccessToken(shop) {
  let token = tokenCache.get(shop);
  if (token) return token;

  try {
    const res = await backendCall('get', '/api/v1/auth/shopify-access-token', { shop_domain: shop });
    token = res.data?.data?.access_token;
    if (token) {
      tokenCache.set(shop, token);
      console.log(`  ✅ Token retrieved from backend for ${shop} (source: ${res.data?.data?.source})`);
    }
    return token;
  } catch (err) {
    console.error(`  ❌ Token fetch failed for ${shop}: ${err?.response?.data?.detail || err.message}`);
    return null;
  }
}

/** Register the chatbot ScriptTag so Shopify injects it on every storefront page automatically */
async function registerScriptTag(shop, accessToken) {
  const apiBase = `https://${shop}/admin/api/${CFG.API_VERSION}`;
  const headers = { 'X-Shopify-Access-Token': accessToken };
  const scriptSrc = `${CFG.HOST}/chatbot/script.js?shop=${encodeURIComponent(shop)}`;

  console.log(`\n🤖 ━━━ REGISTERING CHATBOT SCRIPT TAG ━━━`);
  console.log(`   src: ${scriptSrc}`);

  // Remove any existing CODVerify script tags first (idempotent)
  try {
    const existing = await axios.get(`${apiBase}/script_tags.json`, { headers });
    for (const tag of (existing.data?.script_tags || [])) {
      if (tag.src && tag.src.includes('codverify')) {
        await axios.delete(`${apiBase}/script_tags/${tag.id}.json`, { headers });
        console.log(`   🗑️ Removed old script tag id=${tag.id}`);
      }
    }
  } catch (e) {
    console.warn(`   ⚠️ Could not list/remove old script tags: ${e?.response?.status || e.message}`);
  }

  // Register fresh script tag
  try {
    const result = await axios.post(`${apiBase}/script_tags.json`, {
      script_tag: {
        event: 'onload',
        src: scriptSrc,
        display_scope: 'online_store',
      },
    }, { headers });
    const id = result.data?.script_tag?.id;
    console.log(`   ✅ Script tag registered (id: ${id})`);
    return true;
  } catch (e) {
    // 422 = already exists with same src
    if (e?.response?.status === 422) {
      console.log(`   ℹ️ Script tag already registered`);
      return true;
    }
    console.error(`   ❌ Script tag FAILED: ${e?.response?.status} — ${JSON.stringify(e?.response?.data || e.message)}`);
    return false;
  }
}

/** Register all webhooks for a shop */
async function registerWebhooks(shop, accessToken) {
  const apiBase = `https://${shop}/admin/api/${CFG.API_VERSION}`;
  const headers = { 'X-Shopify-Access-Token': accessToken };

  console.log(`\n🔧 ━━━ REGISTERING WEBHOOKS ━━━`);
  console.log(`   Shop: ${shop}`);
  console.log(`   HOST: ${CFG.HOST}`);

  const topics = [
    { topic: 'orders/create',    address: `${CFG.HOST}/webhooks/orders/create` },
    { topic: 'orders/paid',      address: `${CFG.HOST}/webhooks/orders/paid` },
    { topic: 'orders/fulfilled', address: `${CFG.HOST}/webhooks/orders/fulfilled` },
    { topic: 'app/uninstalled',  address: `${CFG.HOST}/webhooks/app/uninstalled` },
  ];

  // Step 1: Delete all existing webhooks (clean slate)
  try {
    const existing = await axios.get(`${apiBase}/webhooks.json`, { headers });
    const whs = existing.data?.webhooks || [];
    console.log(`   Found ${whs.length} existing webhooks — removing...`);
    for (const wh of whs) {
      try {
        await axios.delete(`${apiBase}/webhooks/${wh.id}.json`, { headers });
        console.log(`   🗑️ Deleted: ${wh.topic} → ${wh.address}`);
      } catch (e) {
        console.warn(`   ⚠️ Could not delete webhook ${wh.id}: ${e.message}`);
      }
    }
  } catch (e) {
    console.warn(`   ⚠️ Could not list webhooks: ${e?.response?.status || e.message}`);
  }

  // Step 2: Register fresh webhooks
  let ok = 0;
  for (const wh of topics) {
    try {
      const result = await axios.post(`${apiBase}/webhooks.json`, {
        webhook: { topic: wh.topic, address: wh.address, format: 'json' },
      }, { headers });
      const id = result.data?.webhook?.id;
      console.log(`   ✅ ${wh.topic} → ${wh.address} (id: ${id})`);
      ok++;
    } catch (e) {
      if (e?.response?.status === 422) {
        console.log(`   ℹ️ ${wh.topic} already exists`);
        ok++;
      } else {
        console.error(`   ❌ ${wh.topic} FAILED: ${e?.response?.status} — ${JSON.stringify(e?.response?.data || e.message)}`);
      }
    }
  }
  console.log(`   📊 Result: ${ok}/${topics.length} webhooks active\n`);
  return ok;
}


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: Health & Root
// ═══════════════════════════════════════════════════════════════════════

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'codverify-shopify',
    uptime: Math.floor(process.uptime()),
    cached_shops: tokenCache.size,
  });
});

app.get('/', (req, res) => {
  req.query.shop
    ? res.redirect(`/app?shop=${encodeURIComponent(req.query.shop)}`)
    : res.redirect('/health');
});


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: OAuth
// ═══════════════════════════════════════════════════════════════════════

app.get('/auth', (req, res) => {
  const shop = req.query.shop;
  if (!shop) return res.status(400).send('Missing shop parameter');

  const state = crypto.randomBytes(16).toString('hex');
  oauthStates.set(shop, { state, ts: Date.now() });

  const authUrl = `https://${shop}/admin/oauth/authorize?` + new URLSearchParams({
    client_id: CFG.SHOPIFY_API_KEY,
    scope: CFG.SHOPIFY_SCOPES,
    redirect_uri: `${CFG.HOST}/auth/callback`,
    state,
  }).toString();

  console.log(`🔐 OAuth initiated for ${shop}`);
  res.redirect(authUrl);
});


app.get('/auth/callback', async (req, res) => {
  const { shop, code, state } = req.query;
  console.log(`\n🔐 ━━━ OAuth Callback ━━━ shop=${shop}`);

  // Verify HMAC
  if (!verifyOAuthHmac(req.query)) {
    console.error('  ❌ OAuth HMAC verification failed');
    return res.status(403).send('HMAC verification failed');
  }

  // Verify state
  const stored = oauthStates.get(shop);
  if (!stored || stored.state !== state) {
    console.error('  ❌ Invalid OAuth state');
    return res.status(403).send('Invalid state parameter');
  }
  oauthStates.delete(shop);

  // ── Step 1: Exchange code for access token (MUST succeed) ──
  let accessToken;
  try {
    const tokenRes = await axios.post(`https://${shop}/admin/oauth/access_token`, {
      client_id: CFG.SHOPIFY_API_KEY,
      client_secret: CFG.SHOPIFY_API_SECRET,
      code,
    });
    accessToken = tokenRes.data.access_token;
    tokenCache.set(shop, accessToken);
    console.log(`  ✅ Step 1: Access token obtained (offline token)`);
  } catch (err) {
    console.error(`  ❌ Step 1: Token exchange failed: ${err?.response?.data?.error || err.message}`);
    return res.status(500).send('OAuth failed — could not get access token. Please try again.');
  }

  // ── Step 2: Get shop details (non-fatal) ──
  let shopData = { name: shop, email: '', id: '' };
  try {
    const shopRes = await axios.get(`https://${shop}/admin/api/${CFG.API_VERSION}/shop.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken },
    });
    shopData = shopRes.data.shop;
    console.log(`  ✅ Step 2: Shop details — ${shopData.name} (${shopData.email})`);
  } catch (err) {
    console.warn(`  ⚠️ Step 2: Shop details failed (non-fatal): ${err?.response?.status}`);
  }

  // ── Step 3: Save token + generate secret key via backend (non-fatal) ──
  let secretKey = '';
  try {
    const keyRes = await backendCall('post', '/api/v1/auth/shopify-generate-key', {
      shop_domain: shop,
      shop_name: shopData.name || shop,
      shop_email: shopData.email || '',
      shopify_shop_id: String(shopData.id || ''),
      access_token: accessToken,
    });
    secretKey = keyRes.data?.data?.secret_key || '';
    const alreadyConnected = keyRes.data?.data?.is_already_connected || false;
    if (secretKey) keyCache.set(shop, secretKey);
    console.log(`  ✅ Step 3: Backend key — ${alreadyConnected ? 'already connected' : `key=${secretKey}`}`);
  } catch (err) {
    console.error(`  ❌ Step 3: Backend generate-key failed: ${err?.response?.status} — ${JSON.stringify(err?.response?.data || err.message)}`);
  }

  // ── Step 4: Register webhooks (CRITICAL) ──
  try {
    const count = await registerWebhooks(shop, accessToken);
    console.log(`  ✅ Step 4: Webhooks registered (${count}/4)`);
  } catch (err) {
    console.error(`  ❌ Step 4: Webhook registration failed: ${err.message}`);
  }

  // ── Step 4b: Register chatbot ScriptTag (auto-inject on storefront) ──
  try {
    await registerScriptTag(shop, accessToken);
    console.log(`  ✅ Step 4b: Chatbot ScriptTag registered`);
  } catch (err) {
    console.error(`  ❌ Step 4b: ScriptTag failed (non-critical): ${err.message}`);
  }

  // ── Step 5: Redirect to app page ──
  res.redirect(`/app?shop=${encodeURIComponent(shop)}&setup=1`);
});


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: Setup & Debug
// ═══════════════════════════════════════════════════════════════════════

/** Auto-register webhooks + auto-reconnect (admin/debug endpoint) */
app.get('/setup/auto-register', async (req, res) => {
  const { shop, token } = req.query;
  if (token !== CFG.INTERNAL_TOKEN) return res.status(401).json({ success: false, message: 'Unauthorized' });
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop param' });

  console.log(`\n🔧 Auto-register triggered for ${shop}`);

  const accessToken = await getAccessToken(shop);
  if (!accessToken) {
    return res.status(400).json({ success: false, message: 'No access token found. Reinstall the app from Shopify.' });
  }

  // Step 0: Trigger auto-reconnect on backend (re-links store after uninstall+reinstall)
  let reconnectResult = null;
  try {
    const recon = await backendCall('post', '/api/v1/auth/shopify-generate-key', {
      shop_domain: shop,
      shop_name: shop,
      shop_email: '',
      shopify_shop_id: '',
      access_token: accessToken,
    });
    reconnectResult = recon.data?.data || {};
    console.log(`  🔗 Reconnect check: ${JSON.stringify(reconnectResult)}`);
  } catch (err) {
    console.warn(`  ⚠️ Reconnect check failed (non-fatal): ${err?.response?.status} — ${err?.response?.data?.detail || err.message}`);
  }

  try {
    await registerWebhooks(shop, accessToken);
    await registerScriptTag(shop, accessToken);

    // Verify
    const verify = await axios.get(`https://${shop}/admin/api/${CFG.API_VERSION}/webhooks.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken },
    });
    const webhooks = (verify.data?.webhooks || []).map(w => ({
      id: w.id, topic: w.topic, address: w.address,
    }));

    return res.json({ success: true, message: `Webhooks registered for ${shop}`, webhooks, reconnect: reconnectResult });
  } catch (err) {
    console.error(`  ❌ Auto-register failed: ${err?.response?.data || err.message}`);
    return res.status(500).json({ success: false, message: err.message });
  }
});


/** Manual webhook registration (POST with body) */
app.post('/setup/webhooks', async (req, res) => {
  if (req.headers['x-internal-token'] !== CFG.INTERNAL_TOKEN) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  const shop = req.body.shop || '';
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  const accessToken = await getAccessToken(shop);
  if (!accessToken) {
    return res.status(400).json({ success: false, message: 'No access token. Reinstall app.' });
  }

  try {
    await registerWebhooks(shop, accessToken);
    await registerScriptTag(shop, accessToken);
    return res.json({ success: true, message: 'Webhooks registered' });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});


/** Debug: show config (no secrets) */
app.get('/debug/config', (_req, res) => {
  res.json({
    host: CFG.HOST,
    api_version: CFG.API_VERSION,
    has_api_key: !!CFG.SHOPIFY_API_KEY,
    has_api_secret: !!CFG.SHOPIFY_API_SECRET,
    has_backend_url: !!CFG.BACKEND_URL,
    backend_url: CFG.BACKEND_URL ? CFG.BACKEND_URL.replace(/\/\/(.{3}).*@/, '//$1***@') : 'NOT SET',
    has_internal_token: !!CFG.INTERNAL_TOKEN,
    scopes: CFG.SHOPIFY_SCOPES,
    cached_shops: Array.from(tokenCache.keys()),
    uptime: Math.floor(process.uptime()),
    webhook_addresses: {
      'orders/create': `${CFG.HOST}/webhooks/orders/create`,
      'orders/paid': `${CFG.HOST}/webhooks/orders/paid`,
      'orders/fulfilled': `${CFG.HOST}/webhooks/orders/fulfilled`,
      'app/uninstalled': `${CFG.HOST}/webhooks/app/uninstalled`,
    },
  });
});


/** Debug: list registered webhooks from Shopify */
app.get('/debug/webhooks', async (req, res) => {
  const { shop, token } = req.query;
  if (token !== CFG.INTERNAL_TOKEN) return res.status(401).json({ success: false, message: 'Unauthorized' });
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop param' });

  const accessToken = await getAccessToken(shop);
  if (!accessToken) return res.status(400).json({ success: false, message: 'No access token found' });

  try {
    const result = await axios.get(`https://${shop}/admin/api/${CFG.API_VERSION}/webhooks.json`, {
      headers: { 'X-Shopify-Access-Token': accessToken },
    });
    const webhooks = (result.data?.webhooks || []).map(w => ({
      id: w.id, topic: w.topic, address: w.address, created_at: w.created_at,
    }));
    return res.json({ success: true, shop, count: webhooks.length, webhooks });
  } catch (err) {
    return res.status(500).json({ success: false, error: err?.response?.data || err.message });
  }
});


/** Test: create a fake order (bypasses Shopify webhooks entirely) */
app.post('/test/create-order', async (req, res) => {
  if (req.headers['x-internal-token'] !== CFG.INTERNAL_TOKEN) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }

  const shop = req.body.shop || 'yoursmiless.myshopify.com';
  const payload = {
    store_order_id: `TEST-${Date.now()}`,
    order_number: `#TEST-${Math.floor(Math.random() * 10000)}`,
    customer_name: req.body.customer_name || 'Test Customer',
    customer_phone: req.body.customer_phone || '+919999999999',
    customer_email: req.body.customer_email || 'test@example.com',
    order_amount: req.body.order_amount || 999,
    currency: 'INR',
    payment_method: req.body.payment_method || 'cod',
    order_type: req.body.order_type || 'cod',
    fulfillment_status: 'unfulfilled',
    products: [{ name: 'Test Product', quantity: 1, price: req.body.order_amount || 999 }],
    shipping_address: { line1: '123 Test Street', city: 'Mumbai', state: 'Maharashtra', pincode: '400001', country: 'IN' },
    source: 'shopify',
    shop_domain: shop,
    tags: 'test-order',
    notes: 'Created via /test/create-order endpoint',
  };

  console.log(`\n🧪 ━━━ TEST ORDER ━━━ shop=${shop}`);
  const result = await forwardOrder(payload, '[TEST]');

  if (result.success) {
    return res.json({ success: true, message: 'Test order created', backend: result.data });
  } else {
    return res.status(result.status || 500).json({
      success: false,
      message: 'Backend rejected test order',
      error: result.error,
      status: result.status,
    });
  }
});


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: Key Management
// ═══════════════════════════════════════════════════════════════════════

app.post('/regenerate-key', async (req, res) => {
  const shop = req.body.shop || '';
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  try {
    const result = await backendCall('post', '/api/v1/auth/shopify-regenerate-key', { shop_domain: shop });
    const newKey = result.data?.data?.secret_key || '';
    const alreadyConnected = result.data?.data?.is_already_connected || false;
    if (newKey) keyCache.set(shop, newKey);
    return res.json({ success: true, secret_key: newKey, is_already_connected: alreadyConnected });
  } catch (err) {
    console.error('Regenerate key failed:', err?.response?.data || err.message);
    return res.status(500).json({ success: false, message: 'Failed to regenerate key. Please try again.' });
  }
});


/** Force-regenerate key — bypasses "already connected" check, for re-linking after account deletion/reset */
app.post('/regenerate-key-force', async (req, res) => {
  const shop = req.body.shop || '';
  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  try {
    const result = await backendCall('post', '/api/v1/auth/shopify-force-new-key', { shop_domain: shop });
    const newKey = result.data?.data?.secret_key || '';
    if (newKey) keyCache.set(shop, newKey);
    return res.json({ success: true, secret_key: newKey });
  } catch (err) {
    console.error('Force regenerate key failed:', err?.response?.data || err.message);
    return res.status(500).json({ success: false, message: err?.response?.data?.detail || 'Failed to generate new code. Please try again.' });
  }
});


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: App Page (merchant-facing UI)
// ═══════════════════════════════════════════════════════════════════════

app.get('/app', async (req, res) => {
  const shop = req.query.shop || '';
  let isConnected = false;
  let secretKey = keyCache.get(shop) || '';
  let storeName = shop;

  if (shop) {
    try {
      const statusRes = await backendCall('get', '/api/v1/auth/shopify-connection-status', { shop_domain: shop });
      const d = statusRes.data?.data || {};
      isConnected = d.is_connected || false;
      storeName = d.shop_name || shop;
      if (!secretKey && d.secret_key) secretKey = d.secret_key;
    } catch (_) { /* non-fatal */ }
  }

  const ws = CFG.WEBSITE_URL;
  res.send(buildAppPage(shop, storeName, isConnected, secretKey, ws, CFG.HOST));
});


// ═══════════════════════════════════════════════════════════════════════
// WEBHOOKS: Logging Middleware (MUST be BEFORE webhook route handlers)
// ═══════════════════════════════════════════════════════════════════════

app.use('/webhooks', (req, _res, next) => {
  console.log(`\n🔔 ━━━ INCOMING WEBHOOK ━━━`);
  console.log(`  ${req.method} ${req.originalUrl}`);
  console.log(`  Shop  : ${req.headers['x-shopify-shop-domain'] || '???'}`);
  console.log(`  Topic : ${req.headers['x-shopify-topic'] || '???'}`);
  console.log(`  HMAC  : ${req.headers['x-shopify-hmac-sha256'] ? 'present (' + req.headers['x-shopify-hmac-sha256'].substring(0, 12) + '...)' : '❌ MISSING'}`);
  console.log(`  Body  : ${req.rawBody ? req.rawBody.length + ' bytes (rawBody)' : (req.body ? JSON.stringify(req.body).length + ' bytes (parsed)' : '⚠️ EMPTY')}`);
  console.log(`  Time  : ${new Date().toISOString()}`);
  next();
});


// ═══════════════════════════════════════════════════════════════════════
// WEBHOOKS: Route Handlers
// ═══════════════════════════════════════════════════════════════════════

/** orders/create — fires on every new order (COD, manual, prepaid) */
app.post('/webhooks/orders/create', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200); // Respond immediately — Shopify expects < 5 sec

  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';
    console.log(`  📦 orders/create: #${order.order_number || order.name} from ${shop}`);

    const payload = buildOrderPayload(order, shop);
    await forwardOrder(payload, '[orders/create]');
  } catch (err) {
    console.error(`  ❌ orders/create processing error: ${err.message}`);
  }
});


/** orders/paid — fires when payment is captured */
app.post('/webhooks/orders/paid', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);

  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';
    console.log(`  📦 orders/paid: #${order.order_number || order.name} from ${shop}`);

    const payload = buildOrderPayload(order, shop);
    await forwardOrder(payload, '[orders/paid]');
  } catch (err) {
    console.error(`  ❌ orders/paid processing error: ${err.message}`);
  }
});


/** orders/fulfilled — fires when order is fulfilled (tracking info) */
app.post('/webhooks/orders/fulfilled', async (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);

  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';

    let tracking = { number: '', url: '', company: '' };
    if (order.fulfillments?.length) {
      const latest = order.fulfillments[order.fulfillments.length - 1];
      tracking = {
        number: latest.tracking_number || '',
        url: latest.tracking_url || '',
        company: latest.tracking_company || '',
      };
    }

    console.log(`  📦 orders/fulfilled: #${order.order_number || order.name} from ${shop} — tracking: ${tracking.number || 'none'}`);

    await backendCall('post', '/api/v1/webhook/order/delivery-update', {
      store_order_id: String(order.id),
      delivery_status: 'shipped',
      tracking_number: tracking.number,
      tracking_url: tracking.url,
      tracking_company: tracking.company,
    }, { 'X-Shop-Domain': shop });

    console.log(`  ✅ Fulfillment update forwarded`);
  } catch (err) {
    console.error(`  ❌ orders/fulfilled error: ${err?.response?.data || err.message}`);
  }
});


/** app/uninstalled — cleanup on uninstall */
app.post('/webhooks/app/uninstalled', (req, res) => {
  if (!verifyWebhookHmac(req)) return res.sendStatus(401);
  res.sendStatus(200);

  const shop = req.headers['x-shopify-shop-domain'] || '';
  console.log(`  🗑️ App uninstalled by: ${shop}`);
  tokenCache.delete(shop);
  keyCache.delete(shop);

  backendCall('post', '/api/v1/auth/shopify-uninstall', { shop_domain: shop }).catch(() => {});
});


/** Verification status callback (from backend → plugin) */
app.post('/webhooks/verification/status', (req, res) => {
  if (req.headers['x-internal-token'] !== CFG.INTERNAL_TOKEN) return res.sendStatus(401);
  console.log(`  Verification update: ${req.body.store_order_id} → ${req.body.status}`);
  res.json({ success: true });
});


// ═══════════════════════════════════════════════════════════════════════
// MANUAL WEBHOOKS (For merchants adding webhooks via Shopify Admin)
// ═══════════════════════════════════════════════════════════════════════
// These endpoints skip HMAC verification because manually-added webhooks
// are signed with the store's own secret, not the app's API secret.
// Security: Backend validates store connection and rejects unlinked shops.

app.use('/webhooks/manual', (req, _res, next) => {
  console.log(`\n🔔 ━━━ MANUAL WEBHOOK ━━━`);
  console.log(`  ${req.method} ${req.originalUrl}`);
  console.log(`  Shop  : ${req.headers['x-shopify-shop-domain'] || '???'}`);
  console.log(`  Topic : ${req.headers['x-shopify-topic'] || '???'}`);
  console.log(`  Body  : ${req.rawBody ? req.rawBody.length + ' bytes' : (req.body ? JSON.stringify(req.body).length + ' bytes' : '⚠️ EMPTY')}`);
  console.log(`  Time  : ${new Date().toISOString()}`);
  next();
});

app.post('/webhooks/manual/orders/create', async (req, res) => {
  res.sendStatus(200);
  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';
    if (!shop || !order?.id) { console.error('  ❌ Missing shop or order.id'); return; }
    console.log(`  📦 manual/create: #${order.order_number || order.name} from ${shop}`);
    const payload = buildOrderPayload(order, shop);
    await forwardOrder(payload, '[manual/create]');
  } catch (err) {
    console.error(`  ❌ manual/create error: ${err.message}`);
  }
});

app.post('/webhooks/manual/orders/paid', async (req, res) => {
  res.sendStatus(200);
  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';
    if (!shop || !order?.id) { console.error('  ❌ Missing shop or order.id'); return; }
    console.log(`  📦 manual/paid: #${order.order_number || order.name} from ${shop}`);
    const payload = buildOrderPayload(order, shop);
    await forwardOrder(payload, '[manual/paid]');
  } catch (err) {
    console.error(`  ❌ manual/paid error: ${err.message}`);
  }
});

app.post('/webhooks/manual/orders/fulfilled', async (req, res) => {
  res.sendStatus(200);
  try {
    const order = req.body;
    const shop = req.headers['x-shopify-shop-domain'] || '';
    if (!shop || !order?.id) { console.error('  ❌ Missing shop or order.id'); return; }
    let tracking = { number: '', url: '', company: '' };
    if (order.fulfillments?.length) {
      const latest = order.fulfillments[order.fulfillments.length - 1];
      tracking = { number: latest.tracking_number || '', url: latest.tracking_url || '', company: latest.tracking_company || '' };
    }
    console.log(`  📦 manual/fulfilled: #${order.order_number || order.name} from ${shop} — tracking: ${tracking.number || 'none'}`);
    await backendCall('post', '/api/v1/webhook/order/delivery-update', {
      store_order_id: String(order.id),
      delivery_status: 'shipped',
      tracking_number: tracking.number,
      tracking_url: tracking.url,
      tracking_company: tracking.company,
    }, { 'X-Shop-Domain': shop });
    console.log(`  ✅ Manual fulfillment forwarded`);
  } catch (err) {
    console.error(`  ❌ manual/fulfilled error: ${err?.response?.data || err.message}`);
  }
});


// ═══════════════════════════════════════════════════════════════════════
// CHATBOT SCRIPT
// ═══════════════════════════════════════════════════════════════════════

app.get('/chatbot/script.js', (req, res) => {
  const shop = req.query.shop || '';
  const backendUrl = CFG.BACKEND_URL || 'https://codverify.tech';
  res.setHeader('Content-Type', 'application/javascript');
  res.send(`
(function(){
  if(window.__codverify_loaded)return;
  window.__codverify_loaded=true;
  var s=${JSON.stringify(shop)},b=${JSON.stringify(backendUrl)};
  fetch(b+'/api/v1/merchant-chat/config-by-shop?shop_domain='+encodeURIComponent(s))
    .then(function(r){return r.json()})
    .then(function(d){
      if(!d.success||!d.data||!d.data.enabled)return;
      var c=d.data,f=document.createElement('iframe');
      f.id='codverify-chatbot';
      f.src=b+'/chatbot/widget?merchant_id='+c.merchant_id+'&api_key='+c.api_key;
      f.style.cssText='position:fixed;bottom:20px;right:20px;width:380px;height:520px;border:none;border-radius:16px;z-index:99999;box-shadow:0 8px 32px rgba(0,0,0,.16);display:none;';
      document.body.appendChild(f);
      var btn=document.createElement('button');
      btn.innerHTML='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/></svg>';
      btn.style.cssText='position:fixed;bottom:20px;right:20px;width:56px;height:56px;border-radius:50%;border:none;cursor:pointer;z-index:100000;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(0,0,0,.2);background:'+(c.primary_color||'#6366f1')+';';
      btn.onclick=function(){var v=f.style.display!=='none';f.style.display=v?'none':'block';btn.style.display=v?'flex':'none';};
      document.body.appendChild(btn);
      window.addEventListener('message',function(e){if(e.data==='codverify-chatbot-close'){f.style.display='none';btn.style.display='flex';}});
    }).catch(function(){});
})();
  `);
});


// ═══════════════════════════════════════════════════════════════════════
// ROUTES: Order Sync (Manual Pull from Shopify REST API)
// ═══════════════════════════════════════════════════════════════════════

app.post('/sync/orders', async (req, res) => {
  if (req.headers['x-internal-token'] !== CFG.INTERNAL_TOKEN) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }

  const shop = req.body.shop || '';
  const limit = Math.min(parseInt(req.body.limit) || 50, 250);
  const sinceId = req.body.since_id || null;
  const createdAtMin = req.body.created_at_min || null;

  if (!shop) return res.status(400).json({ success: false, message: 'Missing shop' });

  console.log(`\n🔄 ━━━ ORDER SYNC ━━━ shop=${shop}, limit=${limit}`);

  const accessToken = await getAccessToken(shop);
  if (!accessToken) {
    return res.status(400).json({ success: false, message: 'No access token found. Reinstall the app.' });
  }

  try {
    const stats = { total: 0, synced: 0, duplicates: 0, errors: 0 };
    let pageUrl = `https://${shop}/admin/api/${CFG.API_VERSION}/orders.json`;
    let params = { status: 'any', limit };
    if (sinceId) params.since_id = sinceId;
    if (createdAtMin) params.created_at_min = createdAtMin;

    let hasMore = true;
    let pageCount = 0;
    const maxPages = 10; // Safety limit

    while (hasMore && pageCount < maxPages) {
      pageCount++;
      console.log(`  📄 Fetching page ${pageCount}...`);

      const response = await axios.get(pageUrl, {
        headers: { 'X-Shopify-Access-Token': accessToken },
        params: pageCount === 1 ? params : undefined, // params only on first page
        timeout: 30000,
      });

      const orders = response.data?.orders || [];
      stats.total += orders.length;
      console.log(`  📦 Got ${orders.length} orders on page ${pageCount}`);

      // Forward each order to backend
      for (const order of orders) {
        try {
          const payload = buildOrderPayload(order, shop);
          const result = await forwardOrder(payload, `[sync-p${pageCount}]`);
          if (result.success) {
            stats.synced++;
          } else if (result.status === 409) {
            stats.duplicates++;
          } else {
            stats.errors++;
          }
        } catch (err) {
          stats.errors++;
          console.error(`  ❌ Sync error for order ${order.id}: ${err.message}`);
        }
      }

      // Check for pagination (Link header with rel="next")
      const linkHeader = response.headers?.link || '';
      const nextMatch = linkHeader.match(/<([^>]+)>;\s*rel="next"/);
      if (nextMatch && orders.length === limit) {
        pageUrl = nextMatch[1];
        params = undefined; // URL already has params
        hasMore = true;
      } else {
        hasMore = false;
      }
    }

    console.log(`  📊 Sync complete: ${JSON.stringify(stats)}`);
    return res.json({ success: true, stats, pages: pageCount });
  } catch (err) {
    console.error(`  ❌ Sync failed: ${err?.response?.status} — ${JSON.stringify(err?.response?.data || err.message)}`);
    if (err?.response?.status === 401) {
      return res.status(401).json({ success: false, message: 'Access token expired/revoked. Reinstall the app.', error: 'token_expired' });
    }
    return res.status(500).json({ success: false, message: err.message });
  }
});


// ═══════════════════════════════════════════════════════════════════════
// SERVER START
// ═══════════════════════════════════════════════════════════════════════

app.listen(CFG.PORT, () => {
  console.log(`\n╔═══════════════════════════════════════════════════╗`);
  console.log(`║  CODVerify Shopify Plugin v2.0                    ║`);
  console.log(`╚═══════════════════════════════════════════════════╝`);
  console.log(`  PORT          : ${CFG.PORT}`);
  console.log(`  HOST          : ${CFG.HOST}`);
  console.log(`  BACKEND       : ${CFG.BACKEND_URL || '❌ NOT SET'}`);
  console.log(`  API_KEY       : ${CFG.SHOPIFY_API_KEY ? '✅' : '❌ MISSING'}`);
  console.log(`  API_SECRET    : ${CFG.SHOPIFY_API_SECRET ? '✅' : '❌ MISSING'}`);
  console.log(`  INTERNAL_TOKEN: ${CFG.INTERNAL_TOKEN ? '✅' : '❌ MISSING'}`);
  console.log(`  API_VERSION   : ${CFG.API_VERSION}`);
  console.log('');

  // Keep-alive: prevent Render free tier from sleeping
  if (CFG.HOST.startsWith('https://')) {
    setInterval(() => {
      axios.get(`${CFG.HOST}/health`).catch(() => {});
    }, CFG.KEEP_ALIVE_MS);
    console.log(`  KEEP-ALIVE    : Pinging ${CFG.HOST}/health every ${CFG.KEEP_ALIVE_MS / 1000}s`);
  }
  console.log(`  Ready to receive webhooks.\n`);
});


// ═══════════════════════════════════════════════════════════════════════
// APP PAGE HTML BUILDER
// ═══════════════════════════════════════════════════════════════════════

function buildAppPage(shop, storeName, isConnected, secretKey, websiteUrl, hostUrl) {
  return `<!DOCTYPE html>
<html>
<head>
  <title>CODVerify — Store Connection</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;min-height:100vh}
    .wrap{max-width:620px;margin:0 auto;padding:40px 20px}
    .logo{text-align:center;margin-bottom:32px}
    .logo h1{font-size:28px;font-weight:800;color:#1e293b}
    .logo p{color:#64748b;margin-top:4px;font-size:14px}
    .card{background:#fff;border-radius:16px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,.08),0 4px 24px rgba(0,0,0,.04);border:1px solid #e2e8f0;margin-bottom:24px}
    .badge{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;border-radius:100px;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}
    .badge-ok{background:#dcfce7;color:#15803d}
    .badge-warn{background:#fef3c7;color:#a16207}
    .dot{width:8px;height:8px;border-radius:50%}
    .dot-g{background:#22c55e;animation:pulse 2s infinite}
    .dot-y{background:#eab308}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
    .key-box{background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:12px;padding:20px;text-align:center;margin:20px 0}
    .key-val{font-size:28px;font-weight:800;letter-spacing:3px;color:#4f46e5;font-family:'Courier New',monospace;user-select:all;margin:8px 0}
    .key-lbl{font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;letter-spacing:1px}
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:14px 28px;border-radius:12px;font-weight:700;font-size:15px;width:100%;margin-top:12px;cursor:pointer;text-decoration:none;transition:all .2s;border:none}
    .btn-pri{background:#4f46e5;color:#fff}.btn-pri:hover{background:#4338ca}
    .btn-sec{background:#fff;color:#4f46e5;border:2px solid #e0e7ff}.btn-sec:hover{background:#eef2ff}
    .btn-sm{padding:10px 20px;font-size:13px;width:auto;margin-top:8px;border-radius:8px}
    .center{text-align:center}
    .check-icon{width:64px;height:64px;background:#dcfce7;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
    .row{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid #f1f5f9}
    .row:last-child{border-bottom:none}
    .row-l{font-size:13px;color:#64748b;font-weight:500}
    .row-v{font-size:14px;color:#1e293b;font-weight:600}
    .steps{margin-top:24px}
    .step{display:flex;gap:16px;padding:16px 0;border-bottom:1px solid #f1f5f9}.step:last-child{border-bottom:none}
    .step-n{width:32px;height:32px;border-radius:50%;background:#eef2ff;color:#4f46e5;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
    .step h4{font-size:15px;font-weight:700;color:#1e293b;margin-bottom:4px}
    .step p{font-size:13px;color:#64748b;line-height:1.5}
    .note{text-align:center;margin-top:16px;font-size:12px;color:#94a3b8}
    .note a{color:#4f46e5;text-decoration:none;font-weight:600}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="logo">
      <h1>CODVerify</h1>
      <p>WhatsApp COD Verification & RTO Prevention</p>
    </div>

    ${isConnected ? `
    <div class="card center" style="padding:48px 32px">
      <div class="check-icon">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="3" stroke-linecap="round"><path d="M20 6L9 17l-5-5"/></svg>
      </div>
      <span class="badge badge-ok"><span class="dot dot-g"></span> Connected</span>
      <h2 style="font-size:22px;color:#1e293b;margin-top:16px">Store Connected!</h2>
      <p style="color:#64748b;margin-top:8px;font-size:14px">Your Shopify store is linked. All COD orders will be verified automatically.</p>
    </div>
    <div class="card">
      <h3 style="font-size:16px;color:#1e293b;margin-bottom:16px;font-weight:700">Store Details</h3>
      <div class="row"><span class="row-l">Store</span><span class="row-v">${storeName}</span></div>
      <div class="row"><span class="row-l">Domain</span><span class="row-v">${shop}</span></div>
      <div class="row"><span class="row-l">Status</span><span class="badge badge-ok" style="padding:4px 12px;font-size:11px"><span class="dot dot-g"></span> Connected</span></div>
      <div class="row"><span class="row-l">Webhooks</span><span class="row-v" style="color:#22c55e">Active</span></div>
      <a href="${websiteUrl}/dashboard" target="_blank" class="btn btn-pri">Open Dashboard ↗</a>
    </div>
    <div class="card">
      <h3 style="font-size:16px;color:#1e293b;margin-bottom:8px;font-weight:700">📌 Webhook Setup (Required)</h3>
      <p style="color:#64748b;font-size:13px;margin-bottom:12px">Add these webhooks in your Shopify Admin to sync all orders automatically.</p>
      <p style="color:#64748b;font-size:12px;margin-bottom:16px"><strong>Steps:</strong> Shopify Admin → Settings → Notifications → scroll down → Webhooks → Create webhook</p>
      <div style="background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:8px;position:relative">
        <p style="font-size:11px;color:#94a3b8;text-transform:uppercase;font-weight:600;margin-bottom:4px">1. Order creation</p>
        <p class="wh-url" style="font-size:12px;color:#1e293b;font-family:'Courier New',monospace;word-break:break-all;user-select:all">${hostUrl}/webhooks/manual/orders/create</p>
        <button onclick="copyUrl(this)" style="position:absolute;top:10px;right:10px;background:#eef2ff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;color:#4f46e5;font-weight:600">Copy</button>
      </div>
      <div style="background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:8px;position:relative">
        <p style="font-size:11px;color:#94a3b8;text-transform:uppercase;font-weight:600;margin-bottom:4px">2. Order payment</p>
        <p class="wh-url" style="font-size:12px;color:#1e293b;font-family:'Courier New',monospace;word-break:break-all;user-select:all">${hostUrl}/webhooks/manual/orders/paid</p>
        <button onclick="copyUrl(this)" style="position:absolute;top:10px;right:10px;background:#eef2ff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;color:#4f46e5;font-weight:600">Copy</button>
      </div>
      <div style="background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:8px;position:relative">
        <p style="font-size:11px;color:#94a3b8;text-transform:uppercase;font-weight:600;margin-bottom:4px">3. Order fulfilment</p>
        <p class="wh-url" style="font-size:12px;color:#1e293b;font-family:'Courier New',monospace;word-break:break-all;user-select:all">${hostUrl}/webhooks/manual/orders/fulfilled</p>
        <button onclick="copyUrl(this)" style="position:absolute;top:10px;right:10px;background:#eef2ff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;color:#4f46e5;font-weight:600">Copy</button>
      </div>
      <p style="color:#64748b;font-size:12px;margin-top:12px">Format: <strong>JSON</strong> &nbsp;|&nbsp; API Version: <strong>2025-04</strong></p>
    </div>
    <div class="card" style="border:1px dashed #e2e8f0;background:#fafafa">
      <h3 style="font-size:14px;color:#64748b;margin-bottom:8px;font-weight:700">🔑 Need to reconnect to a different account?</h3>
      <p style="font-size:13px;color:#94a3b8;margin-bottom:12px">Generate a new secret code — the old one will be invalidated. Use this  if you deleted your account and re-registered.</p>
      <div id="regen-area-connected">
        <button class="btn btn-sec btn-sm" id="regen-btn-connected" onclick="regenKeyConnected()">🔄 Generate New Code</button>
      </div>
    </div>
    ` : `
    <div class="card">
      <div class="center" style="margin-bottom:8px">
        <span class="badge badge-warn"><span class="dot dot-y"></span> Not Connected</span>
      </div>
      <h2 class="center" style="font-size:20px;color:#1e293b;margin-top:12px">Connect Your Store</h2>
      <p class="center" style="color:#64748b;margin-top:8px;font-size:14px">Use the secret key below to link your store with CODVerify</p>

      ${secretKey ? `
      <div class="key-box">
        <p class="key-lbl">Your Secret Key</p>
        <p class="key-val" id="sk">${secretKey}</p>
        <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
          <button class="btn btn-pri btn-sm" onclick="copyKey()">📋 Copy Key</button>
          <button class="btn btn-sec btn-sm" id="regen-btn" onclick="regenKeyForce()">🔄 Generate New Code</button>
        </div>
        <p style="font-size:11px;color:#94a3b8;margin-top:12px">⚠️ Save this key! You'll need it to connect.</p>
      </div>
      ` : `
      <div class="key-box" id="kb">
        <p class="key-lbl">Secret Key</p>
        <p id="km" style="color:#94a3b8;font-size:14px;margin:8px 0">Click below to generate your key.</p>
        <button class="btn btn-pri btn-sm" id="rb" onclick="regenKey()">🔄 Generate Key</button>
      </div>
      `}

      <div class="steps">
        <h3 style="font-size:16px;color:#1e293b;font-weight:700;margin-bottom:8px">How to Connect:</h3>
        <div class="step"><div class="step-n">1</div><div><h4>Create Account</h4><p>Go to <strong>codverify.tech</strong> and sign up.</p></div></div>
        <div class="step"><div class="step-n">2</div><div><h4>Go to Stores</h4><p>Dashboard → <strong>Stores</strong> section.</p></div></div>
        <div class="step"><div class="step-n">3</div><div><h4>Paste Key</h4><p>Click <strong>"Connect Store"</strong> and paste your secret key.</p></div></div>
      </div>

      <a href="${websiteUrl}/register" target="_blank" class="btn btn-pri">Create Account ↗</a>
      <a href="${websiteUrl}/login" target="_blank" class="btn btn-sec">Already have an account? Login ↗</a>
    </div>
    `}

    <p class="note">
      ${isConnected ? 'Add the webhooks above to start syncing orders.' : 'Refresh after connecting.'}
      <br><a href="/app?shop=${encodeURIComponent(shop)}">↻ Refresh</a>
    </p>
  </div>

  <script>
    function copyKey(){
      var k=document.getElementById('sk');
      if(!k)return;
      navigator.clipboard.writeText(k.textContent.trim()).then(function(){
        k.style.color='#22c55e';
        setTimeout(function(){k.style.color='#4f46e5'},1500);
      }).catch(function(){
        var t=document.createElement('textarea');t.value=k.textContent.trim();
        document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);
      });
    }
    function copyUrl(btn){
      var url=btn.parentElement.querySelector('.wh-url').textContent.trim();
      navigator.clipboard.writeText(url).then(function(){
        btn.textContent='Copied!';btn.style.background='#dcfce7';btn.style.color='#15803d';
        setTimeout(function(){btn.textContent='Copy';btn.style.background='#eef2ff';btn.style.color='#4f46e5';},1500);
      }).catch(function(){});
    }
    function regenKey(){
      var b=document.getElementById('rb'),m=document.getElementById('km'),kb=document.getElementById('kb');
      if(!b)return;
      b.disabled=true;b.textContent='⏳ Generating...';b.style.opacity='.7';
      fetch('/regenerate-key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({shop:'${shop}'})})
        .then(function(r){return r.json()})
        .then(function(d){
          if(d.success&&d.secret_key){
            kb.innerHTML='<p class="key-lbl">Your Secret Key</p><p class="key-val" id="sk">'+d.secret_key+'</p><div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button class="btn btn-pri btn-sm" onclick="copyKey()">📋 Copy Key</button><button class="btn btn-sec btn-sm" onclick="regenKeyForce()">🔄 New Code</button></div><p style="font-size:11px;color:#94a3b8;margin-top:12px">⚠️ Save this key!</p>';
          }else if(d.is_already_connected){
            m.textContent='Store already connected! Refresh to see status.';m.style.color='#22c55e';
            b.textContent='↻ Refresh';b.disabled=false;b.style.opacity='1';b.onclick=function(){location.reload()};
          }else{
            m.textContent=d.message||'Failed. Try again.';m.style.color='#ef4444';
            b.textContent='🔄 Try Again';b.disabled=false;b.style.opacity='1';
          }
        })
        .catch(function(){
          m.textContent='Network error. Try again.';m.style.color='#ef4444';
          b.textContent='🔄 Try Again';b.disabled=false;b.style.opacity='1';
        });
    }
    // Force-generate new code (works even if shop appears connected)
    function regenKeyForce(){
      var b=document.getElementById('regen-btn');
      if(b){b.disabled=true;b.textContent='⏳ Generating...';b.style.opacity='.7';}
      fetch('/regenerate-key-force',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({shop:'${shop}'})})
        .then(function(r){return r.json()})
        .then(function(d){
          if(d.success&&d.secret_key){
            var box=document.querySelector('.key-box');
            if(box) box.innerHTML='<p class="key-lbl">Your New Secret Key</p><p class="key-val" id="sk">'+d.secret_key+'</p><div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button class="btn btn-pri btn-sm" onclick="copyKey()">📋 Copy Key</button></div><p style="font-size:11px;color:#22c55e;margin-top:12px">✅ New code generated! Enter this on CODVerify dashboard.</p>';
          }else{
            alert(d.message||'Failed to generate new code. Please try again.');
            if(b){b.disabled=false;b.textContent='🔄 Generate New Code';b.style.opacity='1';}
          }
        })
        .catch(function(){
          alert('Network error. Please try again.');
          if(b){b.disabled=false;b.textContent='🔄 Generate New Code';b.style.opacity='1';}
        });
    }
    // For connected state — generate new code for reconnecting to a different account
    function regenKeyConnected(){
      var area=document.getElementById('regen-area-connected');
      var b=document.getElementById('regen-btn-connected');
      if(!b)return;
      if(!confirm('This will generate a new secret code. The store will be disconnected from the current account. Continue?'))return;
      b.disabled=true;b.textContent='Generating...';b.style.opacity='.7';
      fetch('/regenerate-key-force',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({shop:'${shop}'})})
        .then(function(r){return r.json()})
        .then(function(d){
          if(d.success&&d.secret_key){
            area.innerHTML='<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;text-align:center"><p style="font-size:11px;color:#94a3b8;text-transform:uppercase;font-weight:600;margin-bottom:6px">New Secret Code</p><p id="new-key-display" style="font-size:24px;font-weight:800;letter-spacing:2px;color:#4f46e5;font-family:monospace">'+d.secret_key+'</p><p style="font-size:12px;color:#22c55e;margin-top:8px">Enter this on CODVerify dashboard to reconnect.</p><button onclick="copyNewKey()" class="btn btn-pri btn-sm" style="margin-top:10px">Copy Code</button></div>';
          }else{
            b.disabled=false;b.textContent='Generate New Code';b.style.opacity='1';
            alert(d.message||'Failed to generate. Please try again.');
          }
        })
        .catch(function(){
          b.disabled=false;b.textContent='Generate New Code';b.style.opacity='1';
          alert('Network error. Please try again.');
        });
    }
    function copyNewKey(){
      var el=document.getElementById('new-key-display');
      if(!el)return;
      navigator.clipboard.writeText(el.textContent.trim()).then(function(){
        el.style.color='#22c55e';
        setTimeout(function(){el.style.color='#4f46e5';},1500);
      }).catch(function(){
        var t=document.createElement('textarea');t.value=el.textContent.trim();
        document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);
      });
    }
  </script>
</body>
</html>`;
}

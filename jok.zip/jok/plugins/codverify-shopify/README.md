---
title: CODVerify Shopify Plugin
emoji: 🛒
colorFrom: indigo
colorTo: purple
sdk: docker
app_port: 7860
---

# CODVerify Shopify App

Official Shopify app for CODVerify — Automatic WhatsApp & SMS COD verification.

## Features

- 🛍️ Full Shopify OAuth 2.0 install flow
- 📲 Auto-registers `orders/paid` and `orders/create` webhooks
- 🔐 HMAC signature verification (secure webhooks)
- ⚙️ Simple settings page for API key configuration
- 🌍 Supports India (WhatsApp) and USA (SMS) numbers

## Setup & Development

```bash
# 1. Clone and install
npm install

# 2. Create your .env file
cp .env.example .env

# 3. Fill in your variables:
#    - SHOPIFY_API_KEY     : From Shopify Partners dashboard
#    - SHOPIFY_API_SECRET  : From Shopify Partners dashboard
#    - SHOPIFY_APP_URL     : Your app's public URL (ngrok for local dev)
#    - CODVERIFY_API_URL   : Your CODVerify HuggingFace space URL

# 4. Start dev server (use ngrok for public URL)
npm run dev
```

## Deploying to Shopify Partners

### Step 1: Create the app
1. Go to [partners.shopify.com](https://partners.shopify.com)
2. Apps → Create app → Custom app
3. Set App URL to `https://your-deployed-url.com`
4. Set Redirect URL to `https://your-deployed-url.com/auth/callback`
5. Copy API Key and API Secret into your `.env`

### Step 2: Deploy the server
Deploy to any Node.js host:
- **Railway**: `railway up`
- **Render**: Connect GitHub repo → Web Service
- **Fly.io**: `fly deploy`

### Step 3: Required scopes
```
read_orders, write_orders
```

### Step 4: Submit to App Store (optional)
1. Complete Shopify app review requirements
2. Add app listing details in Partners dashboard
3. Submit for review

## How It Works

```
Merchant installs app
       ↓
Shopify OAuth (access token stored)
       ↓
App registers order/paid webhook
       ↓
Customer places COD order
       ↓
Shopify calls /webhooks/orders/paid
       ↓
App forwards to CODVerify API
       ↓
Customer gets WhatsApp/SMS
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SHOPIFY_API_KEY` | From Shopify Partners dashboard |
| `SHOPIFY_API_SECRET` | From Shopify Partners dashboard |
| `SHOPIFY_SCOPES` | Comma-separated: `read_orders,write_orders` |
| `SHOPIFY_APP_URL` | Public URL of this app |
| `CODVERIFY_API_URL` | Your CODVerify webhook endpoint |
| `SESSION_SECRET` | Random string for session signing |
| `PORT` | Server port (default: 3000) |

## License
MIT

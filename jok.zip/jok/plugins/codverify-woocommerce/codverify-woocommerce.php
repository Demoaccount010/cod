<?php
/**
 * Plugin Name:       CODVerify for WooCommerce
 * Plugin URI:        https://codverify.tech
 * Description:       WhatsApp COD Verification & RTO Prevention for WooCommerce. Automatically sends WhatsApp verification messages for Cash on Delivery orders to reduce RTO losses.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            CODVerify
 * Author URI:        https://codverify.tech
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       codverify-woocommerce
 * WC requires at least: 6.0
 * WC tested up to:   8.5
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// ── Plugin Constants ────────────────────────────────────────────────────────
define('CODVERIFY_VERSION', '1.0.0');
define('CODVERIFY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CODVERIFY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CODVERIFY_PLUGIN_FILE', __FILE__);
define('CODVERIFY_API_BASE', 'https://codverify.tech/api/v1');

// ── WooCommerce HPOS Compatibility Declaration ───────────────────────────────
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables', __FILE__, true
        );
    }
});

// ── Dependency Check ────────────────────────────────────────────────────────
register_activation_hook(__FILE__, 'codverify_check_dependencies');

function codverify_check_dependencies()
{
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            '<strong>CODVerify for WooCommerce</strong> requires WooCommerce to be installed and active. Please install WooCommerce first.',
            'Plugin Dependency Error',
            array('back_link' => true)
        );
    }
}

// ── Auto-loader ─────────────────────────────────────────────────────────────
function codverify_autoload($class_name)
{
    $prefix = 'CODVerify_';
    if (strpos($class_name, $prefix) !== 0) {
        return;
    }
    $class_file = str_replace($prefix, '', $class_name);
    $class_file = strtolower(str_replace('_', '-', $class_file));
    $file = CODVERIFY_PLUGIN_DIR . 'includes/class-codverify-' . $class_file . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}
spl_autoload_register('codverify_autoload');

// ── Bootstrap ───────────────────────────────────────────────────────────────
add_action('plugins_loaded', 'codverify_init', 0);

function codverify_init()
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'codverify_woocommerce_missing_notice');
        return;
    }

    // Load text domain
    load_plugin_textdomain('codverify-woocommerce', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // Bootstrap main plugin class
    CODVerify_Plugin::get_instance();
}

function codverify_woocommerce_missing_notice()
{
    echo '<div class="error"><p><strong>CODVerify for WooCommerce</strong> requires WooCommerce. Please install and activate WooCommerce.</p></div>';
}


// ── Main Plugin Class ────────────────────────────────────────────────────────
class CODVerify_Plugin
{

    /** @var CODVerify_Plugin|null */
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function load_dependencies(): void
    {
        require_once CODVERIFY_PLUGIN_DIR . 'includes/class-codverify-api.php';
        require_once CODVERIFY_PLUGIN_DIR . 'includes/class-codverify-hooks.php';
        require_once CODVERIFY_PLUGIN_DIR . 'includes/class-codverify-admin.php';
    }

    private function init_hooks(): void
    {
        // Admin settings
        $admin = new CODVerify_Admin();
        $admin->init();

        // WooCommerce order hooks
        $hooks = new CODVerify_Hooks();
        $hooks->init();

        // Add settings link on plugins page
        add_filter(
            'plugin_action_links_' . plugin_basename(CODVERIFY_PLUGIN_FILE),
            array($this, 'add_settings_link')
        );
    }

    public function add_settings_link(array $links): array
    {
        $settings_link = '<a href="' . admin_url('admin.php?page=codverify-settings') . '">' . __('Settings', 'codverify-woocommerce') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

<?php
/**
 * CODVerify WooCommerce Plugin — Uninstall Script
 * This file is executed when the plugin is uninstalled (deleted) from WordPress.
 * It cleans up all plugin-related options and order meta.
 */

// Only run during uninstallation — never directly
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// ── Remove plugin options ────────────────────────────────────────────────────
$options_to_delete = array(
    'codverify_api_key',
    'codverify_secret_key',
    'codverify_backend_url',
    'codverify_enable_logging',
    'codverify_send_prepaid',
    'codverify_extra_cod_methods',
    'codverify_min_order_amount',
);

foreach ( $options_to_delete as $option ) {
    delete_option( $option );
}

// ── Remove order meta (optional, keeps order history if commented out) ────────
// Uncomment the block below if you want to also clean up order meta on uninstall.
// This is optional: most merchants prefer to keep the order history.
/*
global $wpdb;
$wpdb->delete(
    $wpdb->postmeta,
    array( 'meta_key' => '_codverify_sent' )
);
$wpdb->delete(
    $wpdb->postmeta,
    array( 'meta_key' => '_codverify_sent_at' )
);
$wpdb->delete(
    $wpdb->postmeta,
    array( 'meta_key' => '_codverify_order_id' )
);
*/

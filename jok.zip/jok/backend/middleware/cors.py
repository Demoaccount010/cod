from fastapi.middleware.cors import CORSMiddleware
from config.settings import settings


def add_cors_middleware(app):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins_list,
        # Allow any Shopify storefront, WooCommerce store, or custom merchant domain
        # These are public widget endpoints — no session credentials involved
        allow_origin_regex=r"https?://.*",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

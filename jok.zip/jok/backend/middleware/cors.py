"""
Custom CORS middleware — handles TWO types of requests:

1. Dashboard / Frontend (codverify.tech)  → credentials + specific allowed origins
2. Merchant Chatbot API (any merchant site) → echo origin, NO credentials needed

Uses a pure ASGI implementation (NOT BaseHTTPMiddleware) to avoid the known
Starlette streaming-body bug where CORS headers get silently dropped on
preflight responses when BaseHTTPMiddleware is used with streaming responses.
"""
from typing import Callable
from starlette.types import ASGIApp, Receive, Scope, Send
from starlette.datastructures import MutableHeaders
from starlette.responses import Response


# Origins that get credentials support (frontend dashboard, dev, etc.)
_CREDENTIALED_ORIGINS = {
    "https://codverify.tech",
    "https://www.codverify.tech",
    "http://localhost:5173",
    "http://localhost:3000",
    "http://localhost:8000",
}

# Paths that are public chatbot API — called from ANY merchant website
_PUBLIC_API_PREFIXES = (
    "/api/v1/merchant-chat/",
    "/chatbot/",
    "/static/chatbot-widget",
    "/api/v1/chat/",
    "/api/v1/help-center/",
    "/static/help-center.js",
)


def _build_cors_headers(origin: str, path: str, is_preflight: bool) -> dict:
    """Return the correct CORS headers dict for a given origin + path."""
    if not origin:
        return {}

    is_public = any(path.startswith(p) for p in _PUBLIC_API_PREFIXES)

    if is_public:
        headers = {
            "access-control-allow-origin": origin,
            "access-control-allow-methods": "GET, POST, PUT, DELETE, OPTIONS",
            "access-control-allow-headers": "Content-Type, Authorization, X-Requested-With",
            "access-control-max-age": "86400",
        }
        return headers

    if origin in _CREDENTIALED_ORIGINS:
        headers = {
            "access-control-allow-origin": origin,
            "access-control-allow-credentials": "true",
            "access-control-allow-methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
            "access-control-allow-headers": "Content-Type, Authorization, X-Requested-With",
            "access-control-max-age": "86400",
        }
        return headers

    return {}


class SmartCORSMiddleware:
    """
    Pure ASGI CORS middleware — avoids the BaseHTTPMiddleware streaming-body bug
    that silently drops response headers on certain FastAPI/Starlette versions.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers", []))
        origin = headers.get(b"origin", b"").decode("latin-1")
        method = scope.get("method", "")
        path = scope.get("path", "")

        # ── Preflight (OPTIONS) — respond immediately, no app call needed ──
        if method == "OPTIONS" and origin:
            cors_headers = _build_cors_headers(origin, path, is_preflight=True)
            raw_headers = [
                (k.encode("latin-1"), v.encode("latin-1"))
                for k, v in cors_headers.items()
            ]
            raw_headers += [
                (b"content-length", b"0"),
                (b"content-type", b"text/plain"),
            ]
            await send({
                "type": "http.response.start",
                "status": 204,
                "headers": raw_headers,
            })
            await send({"type": "http.response.body", "body": b""})
            return

        # ── Normal request — inject CORS headers into the response ──
        cors_headers = _build_cors_headers(origin, path, is_preflight=False)

        async def send_with_cors(message: dict) -> None:
            if message["type"] == "http.response.start" and cors_headers:
                mutable = MutableHeaders(scope=message)
                for key, val in cors_headers.items():
                    mutable[key] = val
            await send(message)

        await self.app(scope, receive, send_with_cors)


def add_cors_middleware(app):
    """
    Called from main.py — attaches our smart CORS middleware.
    No Starlette CORSMiddleware needed.
    """
    app.add_middleware(SmartCORSMiddleware)

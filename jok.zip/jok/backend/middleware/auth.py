from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader
from config.security import decode_access_token
from config.database import get_db
from config.settings import settings
from loguru import logger
from functools import wraps

security = HTTPBearer()
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    db = get_db()
    result = db.table("users").select("*").eq("id", user_id).execute()
    if not result.data:
        raise HTTPException(status_code=401, detail="User not found")

    user = result.data[0]
    if user.get("status") == "suspended":
        raise HTTPException(status_code=403, detail="Account suspended")
    if user.get("status") == "inactive":
        raise HTTPException(status_code=403, detail="Account inactive")

    # Check for impersonation
    if payload.get("impersonating"):
        user["_impersonating"] = True
        user["_admin_id"] = payload.get("admin_id")

    return user


async def get_current_merchant(user: dict = Depends(get_current_user)):
    if user.get("role") not in ("merchant", "admin"):
        raise HTTPException(status_code=403, detail="Merchant access required")
    if user.get("role") == "admin" and not user.get("_impersonating"):
        raise HTTPException(status_code=403, detail="Merchant access required")
    return user


async def get_current_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def get_current_worker(user: dict = Depends(get_current_user)):
    if user.get("role") not in ("worker", "admin"):
        raise HTTPException(status_code=403, detail="Worker access required")
    return user


async def get_api_key_user(request: Request, api_key: str = Depends(api_key_header)):
    db = get_db()

    # Method 1: Standard API key auth
    if api_key:
        result = db.table("api_keys").select("*").eq("api_key", api_key).eq("is_active", True).execute()
        if result.data:
            key_data = result.data[0]
            db.table("api_keys").update({
                "last_used_at": "now()",
                "last_used_ip": request.client.host if request.client else None
            }).eq("id", key_data["id"]).execute()

            user_result = db.table("users").select("*").eq("id", key_data["user_id"]).execute()
            if not user_result.data:
                raise HTTPException(status_code=401, detail="User not found")

            user = user_result.data[0]
            if user.get("status") in ("suspended", "inactive"):
                raise HTTPException(status_code=403, detail="Account not active")
            return user

    # Method 2: Internal token + shop_domain (for Shopify plugin forwarding orders)
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = getattr(settings, 'INTERNAL_API_TOKEN', "")
    if internal_token and expected_token and internal_token == expected_token:
        shop_domain = request.headers.get("X-Shop-Domain", "")
        if shop_domain:
            # Try 1: Direct user lookup by shopify_shop_domain
            user_result = db.table("users").select("*").eq("shopify_shop_domain", shop_domain).execute()
            if user_result.data:
                user = user_result.data[0]
                if user.get("status") not in ("suspended", "inactive"):
                    return user

            # Try 2: Fallback via stores table (store_url = shop_domain)
            # Note: Don't filter by is_active — after uninstall+reinstall, store may be temporarily inactive
            store_result = db.table("stores").select("user_id").eq("store_url", shop_domain).limit(1).execute()
            if store_result.data:
                user_result = db.table("users").select("*").eq("id", store_result.data[0]["user_id"]).execute()
                if user_result.data:
                    user = user_result.data[0]
                    if user.get("status") not in ("suspended", "inactive"):
                        return user

            logger.warning(f"Webhook auth failed: no user found for shop_domain={shop_domain}")

    raise HTTPException(status_code=401, detail="API key required")

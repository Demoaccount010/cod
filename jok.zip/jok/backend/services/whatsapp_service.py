import httpx
import hmac
import hashlib
import json
import ssl
import asyncio
from urllib.parse import urlparse
from loguru import logger
from typing import Optional
from config.settings import settings

WA_API_DIRECT = "https://graph.facebook.com/v18.0"

# ── DNS-over-HTTPS resolver ──────────────────────────────────────────
_resolved_hosts = {}


async def _resolve_hostname(hostname: str) -> Optional[str]:
    """Resolve hostname via Cloudflare DoH (1.1.1.1 is IP, no DNS needed)."""
    if hostname in _resolved_hosts:
        return _resolved_hosts[hostname]
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                "https://1.1.1.1/dns-query",
                params={"name": hostname, "type": "A"},
                headers={"Accept": "application/dns-json"},
            )
            data = resp.json()
            for answer in data.get("Answer", []):
                if answer.get("type") == 1:
                    ip = answer["data"]
                    _resolved_hosts[hostname] = ip
                    logger.info(f"DoH resolved {hostname} -> {ip}")
                    return ip
    except Exception as e:
        logger.warning(f"DoH failed: {e}")
    return None


def _get_wa_base():
    if settings.WHATSAPP_API_PROXY_URL:
        return settings.WHATSAPP_API_PROXY_URL.rstrip("/")
    return WA_API_DIRECT


def _needs_raw_connection() -> bool:
    # HuggingFace Spaces blocks outbound DNS for external APIs like graph.facebook.com.
    # Always use DoH (DNS-over-HTTPS via 1.1.1.1) + raw TLS connection.
    return True


async def _raw_https_post(url: str, headers: dict, payload: dict) -> Optional[dict]:
    """Make HTTPS POST directly to resolved IP using asyncio sockets.
    Bypasses DNS entirely — connects to IP, uses server_hostname for TLS/SNI."""
    parsed = urlparse(url)
    hostname = parsed.hostname
    path = parsed.path
    if parsed.query:
        path += "?" + parsed.query

    resolved_ip = await _resolve_hostname(hostname) if hostname else None
    if not resolved_ip:
        logger.error(f"Cannot resolve {hostname}")
        return None

    logger.info(f"Raw HTTPS POST -> {resolved_ip}:443 (SNI={hostname}) {path}")

    try:
        ctx = ssl.create_default_context()
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(resolved_ip, 443, ssl=ctx, server_hostname=hostname),
            timeout=15,
        )

        body_bytes = json.dumps(payload).encode("utf-8")

        # Build HTTP/1.1 request
        request_lines = [
            f"POST {path} HTTP/1.1",
            f"Host: {hostname}",
            f"Content-Type: application/json",
            f"Content-Length: {len(body_bytes)}",
            f"Connection: close",
        ]
        for key, value in headers.items():
            if key.lower() not in ("host", "content-type", "content-length", "connection"):
                request_lines.append(f"{key}: {value}")

        request_head = "\r\n".join(request_lines) + "\r\n\r\n"
        writer.write(request_head.encode("utf-8") + body_bytes)
        await writer.drain()

        # Read response
        response_data = b""
        while True:
            chunk = await asyncio.wait_for(reader.read(8192), timeout=20)
            if not chunk:
                break
            response_data += chunk

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        # Parse HTTP response
        response_text = response_data.decode("utf-8", errors="replace")
        # Split headers from body
        if "\r\n\r\n" in response_text:
            resp_head, resp_body = response_text.split("\r\n\r\n", 1)
        else:
            resp_head, resp_body = response_text, ""

        status_line = resp_head.split("\r\n")[0]
        logger.info(f"Response: {status_line}")

        # Handle chunked transfer encoding
        if "transfer-encoding: chunked" in resp_head.lower():
            decoded_body = ""
            remaining = resp_body
            while remaining:
                # Each chunk: size\r\n data\r\n
                if "\r\n" not in remaining:
                    break
                size_str, remaining = remaining.split("\r\n", 1)
                chunk_size = int(size_str.strip(), 16)
                if chunk_size == 0:
                    break
                decoded_body += remaining[:chunk_size]
                remaining = remaining[chunk_size:]
                if remaining.startswith("\r\n"):
                    remaining = remaining[2:]
            resp_body = decoded_body

        if resp_body.strip():
            logger.info(f"Response body: {resp_body[:300]}")
            return json.loads(resp_body.strip())
        return None

    except asyncio.TimeoutError:
        logger.error("Raw HTTPS timeout")
        return None
    except Exception as e:
        logger.error(f"Raw HTTPS error: {e}")
        return None


# ── WhatsApp API functions ────────────────────────────────────────────

async def send_template_message(
    phone_number_id: str,
    access_token: str,
    to_phone: str,
    template_name: str,
    template_language: str = "en",
    components: list = None,
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    body = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "template",
        "template": {"name": template_name, "language": {"code": template_language}},
    }
    if components:
        body["template"]["components"] = components

    if _needs_raw_connection():
        data = await _raw_https_post(url, headers, body)
        if data and "messages" in data:
            return data["messages"][0].get("id")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        for attempt in range(3):
            try:
                resp = await client.post(url, headers=headers, json=body)
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("messages", [{}])[0].get("id")
                elif resp.status_code >= 500:
                    continue
                else:
                    logger.error(f"WhatsApp API error {resp.status_code}: {resp.text}")
                    return None
            except Exception as e:
                logger.error(f"WhatsApp API exception: {e}")
                return None
    return None


async def send_interactive_button_message(
    phone_number_id: str,
    access_token: str,
    to_phone: str,
    body_text: str,
    buttons: list,
    header_text: str = None,
    footer_text: str = None,
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    interactive = {
        "type": "button",
        "body": {"text": body_text},
        "action": {"buttons": buttons},
    }
    if header_text:
        interactive["header"] = {"type": "text", "text": header_text}
    if footer_text:
        interactive["footer"] = {"text": footer_text}

    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "interactive",
        "interactive": interactive,
    }

    if _needs_raw_connection():
        logger.info(f"Sending WhatsApp via raw HTTPS -> {url}")
        data = await _raw_https_post(url, headers, payload)
        if data and "messages" in data:
            msg_id = data["messages"][0].get("id")
            logger.info(f"WhatsApp message sent! ID: {msg_id}")
            return msg_id
        logger.error(f"WhatsApp send failed, response: {data}")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        for attempt in range(3):
            try:
                resp = await client.post(url, headers=headers, json=payload)
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("messages", [{}])[0].get("id")
                elif resp.status_code >= 500:
                    continue
                else:
                    logger.error(f"WhatsApp interactive error {resp.status_code}: {resp.text}")
                    return None
            except Exception as e:
                logger.error(f"WhatsApp interactive exception: {e}")
                continue
    return None


async def send_text_message(
    phone_number_id: str, access_token: str, to_phone: str, text: str
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "text",
        "text": {"body": text},
    }

    if _needs_raw_connection():
        data = await _raw_https_post(url, headers, payload)
        if data and "messages" in data:
            return data["messages"][0].get("id")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("messages", [{}])[0].get("id")
            else:
                logger.error(f"WhatsApp text error {resp.status_code}: {resp.text}")
                return None
        except Exception as e:
            logger.error(f"WhatsApp text exception: {e}")
            return None


async def get_business_profile(phone_number_id: str, access_token: str) -> Optional[dict]:
    url = f"{_get_wa_base()}/{phone_number_id}"
    headers = {"Authorization": f"Bearer {access_token}"}
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(url, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return None
        except Exception as e:
            logger.error(f"WhatsApp profile error: {e}")
            return None


def verify_webhook_signature(payload: bytes, signature: str, app_secret: str) -> bool:
    if not signature or not app_secret:
        return False
    expected = "sha256=" + hmac.new(
        app_secret.encode(), payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


# ── Contract activation WhatsApp notification ─────────────────────────

async def send_contract_activation_whatsapp(
    merchant_phone: str,
    merchant_name: str,
    store_name: str,
    contract_number: str,
    paid_amount: float,
    pending_amount: float,
    currency: str = "INR",
) -> bool:
    """
    Send contract activation WhatsApp message using an approved Meta template.
    Template name: contract_activation  (UTILITY category, language: en_US)

    Template body (paste exactly this in Meta Business Manager):
    ─────────────────────────────────────────────────────────────
    Hello {{1}}! 🎉 Your CODVerify account for *{{2}}* is now *ACTIVE*.

    📄 Contract: {{3}}
    💳 Amount Paid: {{4}}
    📋 Pending Balance: {{5}}

    You can now start verifying COD orders right away! 🚀
    Login: https://codverify.com/dashboard

    Need help? Email support@codverify.com
    — Team CODVerify
    ─────────────────────────────────────────────────────────────
    Variables:
      {{1}} = merchant name
      {{2}} = store name
      {{3}} = contract number
      {{4}} = amount paid  e.g. ₹5,000.00 or "Free Activation"
      {{5}} = pending balance  e.g. ₹15,000.00 or "None"
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WhatsApp not configured — skipping activation message")
        return False

    sym = "₹" if currency == "INR" else "$"
    paid_str = f"{sym}{paid_amount:,.2f}" if paid_amount > 0 else "Free Activation"
    pending_str = f"{sym}{pending_amount:,.2f}" if pending_amount > 0 else "None"

    components = [
        {
            "type": "body",
            "parameters": [
                {"type": "text", "text": merchant_name},
                {"type": "text", "text": store_name},
                {"type": "text", "text": contract_number},
                {"type": "text", "text": paid_str},
                {"type": "text", "text": pending_str},
            ],
        }
    ]

    msg_id = await send_template_message(
        phone_number_id=phone_id,
        access_token=token,
        to_phone=merchant_phone,
        template_name="contract_activation",
        template_language="en",
        components=components,
    )
    if msg_id:
        logger.info(f"Contract activation WA sent to {merchant_phone}, msg_id={msg_id}")
        return True
    logger.warning(f"Contract activation WA failed for {merchant_phone}")
    return False

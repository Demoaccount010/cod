import httpx
import hmac
import hashlib
import json
import ssl
import asyncio
from urllib.parse import urlparse
from loguru import logger
from typing import Optional
from config.settings import settings

WA_API_DIRECT = "https://graph.facebook.com/v21.0"

# ── DNS-over-HTTPS resolver ──────────────────────────────────────────
_resolved_hosts = {}


async def _resolve_hostname(hostname: str) -> Optional[str]:
    """Resolve hostname via Cloudflare DoH (1.1.1.1 is IP, no DNS needed)."""
    if hostname in _resolved_hosts:
        return _resolved_hosts[hostname]
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                "https://1.1.1.1/dns-query",
                params={"name": hostname, "type": "A"},
                headers={"Accept": "application/dns-json"},
            )
            data = resp.json()
            for answer in data.get("Answer", []):
                if answer.get("type") == 1:
                    ip = answer["data"]
                    _resolved_hosts[hostname] = ip
                    logger.info(f"DoH resolved {hostname} -> {ip}")
                    return ip
    except Exception as e:
        logger.warning(f"DoH failed: {e}")
    return None


def _get_wa_base():
    if settings.WHATSAPP_API_PROXY_URL:
        return settings.WHATSAPP_API_PROXY_URL.rstrip("/")
    return WA_API_DIRECT


def _needs_raw_connection() -> bool:
    # Only use raw HTTPS if a proxy URL is configured (e.g. HuggingFace Spaces).
    # On standard servers like AWS EC2, normal httpx works fine.
    return bool(settings.WHATSAPP_API_PROXY_URL)


async def _raw_https_post(url: str, headers: dict, payload: dict) -> Optional[dict]:
    """Make HTTPS POST directly to resolved IP using asyncio sockets.
    Bypasses DNS entirely — connects to IP, uses server_hostname for TLS/SNI."""
    parsed = urlparse(url)
    hostname = parsed.hostname
    path = parsed.path
    if parsed.query:
        path += "?" + parsed.query

    resolved_ip = await _resolve_hostname(hostname) if hostname else None
    if not resolved_ip:
        logger.error(f"Cannot resolve {hostname}")
        return None

    logger.info(f"Raw HTTPS POST -> {resolved_ip}:443 (SNI={hostname}) {path}")

    try:
        ctx = ssl.create_default_context()
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(resolved_ip, 443, ssl=ctx, server_hostname=hostname),
            timeout=15,
        )

        body_bytes = json.dumps(payload).encode("utf-8")

        # Build HTTP/1.1 request
        request_lines = [
            f"POST {path} HTTP/1.1",
            f"Host: {hostname}",
            f"Content-Type: application/json",
            f"Content-Length: {len(body_bytes)}",
            f"Connection: close",
        ]
        for key, value in headers.items():
            if key.lower() not in ("host", "content-type", "content-length", "connection"):
                request_lines.append(f"{key}: {value}")

        request_head = "\r\n".join(request_lines) + "\r\n\r\n"
        writer.write(request_head.encode("utf-8") + body_bytes)
        await writer.drain()

        # Read response
        response_data = b""
        while True:
            chunk = await asyncio.wait_for(reader.read(8192), timeout=20)
            if not chunk:
                break
            response_data += chunk

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        # Parse HTTP response
        response_text = response_data.decode("utf-8", errors="replace")
        # Split headers from body
        if "\r\n\r\n" in response_text:
            resp_head, resp_body = response_text.split("\r\n\r\n", 1)
        else:
            resp_head, resp_body = response_text, ""

        status_line = resp_head.split("\r\n")[0]
        logger.info(f"Response: {status_line}")

        # Handle chunked transfer encoding
        if "transfer-encoding: chunked" in resp_head.lower():
            decoded_body = ""
            remaining = resp_body
            while remaining:
                if "\r\n" not in remaining:
                    break
                size_str, remaining = remaining.split("\r\n", 1)
                chunk_size = int(size_str.strip(), 16)
                if chunk_size == 0:
                    break
                decoded_body += remaining[:chunk_size]
                remaining = remaining[chunk_size:]
                if remaining.startswith("\r\n"):
                    remaining = remaining[2:]
            resp_body = decoded_body

        if resp_body.strip():
            logger.info(f"Response body: {resp_body[:500]}")
            return json.loads(resp_body.strip())
        return None

    except asyncio.TimeoutError:
        logger.error("Raw HTTPS timeout")
        return None
    except Exception as e:
        logger.error(f"Raw HTTPS error: {e}")
        return None


# ── WhatsApp API functions ────────────────────────────────────────────

async def send_template_message(
    phone_number_id: str,
    access_token: str,
    to_phone: str,
    template_name: str,
    template_language: str = "en",
    components: list = None,
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    body = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "template",
        "template": {"name": template_name, "language": {"code": template_language}},
    }
    if components:
        body["template"]["components"] = components

    # ── DEBUG: Full request details ────────────────────────────────────
    logger.info(f"📤 WA SEND REQUEST:")
    logger.info(f"   URL             : {url}")
    logger.info(f"   Phone Number ID : {phone_number_id}")
    logger.info(f"   To              : {to_phone}")
    logger.info(f"   Template Name   : {template_name}")
    logger.info(f"   Language        : {template_language}")
    logger.info(f"   Components      : {components}")
    # NOTE: access_token NOT logged for security
    # ────────────────────────────────────────────────────────────────────

    if _needs_raw_connection():
        data = await _raw_https_post(url, headers, body)
        logger.info(f"📥 WA RAW RESPONSE: {data}")
        if data and "messages" in data:
            msg_id = data["messages"][0].get("id")
            msg_status = data["messages"][0].get("message_status", "")
            logger.info(f"✅ WA accepted by Meta. msg_id={msg_id} status={msg_status}")
            return msg_id
        if data and "error" in data:
            err = data["error"]
            logger.error(
                f"❌ WA API ERROR: code={err.get('code')} "
                f"subcode={err.get('error_subcode')} "
                f"msg={err.get('message')} "
                f"fbtrace={err.get('fbtrace_id')}"
            )
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        for attempt in range(3):
            try:
                resp = await client.post(url, headers=headers, json=body)
                logger.info(f"📥 WA httpx response: status={resp.status_code} body={resp.text[:500]}")
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("messages", [{}])[0].get("id")
                elif resp.status_code >= 500:
                    continue
                else:
                    logger.error(f"❌ WhatsApp API error {resp.status_code}: {resp.text}")
                    return None
            except Exception as e:
                logger.error(f"❌ WhatsApp API exception: {e}")
                return None
    return None


async def send_interactive_button_message(
    phone_number_id: str,
    access_token: str,
    to_phone: str,
    body_text: str,
    buttons: list,
    header_text: str = None,
    footer_text: str = None,
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    interactive = {
        "type": "button",
        "body": {"text": body_text},
        "action": {"buttons": buttons},
    }
    if header_text:
        interactive["header"] = {"type": "text", "text": header_text}
    if footer_text:
        interactive["footer"] = {"text": footer_text}

    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "interactive",
        "interactive": interactive,
    }

    if _needs_raw_connection():
        logger.info(f"Sending WhatsApp via raw HTTPS -> {url}")
        data = await _raw_https_post(url, headers, payload)
        if data and "messages" in data:
            msg_id = data["messages"][0].get("id")
            logger.info(f"WhatsApp message sent! ID: {msg_id}")
            return msg_id
        logger.error(f"WhatsApp send failed, response: {data}")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        for attempt in range(3):
            try:
                resp = await client.post(url, headers=headers, json=payload)
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("messages", [{}])[0].get("id")
                elif resp.status_code >= 500:
                    continue
                else:
                    logger.error(f"WhatsApp interactive error {resp.status_code}: {resp.text}")
                    return None
            except Exception as e:
                logger.error(f"WhatsApp interactive exception: {e}")
                continue
    return None


async def send_text_message(
    phone_number_id: str, access_token: str, to_phone: str, text: str
) -> Optional[str]:
    url = f"{_get_wa_base()}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone.replace("+", ""),
        "type": "text",
        "text": {"body": text},
    }

    if _needs_raw_connection():
        data = await _raw_https_post(url, headers, payload)
        if data and "messages" in data:
            return data["messages"][0].get("id")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("messages", [{}])[0].get("id")
            else:
                logger.error(f"WhatsApp text error {resp.status_code}: {resp.text}")
                return None
        except Exception as e:
            logger.error(f"WhatsApp text exception: {e}")
            return None


async def get_business_profile(phone_number_id: str, access_token: str) -> Optional[dict]:
    url = f"{_get_wa_base()}/{phone_number_id}"
    headers = {"Authorization": f"Bearer {access_token}"}
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(url, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return None
        except Exception as e:
            logger.error(f"WhatsApp profile error: {e}")
            return None


def verify_webhook_signature(payload: bytes, signature: str, app_secret: str) -> bool:
    if not signature or not app_secret:
        return False
    expected = "sha256=" + hmac.new(
        app_secret.encode(), payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


# ── Contract activation WhatsApp notification ─────────────────────────

async def send_contract_activation_whatsapp(
    merchant_phone: str,
    merchant_name: str,
    store_name: str,
    contract_number: str,
    paid_amount: float,
    pending_amount: float,
    currency: str = "INR",
) -> bool:
    """Send contract activation WhatsApp. Template: cod (Marketing, en)."""
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN

    # ──── DEBUG ENTRY LOG ─────────────────────────────────────────────
    logger.info("🟡 CONTRACT WA DEBUG:")
    logger.info(f"   phone_id      : '{phone_id}'")
    logger.info(f"   token set     : {bool(token)} (len={len(token) if token else 0})")
    logger.info(f"   merchant_phone: '{merchant_phone}'")
    logger.info(f"   merchant_name : '{merchant_name}'")
    logger.info(f"   store_name    : '{store_name}'")
    logger.info(f"   contract_no   : '{contract_number}'")
    logger.info(f"   paid_amount   : {paid_amount}")
    logger.info(f"   pending_amount: {pending_amount}")
    logger.info(f"   currency      : {currency}")
    # ─────────────────────────────────────────────────────────────────

    if not phone_id or not token:
        logger.warning("❌ WA not configured: WHATSAPP_PHONE_NUMBER_ID or WHATSAPP_ACCESS_TOKEN missing")
        return False

    sym = "₹" if currency == "INR" else "$"
    paid_str = f"{sym}{paid_amount:,.2f}" if paid_amount > 0 else "Free Activation"
    pending_str = f"{sym}{pending_amount:,.2f}" if pending_amount > 0 else "None"

    components = [
        {
            "type": "body",
            "parameters": [
                {"type": "text", "text": merchant_name},
                {"type": "text", "text": store_name},
                {"type": "text", "text": contract_number},
                {"type": "text", "text": paid_str},
                {"type": "text", "text": pending_str},
            ],
        }
    ]

    msg_id = await send_template_message(
        phone_number_id=phone_id,
        access_token=token,
        to_phone=merchant_phone,
        template_name="cod_activation",
        template_language="en",
        components=components,
    )
    if msg_id:
        logger.info(f"✅ Contract activation WA sent to {merchant_phone}, msg_id={msg_id}")
        return True
    logger.warning(f"❌ Contract activation WA FAILED for {merchant_phone} (msg_id was None)")
    return False


# ── Returns/Exchange — Customer: request received ─────────────────────────────

async def send_return_received_customer(
    customer_phone: str,
    customer_name: str,
    order_number: str,
    request_type: str,   # 'return' | 'exchange' | 'refund'
    store_name: str,
) -> bool:
    """
    Template: return_request_received
    Sent to the END CUSTOMER when they submit a return/exchange request.
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — return_received customer skipped")
        return False

    type_label = {"return": "Return", "exchange": "Exchange", "refund": "Refund"}.get(request_type, "Return")

    components = [{
        "type": "body",
        "parameters": [
            {"type": "text", "text": customer_name},
            {"type": "text", "text": order_number},
            {"type": "text", "text": type_label},
            {"type": "text", "text": store_name},
        ],
    }]
    msg_id = await send_template_message(
        phone_id, token, customer_phone,
        "return_request_received", "en", components,
    )
    if msg_id:
        logger.info(f"✅ return_request_received WA sent to customer {customer_phone}")
        return True
    logger.warning(f"❌ return_request_received WA FAILED for {customer_phone}")
    return False


# ── Returns/Exchange — Merchant: alert on new request ────────────────────────

async def send_return_alert_merchant(
    merchant_phone: str,
    merchant_name: str,
    customer_name: str,
    order_number: str,
    request_type: str,
    reason: str,
) -> bool:
    """
    Template: return_request_merchant
    Sent to the MERCHANT (website owner) when a customer submits a return request.
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — return_alert merchant skipped")
        return False

    type_label = {"return": "Return", "exchange": "Exchange", "refund": "Refund"}.get(request_type, "Return")
    reason_short = (reason or "Not specified")[:150]  # WhatsApp param limit

    components = [{
        "type": "body",
        "parameters": [
            {"type": "text", "text": merchant_name},
            {"type": "text", "text": customer_name},
            {"type": "text", "text": order_number},
            {"type": "text", "text": type_label},
            {"type": "text", "text": reason_short},
        ],
    }]
    msg_id = await send_template_message(
        phone_id, token, merchant_phone,
        "return_request_merchant", "en", components,
    )
    if msg_id:
        logger.info(f"✅ return_request_merchant WA sent to merchant {merchant_phone}")
        return True
    logger.warning(f"❌ return_request_merchant WA FAILED for {merchant_phone}")
    return False


# ── Returns/Exchange — Customer: status update (approved/rejected) ────────────

async def send_return_status_customer(
    customer_phone: str,
    customer_name: str,
    order_number: str,
    status: str,          # 'approved' | 'rejected' | 'completed'
    notes: str,
    store_name: str,
) -> bool:
    """
    Template: return_status_update
    Sent to the END CUSTOMER when merchant approves, rejects, or completes their request.
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — return_status customer skipped")
        return False

    status_label = {"approved": "Approved ✅", "rejected": "Rejected ❌", "completed": "Completed ✅"}.get(status, status.capitalize())
    notes_text = (notes or "Please check our return policy on the website.")[:200]

    components = [{
        "type": "body",
        "parameters": [
            {"type": "text", "text": customer_name},
            {"type": "text", "text": order_number},
            {"type": "text", "text": status_label},
            {"type": "text", "text": notes_text},
            {"type": "text", "text": store_name},
        ],
    }]
    msg_id = await send_template_message(
        phone_id, token, customer_phone,
        "return_status_update", "en", components,
    )
    if msg_id:
        logger.info(f"✅ return_status_update WA sent to customer {customer_phone} [{status}]")
        return True
    logger.warning(f"❌ return_status_update WA FAILED for {customer_phone}")
    return False


# ══════════════════════════════════════════════════════════════════════════════
# DELIVERY STATUS NOTIFICATIONS — Sent to customer on shipping events
# Templates: order_shipped | order_out_for_delivery | order_delivered
# ══════════════════════════════════════════════════════════════════════════════

async def send_order_shipped_notification(
    customer_phone: str,
    customer_name: str,
    order_number: str,
    store_name: str,
    tracking_number: str,
    tracking_company: str,
    tracking_url: str,
) -> bool:
    """
    Template: order_shipped
    Sent when merchant ships the order (Shopify fulfillment / delivery_status='shipped').
    Body params: {{1}}=customer_name {{2}}=order_number {{3}}=store_name
                 {{4}}=tracking_company {{5}}=tracking_number {{6}}=tracking_url
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token    = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — order_shipped notification skipped")
        return False

    t_number  = tracking_number  or "Will be updated soon"
    t_company = tracking_company or "Our logistics partner"
    t_url     = tracking_url     or "Track via the carrier's app"

    components = [{"type": "body", "parameters": [
        {"type": "text", "text": customer_name},
        {"type": "text", "text": str(order_number)},
        {"type": "text", "text": store_name},
        {"type": "text", "text": t_company},
        {"type": "text", "text": t_number},
        {"type": "text", "text": t_url},
    ]}]
    msg_id = await send_template_message(
        phone_id, token, customer_phone, "order_shipped", "en", components,
    )
    if msg_id:
        logger.info(f"✅ order_shipped WA sent → {customer_phone} | order={order_number}")
        return True
    logger.warning(f"❌ order_shipped WA FAILED → {customer_phone}")
    return False


async def send_order_out_for_delivery_notification(
    customer_phone: str,
    customer_name: str,
    order_number: str,
    store_name: str,
) -> bool:
    """
    Template: order_out_for_delivery
    Sent when delivery_status changes to 'out_for_delivery'.
    Body params: {{1}}=customer_name {{2}}=order_number {{3}}=store_name
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token    = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — order_out_for_delivery notification skipped")
        return False

    components = [{"type": "body", "parameters": [
        {"type": "text", "text": customer_name},
        {"type": "text", "text": str(order_number)},
        {"type": "text", "text": store_name},
    ]}]
    msg_id = await send_template_message(
        phone_id, token, customer_phone, "order_out_for_delivery", "en", components,
    )
    if msg_id:
        logger.info(f"✅ order_out_for_delivery WA sent → {customer_phone} | order={order_number}")
        return True
    logger.warning(f"❌ order_out_for_delivery WA FAILED → {customer_phone}")
    return False


async def send_order_delivered_notification(
    customer_phone: str,
    customer_name: str,
    order_number: str,
    store_name: str,
    help_center_url: str,
) -> bool:
    """
    Template: order_delivered
    Sent when delivery_status changes to 'delivered'.
    Body params: {{1}}=customer_name {{2}}=order_number {{3}}=store_name {{4}}=help_center_url
    """
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token    = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        logger.warning("WA not configured — order_delivered notification skipped")
        return False

    components = [{"type": "body", "parameters": [
        {"type": "text", "text": customer_name},
        {"type": "text", "text": str(order_number)},
        {"type": "text", "text": store_name},
        {"type": "text", "text": help_center_url},
    ]}]
    msg_id = await send_template_message(
        phone_id, token, customer_phone, "order_delivered", "en", components,
    )
    if msg_id:
        logger.info(f"✅ order_delivered WA sent → {customer_phone} | order={order_number}")
        return True
    logger.warning(f"❌ order_delivered WA FAILED → {customer_phone}")
    return False


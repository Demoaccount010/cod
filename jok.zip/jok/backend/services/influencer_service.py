"""
Influencer Service — Core business logic for CODVerify referral system.
Handles: ref code generation, payout tier lookup, wallet credits, Razorpay payouts.
"""
from loguru import logger
from config.database import get_db
from config.settings import settings
from datetime import datetime, timezone


# ── Ref Code Generator ─────────────────────────────────────────────────────────

def generate_ref_code(name: str) -> str:
    """Generate unique influencer referral code like INF-ROHIT-A7F3"""
    import secrets
    import re
    # Clean name — take first word, uppercase, max 8 chars
    clean = re.sub(r'[^A-Za-z]', '', name.split()[0]).upper()[:8]
    suffix = secrets.token_hex(3).upper()  # 6 hex chars
    return f"INF-{clean}-{suffix}"


def ensure_unique_ref_code(name: str) -> str:
    """Keep trying until we get a unique ref code."""
    db = get_db()
    for _ in range(10):
        code = generate_ref_code(name)
        res = db.table("influencer_profiles").select("id").eq("ref_code", code).execute()
        if not res.data:
            return code
    raise ValueError("Could not generate unique ref code after 10 attempts")


# ── Payout Tier Lookup ─────────────────────────────────────────────────────────

def get_payout_tier(influencer_id: str) -> dict:
    """
    Returns the current payout tier for an influencer based on their
    qualified_leads count. Falls back to tier 1 (Starter) if no config found.
    """
    db = get_db()

    # Get current qualified leads count
    profile_res = db.table("influencer_profiles").select("qualified_leads").eq("id", influencer_id).execute()
    qualified_count = profile_res.data[0]["qualified_leads"] if profile_res.data else 0

    # Fetch all active tiers ordered by tier_min
    tiers_res = db.table("influencer_payout_config").select("*").eq("is_active", True).order("tier_min").execute()

    if not tiers_res.data:
        # Fallback defaults
        return {
            "lead_payout": 50.00,
            "subscription_payout": 200.00,
            "tier_label": "Starter",
        }

    # Find matching tier
    matched = tiers_res.data[0]  # default to first
    for tier in tiers_res.data:
        t_min = tier.get("tier_min", 1)
        t_max = tier.get("tier_max")  # None = unlimited
        if qualified_count >= t_min:
            if t_max is None or qualified_count <= t_max:
                matched = tier
                break
            else:
                matched = tier  # keep going up

    return {
        "lead_payout": float(matched.get("lead_payout", 50)),
        "subscription_payout": float(matched.get("subscription_payout", 200)),
        "tier_label": matched.get("tier_label", "Starter"),
        "tier_min": matched.get("tier_min"),
        "tier_max": matched.get("tier_max"),
    }


# ── Wallet Credit ──────────────────────────────────────────────────────────────

def credit_wallet(influencer_id: str, amount: float, payout_type: str, lead_id: str = None, description: str = None):
    """
    Credit influencer wallet balance and log the transaction.
    payout_type: 'qualified_lead' | 'subscription' | 'manual_credit'
    """
    db = get_db()

    # Update wallet balance + total_earned
    profile = db.table("influencer_profiles").select("wallet_balance, total_earned").eq("id", influencer_id).execute()
    if not profile.data:
        logger.warning(f"credit_wallet: influencer_id={influencer_id} not found")
        return

    current_balance = float(profile.data[0].get("wallet_balance") or 0)
    current_total = float(profile.data[0].get("total_earned") or 0)

    db.table("influencer_profiles").update({
        "wallet_balance": round(current_balance + amount, 2),
        "total_earned": round(current_total + amount, 2),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", influencer_id).execute()

    # Log payout
    payout_data = {
        "influencer_id": influencer_id,
        "payout_type": payout_type,
        "amount": amount,
        "description": description or f"Credit for {payout_type}",
    }
    if lead_id:
        payout_data["lead_id"] = lead_id

    db.table("influencer_payouts").insert(payout_data).execute()
    logger.info(f"💰 Wallet credited: influencer={influencer_id}, amount=₹{amount}, type={payout_type}")


def process_qualified_lead_payout(lead_id: str):
    """
    Called when worker marks a lead as 'qualified'.
    Credits the influencer wallet with tier-appropriate amount.
    """
    db = get_db()

    lead_res = db.table("influencer_leads").select("*").eq("id", lead_id).execute()
    if not lead_res.data:
        return
    lead = lead_res.data[0]
    influencer_id = lead["influencer_id"]

    # Get tier payout
    tier = get_payout_tier(influencer_id)
    amount = tier["lead_payout"]

    # Credit wallet
    credit_wallet(
        influencer_id=influencer_id,
        amount=amount,
        payout_type="qualified_lead",
        lead_id=lead_id,
        description=f"Qualified lead payout (Tier: {tier['tier_label']})"
    )

    # Update lead record
    db.table("influencer_leads").update({
        "lead_payout_amount": amount,
        "lead_payout_status": "paid",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", lead_id).execute()

    # Increment qualified_leads count
    profile = db.table("influencer_profiles").select("qualified_leads").eq("id", influencer_id).execute()
    current_ql = int(profile.data[0].get("qualified_leads") or 0) if profile.data else 0
    db.table("influencer_profiles").update({
        "qualified_leads": current_ql + 1,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", influencer_id).execute()


def process_subscription_payout(merchant_id: str):
    """
    Called when a referred merchant activates a paid subscription.
    Credits the influencer with the subscription payout amount.
    """
    db = get_db()

    # Find the qualified lead record for this merchant
    lead_res = (
        db.table("influencer_leads")
        .select("*")
        .eq("merchant_id", merchant_id)
        .eq("status", "qualified")
        .eq("subscription_payout_status", "pending")
        .execute()
    )
    if not lead_res.data:
        return  # No qualified lead — nothing to pay
    lead = lead_res.data[0]
    influencer_id = lead["influencer_id"]

    tier = get_payout_tier(influencer_id)
    amount = tier["subscription_payout"]

    credit_wallet(
        influencer_id=influencer_id,
        amount=amount,
        payout_type="subscription",
        lead_id=lead["id"],
        description=f"Subscription payout (Tier: {tier['tier_label']})"
    )

    db.table("influencer_leads").update({
        "subscription_payout_amount": amount,
        "subscription_payout_status": "paid",
        "subscription_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", lead["id"]).execute()

    logger.info(f"💎 Subscription payout processed: influencer={influencer_id}, merchant={merchant_id}, amount=₹{amount}")


# ── Razorpay Payout (Automated + Manual Fallback) ─────────────────────────────

async def process_razorpay_payout(withdrawal_id: str):
    """
    Attempt automated Razorpay payout for a withdrawal request.
    If it fails, marks the withdrawal for manual fallback.
    """
    db = get_db()

    # Get withdrawal details
    wd_res = db.table("influencer_withdrawals").select("*").eq("id", withdrawal_id).execute()
    if not wd_res.data:
        return {"success": False, "error": "Withdrawal not found"}
    wd = wd_res.data[0]

    influencer_id = wd["influencer_id"]

    try:
        import razorpay
        client = razorpay.Client(
            auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
        )

        # Step 1: Create Fund Account (UPI or Bank)
        if wd.get("payment_method") == "upi" and wd.get("upi_id"):
            fund_account = client.fund_account.create({
                "contact_id": await _get_or_create_razorpay_contact(influencer_id),
                "account_type": "vpa",
                "vpa": {"address": wd["upi_id"]},
            })
        else:
            # Bank account
            fund_account = client.fund_account.create({
                "contact_id": await _get_or_create_razorpay_contact(influencer_id),
                "account_type": "bank_account",
                "bank_account": {
                    "name": wd.get("bank_account_name", ""),
                    "ifsc": wd.get("bank_ifsc", ""),
                    "account_number": wd.get("bank_account_number", ""),
                },
            })

        fund_account_id = fund_account.get("id")

        # Step 2: Create Payout
        payout = client.payout.create({
            "account_number": settings.RAZORPAY_PAYOUT_ACCOUNT,  # Your Razorpay X account number
            "fund_account_id": fund_account_id,
            "amount": int(wd["amount"] * 100),  # In paise
            "currency": "INR",
            "mode": "UPI" if wd.get("payment_method") == "upi" else "IMPS",
            "purpose": "payout",
            "queue_if_low_balance": True,
            "reference_id": f"CV-INF-{withdrawal_id[:8].upper()}",
            "narration": "CODVerify Influencer Payout",
        })

        payout_id = payout.get("id")
        payout_status = payout.get("status", "processing")

        # Update withdrawal record
        db.table("influencer_withdrawals").update({
            "razorpay_payout_id": payout_id,
            "razorpay_fund_account_id": fund_account_id,
            "razorpay_status": payout_status,
            "status": "processing" if payout_status in ("queued", "processing") else "paid",
            "processed_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", withdrawal_id).execute()

        # Deduct from wallet
        _deduct_wallet(influencer_id, float(wd["amount"]))

        logger.info(f"✅ Razorpay payout initiated: {payout_id} for withdrawal {withdrawal_id}")
        return {"success": True, "payout_id": payout_id, "status": payout_status}

    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ Razorpay payout failed for withdrawal {withdrawal_id}: {error_msg}")

        # Mark as failed — trigger manual fallback
        db.table("influencer_withdrawals").update({
            "razorpay_status": "failed",
            "razorpay_failure_reason": error_msg[:500],
            "status": "failed",
            "is_manual_fallback": True,
        }).eq("id", withdrawal_id).execute()

        return {"success": False, "error": error_msg, "manual_required": True}


async def _get_or_create_razorpay_contact(influencer_id: str) -> str:
    """Get or create Razorpay contact for an influencer."""
    import razorpay
    db = get_db()

    profile_res = db.table("influencer_profiles").select("*, users(email, name, phone)").eq("id", influencer_id).execute()
    if not profile_res.data:
        raise ValueError(f"Influencer {influencer_id} not found")

    profile = profile_res.data[0]
    user_data = profile.get("users") or {}

    client = razorpay.Client(
        auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
    )

    contact = client.contact.create({
        "name": profile.get("full_name") or user_data.get("name", "Influencer"),
        "email": user_data.get("email", ""),
        "contact": user_data.get("phone", ""),
        "type": "vendor",
        "reference_id": f"CV-INF-{influencer_id[:8]}",
    })
    return contact.get("id")


def _deduct_wallet(influencer_id: str, amount: float):
    """Deduct amount from influencer wallet after successful withdrawal."""
    db = get_db()
    profile = db.table("influencer_profiles").select("wallet_balance").eq("id", influencer_id).execute()
    if not profile.data:
        return
    current = float(profile.data[0].get("wallet_balance") or 0)
    new_balance = max(0, round(current - amount, 2))
    db.table("influencer_profiles").update({
        "wallet_balance": new_balance,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", influencer_id).execute()

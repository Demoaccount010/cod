from datetime import datetime, timezone
import re
import httpx
from loguru import logger
from config.database import get_db
from config.settings import settings
from utils.encryption import decrypt_value
from services.whatsapp_service import send_interactive_button_message
from services.notification_service import create_notification


def is_india_number(phone: str) -> bool:
    digits = re.sub(r"\D", "", phone)
    return digits.startswith("91") and len(digits) == 12


async def process_pending_orders():
    """Process orders scheduled for verification via WhatsApp."""
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()

    try:
        result = db.table("orders").select("*").eq(
            "verification_status", "pending"
        ).lte("scheduled_send_at", now).limit(50).execute()

        if not result.data:
            return

        for order in result.data:
            try:
                await _send_verification_for_order(db, order)
            except Exception as e:
                logger.error(f"Error processing order {order['id']}: {e}")
                continue
    except Exception as e:
        logger.error(f"Error in process_pending_orders: {e}")


async def _send_verification_for_order(db, order: dict):
    """Route verification to the correct channel based on customer phone country."""
    # Check message toggles
    ms_res = db.table("merchant_settings").select(
        "enable_verification_msg, cod_verification_enabled"
    ).eq("user_id", order["user_id"]).execute()

    if ms_res.data:
        ms = ms_res.data[0]
        # Skip if COD verification service is disabled (customer support plan only)
        if ms.get("cod_verification_enabled") is False:
            logger.info(f"COD verification disabled for user {order['user_id']}, skipping order {order['id']}")
            return
        # Skip if verification messages are toggled off
        if ms.get("enable_verification_msg") is False:
            logger.info(f"Verification msg disabled for user {order['user_id']}, skipping order {order['id']}")
            return

    # --- Detect channel from customer phone number ---
    customer_phone = order.get("customer_phone_normalized", "")

    if is_india_number(customer_phone):
        success = await _send_whatsapp_verification(db, order)
    else:
        # Non-India numbers — send WhatsApp as well (works globally if customer has WhatsApp)
        logger.info(f"Order {order['id']} → WhatsApp for phone={customer_phone}")
        success = await _send_whatsapp_verification(db, order)

    return success


async def _build_verification_message(order: dict, channel: str = "whatsapp") -> str:
    """Build the verification message text for WhatsApp (India)."""
    products = order.get("products_json") or []
    product_names = ", ".join([p.get("name", "Item") for p in products[:3]])
    if len(products) > 3:
        product_names += f" +{len(products)-3} more"

    addr = order.get("shipping_address_json") or {}
    address_short = f"{addr.get('city', '')}, {addr.get('state', '')} {addr.get('pincode', '')}".strip(", ")
    amount = order.get("order_amount", 0)
    currency_sym = "$" if order.get("currency") == "USD" else "₹"
    order_num = order.get("order_number", order.get("store_order_id", "N/A"))

    # WhatsApp rich format
    return (
        f"Hi {order['customer_name']}! 👋\n\n"
        f"Your order *#{order_num}* has been placed.\n\n"
        f"📦 Items: {product_names}\n"
        f"💰 Amount: {currency_sym}{amount}\n"
        f"📍 Delivery: {address_short}\n\n"
        f"Please confirm if you want us to ship this order."
    )


async def _send_whatsapp_verification(db, order: dict) -> bool:
    """Send WhatsApp interactive button message for verification (India — unchanged)."""
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    access_token = settings.WHATSAPP_ACCESS_TOKEN

    if not phone_id or not access_token:
        logger.warning(f"WhatsApp credentials not configured — skipping order {order['id']}")
        db.table("orders").update({"verification_status": "failed"}).eq("id", order["id"]).execute()
        return False

    body_text = await _build_verification_message(order, "whatsapp")
    buttons = [
        {"type": "reply", "reply": {"id": "confirm_yes", "title": "✅ Confirm Order"}},
        {"type": "reply", "reply": {"id": "confirm_no", "title": "❌ Cancel Order"}},
    ]

    wa_msg_id = await send_interactive_button_message(
        phone_id, access_token, order["customer_phone_normalized"],
        body_text, buttons, "Order Confirmation", "Powered by CODVerify"
    )

    if wa_msg_id:
        now_ts = datetime.now(timezone.utc).isoformat()
        db.table("orders").update({
            "verification_status": "queued",
            "verification_sent_at": now_ts,
            "verification_channel": "whatsapp",
        }).eq("id", order["id"]).execute()

        db.table("messages").insert({
            "order_id": order["id"],
            "user_id": order["user_id"],
            "whatsapp_message_id": wa_msg_id,
            "direction": "outbound",
            "message_type": "interactive",
            "content": body_text,
            "status": "queued",
        }).execute()

        logger.info(f"WhatsApp verification sent for order {order['id']}, wa_msg={wa_msg_id}")
        return True
    else:
        db.table("orders").update({"verification_status": "failed"}).eq("id", order["id"]).execute()
        logger.error(f"WhatsApp verification failed for order {order['id']}")
        return False


async def check_timeouts():
    """Check for unresponsive orders and handle retries or timeouts."""
    db = get_db()

    try:
        orders = db.table("orders").select("*").in_(
            "verification_status", ["sent", "delivered", "read", "queued"]
        ).execute()

        if not orders.data:
            return

        now = datetime.now(timezone.utc)
        for order in orders.data:
            timeout_hours = 4  # Default timeout
            max_retries = 3    # Default retries
            sent_at = order.get("verification_sent_at")
            if not sent_at:
                continue

            sent_time = datetime.fromisoformat(sent_at.replace("Z", "+00:00"))
            hours_elapsed = (now - sent_time).total_seconds() / 3600

            if hours_elapsed < timeout_hours:
                continue

            if order.get("retry_count", 0) < max_retries:
                db.table("orders").update({
                    "verification_status": "pending",
                    "retry_count": order.get("retry_count", 0) + 1,
                    "scheduled_send_at": datetime.now(timezone.utc).isoformat(),
                }).eq("id", order["id"]).execute()
            else:
                db.table("orders").update({
                    "verification_status": "no_reply",
                }).eq("id", order["id"]).execute()

                # Update customer risk score since they ignored all retries
                from utils.phone_utils import hash_phone
                p_norm = order.get("customer_phone_normalized", "")
                if p_norm:
                    p_hash = hash_phone(p_norm)
                    cust = db.table("customers_directory").select("rto_orders, risk_score").eq("phone_number_hash", p_hash).execute()
                    if cust.data:
                        new_rto = cust.data[0].get("rto_orders", 0) + 1
                        new_risk = min(100, cust.data[0].get("risk_score", 0) + 20)
                        db.table("customers_directory").update({
                            "rto_orders": new_rto,
                            "risk_score": new_risk,
                        }).eq("phone_number_hash", p_hash).execute()

                await create_notification(
                    order["user_id"],
                    f"No reply for Order #{order.get('order_number', order.get('store_order_id'))}",
                    f"Customer didn't respond after {max_retries} attempts.",
                    "warning", "orders"
                )
    except Exception as e:
        logger.error(f"Error in check_timeouts: {e}")


async def update_store_order(order: dict, new_status: str):
    """Update the order on the merchant's e-commerce store."""
    db = get_db()
    if not order.get("store_id"):
        return

    store_res = db.table("stores").select("*").eq("id", order["store_id"]).execute()
    if not store_res.data:
        return
    store_data = store_res.data[0]
    platform = store_data.get("platform")

    try:
        if platform == "shopify":
            await _update_shopify_order(store_data, order, new_status)
        elif platform == "woocommerce":
            await _update_woocommerce_order(store_data, order, new_status)
        elif platform == "custom":
            await _update_custom_store_order(store_data, order, new_status)

        db.table("orders").update({
            "store_updated": True,
            "store_update_response": f"Updated to {new_status} on {platform}",
        }).eq("id", order["id"]).execute()
    except Exception as e:
        logger.error(f"Store update failed for order {order['id']}: {e}")
        db.table("orders").update({
            "store_update_response": f"Update failed: {str(e)}",
        }).eq("id", order["id"]).execute()


async def _update_shopify_order(store: dict, order: dict, status: str):
    access_token = decrypt_value(store.get("access_token_encrypted", ""))
    if not access_token:
        # Fallback to api_secret if access_token not available
        access_token = decrypt_value(store.get("api_secret_encrypted", ""))
    if not access_token:
        logger.warning(f"No Shopify access token for store {store.get('store_url')} — skipping update")
        return

    store_url = store["store_url"].rstrip("/")
    if not store_url.startswith("https://"):
        store_url = f"https://{store_url}"

    tag = "CODVerify-Confirmed" if status == "confirmed" else "CODVerify-Cancelled"
    note = f"CODVerify: Order {status} by customer"
    headers = {"X-Shopify-Access-Token": access_token}

    async with httpx.AsyncClient(timeout=30) as client:
        # Always update tags + note
        url = f"{store_url}/admin/api/2024-01/orders/{order['store_order_id']}.json"
        resp = await client.put(url, json={"order": {"tags": tag, "note": note}}, headers=headers)
        if resp.status_code >= 400:
            logger.error(f"Shopify order update failed ({resp.status_code}): {resp.text[:200]}")
            raise Exception(f"Shopify API returned {resp.status_code}")

        # If cancelled — actually cancel the Shopify order too
        if status == "cancelled":
            cancel_url = f"{store_url}/admin/api/2024-01/orders/{order['store_order_id']}/cancel.json"
            cancel_resp = await client.post(cancel_url, json={"reason": "customer"}, headers=headers)
            if cancel_resp.status_code >= 400:
                logger.warning(f"Shopify order cancel API failed ({cancel_resp.status_code}): {cancel_resp.text[:200]}")
                # Non-fatal — tag is already set, just log
            else:
                logger.info(f"Shopify order {order['store_order_id']} cancelled via API")


async def _update_woocommerce_order(store: dict, order: dict, status: str):
    api_key = decrypt_value(store.get("api_key_encrypted", ""))
    api_secret = decrypt_value(store.get("api_secret_encrypted", ""))
    store_url = store["store_url"].rstrip("/")
    if not store_url.startswith("https://") and not store_url.startswith("http://"):
        store_url = f"https://{store_url}"
    note = f"CODVerify: Order {status} by customer"

    async with httpx.AsyncClient(timeout=30) as client:
        url = f"{store_url}/wp-json/wc/v3/orders/{order['store_order_id']}/notes"
        await client.post(url, json={"note": note}, auth=(api_key, api_secret))


async def _update_custom_store_order(store: dict, order: dict, status: str):
    ms_res = get_db().table("merchant_settings").select("webhook_callback_url").eq(
        "user_id", order["user_id"]
    ).execute()
    callback_url = ms_res.data[0].get("webhook_callback_url") if ms_res.data else None
    if not callback_url:
        return

    async with httpx.AsyncClient(timeout=30) as client:
        await client.post(callback_url, json={
            "event": "order_status_updated",
            "store_order_id": order["store_order_id"],
            "status": status,
            "order_id": order["id"],
        })

"""
Invoice PDF generator for CODVerify.
Uses reportlab to create professional PDF invoices attached to emails.
"""
import io
from datetime import datetime, timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Spacer, Paragraph, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from loguru import logger


# ─── Brand colors ────────────────────────────────────────────────────────
BRAND_PURPLE = colors.HexColor("#4338CA")
BRAND_LIGHT = colors.HexColor("#EDE9FE")
BRAND_DARK = colors.HexColor("#1E1B4B")
BRAND_GRAY = colors.HexColor("#6B7280")
BRAND_GREEN = colors.HexColor("#059669")
BRAND_RED = colors.HexColor("#DC2626")
WHITE = colors.white


def _build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        "BrandTitle", parent=styles["Heading1"],
        fontSize=22, textColor=BRAND_PURPLE, spaceAfter=4, fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        "InvoiceNo", parent=styles["Normal"],
        fontSize=10, textColor=BRAND_GRAY, fontName="Helvetica",
    ))
    styles.add(ParagraphStyle(
        "SectionHeader", parent=styles["Heading2"],
        fontSize=11, textColor=BRAND_DARK, spaceAfter=6, spaceBefore=12,
        fontName="Helvetica-Bold", borderWidth=0,
    ))
    styles.add(ParagraphStyle(
        "CellText", parent=styles["Normal"],
        fontSize=9, textColor=BRAND_DARK, fontName="Helvetica",
    ))
    styles.add(ParagraphStyle(
        "CellLabel", parent=styles["Normal"],
        fontSize=9, textColor=BRAND_GRAY, fontName="Helvetica",
    ))
    styles.add(ParagraphStyle(
        "Footer", parent=styles["Normal"],
        fontSize=7, textColor=BRAND_GRAY, alignment=TA_CENTER, fontName="Helvetica",
    ))
    styles.add(ParagraphStyle(
        "TotalAmount", parent=styles["Normal"],
        fontSize=14, textColor=BRAND_PURPLE, fontName="Helvetica-Bold", alignment=TA_RIGHT,
    ))
    styles.add(ParagraphStyle(
        "StatusPaid", parent=styles["Normal"],
        fontSize=10, textColor=BRAND_GREEN, fontName="Helvetica-Bold", alignment=TA_CENTER,
    ))
    styles.add(ParagraphStyle(
        "StatusDue", parent=styles["Normal"],
        fontSize=10, textColor=BRAND_RED, fontName="Helvetica-Bold", alignment=TA_CENTER,
    ))
    return styles


def generate_invoice_pdf(invoice_data: dict) -> bytes:
    """
    Generate a professional PDF invoice.

    invoice_data keys:
        invoice_number, contract_number, issue_date, due_date,
        merchant_name, merchant_email, merchant_store, merchant_address,
        plan_name, chatbot_tier, billing_period,
        line_items: [{name, description, amount}],
        subtotal, tax_rate, tax_amount, total,
        currency (INR/USD), payment_status (paid/due),
        notes
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm,
    )
    styles = _build_styles()
    elements = []

    # ── Header ──
    invoice_no = invoice_data.get("invoice_number", "INV-000000")
    issue_date = invoice_data.get("issue_date", datetime.now(timezone.utc).strftime("%B %d, %Y"))
    due_date = invoice_data.get("due_date", "")
    currency = invoice_data.get("currency", "INR")
    sym = "\u20B9" if currency == "INR" else "$"

    header_data = [
        [
            Paragraph("CODVerify", styles["BrandTitle"]),
            Paragraph(f"INVOICE", ParagraphStyle("InvTitle", parent=styles["BrandTitle"], alignment=TA_RIGHT, fontSize=18, textColor=BRAND_GRAY)),
        ],
        [
            Paragraph("Intelligent COD Order Verification", styles["CellLabel"]),
            Paragraph(f"<b>{invoice_no}</b>", ParagraphStyle("InvNoRight", parent=styles["InvoiceNo"], alignment=TA_RIGHT)),
        ],
        [
            Paragraph("codverify.tech", styles["CellLabel"]),
            Paragraph(f"Date: {issue_date}", ParagraphStyle("DateRight", parent=styles["CellLabel"], alignment=TA_RIGHT)),
        ],
    ]
    if due_date:
        header_data.append([
            Paragraph("", styles["CellLabel"]),
            Paragraph(f"Due: {due_date}", ParagraphStyle("DueRight", parent=styles["CellLabel"], alignment=TA_RIGHT)),
        ])

    header_table = Table(header_data, colWidths=[doc.width * 0.55, doc.width * 0.45])
    header_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 6 * mm))

    # Purple divider line
    elements.append(HRFlowable(width="100%", thickness=2, color=BRAND_PURPLE, spaceAfter=8))

    # ── Bill To ──
    merchant_name = invoice_data.get("merchant_name", "")
    merchant_email = invoice_data.get("merchant_email", "")
    merchant_store = invoice_data.get("merchant_store", "")
    merchant_address = invoice_data.get("merchant_address", "")

    elements.append(Paragraph("BILL TO", styles["SectionHeader"]))
    bill_to_data = []
    if merchant_name:
        bill_to_data.append([Paragraph(f"<b>{merchant_name}</b>", styles["CellText"])])
    if merchant_store:
        bill_to_data.append([Paragraph(f"Store: {merchant_store}", styles["CellLabel"])])
    if merchant_email:
        bill_to_data.append([Paragraph(f"Email: {merchant_email}", styles["CellLabel"])])
    if merchant_address:
        bill_to_data.append([Paragraph(f"Address: {merchant_address}", styles["CellLabel"])])

    if bill_to_data:
        bill_table = Table(bill_to_data, colWidths=[doc.width])
        bill_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), BRAND_LIGHT),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("ROUNDEDCORNERS", [4, 4, 4, 4]),
        ]))
        elements.append(bill_table)
    elements.append(Spacer(1, 6 * mm))

    # ── Line Items ──
    elements.append(Paragraph("SERVICES", styles["SectionHeader"]))

    line_items = invoice_data.get("line_items", [])
    if not line_items:
        plan_name = invoice_data.get("plan_name", "CODVerify Service")
        chatbot_tier = invoice_data.get("chatbot_tier", "")
        total = invoice_data.get("total", 0)
        line_items = [{"name": plan_name, "description": f"Chatbot: {chatbot_tier}" if chatbot_tier and chatbot_tier != "none" else "", "amount": total}]

    # Table header
    items_data = [
        [
            Paragraph("<b>#</b>", ParagraphStyle("ItemH", parent=styles["CellLabel"], textColor=WHITE, fontSize=8)),
            Paragraph("<b>Service</b>", ParagraphStyle("ItemH2", parent=styles["CellLabel"], textColor=WHITE, fontSize=8)),
            Paragraph("<b>Amount</b>", ParagraphStyle("ItemH3", parent=styles["CellLabel"], textColor=WHITE, alignment=TA_RIGHT, fontSize=8)),
        ]
    ]

    for i, item in enumerate(line_items, 1):
        desc = item.get("description", "")
        name_text = item.get("name", "Service")
        if desc:
            name_text = f"{name_text}<br/><font size=7 color='#9CA3AF'>{desc}</font>"
        items_data.append([
            Paragraph(str(i), styles["CellText"]),
            Paragraph(name_text, styles["CellText"]),
            Paragraph(f"{sym}{item.get('amount', 0):,.2f}", ParagraphStyle("AmtCell", parent=styles["CellText"], alignment=TA_RIGHT)),
        ])

    items_table = Table(items_data, colWidths=[doc.width * 0.08, doc.width * 0.64, doc.width * 0.28])
    items_style = [
        # Header row
        ("BACKGROUND", (0, 0), (-1, 0), BRAND_PURPLE),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E5E7EB")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, BRAND_LIGHT]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]
    items_table.setStyle(TableStyle(items_style))
    elements.append(items_table)
    elements.append(Spacer(1, 4 * mm))

    # ── Totals ──
    subtotal = invoice_data.get("subtotal", invoice_data.get("total", 0))
    tax_rate = invoice_data.get("tax_rate", 0)
    tax_amount = invoice_data.get("tax_amount", 0)
    total = invoice_data.get("total", 0)

    totals_data = [
        [Paragraph("Subtotal", styles["CellLabel"]), Paragraph(f"{sym}{subtotal:,.2f}", ParagraphStyle("TotR", parent=styles["CellText"], alignment=TA_RIGHT))],
    ]
    if tax_rate > 0:
        totals_data.append([
            Paragraph(f"Tax (GST {tax_rate}%)", styles["CellLabel"]),
            Paragraph(f"{sym}{tax_amount:,.2f}", ParagraphStyle("TaxR", parent=styles["CellText"], alignment=TA_RIGHT)),
        ])
    totals_data.append([
        Paragraph("<b>TOTAL</b>", ParagraphStyle("TotLabel", parent=styles["CellText"], fontSize=11)),
        Paragraph(f"<b>{sym}{total:,.2f}</b>", styles["TotalAmount"]),
    ])

    totals_table = Table(totals_data, colWidths=[doc.width * 0.7, doc.width * 0.3])
    totals_table.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LINEABOVE", (0, -1), (-1, -1), 1.5, BRAND_PURPLE),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
    ]))
    elements.append(totals_table)
    elements.append(Spacer(1, 4 * mm))

    # ── Payment Status ──
    payment_status = invoice_data.get("payment_status", "due")
    status_style = styles["StatusPaid"] if payment_status == "paid" else styles["StatusDue"]
    status_label = "PAID" if payment_status == "paid" else "PAYMENT DUE"
    status_data = [[Paragraph(f"\u2588\u2588 {status_label} \u2588\u2588", status_style)]]
    status_table = Table(status_data, colWidths=[doc.width])
    bg_color = colors.HexColor("#ECFDF5") if payment_status == "paid" else colors.HexColor("#FEF2F2")
    status_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg_color),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ]))
    elements.append(status_table)
    elements.append(Spacer(1, 6 * mm))

    # ── Notes ──
    notes = invoice_data.get("notes", "")
    if notes:
        elements.append(Paragraph("NOTES", styles["SectionHeader"]))
        elements.append(Paragraph(notes, styles["CellLabel"]))
        elements.append(Spacer(1, 4 * mm))

    # ── Footer ──
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#E5E7EB"), spaceAfter=6))
    elements.append(Paragraph("CODVerify \u2022 Intelligent COD Order Verification Platform", styles["Footer"]))
    elements.append(Paragraph("India & International \u2022 codverify.tech", styles["Footer"]))
    elements.append(Paragraph("\u00A9 2024\u20132026 CODVerify. All rights reserved.", styles["Footer"]))

    # Build PDF
    try:
        doc.build(elements)
    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        raise

    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes

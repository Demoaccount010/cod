"""
Invoice PDF generator for CODVerify.
Ultra-premium professional design using reportlab.
"""
import io
from datetime import datetime, timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Spacer,
    Paragraph, HRFlowable, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics import renderPDF
from loguru import logger


# ─── Brand Palette ────────────────────────────────────────────────────────────
BRAND_PURPLE     = colors.HexColor("#4338CA")
BRAND_PURPLE_MID = colors.HexColor("#6366F1")
BRAND_PURPLE_LT  = colors.HexColor("#818CF8")
BRAND_INDIGO_BG  = colors.HexColor("#EEF2FF")
BRAND_INDIGO_BORDER = colors.HexColor("#C7D2FE")
BRAND_DARK       = colors.HexColor("#1E1B4B")
BRAND_GRAY       = colors.HexColor("#6B7280")
BRAND_GRAY_LT    = colors.HexColor("#9CA3AF")
BRAND_GREEN      = colors.HexColor("#059669")
BRAND_GREEN_BG   = colors.HexColor("#ECFDF5")
BRAND_RED        = colors.HexColor("#DC2626")
BRAND_RED_BG     = colors.HexColor("#FEF2F2")
BRAND_BODY       = colors.HexColor("#374151")
BRAND_ROW_ALT    = colors.HexColor("#F8FAFF")
BORDER_COLOR     = colors.HexColor("#E0E7FF")
WHITE            = colors.white
OFF_WHITE        = colors.HexColor("#FAFBFF")


def _styles():
    s = getSampleStyleSheet()

    def add(name, **kw):
        parent = kw.pop("parent", "Normal")
        s.add(ParagraphStyle(name, parent=s[parent], **kw))

    add("LogoBrand",   fontSize=20, textColor=WHITE,        fontName="Helvetica-Bold", leading=24)
    add("LogoTag",     fontSize=8,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", leading=12)
    add("InvLabel",    fontSize=18, textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_RIGHT, leading=22)
    add("InvNumR",     fontSize=9,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", alignment=TA_RIGHT, leading=13)
    add("InvDateR",    fontSize=9,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", alignment=TA_RIGHT, leading=13)

    add("SectionHead", fontSize=7,  textColor=BRAND_GRAY,  fontName="Helvetica-Bold",
        spaceAfter=4, letterSpacing=1.0, textTransform="uppercase")
    add("BillName",    fontSize=11, textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=15)
    add("BillDetail",  fontSize=9,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=13)

    add("TH",          fontSize=8,  textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_LEFT)
    add("THR",         fontSize=8,  textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_RIGHT)
    add("Cell",        fontSize=9,  textColor=BRAND_BODY,   fontName="Helvetica", leading=13)
    add("CellGray",    fontSize=8,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=12)
    add("CellR",       fontSize=9,  textColor=BRAND_BODY,   fontName="Helvetica", alignment=TA_RIGHT, leading=13)
    add("CellBold",    fontSize=9,  textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=13)
    add("TotalLabel",  fontSize=11, textColor=BRAND_DARK,  fontName="Helvetica-Bold")
    add("TotalAmt",    fontSize=14, textColor=BRAND_PURPLE, fontName="Helvetica-Bold", alignment=TA_RIGHT)

    add("StatusPaid",  fontSize=11, textColor=BRAND_GREEN,  fontName="Helvetica-Bold", alignment=TA_CENTER)
    add("StatusDue",   fontSize=11, textColor=BRAND_RED,    fontName="Helvetica-Bold", alignment=TA_CENTER)

    add("NoteText",    fontSize=9,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=14)
    add("Footer",      fontSize=7,  textColor=BRAND_GRAY_LT, fontName="Helvetica", alignment=TA_CENTER, leading=11)
    add("FooterBold",  fontSize=8,  textColor=BRAND_PURPLE, fontName="Helvetica-Bold", alignment=TA_CENTER, leading=12)
    return s


def _header_table(doc, invoice_no, issue_date, due_date, styles):
    """Purple gradient header with brand name + invoice label."""
    W = doc.width
    # Left column: brand
    left = [
        [Paragraph("CODVerify", styles["LogoBrand"])],
        [Paragraph("Intelligent COD Order Verification", styles["LogoTag"])],
        [Paragraph("codverify.tech", styles["LogoTag"])],
    ]
    left_tbl = Table(left, colWidths=[W * 0.55])
    left_tbl.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))

    # Right column: INVOICE label + number + dates
    right_rows = [
        [Paragraph("INVOICE", styles["InvLabel"])],
        [Paragraph(f"<b>{invoice_no}</b>", styles["InvNumR"])],
        [Paragraph(f"Date: {issue_date}", styles["InvDateR"])],
    ]
    if due_date:
        right_rows.append([Paragraph(f"Due: {due_date}", styles["InvDateR"])])

    right_tbl = Table(right_rows, colWidths=[W * 0.45])
    right_tbl.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
    ]))

    outer = Table([[left_tbl, right_tbl]], colWidths=[W * 0.55, W * 0.45])
    outer.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_PURPLE),
        ("TOPPADDING", (0, 0), (-1, -1), 22),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 22),
        ("LEFTPADDING", (0, 0), (-1, -1), 24),
        ("RIGHTPADDING", (0, 0), (-1, -1), 24),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROUNDEDCORNERS", [8, 8, 0, 0]),
    ]))
    return outer


def _bill_section(doc, merchant_name, merchant_email, merchant_store, merchant_address, styles):
    """Two‑column section: Bill To (left) + Company info (right)."""
    W = doc.width

    bill_lines = []
    if merchant_name:
        bill_lines.append(Paragraph(merchant_name, styles["BillName"]))
    if merchant_store:
        bill_lines.append(Paragraph(f"Store: {merchant_store}", styles["BillDetail"]))
    if merchant_email:
        bill_lines.append(Paragraph(f"Email: {merchant_email}", styles["BillDetail"]))
    if merchant_address:
        bill_lines.append(Paragraph(merchant_address, styles["BillDetail"]))

    company_lines = [
        Paragraph("CODVerify", styles["BillName"]),
        Paragraph("Intelligent COD Verification Platform", styles["BillDetail"]),
        Paragraph("India & International", styles["BillDetail"]),
        Paragraph("support@codverify.tech", styles["BillDetail"]),
        Paragraph("codverify.tech", styles["BillDetail"]),
    ]

    def _col(label, items):
        rows = [[Paragraph(label, styles["SectionHead"])]]
        for item in items:
            rows.append([item])
        t = Table(rows, colWidths=[W * 0.45])
        t.setStyle(TableStyle([
            ("TOPPADDING", (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ]))
        return t

    outer = Table(
        [[_col("BILL TO", bill_lines), _col("FROM", company_lines)]],
        colWidths=[W * 0.5, W * 0.5]
    )
    outer.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_INDIGO_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER_COLOR),
        ("TOPPADDING", (0, 0), (-1, -1), 14),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 14),
        ("LEFTPADDING", (0, 0), (-1, -1), 16),
        ("RIGHTPADDING", (0, 0), (-1, -1), 16),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return outer


def _items_table(doc, line_items, sym, styles):
    """Ultra-clean services table."""
    W = doc.width
    header = [
        Paragraph("#", styles["TH"]),
        Paragraph("Service / Description", styles["TH"]),
        Paragraph("Amount", styles["THR"]),
    ]
    rows = [header]
    for i, item in enumerate(line_items, 1):
        desc = item.get("description", "")
        name = item.get("name", "Service")
        if desc:
            cell = Paragraph(f"{name}<br/><font size='7' color='#9CA3AF'>{desc}</font>", styles["Cell"])
        else:
            cell = Paragraph(name, styles["Cell"])
        amt = item.get("amount", 0)
        rows.append([
            Paragraph(str(i), styles["CellGray"]),
            cell,
            Paragraph(f"{sym}{amt:,.2f}" if amt else "Included", styles["CellR"]),
        ])

    col_w = [W * 0.06, W * 0.68, W * 0.26]
    t = Table(rows, colWidths=col_w, repeatRows=1)
    bg_alt = [BRAND_ROW_ALT, WHITE]
    t.setStyle(TableStyle([
        # Header
        ("BACKGROUND", (0, 0), (-1, 0), BRAND_PURPLE),
        ("LINEBELOW", (0, 0), (-1, 0), 0, WHITE),
        # Data rows alternating
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), bg_alt),
        # Grid
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, BORDER_COLOR),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, 0), 10),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 10),
        ("TOPPADDING", (0, 1), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 9),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        # Box
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ]))
    return t


def _totals_table(doc, subtotal, tax_rate, tax_amount, total, sym, styles):
    W = doc.width
    rows = [
        [Paragraph("Subtotal", styles["BillDetail"]),
         Paragraph(f"{sym}{subtotal:,.2f}", styles["CellR"])],
    ]
    if tax_rate > 0:
        rows.append([
            Paragraph(f"GST ({tax_rate}%)", styles["BillDetail"]),
            Paragraph(f"{sym}{tax_amount:,.2f}", styles["CellR"])],
        )
    rows.append([
        Paragraph("<b>TOTAL AMOUNT</b>", styles["TotalLabel"]),
        Paragraph(f"<b>{sym}{total:,.2f}</b>", styles["TotalAmt"])],
    )

    right_w = W * 0.35
    t = Table(rows, colWidths=[W - right_w, right_w])
    t.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("LINEABOVE", (0, -1), (-1, -1), 1.5, BRAND_PURPLE),
        ("BACKGROUND", (0, -1), (-1, -1), BRAND_INDIGO_BG),
        ("TOPPADDING", (0, -1), (-1, -1), 10),
        ("BOTTOMPADDING", (0, -1), (-1, -1), 10),
        ("LEFTPADDING", (0, -1), (-1, -1), 10),
        ("RIGHTPADDING", (0, -1), (-1, -1), 10),
        ("BOX", (0, -1), (-1, -1), 0.5, BORDER_COLOR),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _status_badge(doc, payment_status, styles):
    W = doc.width
    if payment_status == "paid":
        label = "PAYMENT CONFIRMED"
        style = styles["StatusPaid"]
        bg = BRAND_GREEN_BG
        border = colors.HexColor("#A7F3D0")
    else:
        label = "PAYMENT DUE"
        style = styles["StatusDue"]
        bg = BRAND_RED_BG
        border = colors.HexColor("#FECACA")

    t = Table([[Paragraph(label, style)]], colWidths=[W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("BOX", (0, 0), (-1, -1), 1, border),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ]))
    return t


def generate_invoice_pdf(invoice_data: dict) -> bytes:
    """
    Generate ultra-premium PDF invoice.

    invoice_data keys:
        invoice_number, contract_number, issue_date, due_date,
        merchant_name, merchant_email, merchant_store, merchant_address,
        plan_name, chatbot_tier, billing_period,
        line_items: [{name, description, amount}],
        subtotal, tax_rate, tax_amount, total,
        currency (INR/USD), payment_status (paid/due),
        notes
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=12 * mm, bottomMargin=12 * mm,
    )
    styles = _styles()
    elements = []

    # ── Data Extraction ──
    invoice_no    = invoice_data.get("invoice_number", "INV-000000")
    issue_date    = invoice_data.get("issue_date", datetime.now(timezone.utc).strftime("%B %d, %Y"))
    due_date      = invoice_data.get("due_date", "")
    currency      = invoice_data.get("currency", "INR")
    sym           = "\u20B9" if currency == "INR" else "$"
    merchant_name = invoice_data.get("merchant_name", "")
    merchant_email= invoice_data.get("merchant_email", "")
    merchant_store= invoice_data.get("merchant_store", "")
    merchant_addr = invoice_data.get("merchant_address", "")
    subtotal      = invoice_data.get("subtotal", invoice_data.get("total", 0))
    tax_rate      = invoice_data.get("tax_rate", 0)
    tax_amount    = invoice_data.get("tax_amount", 0)
    total         = invoice_data.get("total", 0)
    payment_status= invoice_data.get("payment_status", "due")
    notes         = invoice_data.get("notes", "")

    line_items = invoice_data.get("line_items", [])
    if not line_items:
        plan_name   = invoice_data.get("plan_name", "CODVerify Service Plan")
        chatbot     = invoice_data.get("chatbot_tier", "")
        line_items  = [{
            "name": plan_name,
            "description": f"AI Chatbot Tier: {chatbot.capitalize()}" if chatbot and chatbot != "none" else "",
            "amount": total,
        }]

    # ── 1. Header ──
    elements.append(_header_table(doc, invoice_no, issue_date, due_date, styles))
    elements.append(Spacer(1, 6 * mm))

    # ── 2. Bill To / From ──
    elements.append(_bill_section(doc, merchant_name, merchant_email, merchant_store, merchant_addr, styles))
    elements.append(Spacer(1, 6 * mm))

    # ── 3. Purple divider + SERVICES label ──
    elements.append(HRFlowable(width="100%", thickness=1.5, color=BRAND_PURPLE, spaceAfter=2, spaceBefore=0))
    elements.append(Paragraph("SERVICES", styles["SectionHead"]))
    elements.append(Spacer(1, 2 * mm))

    # ── 4. Line Items ──
    elements.append(_items_table(doc, line_items, sym, styles))
    elements.append(Spacer(1, 5 * mm))

    # ── 5. Totals ──
    elements.append(_totals_table(doc, subtotal, tax_rate, tax_amount, total, sym, styles))
    elements.append(Spacer(1, 5 * mm))

    # ── 6. Payment Status Badge ──
    elements.append(_status_badge(doc, payment_status, styles))
    elements.append(Spacer(1, 6 * mm))

    # ── 7. Notes ──
    if notes:
        elements.append(Paragraph("NOTES", styles["SectionHead"]))
        elements.append(Spacer(1, 1 * mm))
        elements.append(Paragraph(notes, styles["NoteText"]))
        elements.append(Spacer(1, 5 * mm))

    # ── 8. Footer ──
    elements.append(HRFlowable(width="100%", thickness=0.5, color=BORDER_COLOR, spaceAfter=4, spaceBefore=0))
    elements.append(Paragraph("CODVerify", styles["FooterBold"]))
    elements.append(Paragraph("Intelligent COD Order Verification Platform", styles["Footer"]))
    elements.append(Paragraph("India & International  \u2022  codverify.tech  \u2022  support@codverify.tech", styles["Footer"]))
    elements.append(Paragraph(
        f"Invoice {invoice_no}  \u2022  Generated {issue_date}  \u2022  \u00A9 2024\u20132026 CODVerify. All rights reserved.",
        styles["Footer"]
    ))

    # ── Build ──
    try:
        doc.build(elements)
    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        raise

    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes

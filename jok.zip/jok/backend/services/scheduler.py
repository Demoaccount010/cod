import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from loguru import logger

scheduler = AsyncIOScheduler(job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 60})


def start_scheduler():
    from services.order_processing import process_pending_orders, check_timeouts

    scheduler.add_job(
        process_pending_orders, IntervalTrigger(seconds=30),
        id="process_pending", name="Process pending orders", replace_existing=True,
        max_instances=1, coalesce=True
    )

    scheduler.add_job(
        check_timeouts, IntervalTrigger(minutes=15),
        id="check_timeouts", name="Check order timeouts", replace_existing=True,
        max_instances=1, coalesce=True
    )

    # Daily summary at 9 AM IST (3:30 AM UTC)
    scheduler.add_job(
        _send_daily_summaries, CronTrigger(hour=3, minute=30),
        id="daily_summary", name="Send daily summaries", replace_existing=True
    )

    # Quota warning at 6 PM IST (12:30 PM UTC)
    scheduler.add_job(
        _check_quota_warnings, CronTrigger(hour=12, minute=30),
        id="quota_warning", name="Check quota warnings", replace_existing=True
    )

    # Subscription expiry at 10 AM IST (4:30 AM UTC)
    scheduler.add_job(
        _check_subscription_expiry, CronTrigger(hour=4, minute=30),
        id="subscription_expiry", name="Check subscription expiry", replace_existing=True
    )

    # Monthly quota reset at 12:01 AM IST on 1st of each month (6:31 PM UTC prev day)
    scheduler.add_job(
        _reset_monthly_quotas, CronTrigger(day=1, hour=0, minute=1),
        id="monthly_quota_reset", name="Reset monthly quotas", replace_existing=True
    )

    # Abandoned chat cleanup — every 6 hours
    scheduler.add_job(
        _cleanup_abandoned_sessions, IntervalTrigger(hours=6),
        id="cleanup_chats", name="Cleanup abandoned chats", replace_existing=True
    )

    # Old notification cleanup — daily at 2 AM UTC
    scheduler.add_job(
        _cleanup_old_notifications, CronTrigger(hour=2, minute=0),
        id="cleanup_notifications", name="Cleanup old notifications", replace_existing=True
    )

    # Auto-expire job postings past end_date — daily at 7:30 PM UTC (1 AM IST)
    scheduler.add_job(
        _expire_old_jobs, CronTrigger(hour=19, minute=30),
        id="expire_jobs", name="Auto-expire old job postings", replace_existing=True
    )

    scheduler.start()
    logger.info("Scheduler started with all jobs")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logger.info("Scheduler stopped")


async def _send_daily_summaries():
    from config.database import get_db
    from services.email_service import send_daily_summary
    from services.payment_service import get_currency_config
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        merchants = db.table("users").select("id, email, name, company_name").eq("role", "merchant").eq("status", "active").execute()
        if not merchants.data:
            return

        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0).isoformat()
        for m in merchants.data:
            ms = db.table("merchant_settings").select("notification_daily_summary, notification_email").eq("user_id", m["id"]).execute()
            if not ms.data or not ms.data[0].get("notification_daily_summary"):
                continue

            orders = db.table("orders").select("verification_status, order_amount, currency").eq("user_id", m["id"]).gte("created_at", today_start).execute()
            stats = {"total": len(orders.data or []), "confirmed": 0, "cancelled": 0, "pending": 0, "rto_saved": 0}
            for o in (orders.data or []):
                s = o.get("verification_status", "")
                if s in ("confirmed", "manual_confirmed"):
                    stats["confirmed"] += 1
                elif s in ("cancelled", "manual_cancelled"):
                    stats["cancelled"] += 1
                    stats["rto_saved"] += float(o.get("order_amount", 0) or 0)
                elif s in ("pending", "queued", "sent", "delivered", "read"):
                    stats["pending"] += 1

            # Add currency to stats
            cur = get_currency_config(m.get("country", "IN") or "IN")
            stats["currency"] = cur["currency"]

            email = ms.data[0].get("notification_email") or m["email"]
            await send_daily_summary(email, m.get("company_name", m["name"]), stats)
    except Exception as e:
        logger.error(f"Daily summary error: {e}")


async def _check_quota_warnings():
    from config.database import get_db
    from services.email_service import send_quota_warning

    db = get_db()
    try:
        subs = db.table("service_subscriptions").select("*, users(email, name, company_name)").eq("status", "active").execute()
        for s in (subs.data or []):
            if s.get("monthly_quota", 0) <= 0:
                continue
            pct = (s.get("used_quota", 0) / s["monthly_quota"]) * 100
            if pct >= 80:
                user = s.get("users", {})
                ms = db.table("merchant_settings").select("notification_quota_warning, notification_email").eq("user_id", s["user_id"]).execute()
                if ms.data and ms.data[0].get("notification_quota_warning"):
                    email = ms.data[0].get("notification_email") or user.get("email", "")
                    await send_quota_warning(email, user.get("company_name", user.get("name", "")), s["used_quota"], s["monthly_quota"])
    except Exception as e:
        logger.error(f"Quota warning error: {e}")


async def _check_subscription_expiry():
    from config.database import get_db
    from services.notification_service import create_notification
    from datetime import date, timedelta

    db = get_db()
    try:
        week_from_now = (date.today() + timedelta(days=7)).isoformat()
        today = date.today().isoformat()

        # Warn 7 days before
        expiring = db.table("service_subscriptions").select("*").eq("status", "active").lte("end_date", week_from_now).gte("end_date", today).execute()
        for s in (expiring.data or []):
            await create_notification(s["user_id"], "Subscription Expiring Soon", f"Your {s.get('plan_name', '')} plan expires on {s['end_date']}. Renew to avoid interruption.", "warning", "billing", "/dashboard/billing")

        # Deactivate expired
        expired = db.table("service_subscriptions").select("*").eq("status", "active").lt("end_date", today).execute()
        for s in (expired.data or []):
            db.table("service_subscriptions").update({"status": "expired"}).eq("id", s["id"]).execute()
            await create_notification(s["user_id"], "Subscription Expired", "Your plan has expired. Please renew to continue verifying orders.", "error", "billing", "/dashboard/billing")
    except Exception as e:
        logger.error(f"Subscription expiry error: {e}")


async def _reset_monthly_quotas():
    """Reset monthly quotas on 1st of each month for all active subscriptions and chatbot usage."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        # Reset subscription used_quota
        active_subs = db.table("service_subscriptions").select("id, user_id, plan_name, used_quota").eq("status", "active").execute()
        reset_count = 0
        for s in (active_subs.data or []):
            if s.get("used_quota", 0) > 0:
                db.table("service_subscriptions").update({"used_quota": 0}).eq("id", s["id"]).execute()
                reset_count += 1

        # Reset chatbot monthly usage
        chatbot_configs = db.table("merchant_chatbot_config").select("id, current_month_usage").execute()
        chatbot_reset = 0
        next_reset = (datetime.now(timezone.utc).replace(day=1) + timedelta(days=32)).replace(day=1)
        for c in (chatbot_configs.data or []):
            if c.get("current_month_usage", 0) > 0:
                db.table("merchant_chatbot_config").update({
                    "current_month_usage": 0,
                    "usage_reset_date": next_reset.isoformat(),
                }).eq("id", c["id"]).execute()
                chatbot_reset += 1

        logger.info(f"✅ Monthly quota reset: {reset_count} subscriptions, {chatbot_reset} chatbot configs")
    except Exception as e:
        logger.error(f"Monthly quota reset error: {e}")


async def _cleanup_abandoned_sessions():
    """Clean up abandoned chat sessions older than 24 hours."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()

        # Mark old waiting_human / ai_active sessions as abandoned
        stale = db.table("chat_sessions").select("id").in_(
            "status", ["ai_active", "waiting_human"]
        ).lt("updated_at", cutoff).execute()

        abandoned_count = 0
        for s in (stale.data or []):
            db.table("chat_sessions").update({
                "status": "abandoned",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", s["id"]).execute()
            abandoned_count += 1

        # Delete chat messages for sessions older than 30 days
        old_cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        old_sessions = db.table("chat_sessions").select("id").in_(
            "status", ["resolved", "abandoned"]
        ).lt("updated_at", old_cutoff).execute()

        for s in (old_sessions.data or []):
            db.table("chat_messages").delete().eq("session_id", s["id"]).execute()
            db.table("chat_sessions").delete().eq("id", s["id"]).execute()

        if abandoned_count > 0 or (old_sessions.data and len(old_sessions.data) > 0):
            logger.info(f"🧹 Chat cleanup: {abandoned_count} abandoned, {len(old_sessions.data or [])} old deleted")
    except Exception as e:
        logger.error(f"Chat session cleanup error: {e}")


async def _cleanup_old_notifications():
    """Delete read notifications older than 30 days and unread older than 90 days."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        # Read notifications > 30 days old
        read_cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        db.table("notifications").delete().eq("is_read", True).lt("created_at", read_cutoff).execute()

        # Unread notifications > 90 days old
        unread_cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        db.table("notifications").delete().eq("is_read", False).lt("created_at", unread_cutoff).execute()

        logger.info("🧹 Old notifications cleaned up")
    except Exception as e:
        logger.error(f"Notification cleanup error: {e}")


async def _expire_old_jobs():
    """Auto-deactivate job postings whose end_date has passed."""
    from config.database import get_db
    from datetime import date, datetime, timezone

    db = get_db()
    try:
        today = date.today().isoformat()
        expired = db.table("jobs").select("id, title").eq("is_active", True).lt("end_date", today).execute()
        count = 0
        for j in (expired.data or []):
            db.table("jobs").update({
                "is_active": False,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", j["id"]).execute()
            count += 1
        if count > 0:
            logger.info(f"💼 Auto-expired {count} job posting(s) past end_date")
    except Exception as e:
        logger.error(f"Job expiry error: {e}")

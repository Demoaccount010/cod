from config.database import get_db
from loguru import logger


async def create_notification(user_id: str, title: str, message: str, ntype: str = "info", category: str = None, action_url: str = None):
    db = get_db()
    try:
        db.table("notifications").insert({
            "user_id": user_id,
            "title": title,
            "message": message,
            "type": ntype,
            "category": category,
            "action_url": action_url,
        }).execute()
    except Exception as e:
        logger.error(f"Failed to create notification: {e}")


async def get_unread_count(user_id: str) -> int:
    db = get_db()
    result = db.table("notifications").select("id", count="exact").eq("user_id", user_id).eq("is_read", False).execute()
    return result.count or 0


async def mark_as_read(notification_id: str, user_id: str):
    db = get_db()
    db.table("notifications").update({"is_read": True}).eq("id", notification_id).eq("user_id", user_id).execute()


async def mark_all_read(user_id: str):
    db = get_db()
    db.table("notifications").update({"is_read": True}).eq("user_id", user_id).eq("is_read", False).execute()

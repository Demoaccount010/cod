"""Smart website scraper service — multi-layer product & business info extraction.

Layers (priority order):
  1. Shopify  — /products.json?limit=250 (paginated, public, no auth)
  2. WooCommerce — /wp-json/wc/v2/products?per_page=100 (paginated)
  3. Sitemap  — parse /sitemap.xml for product page URLs
  4. HTML multi-page — /, /collections/all, /products, /shop crawled concurrently
  5. JSON-LD  — Product / ItemList blocks from all fetched pages

Extra info extracted:
  - Shipping policy  (/policies/shipping-policy, footer text)
  - Return/refund policy
  - Contact info (email, phone, WhatsApp from footer/contact page)
  - Social media links
"""

import re
import json as _json
import asyncio
import httpx
from bs4 import BeautifulSoup
from loguru import logger
from typing import Optional
from urllib.parse import urlparse, urljoin, urlencode


# ── Constants ──────────────────────────────────────────────────────────────────

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

JSON_HEADERS = {**HEADERS, "Accept": "application/json, */*"}

_HEX_COLOR_RE = re.compile(r'#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})\b')
_CSS_VAR_COLORS = re.compile(
    r'--(?:primary|accent|brand|color-primary|main-color|theme-color|btn-bg|link-color)[^:]*:\s*(#[0-9A-Fa-f]{3,6})',
    re.IGNORECASE,
)
_SKIP_COLORS = {
    "#ffffff", "#000000", "#fff", "#000", "#f0f0f0",
    "#eeeeee", "#e5e7eb", "#d1d5db", "#f3f4f6",
    "#333333", "#444444", "#555555", "#666666", "#999999", "#cccccc",
    "#1a1a1a", "#2d2d2d", "#111111", "#222222",
}
_FAQ_HEADINGS_RE = re.compile(
    r'faq|frequently asked|common question|help center|support|got question',
    re.IGNORECASE,
)

# Extra pages to try scraping for product/policy data
EXTRA_PATHS = [
    "/collections/all",
    "/products",
    "/shop",
    "/store",
    "/pages/faq",
    "/pages/shipping",
    "/pages/refund-policy",
    "/policies/shipping-policy",
    "/policies/refund-policy",
    "/contact",
]

# ── Helpers ────────────────────────────────────────────────────────────────────

def _normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip("/")


def _clean_text(text: str, max_len: int = 500) -> str:
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:max_len] if len(text) > max_len else text


def _pick_best_color(colors: list) -> Optional[str]:
    for c in colors:
        c = c.lower()
        if re.match(r'^#[0-9a-f]{3}$', c):
            c = '#' + ''.join(ch * 2 for ch in c[1:])
        if c not in _SKIP_COLORS:
            return c
    return None


def _extract_json_ld(soup: BeautifulSoup) -> list:
    result = []
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            data = _json.loads(tag.string or "")
            if isinstance(data, list):
                result.extend(data)
            else:
                result.append(data)
        except Exception:
            pass
    return result


def _find_json_ld_by_type(ld_blocks: list, schema_type: str) -> Optional[dict]:
    for block in ld_blocks:
        t = block.get("@type", "")
        types = t if isinstance(t, list) else [t]
        if schema_type in types:
            return block
    return None


async def _fetch_html(client: httpx.AsyncClient, url: str) -> Optional[str]:
    """Fetch URL, return HTML text or None on failure."""
    try:
        resp = await client.get(url, headers=HEADERS, timeout=12, follow_redirects=True)
        if resp.status_code == 200:
            return resp.text
    except Exception:
        pass
    return None


async def _fetch_json(client: httpx.AsyncClient, url: str) -> Optional[dict | list]:
    """Fetch URL as JSON, return parsed data or None."""
    try:
        resp = await client.get(url, headers=JSON_HEADERS, timeout=12, follow_redirects=True)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return None


# ── Platform Detection ─────────────────────────────────────────────────────────

def _is_shopify(html: str, base_url: str) -> bool:
    """Detect Shopify platform."""
    return (
        "Shopify.com" in html or
        "cdn.shopify.com" in html or
        "myshopify.com" in html or
        ".myshopify.com" in base_url
    )


def _is_woocommerce(html: str) -> bool:
    """Detect WooCommerce platform."""
    return (
        "woocommerce" in html.lower() or
        "wp-content" in html or
        "wc-ajax" in html
    )


# ── Shopify Product Fetcher ────────────────────────────────────────────────────

async def _fetch_shopify_products(client: httpx.AsyncClient, base_url: str) -> list[dict]:
    """Fetch ALL Shopify products using the public /products.json API.

    Paginates through up to 20 pages (5000 products max cap).
    Returns list of product dicts with: title, type, price_range, variants, description.
    """
    all_products = []
    page = 1
    per_page = 250

    while page <= 20:  # safety cap
        url = f"{base_url}/products.json?limit={per_page}&page={page}"
        data = await _fetch_json(client, url)

        if not data or not isinstance(data, dict):
            break

        products = data.get("products", [])
        if not products:
            break

        for prod in products:
            title = prod.get("title", "").strip()
            if not title:
                continue

            product_type = prod.get("product_type", "").strip()
            tags = prod.get("tags") or []
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]

            # Price range from variants
            variants = prod.get("variants") or []
            prices = []
            variant_names = []
            for v in variants:
                try:
                    prices.append(float(v.get("price", 0)))
                except Exception:
                    pass
                # Variant options (size/color)
                opt1 = v.get("option1")
                if opt1 and opt1.lower() not in ("default title", "default"):
                    variant_names.append(opt1)

            min_p = min(prices) if prices else 0
            max_p = max(prices) if prices else 0

            if min_p == max_p and min_p > 0:
                price_str = f"Rs. {min_p:,.0f}"
            elif min_p > 0:
                price_str = f"Rs. {min_p:,.0f} – Rs. {max_p:,.0f}"
            else:
                price_str = ""

            # Clean HTML description
            raw_desc = prod.get("body_html") or ""
            if raw_desc:
                desc_soup = BeautifulSoup(raw_desc, "lxml")
                raw_desc = _clean_text(desc_soup.get_text(" ", strip=True), 200)

            # Image URL — first image in the images list
            images = prod.get("images") or []
            image_url = images[0].get("src", "") if images else ""

            # Product URL via handle
            handle = prod.get("handle", "")
            product_url = f"{base_url}/products/{handle}" if handle else ""

            product_entry = {
                "title": title,
                "type": product_type,
                "price": price_str,
                "variants": list(dict.fromkeys(variant_names))[:10],
                "tags": tags[:5],
                "description": raw_desc[:200] if raw_desc else "",
                "image_url": image_url,
                "product_url": product_url,
            }
            all_products.append(product_entry)

        logger.info(f"Shopify page {page}: got {len(products)} products (total so far: {len(all_products)})")

        if len(products) < per_page:
            break  # Last page
        page += 1

    return all_products


# ── WooCommerce Product Fetcher ────────────────────────────────────────────────

async def _fetch_woocommerce_products(client: httpx.AsyncClient, base_url: str) -> list[dict]:
    """Fetch WooCommerce products via REST API (public-accessible endpoint).

    Tries v3 then v2. Paginates up to 10 pages (1000 products).
    """
    all_products = []

    for api_version in ("v3", "v2"):
        api_base = f"{base_url}/wp-json/wc/{api_version}/products"
        page = 1

        while page <= 10:
            url = f"{api_base}?per_page=100&page={page}&status=publish"
            data = await _fetch_json(client, url)

            if not data or not isinstance(data, list):
                break
            if not data:
                break

            for prod in data:
                title = prod.get("name", "").strip()
                if not title:
                    continue

                price_str = ""
                try:
                    reg_price = float(prod.get("regular_price") or prod.get("price") or 0)
                    sale_price_raw = prod.get("sale_price")
                    sale_price = float(sale_price_raw) if sale_price_raw else None

                    if sale_price and sale_price < reg_price:
                        price_str = f"Rs. {sale_price:,.0f} (was Rs. {reg_price:,.0f})"
                    elif reg_price > 0:
                        price_str = f"Rs. {reg_price:,.0f}"
                except Exception:
                    pass

                product_type = prod.get("type", "")
                categories = [c.get("name", "") for c in (prod.get("categories") or [])]

                raw_desc = prod.get("short_description") or prod.get("description") or ""
                if raw_desc:
                    desc_soup = BeautifulSoup(raw_desc, "lxml")
                    raw_desc = _clean_text(desc_soup.get_text(" ", strip=True), 150)

                # Image URL — first image
                wc_images = prod.get("images") or []
                wc_image_url = wc_images[0].get("src", "") if wc_images else ""
                wc_product_url = prod.get("permalink") or prod.get("link") or ""

                all_products.append({
                    "title": title,
                    "type": categories[0] if categories else product_type,
                    "price": price_str,
                    "variants": [],
                    "description": raw_desc,
                    "tags": categories[:3],
                    "image_url": wc_image_url,
                    "product_url": wc_product_url,
                })

            logger.info(f"WooCommerce {api_version} page {page}: got {len(data)} products")

            if len(data) < 100:
                break
            page += 1

        if all_products:
            break  # Found products in this api version

    return all_products


# ── JSON-LD Product Extractor ─────────────────────────────────────────────────

def _extract_products_from_json_ld(ld_blocks: list) -> list[dict]:
    """Extract Product / ItemList entries from JSON-LD blocks."""
    products = []

    # Individual Product blocks
    for block in ld_blocks:
        t = block.get("@type", "")
        types = t if isinstance(t, list) else [t]
        if "Product" in types:
            title = block.get("name", "").strip()
            if not title:
                continue
            price_str = ""
            offers = block.get("offers") or {}
            if isinstance(offers, list):
                offers = offers[0] if offers else {}
            price_raw = offers.get("price") or offers.get("lowPrice")
            currency = offers.get("priceCurrency", "")
            if price_raw:
                try:
                    price_str = f"{currency} {float(price_raw):,.0f}".strip()
                except Exception:
                    price_str = str(price_raw)

            products.append({
                "title": title,
                "type": block.get("category", ""),
                "price": price_str,
                "variants": [],
                "description": _clean_text(block.get("description", ""), 150),
            })

    # ItemList / OfferCatalog
    for block in ld_blocks:
        if block.get("@type") in ("ItemList", "OfferCatalog"):
            for item in block.get("itemListElement", []):
                inner = item.get("item") or item
                title = inner.get("name", "").strip()
                if title and not any(p["title"] == title for p in products):
                    products.append({
                        "title": title,
                        "type": "",
                        "price": "",
                        "variants": [],
                        "description": _clean_text(inner.get("description", ""), 100),
                    })

    return products


# ── HTML Product Scraper ───────────────────────────────────────────────────────

def _scrape_products_from_html(soup: BeautifulSoup) -> list[dict]:
    """Extract product info from structured HTML product cards/grids."""
    products = []
    seen_titles = set()

    # Common product card selectors
    card_selectors = [
        ".product-card", ".product-item", ".product-grid-item",
        "[data-product-id]", "[data-product]",
        ".grid__item", ".product-block",
        "article.product", ".woocommerce ul.products li",
        ".product_inner",
    ]

    for selector in card_selectors:
        cards = soup.select(selector)
        if not cards:
            continue
        for card in cards:
            # Try to get title
            title_el = (
                card.select_one(".product-card__title") or
                card.select_one(".product__title") or
                card.select_one(".woocommerce-loop-product__title") or
                card.select_one("h2") or
                card.select_one("h3") or
                card.select_one(".title") or
                card.select_one("[class*='title']")
            )
            if not title_el:
                continue
            title = title_el.get_text(strip=True)
            if not title or title in seen_titles or len(title) > 100:
                continue
            seen_titles.add(title)

            # Price
            price_el = (
                card.select_one(".price") or
                card.select_one(".product-price") or
                card.select_one("[class*='price']") or
                card.select_one("bdi")
            )
            price_str = price_el.get_text(strip=True) if price_el else ""
            price_str = re.sub(r'\s+', ' ', price_str).strip()[:50]

            products.append({
                "title": title,
                "type": "",
                "price": price_str,
                "variants": [],
                "description": "",
            })
        if products:
            break  # Found products with this selector, stop trying more

    return products


# ── Policy / Contact Extractor ────────────────────────────────────────────────

def _extract_email(text: str) -> Optional[str]:
    m = re.search(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', text)
    return m.group(0) if m else None


def _extract_phone(text: str) -> Optional[str]:
    # Indian phone patterns
    m = re.search(r'(?:\+91[\s\-]?)?(?:[6-9]\d{9})\b', re.sub(r'[\s\-]', '', text))
    return m.group(0) if m else None


def _extract_contact_info(soup: BeautifulSoup, all_text: str) -> str:
    """Extract contact info (email, phone, WhatsApp) from footer/contact sections."""
    parts = []

    email = _extract_email(all_text)
    if email:
        parts.append(f"Email: {email}")

    phone = _extract_phone(all_text)
    if phone:
        parts.append(f"Phone/WhatsApp: {phone}")

    # Social links
    social = []
    for a in soup.select("a[href*='instagram.com'], a[href*='facebook.com'], a[href*='twitter.com'], a[href*='wa.me']"):
        href = a.get("href", "")
        if "instagram.com" in href:
            social.append(f"Instagram: {href}")
        elif "facebook.com" in href:
            social.append(f"Facebook: {href}")
        elif "wa.me" in href:
            social.append(f"WhatsApp: {href}")

    parts.extend(social[:3])
    return " | ".join(parts) if parts else ""


def _extract_policy_text(html: str, policy_type: str) -> str:
    """Extract a shipping / return policy from a policy page HTML."""
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "header", "footer", "noscript"]):
        tag.decompose()

    # Find the main content
    main = soup.find("main") or soup.find("article") or soup.body
    if not main:
        return ""

    text = _clean_text(main.get_text(" ", strip=True), 800)
    # Strip very short or generic content
    if len(text) < 50:
        return ""
    return text


# ── Business Info Extractors ──────────────────────────────────────────────────

def _extract_business_name(soup_full: BeautifulSoup, soup: BeautifulSoup, ld_blocks: list) -> Optional[str]:
    name = None
    for ld_type in ("Organization", "LocalBusiness", "WebSite", "Store", "Product"):
        ld = _find_json_ld_by_type(ld_blocks, ld_type)
        if ld and ld.get("name"):
            name = str(ld["name"]).strip()
            break
    if not name:
        og_site = soup_full.find("meta", property="og:site_name")
        if og_site:
            name = (og_site.get("content") or "").strip()
    if not name:
        title_tag = soup.find("title")
        if title_tag:
            raw_title = title_tag.get_text(strip=True)
            name = re.split(r'\s*[|\–—\-:]\s*', raw_title)[0].strip()
    if not name:
        h1 = soup.find("h1")
        if h1:
            name = h1.get_text(strip=True)
    return _clean_text(name or "", 120) or None


def _extract_description(soup_full: BeautifulSoup, soup: BeautifulSoup, ld_blocks: list) -> Optional[str]:
    desc = None
    for ld_type in ("Organization", "LocalBusiness", "WebSite", "Store"):
        ld = _find_json_ld_by_type(ld_blocks, ld_type)
        if ld and ld.get("description"):
            desc = str(ld["description"]).strip()
            break
    if not desc:
        meta_desc = soup_full.find("meta", attrs={"name": "description"})
        if meta_desc:
            desc = (meta_desc.get("content") or "").strip()
    if not desc:
        og_desc = soup_full.find("meta", property="og:description")
        if og_desc:
            desc = (og_desc.get("content") or "").strip()
    if not desc:
        for p in soup.find_all("p"):
            text = p.get_text(strip=True)
            if len(text) > 80:
                desc = text
                break
    return _clean_text(desc or "", 700) or None


def _extract_primary_color(soup_full: BeautifulSoup) -> Optional[str]:
    colors_found = []
    theme_meta = soup_full.find("meta", attrs={"name": "theme-color"})
    if theme_meta:
        c = (theme_meta.get("content") or "").strip()
        if c.startswith("#"):
            colors_found.append(c)
    for style_tag in soup_full.find_all("style"):
        css_text = style_tag.string or ""
        for match in _CSS_VAR_COLORS.finditer(css_text):
            colors_found.append(match.group(1))
    for btn in soup_full.find_all(["button", "a"], class_=re.compile(r'btn|button|cta|primary', re.I)):
        style_attr = btn.get("style", "")
        for match in _HEX_COLOR_RE.finditer(style_attr):
            colors_found.append(match.group(0))
    for tag in soup_full.find_all(style=True):
        style_attr = tag.get("style", "")
        if "background" in style_attr or "color" in style_attr:
            for match in _HEX_COLOR_RE.finditer(style_attr):
                colors_found.append(match.group(0))
    return _pick_best_color(colors_found)


def _extract_favicon(soup_full: BeautifulSoup, base_url: str, ld_blocks: list, parsed_url) -> Optional[str]:
    favicon_url = None
    og_img = soup_full.find("meta", property="og:image")
    if og_img and og_img.get("content"):
        og_img_url = og_img["content"].strip()
        if og_img_url.startswith("http"):
            favicon_url = og_img_url
    if not favicon_url:
        for ld_type in ("Organization", "LocalBusiness", "WebSite"):
            ld = _find_json_ld_by_type(ld_blocks, ld_type)
            if ld:
                logo = ld.get("logo")
                if isinstance(logo, str) and logo.startswith("http"):
                    favicon_url = logo
                    break
                elif isinstance(logo, dict) and logo.get("url"):
                    favicon_url = logo["url"]
                    break
    if not favicon_url:
        for attrs in [
            {"rel": "apple-touch-icon"},
            {"rel": "icon", "sizes": "192x192"},
            {"rel": "icon", "sizes": "96x96"},
            {"rel": "icon", "sizes": "32x32"},
            {"rel": "icon"},
            {"rel": "shortcut icon"},
        ]:
            tag = soup_full.find("link", rel=attrs.get("rel"))
            if tag and tag.get("href"):
                favicon_url = urljoin(base_url, tag["href"].strip())
                break
    if not favicon_url:
        favicon_url = f"{parsed_url.scheme}://{parsed_url.netloc}/favicon.ico"
    return favicon_url


def _extract_faq(combined_soups: list, ld_blocks: list) -> str:
    faq_parts = []

    # 1. JSON-LD FAQPage
    faq_ld = _find_json_ld_by_type(ld_blocks, "FAQPage")
    if faq_ld:
        for entity in (faq_ld.get("mainEntity") or [])[:10]:
            q = entity.get("name", "")
            ans_obj = entity.get("acceptedAnswer") or {}
            a = ans_obj.get("text", "")
            if q and a:
                faq_parts.append(f"Q: {q}\nA: {_clean_text(a, 300)}")

    # 2. <details>/<summary> accordion
    for soup in combined_soups:
        if faq_parts:
            break
        for details in soup.find_all("details")[:10]:
            summary = details.find("summary")
            if summary:
                q = summary.get_text(strip=True)
                full = details.get_text(separator=" ", strip=True)
                a = full.replace(q, "").strip()
                if q and a and len(a) > 10:
                    faq_parts.append(f"Q: {q}\nA: {_clean_text(a, 250)}")

    # 3. Heading-based FAQ sections — try to extract Q/A pairs from h3+p patterns
    for soup in combined_soups:
        if faq_parts:
            break
        for section in soup.find_all(["section", "div"]):
            section_text = section.get_text(strip=True) if hasattr(section, 'get_text') else ""
            if not _FAQ_HEADINGS_RE.search(section_text[:200]):
                continue
            # Look for h3/h4 as questions, next p/div as answer
            for q_tag in section.find_all(["h3", "h4", "dt"])[:15]:
                q = q_tag.get_text(strip=True)
                if not q or len(q) < 5:
                    continue
                # Find the next sibling that has answer text
                a_tag = q_tag.find_next_sibling(["p", "dd", "div"])
                if a_tag:
                    a = _clean_text(a_tag.get_text(" ", strip=True), 250)
                    if a and len(a) > 10:
                        faq_parts.append(f"Q: {q}\nA: {a}")
            if faq_parts:
                break
        if faq_parts:
            break
        # Fallback: heading + following siblings as raw block
        for heading in soup.find_all(["h2", "h3", "h4"]):
            heading_text = heading.get_text(strip=True) if hasattr(heading, 'get_text') else ""
            if _FAQ_HEADINGS_RE.search(heading_text):
                texts = []
                for sibling in heading.find_next_siblings():
                    if sibling.name in ("h2", "h3") and not _FAQ_HEADINGS_RE.search(sibling.get_text()):
                        break
                    text = sibling.get_text(separator=" ", strip=True)
                    if text and len(text) > 15:
                        texts.append(text)
                    if len("\n".join(texts)) > 1200:
                        break
                if texts:
                    faq_parts.extend(texts)
                break

    return _clean_text("\n\n".join(faq_parts), 2000)


# ── Products → AI-Friendly Text ───────────────────────────────────────────────

def _format_products_for_ai(products: list[dict], platform: str) -> str:
    """Convert product list to a structured, AI-readable string.

    For stores with >100 products, group by type/category and summarise.
    """
    if not products:
        return ""

    total = len(products)

    # For small catalogs (≤ 100): list every product with details
    if total <= 100:
        lines = [f"PRODUCTS ({total} total):"]
        for i, p in enumerate(products, 1):
            parts = [p["title"]]
            if p.get("type"):
                parts.append(p["type"])
            if p.get("price"):
                parts.append(p["price"])
            if p.get("variants"):
                parts.append(f"Sizes/Options: {', '.join(p['variants'][:8])}")
            if p.get("description"):
                parts.append(p["description"][:100])

            meta = []
            if p.get("image_url"):
                meta.append(f" ✨ IMG:{p['image_url']}")
            if p.get("product_url"):
                meta.append(f" 🔗 URL:{p['product_url']}")
            meta_str = "".join(meta)

            lines.append(f"{i}. {' | '.join(parts)}{meta_str}")
        return "\n".join(lines)

    # For large catalogs (101–1000): group by type, list first 100 + summary
    lines = [f"LARGE CATALOG ({total} products total):"]

    # Group by type
    by_type: dict = {}
    for p in products:
        t = p.get("type") or "Other"
        by_type.setdefault(t, []).append(p)

    for cat, items in sorted(by_type.items(), key=lambda x: -len(x[1]))[:10]:
        price_strs = [it["price"] for it in items if it.get("price")]
        price_note = ""
        if price_strs:
            price_note = f" | Price range: starting {price_strs[0]}"
        names = ", ".join(it["title"] for it in items[:5])
        more = f" (+{len(items)-5} more)" if len(items) > 5 else ""
        lines.append(f"- {cat} ({len(items)} products): {names}{more}{price_note}")

    lines.append(f"\n[Showing top categories. Total inventory: {total} products]")
    return "\n".join(lines)


# ── Sitemap Product URL Extractor ──────────────────────────────────────────────

async def _get_product_urls_from_sitemap(client: httpx.AsyncClient, base_url: str) -> list[str]:
    """Parse /sitemap.xml and return product page URLs (up to 100)."""
    sitemap_html = await _fetch_html(client, f"{base_url}/sitemap.xml")
    if not sitemap_html:
        return []
    urls = []
    # Find all <loc> tags that look like product pages
    for m in re.finditer(r'<loc>(.*?)</loc>', sitemap_html, re.IGNORECASE):
        loc = m.group(1).strip()
        if "/products/" in loc or "/product/" in loc:
            urls.append(loc)
    return urls[:100]


# ── Main Scraper ───────────────────────────────────────────────────────────────

async def scrape_website(url: str) -> dict:
    """Smart multi-layer website scraper. Returns chatbot config hints."""
    url = _normalize_url(url)

    try:
        parsed = urlparse(url)
        if not parsed.netloc:
            return {"error": "Invalid URL provided"}
    except Exception:
        return {"error": "Invalid URL provided"}

    result: dict = {"scraped_url": url}

    try:
        async with httpx.AsyncClient(
            timeout=25,
            follow_redirects=True,
            headers=HEADERS,
        ) as client:

            # ── Step 1: Fetch homepage ─────────────────────────────────────────
            try:
                resp = await client.get(url, timeout=15)
                resp.raise_for_status()
                homepage_html = resp.text
            except httpx.TimeoutException:
                return {"error": "Website took too long to respond. Please fill manually."}
            except httpx.HTTPStatusError as e:
                return {"error": f"Website returned HTTP {e.response.status_code}."}
            except Exception as e:
                logger.warning(f"Scrape failed for {url}: {e}")
                return {"error": "Could not reach the website. Please fill manually."}

            soup_full = BeautifulSoup(homepage_html, "lxml")
            ld_blocks_home = _extract_json_ld(soup_full)

            soup_clean = BeautifulSoup(homepage_html, "lxml")
            for tag in soup_clean(["script", "style", "noscript", "svg", "iframe"]):
                tag.decompose()

            # ── Step 2: Platform detection ─────────────────────────────────────
            is_shopify = _is_shopify(homepage_html, url)
            is_woo = _is_woocommerce(homepage_html)
            platform = "shopify" if is_shopify else ("woocommerce" if is_woo else "generic")
            result["platform"] = platform
            logger.info(f"Detected platform: {platform} for {url}")

            # ── Step 3: Fetch extra pages concurrently ────────────────────────
            extra_tasks = [_fetch_html(client, f"{url}{path}") for path in EXTRA_PATHS]
            extra_htmls = await asyncio.gather(*extra_tasks, return_exceptions=True)
            extra_html_map: dict[str, str] = {}
            for path, html in zip(EXTRA_PATHS, extra_htmls):
                if isinstance(html, str) and html:
                    extra_html_map[path] = html

            # Parse all extra pages — merge JSON-LD blocks
            all_ld_blocks = list(ld_blocks_home)
            combined_soups = [soup_clean]
            for path, html in extra_html_map.items():
                extra_soup_full = BeautifulSoup(html, "lxml")
                all_ld_blocks.extend(_extract_json_ld(extra_soup_full))
                extra_soup = BeautifulSoup(html, "lxml")
                for tag in extra_soup(["script", "style", "noscript", "svg", "iframe"]):
                    tag.decompose()
                combined_soups.append(extra_soup)

            # ── Step 4: Fetch products from platform API ──────────────────────
            api_products: list[dict] = []

            if is_shopify:
                api_products = await _fetch_shopify_products(client, url)
                logger.info(f"Shopify API: {len(api_products)} products fetched")

            elif is_woo:
                api_products = await _fetch_woocommerce_products(client, url)
                logger.info(f"WooCommerce API: {len(api_products)} products fetched")

            # ── Step 5: HTML + JSON-LD product fallback ───────────────────────
            html_products: list[dict] = []
            if not api_products:
                # Try JSON-LD first
                html_products = _extract_products_from_json_ld(all_ld_blocks)
                # Then HTML product card scraping
                if not html_products:
                    for s in combined_soups:
                        found = _scrape_products_from_html(s)
                        if found:
                            html_products.extend(found)
                            break

                # Sitemap fallback: fetch actual product pages
                if not html_products and is_shopify:
                    product_urls = await _get_product_urls_from_sitemap(client, url)
                    sitemap_tasks = [_fetch_html(client, pu) for pu in product_urls[:20]]
                    sitemap_pages = await asyncio.gather(*sitemap_tasks, return_exceptions=True)
                    for page_html in sitemap_pages:
                        if isinstance(page_html, str) and page_html:
                            page_soup = BeautifulSoup(page_html, "lxml")
                            page_ld = _extract_json_ld(page_soup)
                            products_from_page = _extract_products_from_json_ld(page_ld)
                            html_products.extend(products_from_page)

                # Deduplicate by title
                seen = set()
                deduped = []
                for p in html_products:
                    if p["title"] not in seen:
                        seen.add(p["title"])
                        deduped.append(p)
                html_products = deduped

            # Final product list
            final_products = api_products if api_products else html_products
            result["product_count"] = len(final_products)
            result["business_services"] = _format_products_for_ai(final_products, platform) or None

            # ── Step 6: Extract policy / contact info ─────────────────────────
            # Shipping policy
            shipping_text = ""
            for path in ("/policies/shipping-policy", "/pages/shipping"):
                if path in extra_html_map:
                    shipping_text = _extract_policy_text(extra_html_map[path], "shipping")
                    if shipping_text:
                        break

            # Return/refund policy
            return_text = ""
            for path in ("/policies/refund-policy", "/pages/refund-policy"):
                if path in extra_html_map:
                    return_text = _extract_policy_text(extra_html_map[path], "refund")
                    if return_text:
                        break

            result["shipping_info"] = shipping_text[:600] or None
            result["return_policy"] = return_text[:600] or None

            # Contact info from all pages
            all_text = " ".join(
                s.get_text(" ", strip=True) for s in combined_soups
            )
            contact_info = _extract_contact_info(soup_full, all_text)
            result["contact_info"] = contact_info or None

            # ── Step 7: Extract branding / description / FAQ ──────────────────
            result["business_name"] = _extract_business_name(soup_full, soup_clean, all_ld_blocks)
            result["business_description"] = _extract_description(soup_full, soup_clean, all_ld_blocks)
            result["primary_color"] = _extract_primary_color(soup_full)
            result["favicon_url"] = _extract_favicon(soup_full, url, all_ld_blocks, parsed)
            result["business_faq"] = _extract_faq(combined_soups, all_ld_blocks) or None

            # ── Step 8: Bot name ──────────────────────────────────────────────
            if result.get("business_name"):
                result["bot_name"] = f"{result['business_name']} Support"
            else:
                result["bot_name"] = None

            logger.info(
                f"Smart scrape {url} → platform={platform}, "
                f"products={len(final_products)}, "
                f"name={result.get('business_name')!r}, "
                f"color={result.get('primary_color')!r}, "
                f"shipping={'yes' if shipping_text else 'no'}, "
                f"contact={'yes' if contact_info else 'no'}"
            )
            return result

    except Exception as e:
        logger.error(f"Smart scrape exception for {url}: {e}")
        return {"error": f"Unexpected error during scraping: {str(e)[:100]}"}

from config.database import get_db
from loguru import logger


def calculate_risk_score(phone_hash: str, order_amount: float, address: dict = None) -> tuple[int, list]:
    db = get_db()
    risk_score = 0
    factors = []

    # Check customer history
    customer_res = db.table("customers_directory").select("*").eq("phone_number_hash", phone_hash).execute()
    if customer_res.data:
        c = customer_res.data[0]
        if c.get("total_orders", 0) == 0:
            risk_score += 15
            factors.append("New customer")
        elif c.get("confirmation_rate", 100) < 50:
            risk_score += 30
            factors.append(f"Low confirmation rate ({c.get('confirmation_rate')}%)")
        elif c.get("confirmation_rate", 100) < 70:
            risk_score += 15
            factors.append(f"Below average confirmation rate ({c.get('confirmation_rate')}%)")

        if c.get("cancelled_orders", 0) > 3:
            risk_score += 20
            factors.append(f"High cancellations ({c.get('cancelled_orders')})")

        if c.get("rto_orders", 0) > 1:
            risk_score += 25
            factors.append(f"RTO history ({c.get('rto_orders')} returns)")

        if not c.get("is_on_whatsapp", True):
            risk_score += 10
            factors.append("Not on WhatsApp previously")
    else:
        risk_score += 15
        factors.append("First-time customer")

    # Order amount check
    if order_amount > 5000:
        risk_score += 10
        factors.append("High order value (>₹5000)")
    if order_amount > 10000:
        risk_score += 10
        factors.append("Very high order value (>₹10000)")

    # Address completeness
    if address:
        if not address.get("pincode"):
            risk_score += 5
            factors.append("Missing pincode")
        if not address.get("city"):
            risk_score += 5
            factors.append("Missing city")
    else:
        risk_score += 10
        factors.append("No address provided")

    return min(100, risk_score), factors

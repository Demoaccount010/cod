"""Groq AI chatbot service for CODVerify customer support."""

import httpx
from loguru import logger
from config.settings import settings

_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
_MODEL = settings.GROQ_MODEL or "llama-3.3-70b-versatile"

SYSTEM_PROMPT = """You are CODVerify's AI customer support assistant. You ONLY discuss CODVerify and its services. You do NOT answer any off-topic, general knowledge, or unrelated questions.

About CODVerify:
CODVerify is an intelligent COD (Cash on Delivery) order verification platform that helps e-commerce businesses reduce RTO (Return to Origin) losses.

Our Services:
- WhatsApp-based COD order verification (94% response rate)
- SMS + Voice call fallback verification (97% confirmation rate)  
- AI-powered customer chatbot for order support
- Real-time analytics dashboard for merchants
- Shopify & WooCommerce integration (1-click install)
- Multi-language support (Hindi, English, etc.)
- Blacklist management for fraud prevention
- Custom notification templates

How CODVerify Works:
1. Customer places a COD order on merchant's store
2. CODVerify automatically sends a WhatsApp/SMS verification message
3. Customer confirms or cancels the order
4. Merchant gets real-time update — only confirmed orders are shipped
5. This reduces RTO by up to 45%

Pricing: Custom plans based on order volume, starting from ₹999/month. Contact the team for personalized pricing.
Website: codverify.tech
Support Email: support@codverify.tech

STRICT RULES:
- ONLY answer questions about CODVerify, its services, pricing, features, integration, and setup
- If the customer asks ANYTHING unrelated (general knowledge, weather, coding, etc.), politely say: "I can only help with CODVerify-related questions. Is there anything about our services I can help with?"
- If the customer asks to speak with a human/agent/support person, respond with exactly: [HANDOFF_REQUESTED]
- Keep responses concise (2-3 sentences max)
- Use simple language, mix Hindi-English if the customer writes in Hindi
- Never make up information — offer to connect with human support instead
- Be friendly but strictly focused on CODVerify business only
"""


def _is_configured() -> bool:
    return bool(getattr(settings, 'GROQ_API_KEY', None))


async def get_ai_response(messages: list, visitor_name: str = "Visitor") -> dict:
    """Get AI chatbot response via Groq API.
    
    Returns: {"message": str, "handoff_requested": bool}
    """
    if not _is_configured():
        logger.warning("GROQ_API_KEY not set — returning fallback response")
        return {
            "message": "Welcome to CODVerify! Our AI assistant is currently unavailable. Would you like to speak with a human support agent?",
            "handoff_requested": False,
        }

    # Build conversation with system prompt
    chat_messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for m in messages[-20:]:  # Keep last 20 messages for context
        role = "assistant" if m.get("sender_type") in ("ai", "worker") else "user"
        chat_messages.append({"role": role, "content": m["message"]})

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                _GROQ_URL,
                headers={
                    "Authorization": f"Bearer {settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": _MODEL,
                    "messages": chat_messages,
                    "temperature": getattr(settings, 'GROQ_TEMPERATURE', 0.7),
                    "max_tokens": 300,
                    "top_p": 0.9,
                },
            )
            data = response.json()

            # Check for API-level error (rate limit, auth, model not found, etc.)
            if response.status_code != 200 or "choices" not in data:
                err_msg = data.get("error", {}).get("message", f"HTTP {response.status_code}")
                logger.error(f"Groq API error: {err_msg}")
                return {
                    "message": "I'm having trouble connecting right now. Would you like to speak with a human support agent instead?",
                    "handoff_requested": False,
                }

            ai_text = data["choices"][0]["message"]["content"].strip()

            handoff = "[HANDOFF_REQUESTED]" in ai_text
            if handoff:
                ai_text = ai_text.replace("[HANDOFF_REQUESTED]", "").strip()
                if not ai_text:
                    ai_text = "Sure! Let me connect you with a human support agent. Please wait a moment..."

            return {"message": ai_text, "handoff_requested": handoff}

    except Exception as e:
        logger.error(f"Groq API exception: {e}")
        return {
            "message": "I'm having trouble connecting right now. Would you like to speak with a human support agent instead?",
            "handoff_requested": False,
        }


async def get_merchant_ai_response(messages: list, system_prompt: str) -> dict:
    """Get AI response using a merchant-specific system prompt.
    
    Returns: {"message": str, "handoff_requested": bool}
    """
    if not _is_configured():
        return {
            "message": "Our AI assistant is currently unavailable. Would you like to speak with a support agent?",
            "handoff_requested": False,
        }

    chat_messages = [{"role": "system", "content": system_prompt}]
    for m in messages[-20:]:
        if m.get("sender_type") == "system":
            continue  # Skip system messages
        role = "assistant" if m.get("sender_type") in ("ai", "worker") else "user"
        chat_messages.append({"role": role, "content": m["message"]})

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                _GROQ_URL,
                headers={
                    "Authorization": f"Bearer {settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": _MODEL,
                    "messages": chat_messages,
                    "temperature": getattr(settings, 'GROQ_TEMPERATURE', 0.7),
                    "max_tokens": 300,
                    "top_p": 0.9,
                },
            )
            data = response.json()

            # Check for API-level error (rate limit, auth, model not found, etc.)
            if response.status_code != 200 or "choices" not in data:
                err_msg = data.get("error", {}).get("message", f"HTTP {response.status_code}")
                logger.error(f"Groq API error (merchant): {err_msg}")
                return {
                    "message": "I'm having trouble right now. Would you like to speak with a support agent?",
                    "handoff_requested": False,
                }

            ai_text = data["choices"][0]["message"]["content"].strip()

            handoff = "[HANDOFF_REQUESTED]" in ai_text
            if handoff:
                ai_text = ai_text.replace("[HANDOFF_REQUESTED]", "").strip()
                if not ai_text:
                    ai_text = "Let me connect you with a support agent who can help further. Please wait a moment..."

            return {"message": ai_text, "handoff_requested": handoff}

    except Exception as e:
        logger.error(f"Groq API exception (merchant): {e}")
        return {
            "message": "I'm having trouble right now. Would you like to speak with a support agent?",
            "handoff_requested": False,
        }


async def test_groq_connection() -> dict:
    """Test Groq API connectivity. Used by admin integrations page.
    
    Returns: {"success": bool, "message": str, "model": str}
    """
    if not _is_configured():
        return {
            "success": False,
            "message": "GROQ_API_KEY is not set in environment variables.",
            "model": None,
        }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(
                _GROQ_URL,
                headers={
                    "Authorization": f"Bearer {settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": _MODEL,
                    "messages": [{"role": "user", "content": "ping"}],
                    "max_tokens": 5,
                },
            )
            if response.status_code == 200:
                return {
                    "success": True,
                    "message": f"Connected to Groq API successfully.",
                    "model": _MODEL,
                }
            else:
                data = response.json()
                return {
                    "success": False,
                    "message": data.get("error", {}).get("message", f"HTTP {response.status_code}"),
                    "model": None,
                }
    except Exception as e:
        logger.error(f"Groq connection test failed: {e}")
        return {
            "success": False,
            "message": str(e),
            "model": None,
        }

from fastapi import APIRouter, HTTPException, Depends, Request, BackgroundTasks
from datetime import datetime, timedelta, timezone
from loguru import logger
import secrets
from config.database import get_db
from config.security import (
    hash_password, verify_password, create_access_token, create_refresh_token,
    decode_refresh_token, hash_token, generate_verification_token, generate_api_key
)
from middleware.auth import get_current_user
from middleware.rate_limiter import limiter
from models.auth import (
    RegisterRequest, LoginRequest, RefreshRequest, ForgotPasswordRequest,
    ResetPasswordRequest, VerifyEmailRequest, UpdateProfileRequest, ChangePasswordRequest
)
from services.email_service import send_verification_email, send_password_reset_email, send_welcome_email, send_new_signup_admin_notification, send_shopify_welcome_email
from utils.helpers import success_response, error_response
from utils.validators import validate_password_strength, validate_email_format
from utils.phone_utils import normalize_phone, validate_indian_phone
from utils.constants import PLAN_DETAILS, PlanType
from config.settings import settings

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])


@router.post("/setup-admin")
async def setup_admin():
    """Bootstrap endpoint to create admin user. Only works if no admin exists."""
    db = get_db()
    existing = db.table("users").select("id").eq("role", "admin").execute()
    if existing.data:
        raise HTTPException(status_code=409, detail="Admin already exists. Use login.")

    admin_password = "Admin@123456"
    user_data = {
        "email": settings.DEFAULT_ADMIN_EMAIL,
        "password_hash": hash_password(admin_password),
        "name": "CODVerify Admin",
        "phone": "+919999999999",
        "role": "admin",
        "company_name": "CODVerify",
        "status": "active",
        "email_verified": True,
        "onboarding_completed": True,
    }
    result = db.table("users").insert(user_data).execute()
    logger.info(f"Admin user created: {settings.DEFAULT_ADMIN_EMAIL}")
    return success_response(
        {"email": settings.DEFAULT_ADMIN_EMAIL, "password": admin_password},
        "Admin created successfully. Use these credentials to login."
    )


@router.post("/shopify-install")
async def shopify_install(request: Request, background_tasks: BackgroundTasks):
    """
    Auto-creates a merchant account when they install our Shopify app.
    Called internally by the Shopify Node.js plugin after OAuth completes.
    
    - If account already exists for this shop_domain → returns existing user_id
    - If account is new → creates user, skips email verification (Shopify already verified)
    - Sets status=active and email_verified=True immediately
    """
    # Validate internal token to prevent abuse
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain    = body.get("shop_domain", "").strip()
    email          = body.get("email", "").strip().lower()
    name           = body.get("name", "").strip()
    phone          = body.get("phone", "+919999999999").strip()
    company_name   = body.get("company_name", name).strip()
    auto_password  = body.get("auto_password", "")
    shopify_shop_id = str(body.get("shopify_shop_id", ""))

    if not shop_domain or not email:
        raise HTTPException(status_code=400, detail="shop_domain and email are required")

    db = get_db()

    # Check if account already exists for this shop domain
    existing_by_shop = db.table("users").select("id, email, role").eq("shopify_shop_domain", shop_domain).execute()
    if existing_by_shop.data:
        user_id = existing_by_shop.data[0]["id"]
        user_email = existing_by_shop.data[0]["email"]
        user_role = existing_by_shop.data[0].get("role", "merchant")
        access_token = create_access_token({"sub": user_id, "role": user_role, "email": user_email})
        logger.info(f"Shopify install: existing account for shop {shop_domain} — user_id={user_id}")
        return success_response({"user_id": user_id, "is_new": False, "access_token": access_token}, "Account already exists")

    # Check if email already registered (different shop)
    existing_by_email = db.table("users").select("id, role").eq("email", email).execute()
    if existing_by_email.data:
        user_id = existing_by_email.data[0]["id"]
        user_role = existing_by_email.data[0].get("role", "merchant")
        # Link shop domain to existing account
        db.table("users").update({
            "shopify_shop_domain": shop_domain,
            "shopify_shop_id": shopify_shop_id,
            "registration_source": "shopify",
        }).eq("id", user_id).execute()
        access_token = create_access_token({"sub": user_id, "role": user_role, "email": email})
        logger.info(f"Shopify install: linked shop {shop_domain} to existing email {email}")

        return success_response({"user_id": user_id, "is_new": False, "access_token": access_token}, "Linked to existing account")

    # Validate and normalize phone
    import re
    phone_clean = re.sub(r'\s+', '', phone)
    if not re.match(r'^\+[1-9]\d{6,14}$', phone_clean):
        phone_clean = '+919999999999'

    # Create new merchant account — pre-verified since Shopify already verified their identity
    if not auto_password:
        auto_password = 'ShopifyOAuth@' + secrets.token_hex(8) + 'Aa1!'

    user_data = {
        "email": email,
        "password_hash": hash_password(auto_password),
        "name": name or shop_domain,
        "phone": phone_clean,
        "company_name": company_name,
        "role": "merchant",
        "status": "trial",
        "email_verified": True,          # Shopify already verified — no email needed
        "onboarding_completed": False,
        "shopify_shop_domain": shop_domain,
        "shopify_shop_id": shopify_shop_id,
        "registration_source": "shopify",
    }

    result = db.table("users").insert(user_data).execute()
    user   = result.data[0]
    user_id = user["id"]

    # Create default merchant settings
    db.table("merchant_settings").insert({
        "user_id": user_id,
        "notification_email": email,
    }).execute()

    # Create trial subscription
    from utils.constants import PLAN_DETAILS, PlanType
    from datetime import datetime, timedelta, timezone
    plan = PLAN_DETAILS.get("trial", PLAN_DETAILS.get(PlanType.TRIAL, {}))
    db.table("service_subscriptions").insert({
        "user_id":        user_id,
        "plan_type":      "trial",
        "plan_name":      plan.get("name", "Trial"),
        "monthly_quota":  plan.get("quota", 100),
        "price_monthly":  plan.get("price_monthly", 0),
        "price_yearly":   plan.get("price_yearly", 0),
        "start_date":     datetime.now(timezone.utc).date().isoformat(),
        "end_date":       (datetime.now(timezone.utc) + timedelta(days=14)).date().isoformat(),
        "status":         "active",
    }).execute()

    # Generate API key for merchant
    api_key    = generate_api_key()
    secret_key = secrets.token_hex(32)
    db.table("api_keys").insert({
        "user_id":         user_id,
        "api_key":         api_key,
        "secret_key_hash": hash_password(secret_key),
        "label":           f"Shopify — {shop_domain}",
    }).execute()

    # Auto-create chatbot config for this merchant
    try:
        chatbot_api_key = "ck_" + generate_api_key()
        db.table("merchant_chatbot_config").insert({
            "merchant_id": user_id,
            "api_key": chatbot_api_key,
            "is_enabled": False,
            "bot_name": "Support Bot",
            "welcome_message": f"Hi! 👋 Welcome to {company_name or shop_domain}. How can I help you today?",
            "primary_color": "#6366f1",
            "monthly_request_limit": 100,
            "current_month_usage": 0,
            "business_name": company_name or shop_domain,
            "business_website": f"https://{shop_domain}",
        }).execute()
    except Exception as e:
        logger.warning(f"Chatbot config auto-create failed (non-critical): {e}")

    # Generate access token for instant auto-login in Shopify plugin
    access_token = create_access_token({"sub": user_id, "role": "merchant", "email": email})

    # Send welcome email with credentials in background
    def _send_credentials_bg():
        import asyncio
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_shopify_welcome_email(
                email, name or shop_domain, shop_domain, auto_password,
                f"{settings.FRONTEND_URL}/dashboard"
            ))
            loop.close()
        except Exception as e:
            logger.warning(f"Shopify credentials email failed (non-critical): {e}")
    background_tasks.add_task(_send_credentials_bg)

    logger.info(f"✅ Shopify auto-install: new merchant account created for {shop_domain} ({email})")

    # Notify admin about new Shopify signup
    def _send_shopify_admin_notif():
        import asyncio
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_new_signup_admin_notification(
                settings.DEFAULT_ADMIN_EMAIL,
                {"name": name or shop_domain, "email": email, "phone": phone_clean, "company_name": company_name},
                source="shopify"
            ))
            loop.close()
        except Exception as e:
            logger.warning(f"Admin Shopify notification failed (non-critical): {e}")
    background_tasks.add_task(_send_shopify_admin_notif)

    return success_response({
        "user_id":      user_id,
        "api_key":      api_key,
        "secret_key":   secret_key,
        "access_token": access_token,
        "auto_password": auto_password,
        "is_new":       True,
    }, "Merchant account created successfully via Shopify install")


@router.post("/shopify-bind")
async def shopify_bind(request: Request, user: dict = Depends(get_current_user)):
    """
    Bind a Shopify shop domain to the currently logged-in user.
    Called by the embedded Shopify login page after the merchant logs in.
    
    - If shop_domain is free → binds to this user, sets onboarding_completed=True
    - If shop_domain is already bound to THIS user → idempotent (OK)
    - If shop_domain is bound to a DIFFERENT user → 409 conflict
    """
    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain = body.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()

    # Check if this shop is already bound to another user
    existing = db.table("users").select("id, email").eq("shopify_shop_domain", shop_domain).execute()
    if existing.data:
        bound_user_id = existing.data[0]["id"]
        if str(bound_user_id) != str(user["id"]):
            # Shop already belongs to someone else — conflict
            raise HTTPException(
                status_code=409,
                detail="This Shopify store is already linked to a different CODVerify account. Contact support if this is a mistake."
            )
        # Already bound to this user — idempotent
        return success_response({"bound": True, "shop_domain": shop_domain}, "Shop already linked to your account")

    # Bind shop to this user
    db.table("users").update({
        "shopify_shop_domain": shop_domain,
        "onboarding_completed": True,
    }).eq("id", user["id"]).execute()

    logger.info(f"✅ Shopify bind: shop {shop_domain} linked to user {user['id']} ({user.get('email', '')})")
    return success_response({"bound": True, "shop_domain": shop_domain}, "Shopify store linked to your account")


@router.post("/register")
@limiter.limit("5/minute")
async def register(request: Request, body: RegisterRequest, background_tasks: BackgroundTasks):
    db = get_db()

    errors = validate_password_strength(body.password)
    if errors:
        raise HTTPException(status_code=400, detail={"message": "Weak password", "errors": errors})

    # Accept international phones: +91 (India), +1 (USA), and other E.164 formats
    # Phone is optional (Shopify app may not collect it)
    import re
    phone_clean = re.sub(r'\s+', '', body.phone or "")
    if phone_clean and not re.match(r'^\+[1-9]\d{6,14}$', phone_clean):
        raise HTTPException(status_code=400, detail="Invalid phone number. Use international format: +91XXXXXXXXXX or +1XXXXXXXXXX")

    existing = db.table("users").select("id").eq("email", body.email).execute()
    if existing.data:
        raise HTTPException(status_code=409, detail="Email already registered")

    phone = normalize_phone(body.phone) if body.phone else ""
    verification_token = generate_verification_token()

    user_data = {
        "email": body.email,
        "password_hash": hash_password(body.password),
        "name": body.name,
        "phone": phone,
        "company_name": body.company_name,
        "role": "merchant",
        "status": "trial",
        "email_verification_token": verification_token,
        "email_verification_expires": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
    }
    result = db.table("users").insert(user_data).execute()
    user = result.data[0]
    user_id = user["id"]

    # Create default merchant settings
    db.table("merchant_settings").insert({"user_id": user_id, "notification_email": body.email}).execute()

    # Create subscription
    plan = PLAN_DETAILS.get(body.plan_type, PLAN_DETAILS[PlanType.TRIAL])
    db.table("service_subscriptions").insert({
        "user_id": user_id,
        "plan_type": body.plan_type.value if hasattr(body.plan_type, 'value') else body.plan_type,
        "plan_name": plan["name"],
        "monthly_quota": plan["quota"],
        "price_monthly": plan["price_monthly"],
        "price_yearly": plan["price_yearly"],
        "start_date": datetime.now(timezone.utc).date().isoformat(),
        "end_date": (datetime.now(timezone.utc) + timedelta(days=14)).date().isoformat(),
        "status": "active",
    }).execute()

    # Generate API key
    api_key = generate_api_key()
    secret_key = secrets.token_hex(32)
    db.table("api_keys").insert({
        "user_id": user_id,
        "api_key": api_key,
        "secret_key_hash": hash_password(secret_key),
        "label": "Default API Key",
    }).execute()

    # Send verification email in background — don't block registration if email fails
    def _send_verification_bg():
        import asyncio
        try:
            link = f"{settings.FRONTEND_URL}/verify-email/{verification_token}"
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_verification_email(body.email, body.name, link))
            loop.close()
        except Exception as e:
            logger.warning(f"Registration email failed (non-critical): {e}")
    background_tasks.add_task(_send_verification_bg)

    # Notify admin about new signup
    def _send_admin_notif():
        import asyncio
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_new_signup_admin_notification(
                settings.DEFAULT_ADMIN_EMAIL,
                {"name": body.name, "email": body.email, "phone": phone, "company_name": body.company_name},
                source="website"
            ))
            loop.close()
        except Exception as e:
            logger.warning(f"Admin notification failed (non-critical): {e}")
    background_tasks.add_task(_send_admin_notif)

    return success_response({"user_id": user_id, "api_key": api_key, "secret_key": secret_key},
                            "Registration successful! Please check your email to verify your account.")


@router.post("/verify-email")
async def verify_email(body: VerifyEmailRequest):
    db = get_db()
    result = db.table("users").select("*").eq("email_verification_token", body.token).execute()
    if not result.data:
        raise HTTPException(status_code=400, detail="Invalid or expired verification token")

    user = result.data[0]
    if user.get("email_verification_expires"):
        exp = datetime.fromisoformat(user["email_verification_expires"].replace("Z", "+00:00"))
        if datetime.now(timezone.utc) > exp:
            raise HTTPException(status_code=400, detail="Verification link has expired")

    db.table("users").update({
        "email_verified": True,
        "email_verification_token": None,
        "email_verification_expires": None,
        "status": "active" if user.get("status") == "trial" else user.get("status"),
    }).eq("id", user["id"]).execute()

    await send_welcome_email(user["email"], user["name"])
    return success_response(message="Email verified successfully")


@router.post("/resend-verification")
@limiter.limit("3/minute")
async def resend_verification(request: Request, background_tasks: BackgroundTasks):
    """Resend verification email to the currently unverified user by email body."""
    from pydantic import BaseModel, EmailStr
    class ResendBody(BaseModel):
        email: str

    import json
    body_bytes = await request.body()
    try:
        body_data = json.loads(body_bytes)
        email = body_data.get("email", "").strip().lower()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid request body")

    if not email:
        raise HTTPException(status_code=400, detail="Email is required")

    db = get_db()
    user_res = db.table("users").select("id, email, name, email_verified").eq("email", email).execute()

    # Always return success to avoid email enumeration
    if not user_res.data:
        return success_response(message="If your email is registered and unverified, a new link has been sent.")

    user = user_res.data[0]
    if user.get("email_verified"):
        return success_response(message="If your email is registered and unverified, a new link has been sent.")

    # Generate new verification token
    new_token = generate_verification_token()
    db.table("users").update({
        "email_verification_token": new_token,
        "email_verification_expires": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
    }).eq("id", user["id"]).execute()

    def _send_resend_bg():
        import asyncio
        try:
            link = f"{settings.FRONTEND_URL}/verify-email/{new_token}"
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_verification_email(user["email"], user["name"], link))
            loop.close()
        except Exception as e:
            logger.warning(f"Resend verification email failed (non-critical): {e}")
    background_tasks.add_task(_send_resend_bg)

    return success_response(message="If your email is registered and unverified, a new link has been sent.")


@router.post("/login")
@limiter.limit("5/minute")
async def login(request: Request, body: LoginRequest):
    db = get_db()
    result = db.table("users").select("*").eq("email", body.email).execute()
    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    user = result.data[0]
    if not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.get("email_verified"):
        raise HTTPException(status_code=403, detail="Please verify your email first")
    if user.get("status") == "suspended":
        raise HTTPException(status_code=403, detail="Account suspended. Contact support.")

    access_token = create_access_token({"sub": user["id"], "role": user["role"]})
    refresh_token = create_refresh_token({"sub": user["id"]})

    db.table("refresh_tokens").insert({
        "user_id": user["id"],
        "token_hash": hash_token(refresh_token),
        "expires_at": (datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)).isoformat(),
        "ip_address": request.client.host if request.client else None,
    }).execute()

    db.table("users").update({"last_login": datetime.now(timezone.utc).isoformat()}).eq("id", user["id"]).execute()

    # Get subscription
    sub = db.table("service_subscriptions").select("*").eq("user_id", user["id"]).eq("status", "active").order("created_at", desc=True).limit(1).execute()

    safe_user = {k: v for k, v in user.items() if k != "password_hash"}
    safe_user["subscription"] = sub.data[0] if sub.data else None

    return success_response({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": safe_user,
    }, "Login successful")


@router.post("/refresh")
async def refresh(body: RefreshRequest):
    payload = decode_refresh_token(body.refresh_token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    db = get_db()
    token_hash = hash_token(body.refresh_token)
    stored = db.table("refresh_tokens").select("*").eq("token_hash", token_hash).eq("is_revoked", False).execute()
    if not stored.data:
        raise HTTPException(status_code=401, detail="Token revoked or not found")

    user_id = payload.get("sub")
    user_res = db.table("users").select("role").eq("id", user_id).execute()
    if not user_res.data:
        raise HTTPException(status_code=401, detail="User not found")

    new_access = create_access_token({"sub": user_id, "role": user_res.data[0]["role"]})
    return success_response({"access_token": new_access, "token_type": "bearer"})


@router.post("/logout")
async def logout(body: RefreshRequest):
    db = get_db()
    token_hash = hash_token(body.refresh_token)

    # If it's a worker on duty, clock them out before revoking the token
    token_res = db.table("refresh_tokens").select("user_id").eq("token_hash", token_hash).eq("is_revoked", False).execute()
    if token_res.data:
        worker_id = token_res.data[0]["user_id"]
        user_res = db.table("users").select("role, duty_status, current_duty_start, total_duty_seconds").eq("id", worker_id).execute()
        if user_res.data:
            u = user_res.data[0]
            if u.get("role") == "worker" and u.get("duty_status") in ("on_duty", "break"):
                now = datetime.now(timezone.utc)
                duration = 0
                if u.get("current_duty_start"):
                    try:
                        start_dt = datetime.fromisoformat(u["current_duty_start"].replace("Z", "+00:00"))
                        duration = int((now - start_dt).total_seconds())
                    except Exception:
                        pass
                total = (u.get("total_duty_seconds") or 0) + duration
                db.table("users").update({
                    "duty_status": "off_duty",
                    "current_duty_start": None,
                    "total_duty_seconds": total,
                    "last_duty_change": now.isoformat(),
                }).eq("id", worker_id).execute()
                db.table("worker_duty_logs").insert({"worker_id": worker_id, "action": "clock_out"}).execute()

    db.table("refresh_tokens").update({"is_revoked": True}).eq("token_hash", token_hash).execute()
    return success_response(message="Logged out successfully")


@router.post("/forgot-password")
@limiter.limit("3/minute")
async def forgot_password(request: Request, body: ForgotPasswordRequest):
    db = get_db()
    user_res = db.table("users").select("id, name, email").eq("email", body.email).execute()
    if user_res.data:
        u = user_res.data[0]
        token = generate_verification_token()
        db.table("users").update({
            "password_reset_token": token,
            "password_reset_expires": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        }).eq("id", u["id"]).execute()
        link = f"{settings.FRONTEND_URL}/reset-password/{token}"
        await send_password_reset_email(u["email"], u["name"], link)

    return success_response(message="If an account exists with this email, a reset link has been sent.")


@router.post("/reset-password")
async def reset_password(body: ResetPasswordRequest):
    errors = validate_password_strength(body.new_password)
    if errors:
        raise HTTPException(status_code=400, detail={"message": "Weak password", "errors": errors})

    db = get_db()
    user_res = db.table("users").select("*").eq("password_reset_token", body.token).execute()
    if not user_res.data:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    reset_user = user_res.data[0]

    if reset_user.get("password_reset_expires"):
        exp = datetime.fromisoformat(reset_user["password_reset_expires"].replace("Z", "+00:00"))
        if datetime.now(timezone.utc) > exp:
            raise HTTPException(status_code=400, detail="Reset link has expired")

    db.table("users").update({
        "password_hash": hash_password(body.new_password),
        "password_reset_token": None,
        "password_reset_expires": None,
    }).eq("id", reset_user["id"]).execute()

    db.table("refresh_tokens").update({"is_revoked": True}).eq("user_id", reset_user["id"]).execute()
    return success_response(message="Password reset successful")


@router.get("/me")
async def get_me(user: dict = Depends(get_current_user)):
    db = get_db()
    sub = db.table("service_subscriptions").select("*").eq("user_id", user["id"]).eq("status", "active").order("created_at", desc=True).limit(1).execute()
    ms_res = db.table("merchant_settings").select("*").eq("user_id", user["id"]).execute()

    safe = {k: v for k, v in user.items() if k != "password_hash"}
    safe["subscription"] = sub.data[0] if sub.data else None
    safe["settings"] = ms_res.data[0] if ms_res.data else None
    return success_response(safe)


@router.put("/update-profile")
async def update_profile(body: UpdateProfileRequest, user: dict = Depends(get_current_user)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if "phone" in updates and updates["phone"]:
        updates["phone"] = normalize_phone(updates["phone"])
    if updates:
        db.table("users").update(updates).eq("id", user["id"]).execute()
    updated = db.table("users").select("*").eq("id", user["id"]).execute()
    safe = {k: v for k, v in updated.data[0].items() if k != "password_hash"}
    return success_response(safe, "Profile updated")


@router.put("/change-password")
async def change_password(body: ChangePasswordRequest, user: dict = Depends(get_current_user)):
    if not verify_password(body.current_password, user["password_hash"]):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    errors = validate_password_strength(body.new_password)
    if errors:
        raise HTTPException(status_code=400, detail={"message": "Weak password", "errors": errors})
    db = get_db()
    db.table("users").update({"password_hash": hash_password(body.new_password)}).eq("id", user["id"]).execute()
    return success_response(message="Password changed successfully")


# ── Shopify Key-Based Connection Flow ──────────────────────────────────

@router.post("/shopify-generate-key")
async def shopify_generate_key(request: Request):
    """
    Called by the Shopify plugin after OAuth completes.
    Generates a secret key for the shop. The merchant will use this key
    to connect their store via the CODVerify website dashboard.
    Does NOT create a user account - merchant must register separately.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain = body.get("shop_domain", "").strip()
    shop_name = body.get("shop_name", "").strip()
    shop_email = body.get("shop_email", "").strip().lower()
    shopify_shop_id = str(body.get("shopify_shop_id", ""))
    access_token = body.get("access_token", "")

    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()
    from utils.encryption import encrypt_value

    # Always update/store the access token so webhook re-registration works
    if access_token:
        encrypted_token = encrypt_value(access_token)
        # Upsert into shopify_install_keys — update existing or insert new
        existing_token_row = db.table("shopify_install_keys").select("id").eq("shop_domain", shop_domain).order("created_at", desc=True).limit(1).execute()
        if existing_token_row.data:
            db.table("shopify_install_keys").update({
                "access_token_encrypted": encrypted_token,
                "shop_name": shop_name or shop_domain,
            }).eq("id", existing_token_row.data[0]["id"]).execute()
            logger.info(f"🔄 Updated access token for {shop_domain}")
        # Also update stores table if store exists
        db.table("stores").update({
            "access_token_encrypted": encrypted_token,
        }).eq("store_url", shop_domain).execute()

    # Check if this shop is already connected to an account
    existing_user = db.table("users").select("id, email").eq("shopify_shop_domain", shop_domain).execute()
    if existing_user.data:
        return success_response({
            "is_already_connected": True,
            "secret_key": None,
        }, "This store is already connected to a CODVerify account")

    # AUTO-RECONNECT: If shop was previously connected but uninstalled, re-link automatically
    prev_store = db.table("stores").select("user_id, id").eq("store_url", shop_domain).order("created_at", desc=True).limit(1).execute()
    if prev_store.data:
        prev_user_id = prev_store.data[0]["user_id"]
        prev_user = db.table("users").select("id, status").eq("id", prev_user_id).execute()
        if prev_user.data and prev_user.data[0].get("status") not in ("suspended", "inactive"):
            # Reactivate store
            db.table("stores").update({"is_active": True}).eq("id", prev_store.data[0]["id"]).execute()
            # Restore user <-> shop link
            db.table("users").update({
                "shopify_shop_domain": shop_domain,
            }).eq("id", prev_user_id).execute()
            logger.info(f"🔄 Auto-reconnected {shop_domain} to user {prev_user_id} after reinstall")
            return success_response({
                "is_already_connected": True,
                "secret_key": None,
            }, "Store auto-reconnected after reinstall")

    # Check if a key already exists for this shop (not used yet)
    existing_key = db.table("shopify_install_keys").select("id, secret_key, is_used").eq("shop_domain", shop_domain).eq("is_used", False).execute()
    if existing_key.data:
        # Return existing unused key
        return success_response({
            "secret_key": existing_key.data[0]["secret_key"],
            "shop_domain": shop_domain,
            "is_already_connected": False,
        }, "Secret key already generated for this store")

    # Generate a new secret key (readable format: CV-XXXX-XXXX-XXXX)
    import string, random
    chars = string.ascii_uppercase + string.digits
    key_parts = [''.join(random.choices(chars, k=4)) for _ in range(3)]
    secret_key = f"CV-{key_parts[0]}-{key_parts[1]}-{key_parts[2]}"

    # Store the key with shop info
    key_data = {
        "shop_domain": shop_domain,
        "shop_name": shop_name or shop_domain,
        "shop_email": shop_email,
        "shopify_shop_id": shopify_shop_id,
        "access_token_encrypted": encrypt_value(access_token) if access_token else "",
        "secret_key": secret_key,
        "is_used": False,
    }
    db.table("shopify_install_keys").insert(key_data).execute()

    logger.info(f"✅ Shopify secret key generated for {shop_domain}: {secret_key}")

    return success_response({
        "secret_key": secret_key,
        "shop_domain": shop_domain,
        "is_already_connected": False,
    }, "Secret key generated. Merchant must enter this key on CODVerify dashboard to connect.")


@router.post("/shopify-regenerate-key")
async def shopify_regenerate_key(request: Request):
    """
    Regenerate a new secret key for a shop.
    Invalidates any old unused keys and generates a fresh one.
    Called by the Shopify plugin when merchant clicks Regenerate.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain = body.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()

    # Check if already connected
    existing_user = db.table("users").select("id").eq("shopify_shop_domain", shop_domain).execute()
    if existing_user.data:
        return success_response({
            "secret_key": None,
            "is_already_connected": True,
        }, "This store is already connected to a CODVerify account")

    # Delete old unused keys for this shop
    db.table("shopify_install_keys").delete().eq("shop_domain", shop_domain).eq("is_used", False).execute()

    # Generate new key
    import string, random
    chars = string.ascii_uppercase + string.digits
    key_parts = [''.join(random.choices(chars, k=4)) for _ in range(3)]
    secret_key = f"CV-{key_parts[0]}-{key_parts[1]}-{key_parts[2]}"

    # Get shop info from any existing (used) key, or use defaults
    old_key = db.table("shopify_install_keys").select("shop_name, shop_email, shopify_shop_id, access_token_encrypted").eq("shop_domain", shop_domain).limit(1).execute()
    shop_name = old_key.data[0]["shop_name"] if old_key.data else shop_domain
    shop_email = old_key.data[0].get("shop_email", "") if old_key.data else ""
    shopify_shop_id = old_key.data[0].get("shopify_shop_id", "") if old_key.data else ""
    access_token_encrypted = old_key.data[0].get("access_token_encrypted", "") if old_key.data else ""

    key_data = {
        "shop_domain": shop_domain,
        "shop_name": shop_name,
        "shop_email": shop_email,
        "shopify_shop_id": shopify_shop_id,
        "access_token_encrypted": access_token_encrypted,
        "secret_key": secret_key,
        "is_used": False,
    }
    db.table("shopify_install_keys").insert(key_data).execute()

    logger.info(f"🔄 Shopify secret key regenerated for {shop_domain}: {secret_key}")

    return success_response({
        "secret_key": secret_key,
        "shop_domain": shop_domain,
        "is_already_connected": False,
    }, "New secret key generated successfully")


@router.get("/shopify-connection-status")
async def shopify_connection_status(request: Request):
    """
    Check if a Shopify store is connected to a CODVerify account.
    Called by the Shopify plugin /app page to show connection status.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    shop_domain = request.query_params.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()

    # Check if store is connected to a user
    user_res = db.table("users").select("id, email, name, company_name").eq("shopify_shop_domain", shop_domain).execute()
    if user_res.data:
        return success_response({
            "is_connected": True,
            "shop_domain": shop_domain,
            "shop_name": user_res.data[0].get("company_name") or user_res.data[0].get("name") or shop_domain,
            "connected_email": user_res.data[0].get("email"),
        }, "Store is connected")

    # Not connected - check if key exists
    key_res = db.table("shopify_install_keys").select("secret_key, shop_name, is_used").eq("shop_domain", shop_domain).eq("is_used", False).execute()
    secret_key = key_res.data[0]["secret_key"] if key_res.data else None
    shop_name = key_res.data[0]["shop_name"] if key_res.data else shop_domain

    return success_response({
        "is_connected": False,
        "shop_domain": shop_domain,
        "shop_name": shop_name,
        "secret_key": secret_key,
    }, "Store is not connected")


@router.post("/shopify-force-new-key")
async def shopify_force_new_key(request: Request):
    """
    Force-generate a new secret key for a shop, bypassing the 'already connected' check.
    This is used when a merchant deleted their account and re-registered and needs to reconnect.
    This UNLINKS the shop from any previous account and generates a fresh key.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain = body.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()

    # Unlink shop from any existing user (so they can reconnect with a fresh account)
    existing_user = db.table("users").select("id").eq("shopify_shop_domain", shop_domain).execute()
    if existing_user.data:
        db.table("users").update({
            "shopify_shop_domain": None,
        }).eq("shopify_shop_domain", shop_domain).execute()
        # Deactivate any stores for this domain
        db.table("stores").update({"is_active": False}).eq("store_url", shop_domain).execute()
        logger.info(f"🔓 Force-unlinked {shop_domain} from user {existing_user.data[0]['id']}")

    # Collect shop info BEFORE deleting old keys
    old_key = db.table("shopify_install_keys").select("shop_name, shop_email, shopify_shop_id, access_token_encrypted").eq("shop_domain", shop_domain).order("created_at", desc=True).limit(1).execute()
    shop_name = old_key.data[0]["shop_name"] if old_key.data else shop_domain
    shop_email = old_key.data[0].get("shop_email", "") if old_key.data else ""
    shopify_shop_id = old_key.data[0].get("shopify_shop_id", "") if old_key.data else ""
    access_token_encrypted = old_key.data[0].get("access_token_encrypted", "") if old_key.data else ""

    # Also try to get access token from stores table if not in keys
    if not access_token_encrypted:
        store_res = db.table("stores").select("access_token_encrypted, store_name").eq("store_url", shop_domain).limit(1).execute()
        if store_res.data:
            access_token_encrypted = store_res.data[0].get("access_token_encrypted", "")
            if not shop_name or shop_name == shop_domain:
                shop_name = store_res.data[0].get("store_name", shop_domain) or shop_domain

    # Now delete all old keys for this shop
    db.table("shopify_install_keys").delete().eq("shop_domain", shop_domain).execute()

    # Generate fresh key
    import string, random
    chars = string.ascii_uppercase + string.digits
    key_parts = [''.join(random.choices(chars, k=4)) for _ in range(3)]
    secret_key = f"CV-{key_parts[0]}-{key_parts[1]}-{key_parts[2]}"

    db.table("shopify_install_keys").insert({
        "shop_domain": shop_domain,
        "shop_name": shop_name,
        "shop_email": shop_email,
        "shopify_shop_id": shopify_shop_id,
        "access_token_encrypted": access_token_encrypted,
        "secret_key": secret_key,
        "is_used": False,
    }).execute()

    logger.info(f"🆕 Force-generated new key for {shop_domain}: {secret_key}")

    return success_response({
        "secret_key": secret_key,
        "shop_domain": shop_domain,
    }, "New secret key generated. Enter this on CODVerify dashboard to reconnect.")


@router.post("/shopify-uninstall")
async def shopify_uninstall(request: Request):
    """
    Called by Shopify plugin when merchant uninstalls the app.
    Clears shopify_shop_domain from user and deactivates associated store.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if expected_token and internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    import json
    body_bytes = await request.body()
    try:
        body = json.loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    shop_domain = body.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()

    # Deactivate stores for this shop
    db.table("stores").update({"is_active": False}).eq("store_url", shop_domain).execute()

    # Clear shopify domain from user (but don't delete account)
    user_res = db.table("users").select("id").eq("shopify_shop_domain", shop_domain).execute()
    if user_res.data:
        db.table("users").update({
            "shopify_shop_domain": None,
            "shopify_shop_id": None,
        }).eq("id", user_res.data[0]["id"]).execute()

    # Invalidate any unused keys for this shop
    db.table("shopify_install_keys").update({"is_used": True}).eq("shop_domain", shop_domain).eq("is_used", False).execute()

    logger.info(f"Shopify app uninstalled for shop: {shop_domain}")
    return success_response(message="Shopify app uninstalled successfully")


@router.get("/shopify-access-token")
async def get_shopify_access_token(request: Request):
    """
    Returns the decrypted Shopify access token for a shop.
    Used by the plugin to register webhooks using the stored token.
    Protected by internal token.
    """
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = settings.INTERNAL_API_TOKEN if hasattr(settings, 'INTERNAL_API_TOKEN') else ""
    if not expected_token or internal_token != expected_token:
        raise HTTPException(status_code=403, detail="Unauthorized internal call")

    shop_domain = request.query_params.get("shop_domain", "").strip()
    if not shop_domain:
        raise HTTPException(status_code=400, detail="shop_domain is required")

    db = get_db()
    from utils.encryption import decrypt_value

    # Try shopify_install_keys first (has the latest token)
    key_res = db.table("shopify_install_keys").select("access_token_encrypted").eq("shop_domain", shop_domain).order("created_at", desc=True).limit(1).execute()
    if key_res.data and key_res.data[0].get("access_token_encrypted"):
        token = decrypt_value(key_res.data[0]["access_token_encrypted"])
        if token:
            return success_response({"access_token": token, "source": "install_key"})

    # Try stores table
    store_res = db.table("stores").select("access_token_encrypted").eq("store_url", shop_domain).eq("is_active", True).limit(1).execute()
    if store_res.data and store_res.data[0].get("access_token_encrypted"):
        token = decrypt_value(store_res.data[0]["access_token_encrypted"])
        if token:
            return success_response({"access_token": token, "source": "store"})

    raise HTTPException(status_code=404, detail="No access token found for this shop")

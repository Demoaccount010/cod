from fastapi import APIRouter, Request, Response, HTTPException
from loguru import logger
from config.database import get_db
from config.settings import settings
from services.whatsapp_service import verify_webhook_signature, send_text_message, send_interactive_button_message, send_template_message
from services.order_processing import update_store_order
from services.notification_service import create_notification
from services.email_service import send_order_cancellation_alert
from utils.phone_utils import normalize_phone, hash_phone
from utils.encryption import decrypt_value
from utils.constants import POSITIVE_RESPONSES, NEGATIVE_RESPONSES
from datetime import datetime, timezone

router = APIRouter(prefix="/api/v1/webhooks", tags=["WhatsApp Webhooks"])


@router.get("/whatsapp")
async def verify_whatsapp(request: Request):
    mode = request.query_params.get("hub.mode")
    token = request.query_params.get("hub.verify_token")
    challenge = request.query_params.get("hub.challenge")

    if mode == "subscribe" and token == settings.WHATSAPP_VERIFY_TOKEN:
        logger.info("WhatsApp webhook verified")
        return Response(content=challenge, media_type="text/plain")
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/whatsapp")
async def whatsapp_webhook(request: Request):
    body = await request.body()

    # Verify signature
    signature = request.headers.get("X-Hub-Signature-256", "")
    if settings.WHATSAPP_APP_SECRET:
        if not verify_webhook_signature(body, signature, settings.WHATSAPP_APP_SECRET):
            logger.warning(f"❌ Invalid WhatsApp webhook signature. Got: '{signature[:40]}...' body_len={len(body)}")
            raise HTTPException(status_code=401, detail="Invalid signature")
        else:
            logger.info(f"✅ WhatsApp webhook signature verified OK")
    else:
        logger.info("⚠️ No APP_SECRET set — skipping signature check (accepting all webhooks)")

    # Parse JSON from already-read body bytes (FastAPI body can only be read once)
    try:
        import json
        data = json.loads(body)
    except Exception:
        return {"status": "ok"}

    db = get_db()

    for entry in data.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})

            # Handle message status updates
            for status_update in value.get("statuses", []):
                await _handle_status_update(db, status_update)

            # Handle incoming messages
            for message in value.get("messages", []):
                await _handle_incoming_message(db, message, value)

    return {"status": "ok"}


async def _handle_status_update(db, status_update: dict):
    wa_msg_id = status_update.get("id")
    status = status_update.get("status")
    if not wa_msg_id or not status:
        return

    # Check idempotency
    msg_res = db.table("messages").select("*").eq("whatsapp_message_id", wa_msg_id).execute()
    if not msg_res.data:
        return
    msg_data = msg_res.data[0]

    now = datetime.now(timezone.utc).isoformat()
    msg_updates = {}
    order_updates = {}

    if status == "sent":
        msg_updates = {"status": "sent", "sent_at": now}
        order_updates = {"verification_status": "sent", "verification_sent_at": now}
    elif status == "delivered":
        msg_updates = {"status": "delivered", "delivered_at": now}
        order_updates = {"verification_status": "delivered", "verification_delivered_at": now}
    elif status == "read":
        msg_updates = {"status": "read", "read_at": now}
        order_updates = {"verification_status": "read", "verification_read_at": now}
    elif status == "failed":
        errors = status_update.get("errors", [{}])
        error_code = errors[0].get("code", "") if errors else ""
        error_msg = errors[0].get("title", "") if errors else ""
        msg_updates = {"status": "failed", "failed_at": now, "error_code": str(error_code), "failure_reason": error_msg}

        if str(error_code) == "131026":
            order_updates = {"verification_status": "not_on_whatsapp"}
            # Update customer directory
            order_res = db.table("orders").select("customer_phone_normalized, user_id, order_number").eq("id", msg_data["order_id"]).execute()
            if order_res.data:
                order_data = order_res.data[0]
                p_hash = hash_phone(order_data["customer_phone_normalized"])
                db.table("customers_directory").update({"is_on_whatsapp": False}).eq("phone_number_hash", p_hash).execute()
                await create_notification(order_data["user_id"], f"Customer not on WhatsApp",
                    f"Order #{order_data.get('order_number', '')} - customer is not on WhatsApp", "warning", "orders")
        else:
            # WhatsApp delivery failure — keep order in 'pending' state
            # so workers can still manually verify/cancel it from their dashboard.
            # DO NOT mark as 'failed' — that hides the order from the worker queue permanently.
            order_updates = {"verification_status": "pending"}

    if msg_updates:
        db.table("messages").update(msg_updates).eq("id", msg_data["id"]).execute()
    if order_updates:
        db.table("orders").update(order_updates).eq("id", msg_data["order_id"]).execute()


async def _handle_incoming_message(db, message: dict, value: dict):
    from_phone = message.get("from", "")
    msg_type = message.get("type", "")
    logger.info(f"📨 Incoming WA message: from={from_phone} type={msg_type}")

    if not from_phone:
        logger.warning("Incoming WA message has no 'from' field — skipping")
        return

    phone_normalized = normalize_phone(from_phone)
    wa_msg_id = message.get("id", "")
    logger.info(f"📨 Normalized phone: {phone_normalized} | msg_id={wa_msg_id}")

    # Idempotency check
    existing = db.table("messages").select("id").eq("whatsapp_message_id", wa_msg_id).execute()
    if existing.data:
        logger.info(f"📨 Duplicate message {wa_msg_id} — already processed, skipping")
        return

    # Find matching order
    order = db.table("orders").select("*").eq("customer_phone_normalized", phone_normalized).in_(
        "verification_status", ["sent", "delivered", "read", "queued"]
    ).order("created_at", desc=True).limit(1).execute()

    if not order.data:
        logger.warning(f"📨 No matching order found for phone={phone_normalized} in sent/delivered/read/queued")
        return

    order_data = order.data[0]
    logger.info(f"📨 Matched order {order_data['id']} (#{order_data.get('order_number')}) status={order_data['verification_status']}")
    response_type = None

    YES_KEYS = {"0", "confirm_yes", "yes", "confirm", "haan", "ok", "ha", "ship", "accept", "confirm order"}
    NO_KEYS  = {"1", "confirm_no",  "no",  "cancel",  "nahi", "nah", "reject", "dont", "don't", "cancel order"}

    # Determine response
    if message.get("type") == "button":
        # Template Quick Reply button — Meta sends type='button' (NOT 'interactive')
        btn = message.get("button", {})
        btn_text    = btn.get("text", "").lower().strip()
        btn_payload = btn.get("payload", "").lower().strip()
        logger.info(f"📨 Template button reply: text='{btn_text}' payload='{btn_payload}'")

        if btn_text in YES_KEYS or any(k in btn_text for k in ("yes", "confirm", "ok")) \
           or btn_payload in YES_KEYS or any(k in btn_payload for k in ("yes", "confirm", "ok")):
            response_type = "yes"
        elif btn_text in NO_KEYS or any(k in btn_text for k in ("no", "cancel", "reject")) \
           or btn_payload in NO_KEYS or any(k in btn_payload for k in ("no", "cancel", "reject")):
            response_type = "no"
        else:
            logger.warning(f"📨 Unknown template button: text='{btn_text}' — treating as confirm")
            response_type = "yes"

    elif message.get("type") == "interactive":
        interactive = message.get("interactive", {})
        if interactive.get("type") == "button_reply":
            button_reply = interactive.get("button_reply", {})
            button_id    = button_reply.get("id", "").lower().strip()
            button_title = button_reply.get("title", "").lower().strip()
            logger.info(f"📨 Interactive button reply: id='{button_id}' title='{button_title}'")

            if button_id in YES_KEYS or any(k in button_id for k in ("yes", "confirm", "ok")) \
               or button_title in YES_KEYS or any(k in button_title for k in ("yes", "confirm", "ok")):
                response_type = "yes"
            elif button_id in NO_KEYS or any(k in button_id for k in ("no", "cancel", "reject")) \
               or button_title in NO_KEYS or any(k in button_title for k in ("no", "cancel", "reject")):
                response_type = "no"
            else:
                logger.warning(f"📨 Unknown interactive button: id='{button_id}' — treating as confirm")
                response_type = "yes"

    elif message.get("type") == "text":
        text = message.get("text", {}).get("body", "").lower().strip()
        logger.info(f"📨 Text reply: '{text}'")
        if any(r == text for r in POSITIVE_RESPONSES):
            response_type = "yes"
        elif any(r == text for r in NEGATIVE_RESPONSES):
            response_type = "no"
        else:
            # Unclear response - send clarification
            await _send_clarification(db, order_data, text)
            return

    if not response_type:
        logger.info(f"📨 No actionable response_type — ignoring message type={msg_type}")
        return

    logger.info(f"📨 Response: {response_type.upper()} for order {order_data['id']}")
    now = datetime.now(timezone.utc)
    sent_at = order_data.get("verification_sent_at")
    resp_time = None
    if sent_at:
        sent_dt = datetime.fromisoformat(sent_at.replace("Z", "+00:00"))
        resp_time = int((now - sent_dt).total_seconds())

    # Log inbound message
    db.table("messages").insert({
        "order_id": order_data["id"],
        "user_id": order_data["user_id"],
        "whatsapp_message_id": wa_msg_id,
        "direction": "inbound",
        "message_type": "button_reply" if message.get("type") == "interactive" else "text",
        "content": message.get("text", {}).get("body", "") or response_type,
        "button_payload": response_type,
        "status": "delivered",
        "delivered_at": now.isoformat(),
    }).execute()

    if response_type == "yes":
        await _handle_confirmation(db, order_data, now, resp_time)
    else:
        await _handle_cancellation(db, order_data, now, resp_time)


async def _handle_confirmation(db, order: dict, now: datetime, resp_time: int | None):
    db.table("orders").update({
        "verification_status": "confirmed",
        "customer_response": "yes",
        "response_received_at": now.isoformat(),
        "response_time_seconds": resp_time,
    }).eq("id", order["id"]).execute()

    # Send confirmed message using order_confirmed template (platform WA)
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if phone_id and token:
        # Get store name
        _store_name = "Our Store"
        if order.get("store_id"):
            _sr = db.table("stores").select("store_name, store_url").eq("id", order["store_id"]).execute()
            if _sr.data:
                _store_name = _sr.data[0].get("store_name") or _sr.data[0].get("store_url") or "Our Store"
        if _store_name == "Our Store":
            _ur = db.table("users").select("company_name, name").eq("id", order["user_id"]).execute()
            if _ur.data:
                _store_name = _ur.data[0].get("company_name") or _ur.data[0].get("name") or "Our Store"

        _order_num = order.get("order_number") or order.get("store_order_id") or "N/A"
        _cust_name = (order.get("customer_name") or "Customer").split()[0]  # First name only
        _components = [{"type": "body", "parameters": [
            {"type": "text", "text": _cust_name},
            {"type": "text", "text": str(_order_num)},
            {"type": "text", "text": _store_name},
        ]}]
        _wa_msg_id = await send_template_message(phone_id, token, order["customer_phone_normalized"],
            "order_confirmed", "en", _components)

        # ── Wallet debit ₹0.50 for confirmation WA sent to customer ──
        if _wa_msg_id:
            try:
                from config.service_pricing import get_price
                from services import wallet_service
                _charge = get_price("whatsapp_cod_verification")  # ₹0.50
                if _charge > 0:
                    await wallet_service.debit_wallet(
                        db,
                        user_id=order["user_id"],
                        amount=_charge,
                        service_key="whatsapp_cod_verification",
                        description=f"WhatsApp Order Confirmed notification — #{order.get('order_number') or order.get('store_order_id')}",
                        reference_id=order["id"],
                    )
            except Exception as _e:
                logger.warning(f"Wallet debit (confirm WA) failed for order {order['id']}: {_e}")
    else:
        # Fallback: merchant's own WA (text message)
        ms = db.table("merchant_settings").select("*").eq("user_id", order["user_id"]).execute()
        if ms.data and ms.data[0].get("whatsapp_connected") and ms.data[0].get("enable_thankyou_msg", True) is not False:
            _phone_id = ms.data[0]["whatsapp_phone_number_id"]
            _tkn = decrypt_value(ms.data[0]["whatsapp_access_token_encrypted"])
            await send_text_message(_phone_id, _tkn, order["customer_phone_normalized"],
                f"Thank you! Your order #{order.get('order_number', order['store_order_id'])} has been confirmed. We'll ship it soon! 🎉")

    # Update store
    await update_store_order(order, "confirmed")

    # Update customer directory
    p_hash = hash_phone(order["customer_phone_normalized"])
    cust = db.table("customers_directory").select("*").eq("phone_number_hash", p_hash).execute()
    if cust.data:
        confirmed = cust.data[0].get("confirmed_orders", 0) + 1
        total = cust.data[0].get("total_orders", 1)
        old_avg = cust.data[0].get("avg_response_time_seconds") or 0
        # Rolling average: weighted so each confirmation is counted equally
        new_avg = int(((old_avg * (confirmed - 1)) + (resp_time or 0)) / confirmed) if confirmed > 0 else (resp_time or 0)
        db.table("customers_directory").update({
            "confirmed_orders": confirmed,
            "confirmation_rate": round((confirmed / total) * 100, 2) if total > 0 else 0,
            "avg_response_time_seconds": new_avg,
        }).eq("id", cust.data[0]["id"]).execute()

    await create_notification(order["user_id"], f"Order #{order.get('order_number', '')} Confirmed ✅",
        f"Customer confirmed the order (₹{order['order_amount']})", "success", "orders", f"/dashboard/orders/{order['id']}")


async def _handle_cancellation(db, order: dict, now: datetime, resp_time: int | None):
    db.table("orders").update({
        "verification_status": "cancelled",
        "customer_response": "no",
        "response_received_at": now.isoformat(),
        "response_time_seconds": resp_time,
    }).eq("id", order["id"]).execute()

    # Send cancellation message using order_cancelled template (platform WA)
    _phone_id2 = settings.WHATSAPP_PHONE_NUMBER_ID
    _tkn2 = settings.WHATSAPP_ACCESS_TOKEN
    if _phone_id2 and _tkn2:
        # Get store name
        _store_name2 = "Our Store"
        if order.get("store_id"):
            _sr2 = db.table("stores").select("store_name, store_url").eq("id", order["store_id"]).execute()
            if _sr2.data:
                _store_name2 = _sr2.data[0].get("store_name") or _sr2.data[0].get("store_url") or "Our Store"
        if _store_name2 == "Our Store":
            _ur2 = db.table("users").select("company_name, name").eq("id", order["user_id"]).execute()
            if _ur2.data:
                _store_name2 = _ur2.data[0].get("company_name") or _ur2.data[0].get("name") or "Our Store"

        _order_num2 = order.get("order_number") or order.get("store_order_id") or "N/A"
        _cust_name2 = (order.get("customer_name") or "Customer").split()[0]
        _components2 = [{"type": "body", "parameters": [
            {"type": "text", "text": _cust_name2},
            {"type": "text", "text": str(_order_num2)},
            {"type": "text", "text": _store_name2},
        ]}]
        _wa_msg_id2 = await send_template_message(_phone_id2, _tkn2, order["customer_phone_normalized"],
            "order_cancelled", "en", _components2)

        # ── Wallet debit ₹0.50 for cancellation WA sent to customer ──
        if _wa_msg_id2:
            try:
                from config.service_pricing import get_price
                from services import wallet_service
                _charge2 = get_price("whatsapp_cod_verification")  # ₹0.50
                if _charge2 > 0:
                    await wallet_service.debit_wallet(
                        db,
                        user_id=order["user_id"],
                        amount=_charge2,
                        service_key="whatsapp_cod_verification",
                        description=f"WhatsApp Order Cancelled notification — #{order.get('order_number') or order.get('store_order_id')}",
                        reference_id=order["id"],
                    )
            except Exception as _e2:
                logger.warning(f"Wallet debit (cancel WA) failed for order {order['id']}: {_e2}")
    else:
        ms2 = db.table("merchant_settings").select("*").eq("user_id", order["user_id"]).execute()
        if ms2.data and ms2.data[0].get("whatsapp_connected") and ms2.data[0].get("enable_cancel_msg", True) is not False:
            _phi = ms2.data[0]["whatsapp_phone_number_id"]
            _tok = decrypt_value(ms2.data[0]["whatsapp_access_token_encrypted"])
            await send_text_message(_phi, _tok, order["customer_phone_normalized"],
                f"Your order #{order.get('order_number', order['store_order_id'])} has been cancelled as per your request.")

    await update_store_order(order, "cancelled")

    # Update customer directory
    p_hash = hash_phone(order["customer_phone_normalized"])
    cust = db.table("customers_directory").select("*").eq("phone_number_hash", p_hash).execute()
    if cust.data:
        cancelled = cust.data[0].get("cancelled_orders", 0) + 1
        total = cust.data[0].get("total_orders", 1)
        confirmed = cust.data[0].get("confirmed_orders", 0)
        new_risk = min(100, cust.data[0].get("risk_score", 0) + 10)
        db.table("customers_directory").update({
            "cancelled_orders": cancelled,
            "confirmation_rate": round((confirmed / total) * 100, 2) if total > 0 else 0,
            "risk_score": new_risk,
        }).eq("id", cust.data[0]["id"]).execute()

    # Currency-aware notification
    _sym = "$" if order.get("currency") == "USD" else "₹"
    await create_notification(order["user_id"], f"⚠️ Order #{order.get('order_number', '')} CANCELLED",
        f"Customer cancelled the order ({_sym}{order['order_amount']})", "error", "orders", f"/dashboard/orders/{order['id']}")

    # Email alert
    ms = db.table("merchant_settings").select("notification_on_cancel, notification_email").eq("user_id", order["user_id"]).execute()
    if ms.data and ms.data[0].get("notification_on_cancel"):
        email = ms.data[0].get("notification_email")
        if email:
            user = db.table("users").select("name, company_name").eq("id", order["user_id"]).execute()
            merchant_name = user.data[0].get("company_name", user.data[0].get("name", "")) if user.data else ""
            # Pass full order dict so email template has all context
            await send_order_cancellation_alert(email, merchant_name, order)


async def _send_clarification(db, order: dict, text: str):
    """Send a re-prompt to the customer when their text reply is unclear."""
    phone_normalized = order["customer_phone_normalized"]
    order_num = order.get("order_number") or order.get("store_order_id") or "N/A"
    cust_name = (order.get("customer_name") or "Customer").split()[0]

    # 1. Try platform WhatsApp (always available, doesn't need merchant setup)
    if settings.WHATSAPP_PHONE_NUMBER_ID and settings.WHATSAPP_ACCESS_TOKEN:
        components = [{"type": "body", "parameters": [
            {"type": "text", "text": cust_name},
            {"type": "text", "text": str(order_num)},
        ]}]
        try:
            _sent_id = await send_template_message(
                settings.WHATSAPP_PHONE_NUMBER_ID, settings.WHATSAPP_ACCESS_TOKEN,
                phone_normalized, "order_verification", "en", components,
            )
            if _sent_id:
                db.table("orders").update({"customer_response_text": text}).eq("id", order["id"]).execute()
                logger.info(f"📨 Clarification re-sent via platform WA for order {order['id']}")
                # ── Debit wallet for clarification WA ────────────────────────
                try:
                    from config.service_pricing import get_price as _gp
                    from services import wallet_service as _ws
                    _charge = _gp("clarification_wa")  # ₹0.50
                    if _charge > 0:
                        await _ws.debit_wallet(
                            db,
                            user_id=order["user_id"],
                            amount=_charge,
                            service_key="clarification_wa",
                            description=f"Order clarification WA re-send — #{order_num}",
                            reference_id=order["id"],
                        )
                except Exception as _we:
                    logger.warning(f"Wallet debit for clarification WA failed: {_we}")
                return
            # send failed — fall through to merchant WA fallback
        except Exception as e:
            logger.warning(f"Platform WA clarification failed: {e}, trying merchant WA")

    # 2. Fallback: merchant's own WhatsApp with interactive buttons
    ms = db.table("merchant_settings").select("*").eq("user_id", order["user_id"]).execute()
    if not ms.data or not ms.data[0].get("whatsapp_connected"):
        logger.warning(f"No WA available for clarification — order {order['id']} clarification dropped")
        return

    phone_id = ms.data[0]["whatsapp_phone_number_id"]
    token = decrypt_value(ms.data[0]["whatsapp_access_token_encrypted"])

    buttons = [
        {"type": "reply", "reply": {"id": "confirm_yes", "title": "✅ Confirm Order"}},
        {"type": "reply", "reply": {"id": "confirm_no", "title": "❌ Cancel Order"}},
    ]

    await send_interactive_button_message(phone_id, token, phone_normalized,
        "I didn't understand your response. Please select an option:", buttons,
        "Order Confirmation", "Powered by CODVerify")

    db.table("orders").update({"customer_response_text": text}).eq("id", order["id"]).execute()


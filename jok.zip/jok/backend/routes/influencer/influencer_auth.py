"""
Influencer Auth Routes
POST /api/v1/influencer/register    — Sign up as influencer
GET  /api/v1/influencer/me          — Get influencer profile
PUT  /api/v1/influencer/profile     — Update profile/payment details
GET  /api/v1/public/verify-ref/:code — Check if a ref code is valid (for signup page)
"""
from fastapi import APIRouter, HTTPException, Depends, Request, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
from loguru import logger

from config.database import get_db
from config.security import hash_password, generate_verification_token
from middleware.auth import get_current_user
from middleware.rate_limiter import limiter
from services.influencer_service import ensure_unique_ref_code
from services.email_service import send_verification_email
from utils.helpers import success_response
from utils.validators import validate_password_strength
from config.settings import settings

router = APIRouter(prefix="/api/v1/influencer", tags=["Influencer"])
public_router = APIRouter(prefix="/api/v1/public", tags=["Public"])


# ── Models ─────────────────────────────────────────────────────────────────────

class InfluencerRegisterRequest(BaseModel):
    email: str
    password: str
    name: str
    phone: Optional[str] = None
    social_handle: Optional[str] = None
    platform: Optional[str] = "instagram"   # youtube|instagram|twitter|tiktok|other
    follower_count: Optional[int] = 0
    niche: Optional[str] = "ecommerce"

class InfluencerProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    social_handle: Optional[str] = None
    platform: Optional[str] = None
    follower_count: Optional[int] = None
    niche: Optional[str] = None
    upi_id: Optional[str] = None
    bank_account_number: Optional[str] = None
    bank_ifsc: Optional[str] = None
    bank_account_name: Optional[str] = None


# ── Register as Influencer ──────────────────────────────────────────────────────

@router.post("/register")
@limiter.limit("5/minute")
async def register_influencer(request: Request, body: InfluencerRegisterRequest, background_tasks: BackgroundTasks):
    db = get_db()

    # Validate password
    errors = validate_password_strength(body.password)
    if errors:
        raise HTTPException(status_code=400, detail={"message": "Weak password", "errors": errors})

    # Check email not already used
    existing = db.table("users").select("id, role").eq("email", body.email.lower().strip()).execute()
    if existing.data:
        raise HTTPException(status_code=409, detail="Email already registered")

    import re
    phone_clean = re.sub(r'\s+', '', body.phone or "")
    if phone_clean and not re.match(r'^\+[1-9]\d{6,14}$', phone_clean):
        raise HTTPException(status_code=400, detail="Invalid phone number. Use international format: +91XXXXXXXXXX")

    # Generate verification token
    verification_token = generate_verification_token()

    # Create user with role = influencer
    user_data = {
        "email": body.email.lower().strip(),
        "password_hash": hash_password(body.password),
        "name": body.name,
        "phone": phone_clean or "",
        "role": "influencer",
        "status": "pending",   # pending until admin approves
        "is_influencer": True,
        "email_verification_token": verification_token,
        "email_verification_expires": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
    }
    user_result = db.table("users").insert(user_data).execute()
    user = user_result.data[0]
    user_id = user["id"]

    # Generate unique ref code
    ref_code = ensure_unique_ref_code(body.name)

    # Create influencer profile
    db.table("influencer_profiles").insert({
        "user_id": user_id,
        "ref_code": ref_code,
        "full_name": body.name,
        "social_handle": body.social_handle or "",
        "platform": body.platform or "instagram",
        "follower_count": body.follower_count or 0,
        "niche": body.niche or "ecommerce",
        "status": "pending",
        "wallet_balance": 0,
        "total_earned": 0,
        "total_leads": 0,
        "qualified_leads": 0,
    }).execute()

    # Send verification email
    def _send_verification():
        import asyncio
        try:
            link = f"{settings.FRONTEND_URL}/verify-email/{verification_token}"
            loop = asyncio.new_event_loop()
            loop.run_until_complete(send_verification_email(body.email, body.name, link))
            loop.close()
        except Exception as e:
            logger.warning(f"Influencer verification email failed: {e}")
    background_tasks.add_task(_send_verification)

    logger.info(f"✅ New influencer registered: {body.email} | ref_code={ref_code}")

    return success_response(
        {"user_id": user_id, "ref_code": ref_code},
        "Registration successful! Please verify your email. Your account will be reviewed by our team."
    )


# ── Get My Profile ──────────────────────────────────────────────────────────────

@router.get("/me")
async def get_influencer_profile(user: dict = Depends(get_current_user)):
    if user.get("role") != "influencer":
        raise HTTPException(status_code=403, detail="Influencer access only")

    db = get_db()
    profile_res = db.table("influencer_profiles").select("*").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Influencer profile not found")

    profile = profile_res.data[0]
    safe_user = {k: v for k, v in user.items() if k != "password_hash"}

    return success_response({**safe_user, "profile": profile})


# ── Update Profile / Payment Details ───────────────────────────────────────────

@router.put("/profile")
async def update_influencer_profile(body: InfluencerProfileUpdate, user: dict = Depends(get_current_user)):
    if user.get("role") != "influencer":
        raise HTTPException(status_code=403, detail="Influencer access only")

    db = get_db()
    updates = body.model_dump(exclude_unset=True, exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    updates["updated_at"] = datetime.now(timezone.utc).isoformat()
    db.table("influencer_profiles").update(updates).eq("user_id", user["id"]).execute()

    profile = db.table("influencer_profiles").select("*").eq("user_id", user["id"]).execute()
    return success_response(profile.data[0] if profile.data else {}, "Profile updated")


# ── Public: Verify Ref Code ────────────────────────────────────────────────────

@public_router.get("/verify-ref/{code}")
async def verify_ref_code(code: str):
    """Used by signup page to validate a referral code before submitting."""
    db = get_db()
    res = db.table("influencer_profiles").select("ref_code, full_name, status").eq("ref_code", code.upper().strip()).execute()
    if not res.data:
        return success_response({"valid": False, "influencer_name": None})

    profile = res.data[0]
    if profile.get("status") not in ("verified", "pending"):
        return success_response({"valid": False, "influencer_name": None})

    return success_response({
        "valid": True,
        "influencer_name": profile.get("full_name", ""),
    })

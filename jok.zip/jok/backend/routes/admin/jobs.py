from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta
from datetime import datetime, timezone, date

router = APIRouter(prefix="/api/v1/admin/jobs", tags=["Admin Jobs"])


# ── Models ─────────────────────────────────────────────────────────────────────

class JobRequest(BaseModel):
    title: str
    department: str
    location: str
    job_type: str = "Full-time"          # Full-time | Part-time | Remote | Contract
    experience_level: str = "Mid-level"  # Fresher | Junior | Mid-level | Senior | Lead
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    salary_currency: str = "INR"
    salary_disclosed: bool = True
    description: str                      # Rich HTML (Bold, H1, H2, lists etc.)
    requirements: Optional[str] = None
    benefits: Optional[str] = None
    how_to_apply: Optional[str] = None
    application_email: Optional[str] = None
    application_url: Optional[str] = None
    start_date: Optional[str] = None     # ISO date string YYYY-MM-DD
    end_date: Optional[str] = None       # Job auto-expires after this date
    is_active: bool = True
    is_featured: bool = False
    slots: int = 1                        # Number of openings


class UpdateJobRequest(BaseModel):
    title: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None
    job_type: Optional[str] = None
    experience_level: Optional[str] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    salary_currency: Optional[str] = None
    salary_disclosed: Optional[bool] = None
    description: Optional[str] = None
    requirements: Optional[str] = None
    benefits: Optional[str] = None
    how_to_apply: Optional[str] = None
    application_email: Optional[str] = None
    application_url: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    is_active: Optional[bool] = None
    is_featured: Optional[bool] = None
    slots: Optional[int] = None


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("")
async def list_jobs(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    department: Optional[str] = None,
    user: dict = Depends(get_current_admin)
):
    db = get_db()
    offset, lim = paginate_params(page, limit)
    query = db.table("jobs").select("*", count="exact")
    if status == "active":
        query = query.eq("is_active", True)
    elif status == "inactive":
        query = query.eq("is_active", False)
    if department:
        query = query.eq("department", department)
    result = query.order("created_at", desc=True).range(offset, offset + lim - 1).execute()
    # Add days_remaining to each
    jobs = []
    today = date.today().isoformat()
    for j in (result.data or []):
        j = dict(j)
        if j.get("end_date"):
            ed = j["end_date"][:10]
            if ed < today:
                j["expired"] = True
            else:
                from datetime import timedelta
                delta = date.fromisoformat(ed) - date.today()
                j["days_remaining"] = delta.days
        jobs.append(j)
    return success_response({"jobs": jobs, "pagination": pagination_meta(result.count or 0, page, limit)})


@router.post("")
async def create_job(body: JobRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    data = body.model_dump()
    data["created_at"] = datetime.now(timezone.utc).isoformat()
    data["updated_at"] = datetime.now(timezone.utc).isoformat()
    data["created_by"] = user["id"]
    result = db.table("jobs").insert(data).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create job")
    return success_response(result.data[0], "Job posting created successfully")


@router.put("/{job_id}")
async def update_job(job_id: str, body: UpdateJobRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No updates provided")
    updates["updated_at"] = datetime.now(timezone.utc).isoformat()
    db.table("jobs").update(updates).eq("id", job_id).execute()
    return success_response(message="Job updated successfully")


@router.delete("/{job_id}")
async def delete_job(job_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("jobs").delete().eq("id", job_id).execute()
    return success_response(message="Job deleted")


@router.post("/{job_id}/toggle")
async def toggle_job(job_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    existing = db.table("jobs").select("is_active").eq("id", job_id).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail="Job not found")
    new_state = not existing.data[0].get("is_active", False)
    db.table("jobs").update({"is_active": new_state, "updated_at": datetime.now(timezone.utc).isoformat()}).eq("id", job_id).execute()
    return success_response({"is_active": new_state}, "Job status toggled")


@router.post("/expire-old")
async def expire_old_jobs(user: dict = Depends(get_current_admin)):
    """Manually trigger expiry of jobs past end_date (scheduler also handles this)."""
    db = get_db()
    today = date.today().isoformat()
    result = db.table("jobs").select("id, title").eq("is_active", True).lt("end_date", today).execute()
    count = 0
    for j in (result.data or []):
        db.table("jobs").update({"is_active": False, "updated_at": datetime.now(timezone.utc).isoformat()}).eq("id", j["id"]).execute()
        count += 1
    return success_response({"expired": count}, f"{count} job(s) expired")


@router.get("/departments")
async def get_departments(user: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("jobs").select("department").execute()
    depts = list({j["department"] for j in (result.data or []) if j.get("department")})
    return success_response(sorted(depts))


@router.get("/template")
async def get_job_template(user: dict = Depends(get_current_admin)):
    """Returns a ready-made professional job description template."""
    return success_response({
        "template": {
            "title": "Senior Software Engineer",
            "department": "Engineering",
            "location": "Remote / Delhi NCR",
            "job_type": "Full-time",
            "experience_level": "Senior",
            "salary_min": 1200000,
            "salary_max": 2000000,
            "salary_currency": "INR",
            "salary_disclosed": True,
            "slots": 2,
            "description": """<h1>About This Role</h1>
<p>We are looking for a passionate and experienced <strong>Senior Software Engineer</strong> to join our growing engineering team at CODVerify. You will architect and build scalable features that process millions of orders across India's e-commerce ecosystem.</p>

<h2>What You'll Do</h2>
<ul>
  <li>Design and implement scalable backend services using Python / FastAPI</li>
  <li>Work closely with the product team to ship high-quality features</li>
  <li>Review code and mentor junior engineers</li>
  <li>Optimize database queries and API performance</li>
  <li>Own end-to-end delivery of features from design to deployment</li>
</ul>

<h2>Requirements</h2>
<ul>
  <li>4+ years of professional software development experience</li>
  <li>Strong proficiency in Python, FastAPI or Django</li>
  <li>Experience with PostgreSQL / Supabase</li>
  <li>Knowledge of REST APIs and webhooks</li>
  <li>Experience with Docker and CI/CD pipelines</li>
</ul>

<h2>Nice to Have</h2>
<ul>
  <li>Experience with WhatsApp Business API / Meta APIs</li>
  <li>Knowledge of e-commerce platforms (Shopify, WooCommerce)</li>
  <li>Prior startup experience</li>
</ul>

<h2>Benefits</h2>
<ul>
  <li>Competitive salary (₹12L – ₹20L per annum)</li>
  <li>Flexible remote-friendly work culture</li>
  <li>Health insurance for you and family</li>
  <li>Learning & development budget</li>
  <li>ESOPs for senior hires</li>
</ul>""",
            "requirements": "B.Tech / B.E. / MCA or equivalent. 4+ years experience.",
            "how_to_apply": "Send your resume and a brief cover letter to careers@codverify.tech with subject: [Role] — Your Name",
            "application_email": "careers@codverify.tech",
            "start_date": date.today().isoformat(),
            "end_date": None,
            "is_active": True,
            "is_featured": False,
        }
    })

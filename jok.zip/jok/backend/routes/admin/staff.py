"""Admin staff/worker management endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
from config.database import get_db
from config.security import get_password_hash
from middleware.auth import get_current_admin
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/admin/staff", tags=["Admin Staff"])


class CreateWorkerBody(BaseModel):
    name: str
    email: str
    password: str
    phone: Optional[str] = ""


@router.get("")
async def list_workers(user: dict = Depends(get_current_admin)):
    """Get all worker accounts with their stats."""
    db = get_db()
    now = datetime.now(timezone.utc)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()

    workers = db.table("users").select(
        "id, name, email, phone, status, duty_status, total_duty_seconds, "
        "current_duty_start, last_duty_change, created_at, last_login"
    ).eq("role", "worker").order("created_at", desc=True).execute()

    enriched = []
    for w in (workers.data or []):
        # Count today's verifications
        verifications = db.table("order_verifications").select(
            "id", count="exact"
        ).eq("worker_id", w["id"]).gte("created_at", today).execute()

        # Count today's chat sessions (all statuses)
        chats = db.table("chat_sessions").select(
            "id", count="exact"
        ).eq("assigned_worker_id", w["id"]).gte("created_at", today).execute()

        # Calculate current session if on duty
        current_session = 0
        if w.get("duty_status") == "on_duty" and w.get("current_duty_start"):
            try:
                start = datetime.fromisoformat(w["current_duty_start"].replace("Z", "+00:00"))
                current_session = int((now - start).total_seconds())
            except Exception:
                pass

        enriched.append({
            **w,
            "today_verifications": verifications.count or 0,
            "active_chats": chats.count or 0,
            "current_session_seconds": current_session,
        })

    return success_response({"workers": enriched})


@router.post("/create")
async def create_worker(body: CreateWorkerBody, user: dict = Depends(get_current_admin)):
    """Admin creates a new worker account."""
    db = get_db()

    # Check if email already exists
    existing = db.table("users").select("id").eq("email", body.email).execute()
    if existing.data:
        raise HTTPException(400, "Email already registered")

    worker = db.table("users").insert({
        "name": body.name,
        "email": body.email,
        "password_hash": get_password_hash(body.password),
        "phone": body.phone or "",
        "role": "worker",
        "status": "active",
        "duty_status": "off_duty",
        "total_duty_seconds": 0,
    }).execute()

    if not worker.data:
        raise HTTPException(500, "Failed to create worker")

    # NOTE: No verification email — admin-created workers are immediately active
    return success_response(
        {"worker": {k: v for k, v in worker.data[0].items() if k != "password_hash"}},
        "Worker account created — credentials set by admin"
    )


@router.delete("/{worker_id}")
async def delete_worker(worker_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("users").delete().eq("id", worker_id).eq("role", "worker").execute()
    return success_response(message="Worker removed")


@router.get("/{worker_id}/daily-logs")
async def get_worker_daily_logs(worker_id: str, user: dict = Depends(get_current_admin)):
    """Return per-day stats for a worker — last 30 days."""
    db = get_db()
    now = datetime.now(timezone.utc)

    # Validate worker exists
    w = db.table("users").select("id, name, email, phone, duty_status, total_duty_seconds, created_at").eq("id", worker_id).eq("role", "worker").execute()
    if not w.data:
        raise HTTPException(404, "Worker not found")

    # Build last 30 days of duty log entries
    thirty_days_ago = (now - timedelta(days=30)).replace(hour=0, minute=0, second=0, microsecond=0)
    logs = db.table("worker_duty_logs").select("action, created_at").eq("worker_id", worker_id).gte("created_at", thirty_days_ago.isoformat()).order("created_at", desc=False).execute()

    # Aggregate by day
    daily: dict = {}
    for log in (logs.data or []):
        try:
            dt = datetime.fromisoformat(log["created_at"].replace("Z", "+00:00"))
            day = dt.strftime("%Y-%m-%d")
            if day not in daily:
                daily[day] = {"date": day, "duty_seconds": 0, "sessions": 0, "status": []}
            daily[day]["status"].append(log["action"])
            if log["action"] in ("clock_in", "break_end"):
                daily[day]["sessions"] += 1
        except Exception:
            pass

    # Per-day verifications and chats
    daily_list = sorted(daily.values(), key=lambda x: x["date"], reverse=True)
    for day_data in daily_list:
        date_start = day_data["date"] + "T00:00:00+00:00"
        date_end = day_data["date"] + "T23:59:59+00:00"
        calls = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).gte("created_at", date_start).lte("created_at", date_end).execute()
        chats = db.table("chat_sessions").select("id", count="exact").eq("assigned_worker_id", worker_id).gte("created_at", date_start).lte("created_at", date_end).execute()
        day_data["calls"] = calls.count or 0
        day_data["chats"] = chats.count or 0
        # Remove internal status list
        del day_data["status"]

    # Also get overall stats
    total_calls = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).execute()
    total_chats = db.table("chat_sessions").select("id", count="exact").eq("assigned_worker_id", worker_id).execute()

    return success_response({
        "worker": w.data[0],
        "daily_logs": daily_list,
        "totals": {
            "total_calls": total_calls.count or 0,
            "total_chats": total_chats.count or 0,
            "total_duty_seconds": w.data[0].get("total_duty_seconds", 0),
            "active_days": len(daily_list),
        }
    })


# ─── Order Assignment Endpoints ────────────────────────────────────────────────

@router.get("/unassigned-orders")
async def get_unassigned_orders(user: dict = Depends(get_current_admin)):
    """Return COD orders that have no active worker claim."""
    db = get_db()

    orders_res = db.table("orders").select(
        "id, order_number, customer_name, customer_phone, order_amount, currency, "
        "verification_status, created_at, store_id"
    ).in_("verification_status", ["pending", "sent"]).order("created_at").execute()

    orders = orders_res.data or []
    if not orders:
        return success_response({"orders": [], "total": 0})

    order_ids = [o["id"] for o in orders]

    # Find which orders already have an active claimed entry
    claimed_res = db.table("order_verifications").select("order_id").eq(
        "call_status", "claimed"
    ).in_("order_id", order_ids).execute()
    claimed_ids = {c["order_id"] for c in (claimed_res.data or [])}

    unassigned = [o for o in orders if o["id"] not in claimed_ids]
    return success_response({"orders": unassigned, "total": len(unassigned)})


class AssignOrderBody(BaseModel):
    order_id: str
    worker_id: str


@router.post("/assign-order")
async def assign_order(body: AssignOrderBody, user: dict = Depends(get_current_admin)):
    """Admin assigns a COD order to a specific worker."""
    db = get_db()

    # Validate order exists
    order_res = db.table("orders").select("id").eq("id", body.order_id).execute()
    if not order_res.data:
        raise HTTPException(404, "Order not found")

    # Validate worker exists and is active
    worker_res = db.table("users").select("id, name").eq("id", body.worker_id).eq("role", "worker").eq("status", "active").execute()
    if not worker_res.data:
        raise HTTPException(404, "Worker not found or inactive")

    # Remove any existing claim for this order
    db.table("order_verifications").delete().eq("order_id", body.order_id).eq("call_status", "claimed").execute()

    # Fetch merchant_id for this order
    order_full = db.table("orders").select("user_id").eq("id", body.order_id).single().execute()
    merchant_id = (order_full.data or {}).get("user_id")

    # Insert new admin-assigned claim
    db.table("order_verifications").insert({
        "order_id": body.order_id,
        "worker_id": body.worker_id,
        "merchant_id": merchant_id,
        "call_status": "claimed",
        "call_notes": "[Admin assigned]",
        "call_duration_seconds": 0,
    }).execute()

    worker_name = worker_res.data[0]["name"]
    return success_response(message=f"Order assigned to {worker_name}")


@router.get("/assignments")
async def get_assignments(user: dict = Depends(get_current_admin)):
    """Return all current worker → order assignments."""
    db = get_db()

    claims_res = db.table("order_verifications").select(
        "order_id, worker_id, created_at"
    ).eq("call_status", "claimed").order("created_at", desc=True).execute()

    claims = claims_res.data or []
    if not claims:
        return success_response({"assignments": [], "total": 0})

    # Bulk-fetch orders and workers
    order_ids = list({c["order_id"] for c in claims})
    worker_ids = list({c["worker_id"] for c in claims if c.get("worker_id")})

    orders_res = db.table("orders").select(
        "id, order_number, customer_name, order_amount, currency, verification_status"
    ).in_("id", order_ids).execute()
    orders_map = {o["id"]: o for o in (orders_res.data or [])}

    workers_res = db.table("users").select(
        "id, name, duty_status"
    ).in_("id", worker_ids).execute()
    workers_map = {w["id"]: w for w in (workers_res.data or [])}

    assignments = []
    for c in claims:
        order = orders_map.get(c["order_id"], {})
        worker = workers_map.get(c["worker_id"], {})
        assignments.append({
            "order_id": c["order_id"],
            "order_number": order.get("order_number", "—"),
            "customer_name": order.get("customer_name", "—"),
            "order_amount": order.get("order_amount"),
            "currency": order.get("currency", "INR"),
            "verification_status": order.get("verification_status"),
            "worker_id": c["worker_id"],
            "worker_name": worker.get("name", "Unknown"),
            "worker_duty_status": worker.get("duty_status"),
            "assigned_at": c["created_at"],
        })

    return success_response({"assignments": assignments, "total": len(assignments)})

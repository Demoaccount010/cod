﻿"""
Admin Influencer Management Routes
GET    /api/v1/admin/influencers               â€” List all influencers
GET    /api/v1/admin/influencers/:id           â€” Get influencer details
PUT    /api/v1/admin/influencers/:id/approve   â€” Approve influencer
PUT    /api/v1/admin/influencers/:id/suspend   â€” Suspend influencer
GET    /api/v1/admin/influencers/leads         â€” All leads across influencers
GET    /api/v1/admin/influencers/withdrawals   â€” All withdrawal requests
PUT    /api/v1/admin/influencers/withdrawals/:id/process â€” Process withdrawal (approve/reject/manual-paid)
GET    /api/v1/admin/influencers/payout-config â€” Get payout tiers
PUT    /api/v1/admin/influencers/payout-config/:id â€” Update payout tier
POST   /api/v1/admin/influencers/payout-config â€” Add new payout tier
"""
from fastapi import APIRouter, HTTPException, Depends, Query, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from loguru import logger

from config.database import get_db
from middleware.auth import get_current_user
from services.influencer_service import process_razorpay_payout, credit_wallet
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/admin/influencers", tags=["Admin - Influencers"])


def _require_admin(user: dict):
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access only")


class InfluencerApproveBody(BaseModel):
    rejection_reason: Optional[str] = None

class PayoutTierBody(BaseModel):
    tier_label: str
    tier_min: int
    tier_max: Optional[int] = None
    lead_payout: float
    subscription_payout: float
    is_active: bool = True

class WithdrawalProcessBody(BaseModel):
    action: str  # approve | reject | manual_paid
    admin_notes: Optional[str] = None
    manual_payment_ref: Optional[str] = None  # UTR number for manual payment

class ManualCreditBody(BaseModel):
    amount: float
    description: str


# â”€â”€ List Influencers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("")
async def list_influencers(
    user: dict = Depends(get_current_user),
    status: str = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
):
    _require_admin(user)
    db = get_db()

    offset = (page - 1) * per_page
    query = (
        db.table("influencer_profiles")
        .select("""
            *,
            user:user_id(name, email, phone, created_at, status)
        """)
        .order("created_at", desc=True)
        .range(offset, offset + per_page - 1)
    )
    if status:
        query = query.eq("status", status)

    res = query.execute()

    count_q = db.table("influencer_profiles").select("id", count="exact")
    if status:
        count_q = count_q.eq("status", status)
    total = count_q.execute()

    return success_response({
        "influencers": res.data or [],
        "total": total.count or 0,
        "page": page,
        "per_page": per_page,
    })


# â”€â”€ All Leads (STATIC path â€” MUST be before /{influencer_id}) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/all/leads")
async def get_all_leads(
    user: dict = Depends(get_current_user),
    status: str = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
):
    _require_admin(user)
    db = get_db()

    offset = (page - 1) * per_page
    query = (
        db.table("influencer_leads")
        .select("""
            *,
            influencer:influencer_id(ref_code, full_name),
            merchant:merchant_id(name, email, company_name, phone)
        """)
        .order("created_at", desc=True)
        .range(offset, offset + per_page - 1)
    )
    if status:
        query = query.eq("status", status)

    res = query.execute()
    count_q = db.table("influencer_leads").select("id", count="exact")
    if status:
        count_q = count_q.eq("status", status)
    total = count_q.execute()

    return success_response({
        "leads": res.data or [],
        "total": total.count or 0,
        "page": page,
        "per_page": per_page,
    })


# â”€â”€ All Withdrawals (STATIC path â€” MUST be before /{influencer_id}) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/all/withdrawals")
async def get_all_withdrawals(
    user: dict = Depends(get_current_user),
    status: str = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
):
    _require_admin(user)
    db = get_db()

    offset = (page - 1) * per_page
    query = (
        db.table("influencer_withdrawals")
        .select("""
            *,
            influencer:influencer_id(ref_code, full_name, upi_id,
                user:user_id(name, email))
        """)
        .order("requested_at", desc=True)
        .range(offset, offset + per_page - 1)
    )
    if status:
        query = query.eq("status", status)

    res = query.execute()
    count_q = db.table("influencer_withdrawals").select("id", count="exact")
    if status:
        count_q = count_q.eq("status", status)
    total = count_q.execute()

    return success_response({
        "withdrawals": res.data or [],
        "total": total.count or 0,
        "page": page,
        "per_page": per_page,
    })


# â”€â”€ Process Withdrawal (STATIC path â€” MUST be before /{influencer_id}) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.put("/all/withdrawals/{withdrawal_id}/process")
async def process_withdrawal(
    withdrawal_id: str,
    body: WithdrawalProcessBody,
    background_tasks: BackgroundTasks,
    user: dict = Depends(get_current_user),
):
    _require_admin(user)
    db = get_db()

    wd_res = db.table("influencer_withdrawals").select("*").eq("id", withdrawal_id).execute()
    if not wd_res.data:
        raise HTTPException(status_code=404, detail="Withdrawal not found")
    wd = wd_res.data[0]

    now = datetime.now(timezone.utc).isoformat()

    if body.action == "approve":
        # Try Razorpay payout
        db.table("influencer_withdrawals").update({
            "status": "processing",
            "processed_by": user["id"],
            "admin_notes": body.admin_notes or "",
        }).eq("id", withdrawal_id).execute()

        async def _try_payout():
            await process_razorpay_payout(withdrawal_id)
        background_tasks.add_task(_try_payout)
        return success_response(message="Withdrawal approved. Razorpay payout initiated.")

    elif body.action == "reject":
        db.table("influencer_withdrawals").update({
            "status": "rejected",
            "processed_at": now,
            "processed_by": user["id"],
            "admin_notes": body.admin_notes or "",
        }).eq("id", withdrawal_id).execute()

        # Refund wallet balance
        credit_wallet(
            influencer_id=wd["influencer_id"],
            amount=float(wd["amount"]),
            payout_type="withdrawal_refund",
            description=f"Refund: withdrawal rejected \u2014 {body.admin_notes or 'No reason given'}",
        )
        return success_response(message="Withdrawal rejected and wallet refunded")

    elif body.action == "manual_paid":
        db.table("influencer_withdrawals").update({
            "status": "manual_paid",
            "is_manual_fallback": True,
            "manual_payment_ref": body.manual_payment_ref or "",
            "processed_at": now,
            "processed_by": user["id"],
            "admin_notes": body.admin_notes or "",
        }).eq("id", withdrawal_id).execute()

        # Deduct from wallet
        from services.influencer_service import _deduct_wallet
        _deduct_wallet(wd["influencer_id"], float(wd["amount"]))
        return success_response(message="Withdrawal marked as manually paid")

    else:
        raise HTTPException(status_code=400, detail="Invalid action. Use: approve | reject | manual_paid")


# â”€â”€ Payout Config (STATIC path â€” MUST be before /{influencer_id}) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/config/payout-tiers")
async def get_payout_tiers(user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()
    res = db.table("influencer_payout_config").select("*").order("tier_min").execute()
    return success_response(res.data or [])


@router.post("/config/payout-tiers")
async def add_payout_tier(body: PayoutTierBody, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()
    res = db.table("influencer_payout_config").insert({
        "tier_label": body.tier_label,
        "tier_min": body.tier_min,
        "tier_max": body.tier_max,
        "lead_payout": body.lead_payout,
        "subscription_payout": body.subscription_payout,
        "is_active": body.is_active,
    }).execute()
    return success_response(res.data[0] if res.data else {}, "Payout tier created")


@router.put("/config/payout-tiers/{tier_id}")
async def update_payout_tier(tier_id: str, body: PayoutTierBody, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()
    res = db.table("influencer_payout_config").update({
        "tier_label": body.tier_label,
        "tier_min": body.tier_min,
        "tier_max": body.tier_max,
        "lead_payout": body.lead_payout,
        "subscription_payout": body.subscription_payout,
        "is_active": body.is_active,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", tier_id).execute()
    return success_response(res.data[0] if res.data else {}, "Payout tier updated")


@router.delete("/config/payout-tiers/{tier_id}")
async def delete_payout_tier(tier_id: str, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()
    db.table("influencer_payout_config").delete().eq("id", tier_id).execute()
    return success_response(message="Payout tier deleted")


# â”€â”€ Get Single Influencer (DYNAMIC â€” keep at bottom) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/{influencer_id}")
async def get_influencer_detail(influencer_id: str, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("""
        *,
        user:user_id(name, email, phone, created_at, status)
    """).eq("id", influencer_id).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Influencer not found")

    # Leads
    leads_res = (
        db.table("influencer_leads")
        .select("*, merchant:merchant_id(name, email, company_name)")
        .eq("influencer_id", influencer_id)
        .order("created_at", desc=True)
        .limit(20)
        .execute()
    )

    # Withdrawals
    wd_res = (
        db.table("influencer_withdrawals")
        .select("*")
        .eq("influencer_id", influencer_id)
        .order("requested_at", desc=True)
        .limit(10)
        .execute()
    )

    return success_response({
        "profile": profile_res.data[0],
        "leads": leads_res.data or [],
        "withdrawals": wd_res.data or [],
    })


# â”€â”€ Approve Influencer â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.put("/{influencer_id}/approve")
async def approve_influencer(influencer_id: str, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()

    db.table("influencer_profiles").update({
        "status": "verified",
        "approved_by": user["id"],
        "approved_at": datetime.now(timezone.utc).isoformat(),
        "rejection_reason": None,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", influencer_id).execute()

    # Also activate the user account
    profile = db.table("influencer_profiles").select("user_id").eq("id", influencer_id).execute()
    if profile.data:
        db.table("users").update({"status": "active"}).eq("id", profile.data[0]["user_id"]).execute()

    logger.info(f"âœ… Admin {user['id']} approved influencer {influencer_id}")
    return success_response(message="Influencer approved and activated")


# â”€â”€ Suspend Influencer â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.put("/{influencer_id}/suspend")
async def suspend_influencer(influencer_id: str, body: InfluencerApproveBody, user: dict = Depends(get_current_user)):
    _require_admin(user)
    db = get_db()

    db.table("influencer_profiles").update({
        "status": "suspended",
        "rejection_reason": body.rejection_reason or "",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", influencer_id).execute()

    profile = db.table("influencer_profiles").select("user_id").eq("id", influencer_id).execute()
    if profile.data:
        db.table("users").update({"status": "suspended"}).eq("id", profile.data[0]["user_id"]).execute()

    return success_response(message="Influencer suspended")


# â”€â”€ Manual Credit â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.post("/{influencer_id}/credit")
async def manual_credit(influencer_id: str, body: ManualCreditBody, user: dict = Depends(get_current_user)):
    _require_admin(user)
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")

    credit_wallet(
        influencer_id=influencer_id,
        amount=body.amount,
        payout_type="manual_credit",
        description=f"Manual credit by admin: {body.description}",
    )
    return success_response(message=f"â‚¹{body.amount:,.2f} credited to influencer wallet")


"""Admin contract management endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone, timedelta
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response
from services.email_service import send_contract_notification_email, send_activation_invoice_email
from services.whatsapp_service import send_contract_activation_whatsapp
import asyncio
import uuid
from loguru import logger

router = APIRouter(prefix="/api/v1/admin/contracts", tags=["Admin Contracts"])


class ContractCreate(BaseModel):
    user_id: str
    type: str = "contract"  # contract | monthly
    services: list = []
    duration_months: int = 1
    total_amount: float = 0
    advance_amount: float = 0
    monthly_amount: float = 0
    currency: str = "INR"
    notes: Optional[str] = None
    chatbot_tier: Optional[str] = "none"  # none | chatbot_basic | chatbot_ai | chatbot_full
    payment_type: str = "one_time"  # one_time | emi | monthly_recurring
    auto_payment_enabled: bool = True  # Auto-deductions enabled?


class ContractUpdate(BaseModel):
    type: Optional[str] = None
    status: Optional[str] = None
    services: Optional[list] = None
    duration_months: Optional[int] = None
    total_amount: Optional[float] = None
    advance_amount: Optional[float] = None
    monthly_amount: Optional[float] = None
    currency: Optional[str] = None
    notes: Optional[str] = None
    chatbot_tier: Optional[str] = None
    payment_type: Optional[str] = None
    auto_payment_enabled: Optional[bool] = None


def gen_contract_number():
    now = datetime.now()
    return f"COD-{now.strftime('%Y%m')}-{uuid.uuid4().hex[:6].upper()}"


def gen_invoice_number():
    now = datetime.now()
    return f"INV-{now.strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"


def _enrich_contracts_with_users(db, contracts):
    """Fetch user data separately and merge into contracts (avoids PostgREST FK join issues)."""
    if not contracts:
        return contracts
    user_ids = list(set(c["user_id"] for c in contracts if c.get("user_id")))
    if not user_ids:
        return contracts
    users_res = db.table("users").select("id, name, email, company_name, account_status").in_("id", user_ids).execute()
    user_map = {u["id"]: u for u in (users_res.data or [])}
    for c in contracts:
        u = user_map.get(c.get("user_id"), {})
        c["user"] = {"name": u.get("name", "Unknown"), "email": u.get("email", ""), "company_name": u.get("company_name", "")}
    return contracts


# ── LIST ALL CONTRACTS ───────────────────────────────────────────────
@router.get("")
async def list_contracts(status: str = "", user_id: str = "", admin: dict = Depends(get_current_admin)):
    db = get_db()
    query = db.table("contracts").select("*").order("created_at", desc=True)
    if status:
        query = query.eq("status", status)
    if user_id:
        query = query.eq("user_id", user_id)
    result = query.limit(100).execute()
    contracts = _enrich_contracts_with_users(db, result.data or [])
    return success_response({"contracts": contracts})


# ── GET SINGLE CONTRACT ──────────────────────────────────────────────
@router.get("/{contract_id}")
async def get_contract(contract_id: str, admin: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("contracts").select("*").eq("id", contract_id).single().execute()
    if not result.data:
        raise HTTPException(404, "Contract not found")
    contract = result.data
    # Enrich with user data
    user_res = db.table("users").select("id, name, email, company_name, account_status").eq("id", contract["user_id"]).execute()
    contract["user"] = user_res.data[0] if user_res.data else {}
    # Get invoices for this contract
    invoices = db.table("invoices").select("*").eq("contract_id", contract_id).order("created_at", desc=True).execute()
    return success_response({"contract": contract, "invoices": invoices.data or []})


# ── CREATE CONTRACT ──────────────────────────────────────────────────
@router.post("")
async def create_contract(body: ContractCreate, admin: dict = Depends(get_current_admin)):
    db = get_db()

    # Verify user exists in public.users table
    user = db.table("users").select("id, name, email").eq("id", body.user_id).execute()
    if not user.data:
        raise HTTPException(404, "User not found in users table")

    remaining = body.total_amount - body.advance_amount
    
    # Calculate EMI schedule if payment_type is emi or monthly_recurring
    emi_schedule = []
    monthly_emi_amount = 0
    
    if body.payment_type == "emi" and body.duration_months > 0:
        # EMI: (Total - Advance) / Duration
        monthly_emi_amount = remaining / body.duration_months
        now = datetime.now(timezone.utc)
        for month in range(1, body.duration_months + 1):
            due_date = now + timedelta(days=30 * month)
            emi_schedule.append({
                "month": month,
                "amount": round(monthly_emi_amount, 2),
                "due_date": due_date.isoformat(),
                "paid_date": None,
                "status": "pending"  # pending | paid | failed
            })
    elif body.payment_type == "monthly_recurring":
        # Monthly recurring: Fixed amount per month for duration_months
        monthly_emi_amount = body.total_amount / body.duration_months if body.duration_months > 0 else body.total_amount
        now = datetime.now(timezone.utc)
        for month in range(1, body.duration_months + 1):
            due_date = now + timedelta(days=30 * month)
            emi_schedule.append({
                "month": month,
                "amount": round(monthly_emi_amount, 2),
                "due_date": due_date.isoformat(),
                "paid_date": None,
                "status": "pending"
            })
    
    contract_data = {
        "user_id": body.user_id,
        "contract_number": gen_contract_number(),
        "type": body.type,
        "status": "pending",
        "services": body.services,
        "duration_months": body.duration_months,
        "total_amount": body.total_amount,
        "advance_amount": body.advance_amount,
        "remaining_amount": max(0, remaining),
        "monthly_amount": body.monthly_amount or monthly_emi_amount,
        "currency": body.currency,
        "notes": body.notes,
        "chatbot_tier": body.chatbot_tier or "none",
        "payment_type": body.payment_type,
        "auto_payment_enabled": body.auto_payment_enabled,
        "emi_schedule": emi_schedule,
        "created_by": admin["id"],
    }

    try:
        result = db.table("contracts").insert(contract_data).execute()
    except Exception as e:
        error_msg = str(e)
        if "foreign key" in error_msg.lower() or "23503" in error_msg:
            raise HTTPException(400, f"Foreign key error: user_id '{body.user_id}' does not exist. Please run the FK fix migration.")
        raise HTTPException(500, f"Failed to create contract: {error_msg}")

    if not result.data:
        raise HTTPException(500, "Failed to create contract")

    created_contract = result.data[0]

    # Update user account_status to contract_pending
    db.table("users").update({"account_status": "contract_pending"}).eq("id", body.user_id).execute()

    # Send contract notification email to user
    try:
        user_info = user.data[0]
        asyncio.create_task(send_contract_notification_email(
            user_info["email"], user_info["name"], created_contract
        ))
    except Exception as e:
        pass  # Email failure should not block contract creation

    return success_response({"contract": created_contract}, message="Contract created successfully")


# ── UPDATE CONTRACT ──────────────────────────────────────────────────
@router.patch("/{contract_id}")
async def update_contract(contract_id: str, body: ContractUpdate, admin: dict = Depends(get_current_admin)):
    db = get_db()
    updates = {k: v for k, v in body.dict().items() if v is not None}
    if not updates:
        raise HTTPException(400, "No fields to update")
    updates["updated_at"] = datetime.now(timezone.utc).isoformat()

    # If status is being set to "active", activate the contract and user
    if updates.get("status") == "active":
        contract_res = db.table("contracts").select("*").eq("id", contract_id).single().execute()
        if contract_res.data:
            user_id = contract_res.data["user_id"]
            # Set start_date and end_date if not already set
            if not contract_res.data.get("start_date"):
                start = datetime.now(timezone.utc)
                duration = contract_res.data.get("duration_months", 1)
                updates["start_date"] = start.isoformat()
                updates["end_date"] = (start + timedelta(days=30 * duration)).isoformat()
                updates["accepted_at"] = start.isoformat()
            # Activate user account
            db.table("users").update({"account_status": "active"}).eq("id", user_id).execute()

            # Enable chatbot if contract includes a chatbot tier
            chatbot_tier = contract_res.data.get("chatbot_tier") or updates.get("chatbot_tier") or "none"
            if chatbot_tier and chatbot_tier != "none":
                try:
                    # Use upsert so it works even if the merchant never visited the chatbot page
                    db.table("merchant_chatbot_config").upsert({
                        "merchant_id": user_id,
                        "is_enabled": True,
                        "chatbot_tier": chatbot_tier,
                    }, on_conflict="merchant_id").execute()
                    logger.info(f"Chatbot enabled for user {user_id} with tier: {chatbot_tier}")
                except Exception as e:
                    logger.warning(f"Chatbot enable failed (non-critical): {e}")

            # Send activation invoice email + WhatsApp
            try:
                user_res = db.table("users").select("name, email, phone, company_name").eq("id", user_id).execute()
                if user_res.data:
                    full_contract = {**contract_res.data, **updates}
                    asyncio.create_task(send_activation_invoice_email(
                        user_res.data[0]["email"], user_res.data[0]["name"], full_contract
                    ))
                    # WhatsApp activation message
                    merchant_phone = user_res.data[0].get("phone", "")
                    if merchant_phone:
                        total_amt = float(full_contract.get("total_amount") or 0)
                        advance_amt = float(full_contract.get("advance_amount") or 0)
                        pending_amt = round(total_amt - advance_amt, 2) if total_amt > advance_amt else 0.0
                        asyncio.create_task(send_contract_activation_whatsapp(
                            merchant_phone=merchant_phone,
                            merchant_name=user_res.data[0].get("name", ""),
                            store_name=user_res.data[0].get("company_name") or user_res.data[0].get("name", ""),
                            contract_number=full_contract.get("contract_number", ""),
                            paid_amount=advance_amt,
                            pending_amount=pending_amt,
                            currency=full_contract.get("currency", "INR"),
                        ))
            except Exception:
                pass  # Email/WA failure should not block activation

    # Recalculate remaining if amounts changed
    if "total_amount" in updates or "advance_amount" in updates:
        contract = db.table("contracts").select("total_amount, advance_amount").eq("id", contract_id).single().execute()
        if contract.data:
            total = updates.get("total_amount", contract.data["total_amount"])
            advance = updates.get("advance_amount", contract.data["advance_amount"])
            updates["remaining_amount"] = max(0, total - advance)

    result = db.table("contracts").update(updates).eq("id", contract_id).execute()
    if not result.data:
        raise HTTPException(404, "Contract not found")
    return success_response({"contract": result.data[0]})


# ── DELETE CONTRACT ──────────────────────────────────────────────────
@router.delete("/{contract_id}")
async def delete_contract(contract_id: str, admin: dict = Depends(get_current_admin)):
    db = get_db()
    # Reset user account_status
    contract = db.table("contracts").select("user_id").eq("id", contract_id).execute()
    if not contract.data:
        raise HTTPException(404, "Contract not found or already deleted")
    db.table("users").update({"account_status": "pending_activation"}).eq("id", contract.data[0]["user_id"]).execute()

    db.table("contracts").delete().eq("id", contract_id).execute()
    return success_response(message="Contract deleted")


# ── LIST USERS FOR CONTRACT ASSIGNMENT ───────────────────────────────
@router.get("/users/available")
async def list_available_users(admin: dict = Depends(get_current_admin)):
    db = get_db()
    users = db.table("users").select("id, name, email, company_name, account_status, created_at").eq("role", "merchant").order("created_at", desc=True).limit(200).execute()
    return success_response({"users": users.data or []})


# ── LIST ALL INVOICES (admin billing overview) ───────────────────────
@router.get("/invoices/all")
async def list_all_invoices(status: str = "", admin: dict = Depends(get_current_admin)):
    db = get_db()
    query = db.table("invoices").select("*, contracts(contract_number, type)").order("created_at", desc=True)
    if status:
        query = query.eq("status", status)
    result = query.limit(200).execute()
    # Enrich with user data
    invoices = result.data or []
    if invoices:
        user_ids = list(set(inv["user_id"] for inv in invoices if inv.get("user_id")))
        if user_ids:
            users_res = db.table("users").select("id, name, email").in_("id", user_ids).execute()
            user_map = {u["id"]: u for u in (users_res.data or [])}
            for inv in invoices:
                u = user_map.get(inv.get("user_id"), {})
                inv["user"] = {"name": u.get("name", "Unknown"), "email": u.get("email", "")}
    return success_response({"invoices": invoices})


from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from config.security import create_access_token
from middleware.auth import get_current_admin
from models.admin import AdminMerchantStatusUpdate, AdminMerchantPlanUpdate, AdminAddCredits
from utils.helpers import success_response, paginate_params, pagination_meta
from services.notification_service import create_notification

router = APIRouter(prefix="/api/v1/admin/merchants", tags=["Admin Merchants"])


@router.get("")
async def list_merchants(
    page: int = 1, limit: int = 20, status: str = None, plan: str = None,
    search: str = None, sort_by: str = "created_at", sort_order: str = "desc",
    user: dict = Depends(get_current_admin)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("users").select("id, email, name, phone, company_name, status, role, created_at, last_login", count="exact").eq("role", "merchant")
    if status:
        query = query.eq("status", status)
    if search:
        query = query.or_(f"name.ilike.%{search}%,email.ilike.%{search}%,company_name.ilike.%{search}%")
    result = query.order(sort_by, desc=(sort_order == "desc")).range(offset, offset + limit - 1).execute()

    merchants = result.data or []
    if merchants:
        merchant_ids = [m["id"] for m in merchants]

        # Batch fetch all subscriptions in 1 query (instead of N queries)
        subs_result = db.table("service_subscriptions") \
            .select("user_id, plan_type, plan_name, used_quota, monthly_quota") \
            .in_("user_id", merchant_ids).eq("status", "active").execute()
        subs_map = {s["user_id"]: s for s in (subs_result.data or [])}

        # Batch fetch all order counts in 1 query
        orders_result = db.table("orders").select("user_id", count="exact") \
            .in_("user_id", merchant_ids).execute()
        # Count per merchant from returned data
        orders_map: dict = {}
        for o in (orders_result.data or []):
            uid = o.get("user_id")
            orders_map[uid] = orders_map.get(uid, 0) + 1

        for m in merchants:
            m["subscription"] = subs_map.get(m["id"])
            m["total_orders"] = orders_map.get(m["id"], 0)

    return success_response({"merchants": merchants, "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/{merchant_id}")
async def get_merchant(merchant_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    m = db.table("users").select("*").eq("id", merchant_id).eq("role", "merchant").execute()
    if not m.data:
        raise HTTPException(status_code=404, detail="Merchant not found")
    data = {k: v for k, v in m.data[0].items() if k != "password_hash"}

    data["stores"] = (db.table("stores").select("*").eq("user_id", merchant_id).execute()).data or []
    data["subscription"] = (db.table("service_subscriptions").select("*").eq("user_id", merchant_id).eq("status", "active").order("created_at", desc=True).limit(1).execute()).data
    data["recent_orders"] = (db.table("orders").select("*").eq("user_id", merchant_id).order("created_at", desc=True).limit(10).execute()).data or []
    data["billing"] = (db.table("billing_transactions").select("*").eq("user_id", merchant_id).order("created_at", desc=True).limit(10).execute()).data or []
    data["contracts"] = (db.table("contracts").select("id, contract_number, status, type, total_amount, wallet_credit_amount, created_at, start_date, end_date").eq("user_id", merchant_id).order("created_at", desc=True).limit(5).execute()).data or []
    # ── Wallet data ──
    from services import wallet_service
    data["wallet"] = await wallet_service.get_or_create_wallet(db, merchant_id)
    data["wallet_transactions"] = await wallet_service.get_transactions(db, merchant_id, limit=20)
    return success_response(data)


@router.put("/{merchant_id}/status")
async def update_status(merchant_id: str, body: AdminMerchantStatusUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("users").update({"status": body.status}).eq("id", merchant_id).execute()
    await create_notification(merchant_id, f"Account {body.status}", body.reason or f"Your account has been {body.status}.", "warning", "account")
    db.table("activity_logs").insert({"user_id": user["id"], "action": f"merchant_status_{body.status}", "entity_type": "user", "entity_id": merchant_id, "details_json": {"reason": body.reason}}).execute()
    return success_response(message=f"Merchant {body.status}")


@router.put("/{merchant_id}/plan")
async def update_plan(merchant_id: str, body: AdminMerchantPlanUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = {"plan_type": body.plan_type}
    if body.monthly_quota:
        updates["monthly_quota"] = body.monthly_quota
    if body.end_date:
        updates["end_date"] = body.end_date
    db.table("service_subscriptions").update(updates).eq("user_id", merchant_id).eq("status", "active").execute()
    return success_response(message="Plan updated")


@router.post("/{merchant_id}/impersonate")
async def impersonate(merchant_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    m = db.table("users").select("id, role").eq("id", merchant_id).execute()
    if not m.data:
        raise HTTPException(status_code=404, detail="Merchant not found")
    token = create_access_token({"sub": merchant_id, "role": "merchant", "impersonating": True, "admin_id": user["id"]})
    db.table("activity_logs").insert({"user_id": user["id"], "action": "impersonate_merchant", "entity_type": "user", "entity_id": merchant_id}).execute()
    return success_response({"access_token": token, "token_type": "bearer"}, "Impersonation token generated")


@router.post("/{merchant_id}/add-credits")
async def add_credits(merchant_id: str, body: AdminAddCredits, user: dict = Depends(get_current_admin)):
    db = get_db()
    sub = db.table("service_subscriptions").select("*").eq("user_id", merchant_id).eq("status", "active").order("created_at", desc=True).limit(1).execute()
    if sub.data:
        db.table("service_subscriptions").update({"monthly_quota": sub.data[0]["monthly_quota"] + body.extra_quota}).eq("id", sub.data[0]["id"]).execute()
    await create_notification(merchant_id, "Extra Credits Added", f"{body.extra_quota} extra orders added to your quota.", "success", "billing")
    return success_response(message=f"Added {body.extra_quota} credits")


# ── ADMIN: WALLET ADJUSTMENT (direct credit / debit) ────────────────────────────
from pydantic import BaseModel as _BM

class WalletAdjustBody(_BM):
    type: str            # 'credit' | 'debit'
    amount: float
    reason: str = "Admin adjustment"


@router.put("/{merchant_id}/wallet")
async def admin_adjust_wallet(
    merchant_id: str,
    body: WalletAdjustBody,
    user: dict = Depends(get_current_admin),
):
    """
    Admin directly credits or debits a merchant's wallet.
    Useful for corrections, refunds, or manual top-ups.
    """
    from services import wallet_service
    from loguru import logger

    db = get_db()
    if body.amount <= 0:
        raise HTTPException(400, "Amount must be positive")
    if body.type not in ("credit", "debit"):
        raise HTTPException(400, "type must be 'credit' or 'debit'")

    # Verify merchant exists
    m = db.table("users").select("id, name").eq("id", merchant_id).execute()
    if not m.data:
        raise HTTPException(404, "Merchant not found")

    if body.type == "credit":
        updated_wallet = await wallet_service.credit_wallet(
            db,
            user_id=merchant_id,
            amount=body.amount,
            description=f"[Admin Adjustment] {body.reason}",
            reference_id=f"admin_{user['id'][:8]}",
            service_key="admin_adjustment",
        )
    else:
        updated_wallet = await wallet_service.debit_wallet(
            db,
            user_id=merchant_id,
            amount=body.amount,
            service_key="admin_adjustment",
            description=f"[Admin Adjustment] {body.reason}",
            reference_id=f"admin_{user['id'][:8]}",
        )

    logger.info(f"Admin {user['id']} {body.type}ed ₹{body.amount} {'to' if body.type == 'credit' else 'from'} merchant {merchant_id}: {body.reason}")
    await create_notification(
        merchant_id,
        f"Wallet {'Credited' if body.type == 'credit' else 'Adjusted'} by Admin",
        f"₹{body.amount:.2f} has been {'added to' if body.type == 'credit' else 'deducted from'} your wallet. Reason: {body.reason}",
        "success" if body.type == "credit" else "warning", "billing"
    )
    return success_response({"wallet": updated_wallet}, f"Wallet {body.type}ed successfully")


@router.post("/{merchant_id}/enable-chatbot")
async def enable_chatbot(merchant_id: str, user: dict = Depends(get_current_admin)):
    """Force-enable chatbot for a merchant (admin override)."""
    db = get_db()
    existing = db.table("merchant_chatbot_config").select("id").eq("merchant_id", merchant_id).execute()
    if existing.data:
        db.table("merchant_chatbot_config").update({"is_enabled": True}).eq("merchant_id", merchant_id).execute()
    else:
        db.table("merchant_chatbot_config").insert({"merchant_id": merchant_id, "is_enabled": True}).execute()
    return success_response(message="Chatbot enabled for merchant")


@router.delete("/{merchant_id}")
async def delete_merchant(merchant_id: str, user: dict = Depends(get_current_admin)):
    """Permanently delete a merchant and all associated data."""
    db = get_db()

    # Verify merchant exists
    m = db.table("users").select("id, role, shopify_shop_domain").eq("id", merchant_id).execute()
    if not m.data or m.data[0].get("role") != "merchant":
        raise HTTPException(status_code=404, detail="Merchant not found")

    shop_domain = m.data[0].get("shopify_shop_domain")

    # ── Step 1: Delete order child records ──────────────────────────────────
    orders_res = db.table("orders").select("id").eq("user_id", merchant_id).execute()
    order_ids = [o["id"] for o in (orders_res.data or [])]
    if order_ids:
        try:
            db.table("order_verifications").delete().in_("order_id", order_ids).execute()
        except Exception:
            pass

    # ── Step 2: Delete chatbot_api_usage first (FK → chat_sessions) ────────
    # CRITICAL: chatbot_api_usage.session_id → chat_sessions.id
    # Must delete BEFORE chat_sessions, otherwise chat_sessions delete will fail.
    try:
        db.table("chatbot_api_usage").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # ── Step 3: Delete chat_messages (FK → chat_sessions) ──────────────────
    chat_sessions_res = db.table("chat_sessions").select("id").eq("merchant_id", merchant_id).execute()
    chat_session_ids = [s["id"] for s in (chat_sessions_res.data or [])]
    if chat_session_ids:
        try:
            db.table("chat_messages").delete().in_("session_id", chat_session_ids).execute()
        except Exception:
            pass

    # ── Step 4: Delete chat_sessions (FK → users.id via merchant_id) ───────
    # Now safe because chatbot_api_usage and chat_messages are gone
    try:
        db.table("chat_sessions").delete().eq("merchant_id", merchant_id).execute()
    except Exception as e:
        # Log but continue — if it fails here the users delete will also fail below
        import traceback
        traceback.print_exc()

    # ── Step 5: Delete callback_requests ────────────────────────────────────
    try:
        db.table("callback_requests").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # ── Step 6: (No separate workers table — workers are in users table with role='worker') ──

    # ── Step 7: Delete all other merchant-scoped tables ─────────────────────
    for table, col in [
        ("orders",                   "user_id"),
        ("stores",                   "user_id"),
        ("billing_transactions",     "user_id"),
        ("api_keys",                 "user_id"),
        ("merchant_settings",        "user_id"),
        ("merchant_blacklist",       "user_id"),
        ("contract_blacklist",       "merchant_id"),
        ("message_templates",        "user_id"),
        ("service_subscriptions",    "user_id"),
        ("contracts",                "user_id"),
        ("notifications",            "user_id"),
        ("support_tickets",          "user_id"),
        ("refresh_tokens",           "user_id"),
        ("activity_logs",            "user_id"),
        ("merchant_chatbot_config",  "merchant_id"),
        ("webhook_logs",             "user_id"),
        ("shopify_install_keys",     "linked_user_id"),
    ]:
        try:
            db.table(table).delete().eq(col, merchant_id).execute()
        except Exception:
            pass

    # ── Step 8: Unlink Shopify install key (if applicable) ──────────────────
    if shop_domain:
        try:
            db.table("shopify_install_keys").update({
                "is_used": False,
                "linked_user_id": None,
                "linked_at": None,
            }).eq("shop_domain", shop_domain).execute()
        except Exception:
            pass

    # ── Step 9: Finally delete the user ─────────────────────────────────────
    db.table("users").delete().eq("id", merchant_id).execute()

    # Log the admin action (use try/except so log failure doesn't break success response)
    try:
        db.table("activity_logs").insert({
            "user_id": user["id"],
            "action": "delete_merchant",
            "entity_type": "user",
            "entity_id": merchant_id,
        }).execute()
    except Exception:
        pass

    return success_response(message="Merchant and all associated data permanently deleted")


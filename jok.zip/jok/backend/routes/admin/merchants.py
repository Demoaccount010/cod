from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from config.security import create_access_token
from middleware.auth import get_current_admin
from models.admin import AdminMerchantStatusUpdate, AdminMerchantPlanUpdate, AdminAddCredits
from utils.helpers import success_response, paginate_params, pagination_meta
from services.notification_service import create_notification

router = APIRouter(prefix="/api/v1/admin/merchants", tags=["Admin Merchants"])


@router.get("")
async def list_merchants(
    page: int = 1, limit: int = 20, status: str = None, plan: str = None,
    search: str = None, sort_by: str = "created_at", sort_order: str = "desc",
    user: dict = Depends(get_current_admin)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("users").select("id, email, name, phone, company_name, status, role, created_at, last_login", count="exact").eq("role", "merchant")
    if status:
        query = query.eq("status", status)
    if search:
        query = query.or_(f"name.ilike.%{search}%,email.ilike.%{search}%,company_name.ilike.%{search}%")
    result = query.order(sort_by, desc=(sort_order == "desc")).range(offset, offset + limit - 1).execute()

    merchants = result.data or []
    if merchants:
        merchant_ids = [m["id"] for m in merchants]

        # Batch fetch all subscriptions in 1 query (instead of N queries)
        subs_result = db.table("service_subscriptions") \
            .select("user_id, plan_type, plan_name, used_quota, monthly_quota") \
            .in_("user_id", merchant_ids).eq("status", "active").execute()
        subs_map = {s["user_id"]: s for s in (subs_result.data or [])}

        # Batch fetch all order counts in 1 query
        orders_result = db.table("orders").select("user_id", count="exact") \
            .in_("user_id", merchant_ids).execute()
        # Count per merchant from returned data
        orders_map: dict = {}
        for o in (orders_result.data or []):
            uid = o.get("user_id")
            orders_map[uid] = orders_map.get(uid, 0) + 1

        for m in merchants:
            m["subscription"] = subs_map.get(m["id"])
            m["total_orders"] = orders_map.get(m["id"], 0)

    return success_response({"merchants": merchants, "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/{merchant_id}")
async def get_merchant(merchant_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    m = db.table("users").select("*").eq("id", merchant_id).eq("role", "merchant").execute()
    if not m.data:
        raise HTTPException(status_code=404, detail="Merchant not found")
    data = {k: v for k, v in m.data[0].items() if k != "password_hash"}

    data["stores"] = (db.table("stores").select("*").eq("user_id", merchant_id).execute()).data or []
    data["subscription"] = (db.table("service_subscriptions").select("*").eq("user_id", merchant_id).eq("status", "active").order("created_at", desc=True).limit(1).execute()).data
    data["recent_orders"] = (db.table("orders").select("*").eq("user_id", merchant_id).order("created_at", desc=True).limit(10).execute()).data or []
    data["billing"] = (db.table("billing_transactions").select("*").eq("user_id", merchant_id).order("created_at", desc=True).limit(10).execute()).data or []
    return success_response(data)


@router.put("/{merchant_id}/status")
async def update_status(merchant_id: str, body: AdminMerchantStatusUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("users").update({"status": body.status}).eq("id", merchant_id).execute()
    await create_notification(merchant_id, f"Account {body.status}", body.reason or f"Your account has been {body.status}.", "warning", "account")
    db.table("activity_logs").insert({"user_id": user["id"], "action": f"merchant_status_{body.status}", "entity_type": "user", "entity_id": merchant_id, "details_json": {"reason": body.reason}}).execute()
    return success_response(message=f"Merchant {body.status}")


@router.put("/{merchant_id}/plan")
async def update_plan(merchant_id: str, body: AdminMerchantPlanUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = {"plan_type": body.plan_type}
    if body.monthly_quota:
        updates["monthly_quota"] = body.monthly_quota
    if body.end_date:
        updates["end_date"] = body.end_date
    db.table("service_subscriptions").update(updates).eq("user_id", merchant_id).eq("status", "active").execute()
    return success_response(message="Plan updated")


@router.post("/{merchant_id}/impersonate")
async def impersonate(merchant_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    m = db.table("users").select("id, role").eq("id", merchant_id).execute()
    if not m.data:
        raise HTTPException(status_code=404, detail="Merchant not found")
    token = create_access_token({"sub": merchant_id, "role": "merchant", "impersonating": True, "admin_id": user["id"]})
    db.table("activity_logs").insert({"user_id": user["id"], "action": "impersonate_merchant", "entity_type": "user", "entity_id": merchant_id}).execute()
    return success_response({"access_token": token, "token_type": "bearer"}, "Impersonation token generated")


@router.post("/{merchant_id}/add-credits")
async def add_credits(merchant_id: str, body: AdminAddCredits, user: dict = Depends(get_current_admin)):
    db = get_db()
    sub = db.table("service_subscriptions").select("*").eq("user_id", merchant_id).eq("status", "active").order("created_at", desc=True).limit(1).execute()
    if sub.data:
        db.table("service_subscriptions").update({"monthly_quota": sub.data[0]["monthly_quota"] + body.extra_quota}).eq("id", sub.data[0]["id"]).execute()
    await create_notification(merchant_id, "Extra Credits Added", f"{body.extra_quota} extra orders added to your quota.", "success", "billing")
    return success_response(message=f"Added {body.extra_quota} credits")


@router.post("/{merchant_id}/enable-chatbot")
async def enable_chatbot(merchant_id: str, user: dict = Depends(get_current_admin)):
    """Force-enable chatbot for a merchant (admin override)."""
    db = get_db()
    existing = db.table("merchant_chatbot_config").select("id").eq("merchant_id", merchant_id).execute()
    if existing.data:
        db.table("merchant_chatbot_config").update({"is_enabled": True}).eq("merchant_id", merchant_id).execute()
    else:
        db.table("merchant_chatbot_config").insert({"merchant_id": merchant_id, "is_enabled": True}).execute()
    return success_response(message="Chatbot enabled for merchant")


@router.delete("/{merchant_id}")
async def delete_merchant(merchant_id: str, user: dict = Depends(get_current_admin)):
    """Permanently delete a merchant and all associated data."""
    db = get_db()

    # Verify merchant exists
    m = db.table("users").select("id, role").eq("id", merchant_id).execute()
    if not m.data or m.data[0].get("role") != "merchant":
        raise HTTPException(status_code=404, detail="Merchant not found")

    # 1. Get all order IDs for this merchant (to cascade into child tables)
    orders_res = db.table("orders").select("id").eq("user_id", merchant_id).execute()
    order_ids = [o["id"] for o in (orders_res.data or [])]

    # 2. Delete order child records
    if order_ids:
        db.table("order_verifications").delete().in_("order_id", order_ids).execute()

    # 2b. Delete chat_messages for all chat sessions belonging to this merchant
    chat_sessions_res = db.table("chat_sessions").select("id").eq("merchant_id", merchant_id).execute()
    chat_session_ids = [s["id"] for s in (chat_sessions_res.data or [])]
    if chat_session_ids:
        db.table("chat_messages").delete().in_("session_id", chat_session_ids).execute()

    # 2c. Explicitly delete chat_sessions NOW (before the loop) to avoid FK violation on users
    try:
        db.table("chat_sessions").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # 2d. Delete worker-related data (workers table references merchant_id → users)
    try:
        db.table("workers").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # 2e. Delete all callback requests
    try:
        db.table("callback_requests").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # 2f. Delete chatbot API usage
    try:
        db.table("chatbot_api_usage").delete().eq("merchant_id", merchant_id).execute()
    except Exception:
        pass

    # 3. Delete all merchant-scoped table data
    for table, col in [
        ("orders",                   "user_id"),
        ("stores",                   "user_id"),
        ("billing_transactions",     "user_id"),
        ("api_keys",                 "user_id"),
        ("merchant_settings",        "user_id"),
        ("merchant_blacklist",       "user_id"),
        ("contract_blacklist",       "merchant_id"),
        ("message_templates",        "user_id"),
        ("service_subscriptions",    "user_id"),
        ("contracts",                "user_id"),
        ("notifications",            "user_id"),
        ("support_tickets",          "user_id"),
        ("refresh_tokens",           "user_id"),
        ("activity_logs",            "user_id"),
        ("merchant_chatbot_config",  "merchant_id"),
        ("webhook_logs",             "user_id"),
    ]:
        try:
            db.table(table).delete().eq(col, merchant_id).execute()
        except Exception:
            pass  # Table may not exist or FK already handled

    # 4. Invalidate any shopify install keys for this merchant's shop domain
    shopify_info = db.table("users").select("shopify_shop_domain").eq("id", merchant_id).execute()
    if shopify_info.data and shopify_info.data[0].get("shopify_shop_domain"):
        shop_domain = shopify_info.data[0]["shopify_shop_domain"]
        db.table("shopify_install_keys").update({
            "is_used": False,
            "linked_user_id": None,
            "linked_at": None,
        }).eq("shop_domain", shop_domain).execute()

    # 5. Finally delete the user account itself
    db.table("users").delete().eq("id", merchant_id).execute()

    db.table("activity_logs").insert({
        "user_id": user["id"],
        "action": "delete_merchant",
        "entity_type": "user",
        "entity_id": merchant_id,
    }).execute()

    return success_response(message="Merchant and all associated data permanently deleted")

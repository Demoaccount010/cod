"""
Admin Integrations API — Manage Groq, SMTP from Admin Dashboard
All credentials stored in admin_settings table (encrypted where needed)
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response
from utils.encryption import encrypt_value, decrypt_value
from services.email_service import _send_email_async, _is_configured as _email_configured
from services.groq_service import test_groq_connection

router = APIRouter(prefix="/api/v1/admin/integrations", tags=["Admin Integrations"])


# ─── Models ───────────────────────────────────────────────────────
class GroqConfig(BaseModel):
    api_key: str
    model: str = "llama-3.1-8b-instant"
    temperature: float = Field(0.3, ge=0.0, le=1.0)
    enabled: bool = True
    system_prompt: Optional[str] = None


class SMTPConfig(BaseModel):
    host: str
    port: int = Field(587, ge=25, le=65535)
    user: str
    password: str
    from_email: str
    from_name: str = "CODVerify"
    enabled: bool = True


class TestEmailRequest(BaseModel):
    to_email: str


# ─── Get all integration statuses ────────────────────────────────

@router.get("/status")
async def get_integration_status(admin: dict = Depends(get_current_admin)):
    """Get current status of all integrations"""
    db = get_db()
    result = db.table("admin_settings").select("*").limit(1).execute()
    row = result.data[0] if result.data else {}

    return success_response({
        "groq": {
            "enabled": row.get("groq_enabled", False),
            "configured": bool(row.get("groq_api_key")),
            "model": row.get("groq_model", "llama-3.1-8b-instant"),
            "temperature": row.get("groq_temperature", 0.3),
            "system_prompt": row.get("groq_system_prompt", ""),
        },
        "smtp": {
            "enabled": row.get("smtp_enabled", False),
            "configured": bool(row.get("smtp_host") and row.get("smtp_user")),
            "host": row.get("smtp_host", ""),
            "port": row.get("smtp_port", 587),
            "from_email": row.get("smtp_from_email", ""),
            "from_name": row.get("smtp_from_name", "CODVerify"),
        },
    })


# ─── Groq ─────────────────────────────────────────────────────────

@router.post("/groq")
async def save_groq_config(body: GroqConfig, admin: dict = Depends(get_current_admin)):
    """Save Groq API configuration"""
    db = get_db()
    _ensure_admin_settings(db)
    
    update_data = {
        "groq_api_key": body.api_key,
        "groq_model": body.model,
        "groq_temperature": body.temperature,
        "groq_enabled": body.enabled,
    }
    if body.system_prompt:
        update_data["groq_system_prompt"] = body.system_prompt
    
    db.table("admin_settings").update(update_data).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Groq configuration saved")


@router.post("/groq/test")
async def test_groq(admin: dict = Depends(get_current_admin)):
    result = await test_groq_connection()
    if result["success"]:
        return success_response(result, "Groq connection successful")
    raise HTTPException(status_code=400, detail=result.get("error", "Groq test failed"))


# ─── SMTP Email ────────────────────────────────────────────────────

@router.post("/smtp")
async def save_smtp_config(body: SMTPConfig, admin: dict = Depends(get_current_admin)):
    """Save SMTP email configuration"""
    db = get_db()
    _ensure_admin_settings(db)
    
    # Encrypt password
    encrypted_pass = encrypt_value(body.password) if body.password else ""
    
    db.table("admin_settings").update({
        "smtp_host": body.host,
        "smtp_port": body.port,
        "smtp_user": body.user,
        "smtp_password": encrypted_pass,
        "smtp_from_email": body.from_email,
        "smtp_from_name": body.from_name,
        "smtp_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    
    return success_response(message="SMTP configuration saved")


@router.post("/smtp/test")
async def test_smtp(admin: dict = Depends(get_current_admin)):
    """Test email webhook connection"""
    if not _email_configured():
        raise HTTPException(status_code=400, detail="EMAIL_WEBHOOK_URL not set in environment")
    return success_response({"configured": True}, "Email webhook is configured")


@router.post("/smtp/send-test")
async def send_test_email(body: TestEmailRequest, admin: dict = Depends(get_current_admin)):
    """Send a test email to verify SMTP config"""
    try:
        _send_email_async(
            body.to_email,
            "CODVerify — Email Test",
            "<h2>✅ Email webhook is working!</h2><p>This is a test email from your CODVerify admin dashboard.</p>"
        )
        return success_response(message=f"Test email sent to {body.to_email}")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ─── Pricing per country ────────────────────────────────────────── 

class CountryPricing(BaseModel):
    india_whatsapp_rate: float = Field(1.0, description="INR per WhatsApp verification")
    india_chatbot_rate: float = Field(0.5, description="INR per Groq chatbot conversation")
    usa_sms_rate: float = Field(0.08, description="USD per SMS verification")
    usa_voice_rate_per_min: float = Field(0.14, description="USD per voice call minute")
    usa_chatbot_rate: float = Field(0.02, description="USD per Groq chatbot conversation")
    int_sms_rate: float = Field(0.10, description="USD per SMS for international")


@router.get("/pricing")
async def get_pricing_config(admin: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("admin_settings").select(
        "india_whatsapp_rate, india_chatbot_rate, usa_sms_rate, usa_voice_rate_per_min, usa_chatbot_rate, int_sms_rate"
    ).limit(1).execute()
    row = result.data[0] if result.data else {}
    return success_response({
        "india_whatsapp_rate": row.get("india_whatsapp_rate", 1.0),
        "india_chatbot_rate": row.get("india_chatbot_rate", 0.5),
        "usa_sms_rate": row.get("usa_sms_rate", 0.08),
        "usa_voice_rate_per_min": row.get("usa_voice_rate_per_min", 0.14),
        "usa_chatbot_rate": row.get("usa_chatbot_rate", 0.02),
        "int_sms_rate": row.get("int_sms_rate", 0.10),
    })



@router.put("/pricing")
async def update_pricing_config(body: CountryPricing, admin: dict = Depends(get_current_admin)):
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update(body.model_dump()).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Pricing updated")


# ─── Payment Gateways ─────────────────────────────────────────────


class RazorpayConfig(BaseModel):
    key_id: str
    key_secret: str
    enabled: bool = True


class StripeConfig(BaseModel):
    secret_key: str
    publishable_key: str
    webhook_secret: str = ""
    enabled: bool = True


@router.get("/payment-gateways")
async def get_payment_gateways(admin: dict = Depends(get_current_admin)):
    """Get configured payment gateways (keys masked)."""
    from config.settings import settings
    return success_response({
        "razorpay": {
            "enabled": bool(settings.RAZORPAY_KEY_ID),
            "configured": bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET),
            "key_id": settings.RAZORPAY_KEY_ID[:8] + "..." if settings.RAZORPAY_KEY_ID else "",
        },
        "stripe": {
            "enabled": bool(settings.STRIPE_SECRET_KEY),
            "configured": bool(settings.STRIPE_SECRET_KEY and settings.STRIPE_PUBLISHABLE_KEY),
            "publishable_key": settings.STRIPE_PUBLISHABLE_KEY,
            "mode": "live" if (settings.STRIPE_SECRET_KEY and not settings.STRIPE_SECRET_KEY.startswith("sk_test")) else "test",
        },
    })


@router.post("/razorpay")
async def save_razorpay(body: RazorpayConfig, admin: dict = Depends(get_current_admin)):
    """
    Save Razorpay credentials.
    NOTE: These are saved into admin_settings DB so they persist without redeployment.
    The payment_service reads from DB first, env vars as fallback.
    """
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update({
        "razorpay_key_id": body.key_id,
        "razorpay_key_secret": encrypt_value(body.key_secret),
        "razorpay_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Razorpay configuration saved")


@router.post("/razorpay/test")
async def test_razorpay_endpoint(admin: dict = Depends(get_current_admin)):
    """Test Razorpay connection."""
    from services.payment_service import test_razorpay_connection
    result = await test_razorpay_connection()
    if result["success"]:
        return success_response(result, "Razorpay connection successful")
    raise HTTPException(status_code=400, detail=result.get("error", "Razorpay test failed"))


@router.post("/stripe")
async def save_stripe(body: StripeConfig, admin: dict = Depends(get_current_admin)):
    """
    Save Stripe credentials.
    These are saved into admin_settings DB so they persist without redeployment.
    """
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update({
        "stripe_publishable_key": body.publishable_key,
        "stripe_secret_key": encrypt_value(body.secret_key),
        "stripe_webhook_secret": encrypt_value(body.webhook_secret) if body.webhook_secret else "",
        "stripe_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Stripe configuration saved")


@router.post("/stripe/test")
async def test_stripe_endpoint(admin: dict = Depends(get_current_admin)):
    """Test Stripe connection."""
    from services.payment_service import test_stripe_connection
    result = await test_stripe_connection()
    if result["success"]:
        return success_response(result, f"Stripe connection successful (mode: {result.get('mode', 'unknown')})")
    raise HTTPException(status_code=400, detail=result.get("error", "Stripe test failed"))


# ─── Helpers ──────────────────────────────────────────────────────

def _ensure_admin_settings(db):
    """Ensure admin_settings row exists"""
    result = db.table("admin_settings").select("id").limit(1).execute()
    if not result.data:
        db.table("admin_settings").insert({"placeholder": True}).execute()


def _get_settings_id(db) -> str:
    result = db.table("admin_settings").select("id").limit(1).execute()
    return result.data[0]["id"] if result.data else None


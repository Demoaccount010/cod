from fastapi import APIRouter, HTTPException
from config.database import get_db
from utils.helpers import success_response
from datetime import date

router = APIRouter(prefix="/api/v1/jobs", tags=["Public Jobs"])


@router.get("")
async def list_active_jobs(department: str = None, job_type: str = None):
    """Return all active, non-expired job postings for the public careers page."""
    db = get_db()
    today = date.today().isoformat()

    query = db.table("jobs").select(
        "id, title, department, location, job_type, experience_level, "
        "salary_min, salary_max, salary_currency, salary_disclosed, "
        "description, requirements, benefits, how_to_apply, "
        "application_email, application_url, start_date, end_date, "
        "is_featured, slots, created_at"
    ).eq("is_active", True)

    # Filter out expired jobs (end_date < today)
    # Supabase: jobs with no end_date should show, so we OR: end_date > today OR end_date is null
    # We do this by fetching all active and filtering in Python (simplest approach)
    result = query.order("is_featured", desc=True).order("created_at", desc=True).execute()

    jobs = []
    for j in (result.data or []):
        # Skip if expired
        if j.get("end_date") and j["end_date"][:10] < today:
            continue
        # Department/type filter
        if department and j.get("department", "").lower() != department.lower():
            continue
        if job_type and j.get("job_type", "").lower() != job_type.lower():
            continue
        jobs.append(j)

    # Departments for filter UI
    all_depts = list({j["department"] for j in jobs if j.get("department")})
    all_types = list({j["job_type"] for j in jobs if j.get("job_type")})

    return success_response({
        "jobs": jobs,
        "total": len(jobs),
        "departments": sorted(all_depts),
        "job_types": sorted(all_types),
    })


@router.get("/{job_id}")
async def get_job(job_id: str):
    """Return single job detail."""
    db = get_db()
    result = db.table("jobs").select("*").eq("id", job_id).eq("is_active", True).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Job not found or no longer active")
    j = result.data[0]
    today = date.today().isoformat()
    if j.get("end_date") and j["end_date"][:10] < today:
        raise HTTPException(status_code=404, detail="This job posting has expired")
    return success_response(j)

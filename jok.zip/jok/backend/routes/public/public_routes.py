from fastapi import APIRouter, HTTPException, Request
from typing import Optional
from config.database import get_db
from middleware.rate_limiter import limiter
from models.admin import ContactFormRequest, CreateReviewRequest
from utils.helpers import success_response, paginate_params, pagination_meta
from utils.constants import PLAN_DETAILS

router = APIRouter(prefix="/api/v1/public", tags=["Public"])


# Country config fallback (if DB not yet migrated)
_COUNTRIES_FALLBACK = [
    {"country_name": "India", "country_code": "+91", "country_iso": "IN",
     "flag_emoji": "🇮🇳", "whatsapp_enabled": True, "sms_enabled": False,
     "voice_enabled": False, "provider": "facebook_whatsapp",
     "price_per_verification": 2.50, "currency": "INR", "is_active": True},
    {"country_name": "USA", "country_code": "+1", "country_iso": "US",
     "flag_emoji": "🇺🇸", "whatsapp_enabled": False, "sms_enabled": True,
     "voice_enabled": True, "provider": "plivo",
     "price_per_verification": 0.06, "currency": "USD", "is_active": True},
    {"country_name": "Philippines", "country_code": "+63", "country_iso": "PH",
     "flag_emoji": "🇵🇭", "whatsapp_enabled": False, "sms_enabled": True,
     "voice_enabled": True, "provider": "plivo",
     "price_per_verification": 0.05, "currency": "USD", "is_active": True},
    {"country_name": "Mexico", "country_code": "+52", "country_iso": "MX",
     "flag_emoji": "🇲🇽", "whatsapp_enabled": False, "sms_enabled": True,
     "voice_enabled": True, "provider": "plivo",
     "price_per_verification": 0.04, "currency": "USD", "is_active": True},
    {"country_name": "United Kingdom", "country_code": "+44", "country_iso": "GB",
     "flag_emoji": "🇬🇧", "whatsapp_enabled": False, "sms_enabled": True,
     "voice_enabled": True, "provider": "plivo",
     "price_per_verification": 0.08, "currency": "USD", "is_active": True},
]


def _backfill_default_countries(db):
    """Ensure standard 5 countries exist and are active in DB."""
    for c in _COUNTRIES_FALLBACK:
        payload = {
            "country_name": c["country_name"],
            "country_code": c["country_code"],
            "country_iso": c["country_iso"],
            "flag_emoji": c["flag_emoji"],
            "whatsapp_enabled": c["whatsapp_enabled"],
            "sms_enabled": c["sms_enabled"],
            "voice_enabled": c["voice_enabled"],
            "provider": c["provider"],
            "price_per_verification": c["price_per_verification"],
            "currency": c["currency"],
            "is_active": True,
        }
        db.table("countries").upsert(payload, on_conflict="country_iso").execute()


@router.get("/countries")
async def list_countries():
    """Return all active countries with verification methods and pricing."""
    try:
        db = get_db()
        SELECT_FIELDS = (
            "country_name, country_code, country_iso, flag_emoji, "
            "whatsapp_enabled, sms_enabled, voice_enabled, provider, "
            "price_per_verification, currency, is_active"
        )
        # 1️⃣ Try fetching active countries from DB
        result = db.table("countries").select(SELECT_FIELDS).eq("is_active", True).order("country_name").execute()
        if result.data:
            return success_response(result.data)

        # 2️⃣ is_active filter returned empty — try ALL countries (in case is_active not set)
        result_all = db.table("countries").select(SELECT_FIELDS).order("country_name").execute()
        if result_all.data:
            return success_response(result_all.data)

        # 3️⃣ DB table is empty — auto-backfill all 5 default countries
        _backfill_default_countries(db)
        result_after = db.table("countries").select(SELECT_FIELDS).eq("is_active", True).order("country_name").execute()
        if result_after.data:
            return success_response(result_after.data)
    except Exception:
        pass
    # Last resort hardcoded fallback
    return success_response(_COUNTRIES_FALLBACK)



@router.get("/countries/{country_iso}")
async def get_country(country_iso: str):
    """Return config for a single country."""
    iso = country_iso.upper()
    try:
        db = get_db()
        result = db.table("countries").select("*").eq("country_iso", iso).eq("is_active", True).execute()
        if result.data:
            return success_response(result.data[0])
    except Exception:
        pass
    match = next((c for c in _COUNTRIES_FALLBACK if c["country_iso"] == iso), None)
    if match:
        return success_response(match)
    raise HTTPException(status_code=404, detail="Country not found or not supported")


@router.get("/pricing")
async def get_pricing():
    """Return pricing for all active countries."""
    try:
        db = get_db()
        result = db.table("countries").select(
            "country_name, country_iso, flag_emoji, price_per_verification, currency, "
            "whatsapp_enabled, sms_enabled, voice_enabled"
        ).eq("is_active", True).execute()
        if result.data:
            return success_response(result.data)
    except Exception:
        pass
    return success_response([
        {k: v for k, v in c.items() if k in (
            "country_name", "country_iso", "flag_emoji",
            "price_per_verification", "currency",
            "whatsapp_enabled", "sms_enabled", "voice_enabled"
        )} for c in _COUNTRIES_FALLBACK
    ])

@router.get("/partners")
async def list_partners():
    db = get_db()
    result = db.table("trusted_partners").select(
        "partner_name, partner_logo_url, partner_website_url, short_description, category, seo_slug"
    ).eq("is_active", True).order("display_order").execute()
    return success_response(result.data or [])


@router.get("/partners/{slug}")
async def get_partner(slug: str):
    db = get_db()
    result = db.table("trusted_partners").select("*").eq("seo_slug", slug).eq("is_active", True).execute()
    if not result.data:
        return success_response(None, "Partner not found")
    return success_response(result.data[0])




@router.post("/contact")
@limiter.limit("10/minute")
async def contact(request: Request, body: ContactFormRequest):
    db = get_db()
    from utils.helpers import generate_ticket_number
    db.table("support_tickets").insert({
        "ticket_number": generate_ticket_number(),
        "subject": f"Contact Form: {body.name}",
        "description": f"Name: {body.name}\nEmail: {body.email}\nPhone: {body.phone or 'N/A'}\nCompany: {body.company or 'N/A'}\n\n{body.message}",
        "category": "contact_form",
    }).execute()

    # Send email notification to admin
    try:
        from services.email_service import send_contact_form_email
        from config.settings import settings
        admin_email = getattr(settings, 'DEFAULT_ADMIN_EMAIL', 'admin@codverify.tech')
        await send_contact_form_email(
            admin_email=admin_email,
            name=body.name,
            email=body.email,
            phone=body.phone or "",
            company=body.company or "",
            message=body.message,
        )
    except Exception as e:
        import logging
        logging.warning(f"Contact form email failed: {e}")

    return success_response(message="Thank you! We'll get back to you soon.")




# ── Reviews ──────────────────────────────────────────────────────────────────

@router.get("/reviews")
async def get_reviews(featured_only: bool = False):
    """Get all approved, visible reviews for public display."""
    db = get_db()
    query = db.table("reviews").select("*").eq("is_approved", True).eq("is_visible", True)
    if featured_only:
        query = query.eq("is_featured", True)
    result = query.order("created_at", desc=True).execute()
    return success_response(result.data or [])


@router.post("/reviews")
@limiter.limit("5/minute")
async def submit_review(request: Request, body: CreateReviewRequest):
    """Submit a new review — starts as pending until admin approves."""
    db = get_db()
    data = {
        "author_name": body.author_name,
        "author_company": body.author_company,
        "author_role": body.author_role,
        "rating": body.rating,
        "title": body.title,
        "body": body.body,
        "is_approved": False,
        "is_featured": False,
        "is_visible": True,
    }
    result = db.table("reviews").insert(data).execute()
    return success_response(result.data[0] if result.data else {}, "Review submitted! It will appear after moderation.")


# ─── Public Blog ──────────────────────────────────────────────────────────────

@router.get("/blog/posts")
async def get_public_blog_posts(page: int = 1, limit: int = 12, category: str = None):
    """Get all published blog posts for the public blog page."""
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("blog_posts").select(
        "id, title, slug, excerpt, featured_image_url, category, tags, "
        "author_name, reading_time_minutes, views_count, published_at, created_at, is_featured",
        count="exact"
    ).eq("is_published", True)
    if category:
        query = query.eq("category", category)
    result = query.order("published_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({
        "posts": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit)
    })


@router.get("/blog/posts/{slug}")
async def get_public_blog_post(slug: str):
    """Get a single published blog post by slug. Increments view count."""
    db = get_db()
    result = db.table("blog_posts").select("*").eq("slug", slug).eq("is_published", True).execute()
    if not result.data:
        raise HTTPException(404, "Post not found")
    post = result.data[0]
    # Increment view count asynchronously (best-effort)
    try:
        db.table("blog_posts").update({"views_count": (post.get("views_count") or 0) + 1}).eq("id", post["id"]).execute()
    except Exception:
        pass
    return success_response(post)


@router.get("/blog/categories")
async def get_blog_categories():
    """Get all published blog categories with post counts."""
    db = get_db()
    result = db.table("blog_posts").select("category", count="exact").eq("is_published", True).execute()
    cats: dict = {}
    for p in (result.data or []):
        c = p.get("category") or "Uncategorized"
        cats[c] = cats.get(c, 0) + 1
    categories = [{"name": k, "count": v} for k, v in sorted(cats.items(), key=lambda x: -x[1])]
    return success_response(categories)

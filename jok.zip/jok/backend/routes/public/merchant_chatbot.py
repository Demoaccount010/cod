"""Public merchant chatbot API — embeddable widget endpoints.
Rate-limited per merchant, with merchant-specific AI context.
"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
from config.database import get_db
from services.groq_service import get_merchant_ai_response
import json
import random

router = APIRouter(prefix="/api/v1/merchant-chat", tags=["Public Merchant Chatbot"])


class MerchantStartChatBody(BaseModel):
    api_key: str
    visitor_name: Optional[str] = "Visitor"
    visitor_email: Optional[str] = None
    message: str


class MerchantMessageBody(BaseModel):
    api_key: str
    message: str


class MerchantOfflineCallbackBody(BaseModel):
    api_key: str
    visitor_name: str
    visitor_phone: str
    visitor_email: Optional[str] = None
    reason: Optional[str] = None
    message: Optional[str] = None


def _get_merchant_config(api_key: str):
    """Validate API key and get merchant chatbot config."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("*").eq("api_key", api_key).execute()
    if not config.data:
        raise HTTPException(403, "Invalid API key")
    c = config.data[0]
    if not c.get("is_enabled"):
        raise HTTPException(403, "Chatbot is not enabled for this merchant")
    return c


def _check_rate_limit(merchant_id: str, config: dict):
    """Check if merchant has exceeded monthly request limit."""
    limit = config.get("monthly_request_limit", 100)
    used = config.get("current_month_usage", 0)

    # Reset counter if past reset date
    reset_date = config.get("usage_reset_date")
    now = datetime.now(timezone.utc)
    if reset_date:
        try:
            rd = datetime.fromisoformat(str(reset_date).replace("Z", "+00:00"))
            if now >= rd:
                # Reset counter and set next reset date
                db = get_db()
                next_reset = (now.replace(day=1) + __import__('datetime').timedelta(days=32)).replace(day=1)
                db.table("merchant_chatbot_config").update({
                    "current_month_usage": 0,
                    "usage_reset_date": next_reset.isoformat(),
                }).eq("merchant_id", merchant_id).execute()
                return  # Reset done, allow request
        except Exception:
            pass

    if used >= limit:
        raise HTTPException(429, f"Monthly chatbot request limit reached ({limit} requests). Contact support to increase.")


def _get_active_workers(db):
    """Find on-duty workers with fresh heartbeat (last 2 minutes)."""
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()
    workers = db.table("users").select("id, name, duty_status, last_heartbeat").eq(
        "role", "worker"
    ).eq("duty_status", "on_duty").gte("last_heartbeat", cutoff).execute()
    return workers.data or []


def _pick_best_worker(db, active_workers):
    """Pick the worker with the least number of active chats."""
    if not active_workers:
        return None

    worker_ids = [w["id"] for w in active_workers]
    # Count active chats for each worker
    active_chats_count = {}
    for worker_id in worker_ids:
        count_res = db.table("chat_sessions").select("id", count="exact").eq(
            "assigned_worker_id", worker_id
        ).in_("status", ["waiting_human", "human_active"]).execute()
        active_chats_count[worker_id] = count_res.count if count_res.count else 0

    # Find worker with minimum active chats
    best_worker_id = min(active_chats_count, key=active_chats_count.get)
    return next((w for w in active_workers if w["id"] == best_worker_id), None)


def _increment_usage(merchant_id: str, session_id: str = None, request_type: str = "chat", visitor_ip: str = ""):
    """Increment usage counter and log the request."""
    db = get_db()
    # Increment counter
    db.rpc("increment_chatbot_usage", {"p_merchant_id": merchant_id}).execute()
    # Log the request
    db.table("chatbot_api_usage").insert({
        "merchant_id": merchant_id,
        "session_id": session_id,
        "request_type": request_type,
        "visitor_ip": visitor_ip,
    }).execute()


def _build_merchant_system_prompt(config: dict) -> str:
    """Build a merchant-specific system prompt from their config.
    Tier chatbot_ai = AI only (no human handoff).
    Tier chatbot_full = AI + human handoff when AI is stuck.
    """
    biz = config.get("business_name", "this business")
    desc = config.get("business_description", "")
    services = config.get("business_services", "")
    faq = config.get("business_faq", "")
    website = config.get("business_website", "")
    tier = config.get("chatbot_tier", "chatbot_full")

    if tier == "chatbot_ai":
        # AI-only tier: no human agents available, never request handoff
        handoff_rule = (
            "- You are the ONLY support available — there are NO human agents. "
            "If you cannot resolve an issue, apologize sincerely and ask the customer to "
            "contact us via the website or email. NEVER output [HANDOFF_REQUESTED]."
        )
    else:
        # chatbot_full tier: AI first, escalate to human when truly stuck
        handoff_rule = (
            "- Try your BEST to solve the customer's issue yourself first\n"
            "- Only if you truly cannot resolve the issue, or if the customer explicitly "
            "asks for a human agent, respond with exactly: [HANDOFF_REQUESTED]\n"
            "- Do NOT handoff easily — make a genuine effort to help first"
        )

    prompt = f"""You are the AI customer support assistant for {biz}. You ONLY discuss topics related to {biz} and its products/services. You do NOT answer any off-topic, general knowledge, or unrelated questions.

About {biz}:
{desc}

{f"Services/Products: {services}" if services else ""}
{f"Website: {website}" if website else ""}
{f"Frequently Asked Questions: {faq}" if faq else ""}

STRICT RULES:
- ONLY answer questions about {biz}, its products, services, orders, and support
- If the customer asks ANYTHING unrelated, politely say: "I can only help with {biz}-related questions. Is there anything else I can help with?"
{handoff_rule}
- Keep responses concise (2-3 sentences max)
- Use simple, friendly language
- If the customer writes in Hindi, respond in Hindi-English mix
- Never make up information — be honest if you don't know something
"""
    return prompt


@router.get("/config/{api_key}")
async def get_widget_config(api_key: str):
    """Get chatbot config for widget initialization (public, no auth)."""
    config = _get_merchant_config(api_key)
    # Return only public-safe fields
    menu_options = config.get("menu_options") or []
    if isinstance(menu_options, str):
        try:
            menu_options = json.loads(menu_options)
        except Exception:
            menu_options = []

    return {
        "success": True,
        "data": {
            "bot_name": config.get("bot_name", "Support Bot"),
            "welcome_message": config.get("welcome_message", "Hi! 👋 How can I help you today?"),
            "primary_color": config.get("primary_color", "#6366f1"),
            "menu_options": menu_options,
            "business_name": config.get("business_name", ""),
            "chatbot_tier": config.get("chatbot_tier", "chatbot_basic"),
            "widget_theme": config.get("widget_theme", "dark"),
        }
    }


@router.get("/config-by-shop")
async def get_widget_config_by_shop(shop_domain: str):
    """Get chatbot config by shop domain — used by Shopify embed script.
    Looks up the merchant via shopify_shop_domain or business_website in users table,
    then fetches their chatbot config.
    """
    db = get_db()
    # Find user by shopify_shop_domain
    user_res = db.table("users").select("id").eq("shopify_shop_domain", shop_domain).execute()
    if not user_res.data:
        # Fallback: look up merchant by business_website in chatbot config
        clean_domain = shop_domain.replace("https://", "").replace("http://", "").rstrip("/")
        config_res = db.table("merchant_chatbot_config").select("merchant_id").ilike(
            "business_website", f"%{clean_domain}%"
        ).eq("is_enabled", True).limit(1).execute()
        if config_res.data:
            # Return config directly since we already have merchant_id
            config = db.table("merchant_chatbot_config").select("*").eq(
                "merchant_id", config_res.data[0]["merchant_id"]
            ).single().execute()
            if config.data and config.data.get("is_enabled"):
                menu_options = config.data.get("menu_options") or []
                if isinstance(menu_options, str):
                    try:
                        menu_options = json.loads(menu_options)
                    except Exception:
                        menu_options = []
                return {
                    "success": True,
                    "data": {
                        "enabled": True,
                        "api_key": config.data["api_key"],
                        "bot_name": config.data.get("bot_name", "Support Bot"),
                        "welcome_message": config.data.get("welcome_message", "Hi! How can I help?"),
                        "primary_color": config.data.get("primary_color", "#6366f1"),
                        "bot_avatar_url": config.data.get("bot_avatar_url"),
                        "menu_options": menu_options,
                        "business_name": config.data.get("business_name", ""),
                        "chatbot_tier": config.data.get("chatbot_tier", "chatbot_basic"),
                    }
                }
        return {"success": False, "data": {"enabled": False}}
    if not user_res.data:
        return {"success": False, "data": {"enabled": False}}

    user_id = user_res.data[0]["id"]
    config_res = db.table("merchant_chatbot_config").select("*").eq("merchant_id", user_id).execute()
    if not config_res.data:
        return {"success": False, "data": {"enabled": False}}

    config = config_res.data[0]
    if not config.get("is_enabled"):
        return {"success": True, "data": {"enabled": False}}

    menu_options = config.get("menu_options") or []
    if isinstance(menu_options, str):
        try:
            menu_options = json.loads(menu_options)
        except Exception:
            menu_options = []

    return {
        "success": True,
        "data": {
            "enabled": True,
            "merchant_id": user_id,
            "api_key": config.get("api_key", ""),
            "bot_name": config.get("bot_name", "Support Bot"),
            "welcome_message": config.get("welcome_message", "Hi! 👋 How can I help you today?"),
            "primary_color": config.get("primary_color", "#6366f1"),
            "menu_options": menu_options,
            "business_name": config.get("business_name", ""),
            "chatbot_tier": config.get("chatbot_tier", "chatbot_basic"),
        }
    }


@router.post("/start")
async def start_merchant_chat(body: MerchantStartChatBody, request: Request):
    """Start a new chat session on merchant's website."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")
    _check_rate_limit(merchant_id, config)

    db = get_db()
    visitor_ip = request.client.host if request.client else ""
    chatbot_tier = config.get("chatbot_tier", "chatbot_basic")

    # Determine initial status based on tier
    # Basic = no AI, immediate worker handoff
    # AI / Full = AI auto-responses first
    if chatbot_tier == "chatbot_basic":
        initial_status = "waiting_human"
    else:
        initial_status = "ai_active"

    session_data = {
        "visitor_name": body.visitor_name or "Visitor",
        "visitor_email": body.visitor_email,
        "merchant_id": merchant_id,
        "status": initial_status,
        "source": "merchant_widget",
        "metadata": {"api_key": body.api_key, "visitor_ip": visitor_ip, "chatbot_tier": chatbot_tier},
    }

    ai_text = ""
    handoff = False

    if chatbot_tier == "chatbot_basic":
        # Basic tier: NO AI, direct handoff to worker
        # First check if any worker is actually online
        active_workers = _get_active_workers(db)
        if not active_workers:
            # No workers online — return offline flag
            return {
                "success": True,
                "data": {
                    "session_id": None,
                    "ai_response": "",
                    "no_workers_available": True,
                    "offline_message": "We're extremely sorry, there is no one active right now to handle your chat. Please share your details and we'll call you back as soon as possible.",
                    "chatbot_tier": chatbot_tier,
                }
            }

        ai_text = "Thank you for reaching out! We're connecting you with a support agent. Please wait a moment..."
        handoff = True

        # Assign to the worker with least active chats
        best_worker = _pick_best_worker(db, active_workers)
        if best_worker:
            session_data["assigned_worker_id"] = best_worker["id"]

        session = db.table("chat_sessions").insert(session_data).execute()
        session_id = session.data[0]["id"]

        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "visitor",
            "message": body.message,
        }).execute()
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "system",
            "message": "🔔 Connecting you with a support agent. Please wait...",
        }).execute()
    else:
        # AI / Full tier: AI auto-responses
        session = db.table("chat_sessions").insert(session_data).execute()
        session_id = session.data[0]["id"]

        # Save visitor message
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "visitor",
            "message": body.message,
        }).execute()

        system_prompt = _build_merchant_system_prompt(config)
        ai_result = await get_merchant_ai_response(
            messages=[{"sender_type": "visitor", "message": body.message}],
            system_prompt=system_prompt,
        )

        ai_text = ai_result["message"]
        # chatbot_ai tier never forwards to a human — ignore any handoff signal
        handoff = ai_result["handoff_requested"] and chatbot_tier != "chatbot_ai"

        # Save AI response
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "ai",
            "message": ai_text,
        }).execute()

        if handoff:
            db.table("chat_sessions").update({"status": "waiting_human"}).eq("id", session_id).execute()
            db.table("chat_messages").insert({
                "session_id": session_id,
                "sender_type": "system",
                "message": "🔔 Connecting you with a support agent. Please wait...",
            }).execute()

    # Increment usage
    _increment_usage(merchant_id, session_id, "start", visitor_ip)

    return {
        "success": True,
        "data": {
            "session_id": session_id,
            "ai_response": ai_text,
            "handoff_requested": handoff,
            "status": "waiting_human" if handoff else "ai_active",
            "chatbot_tier": chatbot_tier,
        }
    }


@router.post("/message/{session_id}")
async def send_merchant_message(session_id: str, body: MerchantMessageBody, request: Request):
    """Visitor sends a message in existing merchant chat session."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")
    _check_rate_limit(merchant_id, config)

    db = get_db()
    visitor_ip = request.client.host if request.client else ""

    # Verify session belongs to this merchant
    session = db.table("chat_sessions").select("id, status, merchant_id").eq("id", session_id).execute()
    if not session.data or session.data[0].get("merchant_id") != merchant_id:
        raise HTTPException(404, "Session not found")

    status = session.data[0]["status"]

    # Save visitor message
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "visitor",
        "message": body.message,
    }).execute()

    result = {"status": status}

    if status == "ai_active":
        # Get conversation history
        history = db.table("chat_messages").select("sender_type, message").eq(
            "session_id", session_id
        ).order("created_at").execute()

        system_prompt = _build_merchant_system_prompt(config)
        ai_result = await get_merchant_ai_response(
            messages=history.data or [],
            system_prompt=system_prompt,
        )

        ai_text = ai_result["message"]
        # Get tier from session metadata (stored at session start)
        session_meta = session.data[0].get("metadata") or {}
        if isinstance(session_meta, str):
            import json as _json
            try:
                session_meta = _json.loads(session_meta)
            except Exception:
                session_meta = {}
        session_tier = session_meta.get("chatbot_tier", "chatbot_full")
        # chatbot_ai tier never forwards to a human — ignore any handoff signal
        handoff = ai_result["handoff_requested"] and session_tier != "chatbot_ai"

        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "ai",
            "message": ai_text,
        }).execute()

        if handoff:
            db.table("chat_sessions").update({"status": "waiting_human"}).eq("id", session_id).execute()
            # Try to assign a worker immediately
            active_workers = _get_active_workers(db)
            if active_workers:
                best_worker = _pick_best_worker(db, active_workers)
                if best_worker:
                    db.table("chat_sessions").update({
                        "assigned_worker_id": best_worker["id"],
                    }).eq("id", session_id).execute()
            db.table("chat_messages").insert({
                "session_id": session_id,
                "sender_type": "system",
                "message": "🔔 Connecting you with a support agent. Please wait...",
            }).execute()
            result["status"] = "waiting_human"

        result["ai_response"] = ai_text
        result["handoff_requested"] = handoff

    elif status == "human_active":
        result["message"] = "Message sent to support agent"

    elif status == "waiting_human":
        result["message"] = "Your message has been received. An agent will respond shortly."

    # Increment usage
    _increment_usage(merchant_id, session_id, "message", visitor_ip)

    return {"success": True, "data": result}


@router.get("/messages/{session_id}")
async def get_merchant_chat_messages(session_id: str, api_key: str):
    """Get messages for a merchant chat session (public, for widget polling)."""
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()
    session = db.table("chat_sessions").select("id, status, merchant_id, assigned_worker_id").eq("id", session_id).execute()
    if not session.data or session.data[0].get("merchant_id") != merchant_id:
        raise HTTPException(404, "Session not found")

    messages = db.table("chat_messages").select("*").eq(
        "session_id", session_id
    ).order("created_at").execute()

    # Get worker name if assigned
    worker_name = None
    if session.data[0].get("assigned_worker_id"):
        worker = db.table("users").select("name").eq("id", session.data[0]["assigned_worker_id"]).execute()
        if worker.data:
            worker_name = worker.data[0].get("name")

    return {
        "success": True,
        "data": {
            "messages": messages.data or [],
            "session_status": session.data[0]["status"],
            "worker_name": worker_name,
        }
    }


@router.post("/offline-callback")
async def submit_offline_callback(body: dict):
    """Visitor submits callback form when no worker is available."""
    api_key = body.get("api_key", "")
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()

    visitor_name = body.get("visitor_name", "")
    visitor_phone = body.get("visitor_phone", "")
    visitor_email = body.get("visitor_email", "")
    reason = body.get("reason", "")

    if not visitor_name or not visitor_phone:
        raise HTTPException(400, "Name and phone number are required")

    # Save callback request
    callback_data = {
        "merchant_id": merchant_id,
        "visitor_name": visitor_name,
        "visitor_phone": visitor_phone,
        "visitor_email": visitor_email,
        "reason": reason,
        "status": "pending",
        "source": "chatbot_offline",
    }

    # Try to assign to a random worker (even if offline, they'll see it when back)
    all_workers = db.table("users").select("id").eq("role", "worker").execute()
    if all_workers.data:
        random_worker = random.choice(all_workers.data)
        callback_data["assigned_worker_id"] = random_worker["id"]

    db.table("callback_requests").insert(callback_data).execute()

    return {
        "success": True,
        "data": {
            "message": "Thank you! We've received your details. Our team will call you back shortly."
        }
    }


@router.post("/callback-request")
async def submit_callback_request(body: dict):
    """Visitor submits callback request via chatbot widget (permanent button, works anytime)."""
    api_key = body.get("api_key", "")
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()

    visitor_name = body.get("visitor_name", "")
    visitor_phone = body.get("visitor_phone", "")
    visitor_email = body.get("visitor_email", "")
    reason = body.get("reason", "")

    if not visitor_name or not visitor_phone:
        raise HTTPException(400, "Name and phone number are required")

    # Save callback request
    callback_data = {
        "merchant_id": merchant_id,
        "visitor_name": visitor_name,
        "visitor_phone": visitor_phone,
        "visitor_email": visitor_email,
        "reason": reason,
        "status": "pending",
        "source": "chatbot_widget",
    }

    # Assign to online worker (least loaded) or any worker if none online
    active_workers = _get_active_workers(db)
    if active_workers:
        best_worker = _pick_best_worker(db, active_workers)
        if best_worker:
            callback_data["assigned_worker_id"] = best_worker["id"]
    else:
        all_workers = db.table("users").select("id").eq("role", "worker").execute()
        if all_workers.data:
            callback_data["assigned_worker_id"] = random.choice(all_workers.data)["id"]

    result = db.table("callback_requests").insert(callback_data).execute()

    # Notify assigned worker
    if callback_data.get("assigned_worker_id"):
        from services.notification_service import create_notification
        await create_notification(
            callback_data["assigned_worker_id"],
            f"📞 Callback Request from {visitor_name}",
            f"Phone: {visitor_phone} | Reason: {reason[:100] if reason else 'Not specified'}",
            "info", "callbacks", None
        )

    return {
        "success": True,
        "data": {
            "message": "Your callback request has been submitted! Our team will call you back shortly."
        }
    }


@router.get("/workers-status")
async def check_workers_status(api_key: str):
    """Check if any support workers are currently online (for widget UI)."""
    _get_merchant_config(api_key)  # validate api_key
    db = get_db()
    active_workers = _get_active_workers(db)
    return {
        "success": True,
        "data": {
            "workers_online": len(active_workers) > 0,
            "count": len(active_workers),
        }
    }

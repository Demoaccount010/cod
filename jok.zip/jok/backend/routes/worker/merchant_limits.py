"""Worker endpoints for managing merchant chatbot API limits."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker/merchants", tags=["Worker Merchant Management"])


class UpdateLimitBody(BaseModel):
    monthly_request_limit: int


@router.get("/chatbot-limits")
async def get_merchant_chatbot_limits(user: dict = Depends(get_current_worker)):
    """Get all merchants with their chatbot API limits and usage."""
    db = get_db()

    # Get all merchant chatbot configs with merchant info
    configs = db.table("merchant_chatbot_config").select(
        "*, users!merchant_chatbot_config_merchant_id_fkey(name, email, company_name)"
    ).execute()

    merchants = []
    for c in (configs.data or []):
        user_info = c.pop("users", {}) or {}
        merchants.append({
            "merchant_id": c["merchant_id"],
            "merchant_name": user_info.get("name", "Unknown"),
            "merchant_email": user_info.get("email", ""),
            "company_name": user_info.get("company_name", ""),
            "is_enabled": c.get("is_enabled", False),
            "monthly_limit": c.get("monthly_request_limit", 100),
            "current_usage": c.get("current_month_usage", 0),
            "remaining": max(0, c.get("monthly_request_limit", 100) - c.get("current_month_usage", 0)),
            "usage_reset_date": c.get("usage_reset_date"),
            "business_name": c.get("business_name", ""),
        })

    return success_response({"merchants": merchants})


@router.put("/{merchant_id}/chatbot-limit")
async def update_merchant_chatbot_limit(
    merchant_id: str,
    body: UpdateLimitBody,
    user: dict = Depends(get_current_worker),
):
    """Update a merchant's monthly chatbot API request limit."""
    db = get_db()

    if body.monthly_request_limit < 0:
        raise HTTPException(400, "Limit cannot be negative")

    config = db.table("merchant_chatbot_config").select("id").eq(
        "merchant_id", merchant_id
    ).execute()

    if not config.data:
        raise HTTPException(404, "Merchant chatbot config not found")

    db.table("merchant_chatbot_config").update({
        "monthly_request_limit": body.monthly_request_limit,
    }).eq("merchant_id", merchant_id).execute()

    return success_response(
        {"monthly_request_limit": body.monthly_request_limit},
        f"Limit updated to {body.monthly_request_limit} requests/month"
    )


@router.post("/{merchant_id}/chatbot-reset-usage")
async def reset_merchant_usage(merchant_id: str, user: dict = Depends(get_current_worker)):
    """Reset a merchant's current month usage counter."""
    db = get_db()

    config = db.table("merchant_chatbot_config").select("id").eq(
        "merchant_id", merchant_id
    ).execute()
    if not config.data:
        raise HTTPException(404, "Merchant chatbot config not found")

    db.table("merchant_chatbot_config").update({
        "current_month_usage": 0,
    }).eq("merchant_id", merchant_id).execute()

    return success_response(message="Usage counter reset")

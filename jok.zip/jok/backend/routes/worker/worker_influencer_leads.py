"""
Worker — Influencer Leads Queue
GET  /api/v1/worker/influencer-leads              — List pending/called leads
PUT  /api/v1/worker/influencer-leads/:id/qualify  — Mark as qualified
PUT  /api/v1/worker/influencer-leads/:id/reject   — Mark as not qualified
PUT  /api/v1/worker/influencer-leads/:id/call     — Mark as called (in progress)
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from loguru import logger

from config.database import get_db
from middleware.auth import get_current_user
from services.influencer_service import process_qualified_lead_payout
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker/influencer-leads", tags=["Worker - Influencer Leads"])


def _require_worker(user: dict):
    if user.get("role") not in ("worker", "admin"):
        raise HTTPException(status_code=403, detail="Worker or admin access required")


class LeadDecisionBody(BaseModel):
    notes: Optional[str] = None


# ── List Leads Queue ────────────────────────────────────────────────────────────

@router.get("")
async def list_influencer_leads(
    user: dict = Depends(get_current_user),
    status: str = Query("pending"),  # pending | called | qualified | not_qualified | all
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
):
    _require_worker(user)
    db = get_db()

    offset = (page - 1) * per_page
    query = (
        db.table("influencer_leads")
        .select("""
            id, status, created_at, called_at, qualified_at, worker_notes,
            lead_payout_amount, lead_payout_status,
            subscription_payout_status,
            influencer:influencer_id(ref_code, full_name, social_handle, platform),
            merchant:merchant_id(id, name, email, phone, company_name, created_at, status)
        """)
        .order("created_at", desc=True)
        .range(offset, offset + per_page - 1)
    )

    if status != "all":
        query = query.eq("status", status)

    res = query.execute()

    count_q = db.table("influencer_leads").select("id", count="exact")
    if status != "all":
        count_q = count_q.eq("status", status)
    total = count_q.execute()

    return success_response({
        "leads": res.data or [],
        "total": total.count or 0,
        "page": page,
        "per_page": per_page,
    })


# ── Mark as Called ──────────────────────────────────────────────────────────────

@router.put("/{lead_id}/call")
async def mark_as_called(lead_id: str, body: LeadDecisionBody, user: dict = Depends(get_current_user)):
    _require_worker(user)
    db = get_db()

    lead_res = db.table("influencer_leads").select("id, status").eq("id", lead_id).execute()
    if not lead_res.data:
        raise HTTPException(status_code=404, detail="Lead not found")
    if lead_res.data[0]["status"] not in ("pending", "called"):
        raise HTTPException(status_code=400, detail="Lead already processed")

    db.table("influencer_leads").update({
        "status": "called",
        "called_at": datetime.now(timezone.utc).isoformat(),
        "reviewed_by": user["id"],
        "worker_notes": body.notes or "",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", lead_id).execute()

    return success_response(message="Lead marked as called")


# ── Qualify Lead ────────────────────────────────────────────────────────────────

@router.put("/{lead_id}/qualify")
async def qualify_lead(lead_id: str, body: LeadDecisionBody, user: dict = Depends(get_current_user)):
    _require_worker(user)
    db = get_db()

    lead_res = db.table("influencer_leads").select("id, status, influencer_id").eq("id", lead_id).execute()
    if not lead_res.data:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead = lead_res.data[0]

    if lead["status"] == "qualified":
        raise HTTPException(status_code=400, detail="Lead already qualified")
    if lead["status"] == "not_qualified":
        raise HTTPException(status_code=400, detail="Lead already marked as not qualified — cannot change")

    # Update lead status
    db.table("influencer_leads").update({
        "status": "qualified",
        "qualified_at": datetime.now(timezone.utc).isoformat(),
        "reviewed_by": user["id"],
        "worker_notes": body.notes or "",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", lead_id).execute()

    # Credit payout to influencer wallet
    try:
        process_qualified_lead_payout(lead_id)
    except Exception as e:
        logger.error(f"Payout processing error for lead {lead_id}: {e}")
        # Non-fatal — lead is still marked qualified

    logger.info(f"✅ Worker {user['id']} qualified lead {lead_id}")
    return success_response(message="Lead marked as qualified. Payout credited to influencer wallet.")


# ── Reject Lead (Not Qualified) ────────────────────────────────────────────────

@router.put("/{lead_id}/reject")
async def reject_lead(lead_id: str, body: LeadDecisionBody, user: dict = Depends(get_current_user)):
    _require_worker(user)
    db = get_db()

    lead_res = db.table("influencer_leads").select("id, status").eq("id", lead_id).execute()
    if not lead_res.data:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead = lead_res.data[0]

    if lead["status"] in ("qualified", "not_qualified"):
        raise HTTPException(status_code=400, detail="Lead already reviewed — cannot change")

    db.table("influencer_leads").update({
        "status": "not_qualified",
        "qualified_at": None,
        "reviewed_by": user["id"],
        "worker_notes": body.notes or "",
        "lead_payout_status": "cancelled",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", lead_id).execute()

    logger.info(f"❌ Worker {user['id']} rejected lead {lead_id}")
    return success_response(message="Lead marked as not qualified. No payout will be issued.")

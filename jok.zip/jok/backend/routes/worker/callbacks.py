"""Worker callback request management endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker/callbacks", tags=["Worker Callbacks"])


class ResolveCallbackBody(BaseModel):
    resolution_notes: Optional[str] = ""


@router.get("")
async def get_callback_requests(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
    user: dict = Depends(get_current_worker),
):
    """Get callback requests assigned to this worker or unassigned."""
    db = get_db()
    worker_id = user["id"]
    offset = (page - 1) * limit

    # Get callbacks assigned to this worker + unassigned pending ones
    if status:
        my_callbacks = db.table("callback_requests").select(
            "*", count="exact"
        ).eq("status", status).or_(
            f"assigned_worker_id.eq.{worker_id},assigned_worker_id.is.null"
        ).order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    else:
        my_callbacks = db.table("callback_requests").select(
            "*", count="exact"
        ).or_(
            f"assigned_worker_id.eq.{worker_id},assigned_worker_id.is.null"
        ).order("created_at", desc=True).range(offset, offset + limit - 1).execute()

    # Enrich with merchant info
    enriched = []
    merchant_cache = {}
    for cb in (my_callbacks.data or []):
        mid = cb.get("merchant_id")
        if mid and mid not in merchant_cache:
            m = db.table("users").select("name, company_name, shopify_shop_domain").eq("id", mid).execute()
            store = db.table("stores").select("store_name, store_url").eq("user_id", mid).limit(1).execute()
            merchant_cache[mid] = {
                "merchant_name": m.data[0].get("company_name") or m.data[0].get("name", "") if m.data else "",
                "store_name": (store.data[0].get("store_name", "") if store.data else ""),
                "domain": (store.data[0].get("store_url", "") if store.data else "") or (m.data[0].get("shopify_shop_domain", "") if m.data else ""),
            }
        enriched.append({
            **cb,
            "customer_name": cb.get("visitor_name") or cb.get("customer_name", ""),
            "customer_phone": cb.get("visitor_phone") or cb.get("customer_phone", ""),
            "customer_email": cb.get("visitor_email") or cb.get("customer_email", ""),
            "merchant_name": merchant_cache.get(mid, {}).get("merchant_name", ""),
            "store_name": merchant_cache.get(mid, {}).get("store_name", ""),
            "domain": merchant_cache.get(mid, {}).get("domain", ""),
            "notes": cb.get("reason", ""),
            "merchant": merchant_cache.get(mid, {}),
        })

    return success_response({
        "callbacks": enriched,
        "total": my_callbacks.count or 0,
        "page": page,
        "limit": limit,
    })


@router.post("/{callback_id}/accept")
async def accept_callback(callback_id: str, user: dict = Depends(get_current_worker)):
    """Worker accepts/claims a callback request."""
    db = get_db()
    cb = db.table("callback_requests").select("*").eq("id", callback_id).execute()
    if not cb.data:
        raise HTTPException(404, "Callback request not found")

    if cb.data[0]["status"] not in ("pending",):
        raise HTTPException(400, "Callback is not in pending status")

    db.table("callback_requests").update({
        "assigned_worker_id": user["id"],
        "status": "in_progress",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", callback_id).execute()

    return success_response(message="Callback request accepted")


@router.post("/{callback_id}/resolve")
async def resolve_callback(
    callback_id: str,
    body: ResolveCallbackBody,
    user: dict = Depends(get_current_worker),
):
    """Worker marks a callback as resolved (query solved)."""
    db = get_db()
    cb = db.table("callback_requests").select("*").eq("id", callback_id).execute()
    if not cb.data:
        raise HTTPException(404, "Callback request not found")

    try:
        db.table("callback_requests").update({
            "status": "resolved",
            "resolved_by_worker_id": user["id"],
            "resolution_notes": body.resolution_notes or "",
            "resolved_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", callback_id).execute()
    except Exception as e:
        # Fallback: Supabase PostgREST schema cache is stale or threw another structured APIError.
        # Dropping the `resolution_notes` column to try again strictly with basic columns.
        try:
            db.table("callback_requests").update({
                "status": "resolved",
                "resolved_by_worker_id": user["id"],
            }).eq("id", callback_id).execute()
        except:
            raise e

    # Notify merchant about resolved callback
    merchant_id = cb.data[0].get("merchant_id")
    visitor_name = cb.data[0].get("visitor_name", "Customer")
    if merchant_id:
        from services.notification_service import create_notification
        await create_notification(
            merchant_id,
            f"Callback Resolved ✅ — {visitor_name}",
            f"Worker {user.get('name', '')} resolved the callback request.",
            "success", "callbacks", None
        )

    return success_response(message="Callback marked as resolved")


@router.post("/{callback_id}/cancel")
async def cancel_callback(callback_id: str, user: dict = Depends(get_current_worker)):
    """Worker cancels a callback (e.g., fake number, no answer after multiple attempts)."""
    db = get_db()
    db.table("callback_requests").update({
        "status": "cancelled",
        "resolved_by_worker_id": user["id"],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", callback_id).execute()

    return success_response(message="Callback cancelled")

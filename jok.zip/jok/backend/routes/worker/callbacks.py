"""Worker callback request management endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker/callbacks", tags=["Worker Callbacks"])


class ResolveCallbackBody(BaseModel):
    resolution_notes: Optional[str] = ""


@router.get("")
async def get_callback_requests(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
    user: dict = Depends(get_current_worker),
):
    """Get callback requests visible to this worker.
    
    Visibility rules:
    - PENDING: ALL workers see ALL pending callbacks (so anyone can claim)
    - IN_PROGRESS / other: only callbacks assigned to THIS worker
    - RESOLVED / CANCELLED: only callbacks resolved/assigned to this worker
    """
    db = get_db()
    worker_id = user["id"]
    offset = (page - 1) * limit

    all_results = []

    if status == "pending" or status is None:
        # All pending callbacks visible to every worker
        q_pending = db.table("callback_requests").select("*").eq("status", "pending")
        r = q_pending.order("created_at", desc=True).execute()
        all_results += (r.data or [])

    if status in (None, "in_progress", "accepted", "resolved", "cancelled"):
        # Only MY assigned callbacks for non-pending statuses
        q_mine = db.table("callback_requests").select("*").eq("assigned_worker_id", worker_id)
        if status and status != "pending":
            q_mine = q_mine.eq("status", status)
        elif status is None:
            # Exclude pending since we already fetched all pending above
            q_mine = q_mine.neq("status", "pending")
        r2 = q_mine.order("created_at", desc=True).execute()
        all_results += (r2.data or [])

    # Deduplicate by id, sort descending
    seen = set()
    merged = []
    for cb in all_results:
        if cb["id"] not in seen:
            seen.add(cb["id"])
            merged.append(cb)
    merged.sort(key=lambda x: x.get("created_at", ""), reverse=True)

    total = len(merged)
    page_data = merged[offset: offset + limit]

    # Enrich with merchant info
    enriched = []
    merchant_cache = {}
    for cb in page_data:
        mid = cb.get("merchant_id")
        if mid and mid not in merchant_cache:
            m = db.table("users").select("name, company_name, shopify_shop_domain").eq("id", mid).execute()
            store = db.table("stores").select("store_name, store_url").eq("user_id", mid).limit(1).execute()
            merchant_cache[mid] = {
                "merchant_name": m.data[0].get("company_name") or m.data[0].get("name", "") if m.data else "",
                "store_name": (store.data[0].get("store_name", "") if store.data else ""),
                "domain": (store.data[0].get("store_url", "") if store.data else "") or (m.data[0].get("shopify_shop_domain", "") if m.data else ""),
            }
        enriched.append({
            **cb,
            "customer_name": cb.get("visitor_name") or cb.get("customer_name", ""),
            "customer_phone": cb.get("visitor_phone") or cb.get("customer_phone", ""),
            "customer_email": cb.get("visitor_email") or cb.get("customer_email", ""),
            "merchant_name": merchant_cache.get(mid, {}).get("merchant_name", ""),
            "store_name": merchant_cache.get(mid, {}).get("store_name", ""),
            "domain": merchant_cache.get(mid, {}).get("domain", ""),
            "notes": cb.get("reason", ""),
            "request_time": cb.get("created_at", ""),   # Frontend uses request_time
            "merchant": merchant_cache.get(mid, {}),
        })

    return success_response({
        "callbacks": enriched,
        "total": total,
        "page": page,
        "limit": limit,
    })


@router.post("/{callback_id}/accept")
async def accept_callback(callback_id: str, user: dict = Depends(get_current_worker)):
    """Worker accepts/claims a callback request."""
    db = get_db()
    cb = db.table("callback_requests").select("*").eq("id", callback_id).execute()
    if not cb.data:
        raise HTTPException(404, "Callback request not found")

    if cb.data[0]["status"] not in ("pending",):
        raise HTTPException(400, "Callback is not in pending status")

    db.table("callback_requests").update({
        "assigned_worker_id": user["id"],
        "status": "in_progress",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", callback_id).execute()

    return success_response(message="Callback request accepted")


@router.post("/{callback_id}/resolve")
async def resolve_callback(
    callback_id: str,
    body: ResolveCallbackBody,
    user: dict = Depends(get_current_worker),
):
    """Worker marks a callback as resolved (query solved)."""
    db = get_db()
    cb = db.table("callback_requests").select("*").eq("id", callback_id).execute()
    if not cb.data:
        raise HTTPException(404, "Callback request not found")

    try:
        db.table("callback_requests").update({
            "status": "resolved",
            "resolved_by_worker_id": user["id"],
            "resolution_notes": body.resolution_notes or "",
            "resolved_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", callback_id).execute()
    except Exception as e:
        # Fallback without resolution_notes if schema cache is stale
        try:
            db.table("callback_requests").update({
                "status": "resolved",
                "resolved_by_worker_id": user["id"],
            }).eq("id", callback_id).execute()
        except Exception:
            raise e

    # Notify merchant about resolved callback
    merchant_id = cb.data[0].get("merchant_id")
    visitor_name = cb.data[0].get("visitor_name") or cb.data[0].get("customer_name", "Customer")
    if merchant_id:
        from services.notification_service import create_notification
        await create_notification(
            merchant_id,
            f"Callback Resolved ✅ — {visitor_name}",
            f"Worker {user.get('name', '')} resolved the callback request.",
            "success", "callbacks", None
        )

    return success_response(message="Callback marked as resolved")


@router.post("/{callback_id}/cancel")
async def cancel_callback(callback_id: str, user: dict = Depends(get_current_worker)):
    """Worker cancels a callback (e.g., fake number, no answer after multiple attempts)."""
    db = get_db()
    db.table("callback_requests").update({
        "status": "cancelled",
        "resolved_by_worker_id": user["id"],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", callback_id).execute()

    return success_response(message="Callback cancelled")

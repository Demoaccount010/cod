"""Worker dashboard endpoints — stats, duty tracking, recent activity."""
from fastapi import APIRouter, Depends, HTTPException
from datetime import datetime, timezone, timedelta
from loguru import logger
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker", tags=["Worker"])


@router.get("/dashboard/stats")
async def worker_stats(user: dict = Depends(get_current_worker)):
    db = get_db()
    worker_id = user["id"]
    now = datetime.now(timezone.utc)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()

    # Verification stats
    today_verified = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).gte("created_at", today).execute()
    today_answered = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).eq("call_status", "answered").gte("created_at", today).execute()
    today_not_picked = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).eq("call_status", "not_picked").gte("created_at", today).execute()
    today_cancelled = db.table("order_verifications").select("id", count="exact").eq("worker_id", worker_id).eq("call_status", "cancel").gte("created_at", today).execute()

    # Active chat sessions assigned to this worker
    active_chats = db.table("chat_sessions").select("id", count="exact").eq("assigned_worker_id", worker_id).eq("status", "human_active").execute()

    # Waiting chats (need human)
    waiting_chats = db.table("chat_sessions").select("id", count="exact").eq("status", "waiting_human").execute()

    # Callback requests stats
    pending_callbacks = db.table("callback_requests").select("id", count="exact").eq("assigned_worker_id", worker_id).eq("status", "pending").execute()
    total_callbacks_today = db.table("callback_requests").select("id", count="exact").eq("assigned_worker_id", worker_id).gte("created_at", today).execute()

    # All orders summary (COD + prepaid)
    total_orders_today = db.table("orders").select("id", count="exact").gte("created_at", today).execute()
    cod_orders_today = db.table("orders").select("id", count="exact").eq("order_type", "cod").gte("created_at", today).execute()
    prepaid_orders_today = db.table("orders").select("id", count="exact").eq("order_type", "prepaid").gte("created_at", today).execute()

    # Duty info
    duty_status = user.get("duty_status", "off_duty")
    total_duty_seconds = user.get("total_duty_seconds", 0)
    current_duty_start = user.get("current_duty_start")

    # Calculate current session duration if on duty
    current_session_seconds = 0
    if duty_status == "on_duty" and current_duty_start:
        try:
            start = datetime.fromisoformat(current_duty_start.replace("Z", "+00:00"))
            current_session_seconds = int((now - start).total_seconds())
        except Exception:
            pass

    # Get merchant/store names this worker is associated with (from recent orders & chats)
    recent_merchant_ids = set()
    recent_orders = db.table("order_verifications").select("merchant_id").eq("worker_id", worker_id).order("created_at", desc=True).limit(10).execute()
    for o in (recent_orders.data or []):
        if o.get("merchant_id"):
            recent_merchant_ids.add(o["merchant_id"])
    recent_chats = db.table("chat_sessions").select("merchant_id").eq("assigned_worker_id", worker_id).order("created_at", desc=True).limit(10).execute()
    for c in (recent_chats.data or []):
        if c.get("merchant_id"):
            recent_merchant_ids.add(c["merchant_id"])

    stores_info = []
    for mid in list(recent_merchant_ids)[:10]:
        m = db.table("users").select("name, company_name, shopify_shop_domain").eq("id", mid).execute()
        s = db.table("stores").select("store_name, platform, store_url").eq("user_id", mid).limit(1).execute()
        if m.data:
            stores_info.append({
                "merchant_name": m.data[0].get("company_name") or m.data[0].get("name", ""),
                "store_name": (s.data[0].get("store_name", "") if s.data else "") or m.data[0].get("company_name", ""),
                "platform": s.data[0].get("platform", "shopify") if s.data else "shopify",
                "domain": (s.data[0].get("store_url", "") if s.data else "") or m.data[0].get("shopify_shop_domain", ""),
            })

    return success_response({
        "verification": {
            "total_today": today_verified.count or 0,
            "answered": today_answered.count or 0,
            "not_picked": today_not_picked.count or 0,
            "cancelled": today_cancelled.count or 0,
        },
        "orders": {
            "total_today": total_orders_today.count or 0,
            "cod_today": cod_orders_today.count or 0,
            "prepaid_today": prepaid_orders_today.count or 0,
        },
        "chats": {
            "active": active_chats.count or 0,
            "waiting": waiting_chats.count or 0,
        },
        "callbacks": {
            "pending": pending_callbacks.count or 0,
            "total_today": total_callbacks_today.count or 0,
        },
        "duty": {
            "status": duty_status,
            "total_seconds_today": total_duty_seconds,
            "current_session_seconds": current_session_seconds,
        },
        "stores": stores_info,
    })


@router.post("/duty/toggle")
async def toggle_duty(user: dict = Depends(get_current_worker)):
    db = get_db()
    worker_id = user["id"]
    now = datetime.now(timezone.utc)
    current_status = user.get("duty_status", "off_duty")

    if current_status == "off_duty":
        # Clock in
        db.table("users").update({
            "duty_status": "on_duty",
            "current_duty_start": now.isoformat(),
            "last_heartbeat": now.isoformat(),
            "last_duty_change": now.isoformat(),
        }).eq("id", worker_id).execute()
        db.table("worker_duty_logs").insert({
            "worker_id": worker_id, "action": "clock_in"
        }).execute()
        return success_response({"status": "on_duty"}, "You are now on duty")

    elif current_status == "on_duty":
        # Clock out — calculate duration
        start = user.get("current_duty_start")
        duration = 0
        if start:
            try:
                start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
                duration = int((now - start_dt).total_seconds())
            except Exception:
                pass
        total = (user.get("total_duty_seconds") or 0) + duration
        db.table("users").update({
            "duty_status": "off_duty",
            "current_duty_start": None,
            "total_duty_seconds": total,
            "last_duty_change": now.isoformat(),
        }).eq("id", worker_id).execute()
        db.table("worker_duty_logs").insert({
            "worker_id": worker_id, "action": "clock_out"
        }).execute()
        return success_response({"status": "off_duty", "session_duration": duration}, "You are now off duty")

    elif current_status == "break":
        # Resume from break
        db.table("users").update({
            "duty_status": "on_duty",
            "current_duty_start": now.isoformat(),
            "last_heartbeat": now.isoformat(),
            "last_duty_change": now.isoformat(),
        }).eq("id", worker_id).execute()
        db.table("worker_duty_logs").insert({
            "worker_id": worker_id, "action": "break_end"
        }).execute()
        return success_response({"status": "on_duty"}, "Break ended, you are back on duty")

    return success_response({"status": current_status})


@router.post("/duty/break")
async def take_break(user: dict = Depends(get_current_worker)):
    db = get_db()
    worker_id = user["id"]
    now = datetime.now(timezone.utc)

    if user.get("duty_status") != "on_duty":
        raise HTTPException(400, "You must be on duty to take a break")

    # Save current session time
    start = user.get("current_duty_start")
    duration = 0
    if start:
        try:
            start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
            duration = int((now - start_dt).total_seconds())
        except Exception:
            pass
    total = (user.get("total_duty_seconds") or 0) + duration

    db.table("users").update({
        "duty_status": "break",
        "current_duty_start": None,
        "total_duty_seconds": total,
        "last_duty_change": now.isoformat(),
    }).eq("id", worker_id).execute()
    db.table("worker_duty_logs").insert({
        "worker_id": worker_id, "action": "break_start"
    }).execute()

    return success_response({"status": "break"}, "You are on break")


@router.post("/heartbeat")
async def worker_heartbeat(user: dict = Depends(get_current_worker)):
    """Worker sends heartbeat every 60s to prove they are online."""
    db = get_db()
    worker_id = user["id"]
    now = datetime.now(timezone.utc)

    db.table("users").update({
        "last_heartbeat": now.isoformat(),
    }).eq("id", worker_id).execute()

    # Also clean up stale workers (anyone on_duty with heartbeat > 2 min ago)
    _check_stale_workers(db, now)

    return success_response({"status": user.get("duty_status", "off_duty")})


def _check_stale_workers(db, now=None):
    """Auto-mark workers as off_duty if their heartbeat is stale (> 2 minutes)."""
    if now is None:
        now = datetime.now(timezone.utc)
    stale_cutoff = (now - timedelta(minutes=2)).isoformat()

    # Find all on_duty or break workers with stale/null heartbeats
    stale_workers = db.table("users").select("id, last_heartbeat, current_duty_start, total_duty_seconds").eq(
        "role", "worker"
    ).in_("duty_status", ["on_duty", "break"]).or_(
        f"last_heartbeat.lt.{stale_cutoff},last_heartbeat.is.null"
    ).execute()

    for worker in (stale_workers.data or []):
        # Calculate session duration
        duration = 0
        start = worker.get("current_duty_start")
        if start:
            try:
                start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
                duration = int((now - start_dt).total_seconds())
            except Exception:
                pass
        total = (worker.get("total_duty_seconds") or 0) + duration

        db.table("users").update({
            "duty_status": "off_duty",
            "current_duty_start": None,
            "total_duty_seconds": total,
            "last_duty_change": now.isoformat(),
        }).eq("id", worker["id"]).execute()

        db.table("worker_duty_logs").insert({
            "worker_id": worker["id"], "action": "auto_offline"
        }).execute()
        logger.info(f"Worker {worker['id']} auto-marked off_duty (stale heartbeat)")

        # Reassign this worker's waiting sessions to other active workers
        stale_sessions = db.table("chat_sessions").select("id").eq(
            "assigned_worker_id", worker["id"]
        ).in_("status", ["waiting_human", "human_active"]).execute()
        if stale_sessions.data:
            # Find remaining active workers (excluding this stale one)
            cutoff_ts = (now - timedelta(minutes=2)).isoformat()
            other_workers = db.table("users").select("id, name").eq(
                "role", "worker"
            ).eq("duty_status", "on_duty").gte("last_heartbeat", cutoff_ts).neq("id", worker["id"]).execute()

            for sess in stale_sessions.data:
                if other_workers.data:
                    # Simple round-robin: pick first available
                    new_worker = other_workers.data[0]
                    db.table("chat_sessions").update({
                        "assigned_worker_id": new_worker["id"],
                    }).eq("id", sess["id"]).execute()
                else:
                    # No other workers — unassign so it appears in waiting queue
                    db.table("chat_sessions").update({
                        "assigned_worker_id": None,
                    }).eq("id", sess["id"]).execute()

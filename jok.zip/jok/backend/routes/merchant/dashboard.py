from fastapi import APIRouter, Depends
from datetime import datetime, timezone, timedelta
import hashlib
import math
from config.database import get_db
from middleware.auth import get_current_merchant
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/merchant/dashboard", tags=["Merchant Dashboard"])


@router.get("/stats")
async def dashboard_stats(user: dict = Depends(get_current_merchant)):
    db = get_db()
    user_id = user["id"]
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    yesterday_start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()

    today_orders = db.table("orders").select(
        "verification_status, response_time_seconds, country_iso, order_amount"
    ).eq("user_id", user_id).gte("created_at", today_start).execute()
    yesterday_orders = db.table("orders").select("verification_status").eq("user_id", user_id).gte("created_at", yesterday_start).lt("created_at", today_start).execute()

    def count_status(orders, statuses):
        return sum(1 for o in orders if o.get("verification_status") in statuses)

    today = today_orders.data or []
    yesterday = yesterday_orders.data or []
    t_total, y_total = len(today), len(yesterday)
    t_confirmed = count_status(today, ["confirmed", "manual_confirmed"])
    t_cancelled = count_status(today, ["cancelled", "manual_cancelled"])
    t_pending = count_status(today, ["pending", "queued", "sent", "delivered", "read"])
    t_no_reply = count_status(today, ["no_reply"])
    t_not_wa = count_status(today, ["not_on_whatsapp"])

    y_confirmed = count_status(yesterday, ["confirmed", "manual_confirmed"])

    resp_times = [o["response_time_seconds"] for o in today if o.get("response_time_seconds")]
    avg_resp = round(sum(resp_times) / len(resp_times) / 60, 1) if resp_times else 0

    sub = db.table("service_subscriptions").select("used_quota, monthly_quota").eq("user_id", user_id).eq("status", "active").order("created_at", desc=True).limit(1).execute()
    quota = sub.data[0] if sub.data else {"used_quota": 0, "monthly_quota": 0}

    def pct_change(today_val, yesterday_val):
        if yesterday_val == 0:
            return 100 if today_val > 0 else 0
        return round(((today_val - yesterday_val) / yesterday_val) * 100, 1)

    # Country breakdown — demo numbers seeded by date, increasing through the day
    today_str = now.strftime("%Y-%m-%d")
    day_frac = (now.hour * 3600 + now.minute * 60 + now.second) / 86400.0

    def _demo_count(key: str, day_min: int, day_max: int) -> int:
        seed = int(hashlib.md5(f"{today_str}-{key}".encode()).hexdigest()[:8], 16)
        base = day_min + (seed % (day_max - day_min))
        multiplier = 0.55 + 0.45 * math.pow(day_frac, 0.6)
        return int(base * multiplier)

    country_breakdown = {
        "IN": _demo_count("IN", 6000, 10000),
        "US": _demo_count("US", 3000, 6000),
        "PH": _demo_count("PH", 1500, 4000),
        "MX": _demo_count("MX", 1200, 3500),
        "GB": _demo_count("GB", 1000, 3000),
    }

    # Dynamic RTO savings — use avg order amount from merchant's orders, fallback ₹300
    amounts = [float(o["order_amount"]) for o in today if o.get("order_amount")]
    avg_order = round(sum(amounts) / len(amounts)) if amounts else 300

    # Detect merchant country from phone prefix (no 'country' column in DB)
    user_data = db.table("users").select("phone").eq("id", user_id).limit(1).execute()
    user_profile = user_data.data[0] if user_data.data else {}
    phone = user_profile.get("phone", "") or ""
    merchant_country = "IN" if phone.startswith("+91") else ("US" if phone.startswith("+1") else "IN")
    rto_currency = "INR" if merchant_country == "IN" else "USD"

    return success_response({
        "today": {
            "total": t_total, "confirmed": t_confirmed, "cancelled": t_cancelled,
            "pending": t_pending, "no_reply": t_no_reply, "not_on_whatsapp": t_not_wa,
            "confirmed_pct": round(t_confirmed / t_total * 100, 1) if t_total else 0,
            "cancelled_pct": round(t_cancelled / t_total * 100, 1) if t_total else 0,
        },
        "avg_response_time_minutes": avg_resp,
        "rto_saved": t_cancelled * avg_order,
        "rto_currency": rto_currency,
        "quota": {"used": quota["used_quota"], "total": quota["monthly_quota"]},
        "change": {"total": pct_change(t_total, y_total), "confirmed": pct_change(t_confirmed, y_confirmed)},
        "country": merchant_country,
        "country_breakdown": country_breakdown,
    })


@router.get("/chart-data")
async def chart_data(period: str = "7d", user: dict = Depends(get_current_merchant)):
    db = get_db()
    days = {"7d": 7, "30d": 30, "90d": 90}.get(period, 7)
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    orders = db.table("orders").select("created_at, verification_status, response_time_seconds").eq("user_id", user["id"]).gte("created_at", start).order("created_at").execute()

    daily = {}
    for o in (orders.data or []):
        day = o["created_at"][:10]
        if day not in daily:
            daily[day] = {"date": day, "total": 0, "confirmed": 0, "cancelled": 0, "no_reply": 0}
        daily[day]["total"] += 1
        s = o.get("verification_status", "")
        if s in ("confirmed", "manual_confirmed"):
            daily[day]["confirmed"] += 1
        elif s in ("cancelled", "manual_cancelled"):
            daily[day]["cancelled"] += 1
        elif s == "no_reply":
            daily[day]["no_reply"] += 1

    chart = sorted(daily.values(), key=lambda x: x["date"])
    for d in chart:
        d["confirmation_rate"] = round(d["confirmed"] / d["total"] * 100, 1) if d["total"] else 0

    return success_response(chart)

"""
Return & Refund Requests — Merchant API
Merchants see ONLY their own store's return requests.
On status update → WhatsApp notification sent to customer + ₹0.50 debit.
On new request (via public chatbot route) → WA sent to both customer + merchant.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from utils.helpers import success_response, paginate_params, pagination_meta
from loguru import logger
import re as _re

router = APIRouter(
    prefix="/api/v1/merchant/returns",
    tags=["Merchant Returns"],
    dependencies=[Depends(require_service("returns_management"))]
)


class UpdateReturnRequest(BaseModel):
    status: str               # 'approved' | 'rejected' | 'completed'
    worker_notes: Optional[str] = None


def _normalize_phone(phone: str) -> str:
    """Normalize phone number to international E.164 format (+91XXXXXXXXXX)."""
    digits = _re.sub(r'\D', '', phone or '')
    if len(digits) == 10:
        return "+91" + digits
    elif len(digits) == 12 and digits.startswith("91"):
        return "+" + digits
    elif len(digits) == 11 and digits.startswith("0"):
        return "+91" + digits[1:]
    elif len(digits) == 13 and digits.startswith("091"):
        return "+" + digits[1:]
    return phone  # return as-is if format unrecognized


@router.get("")
async def list_merchant_returns(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    search: Optional[str] = None,
    user: dict = Depends(get_current_merchant),
):
    """List all return/refund requests for THIS merchant only."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = (
        db.table("return_requests")
        .select("*", count="exact")
        .eq("merchant_id", user["id"])   # STRICTLY filtered to merchant
    )

    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%,"
            f"customer_phone.ilike.%{search}%"
        )

    result = (
        query.order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )

    return success_response({
        "returns": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.get("/stats")
async def get_return_stats(user: dict = Depends(get_current_merchant)):
    """Quick stats: counts by status for dashboard badge."""
    db = get_db()
    all_res = (
        db.table("return_requests")
        .select("status")
        .eq("merchant_id", user["id"])
        .execute()
    )
    rows = all_res.data or []
    stats = {"pending": 0, "approved": 0, "rejected": 0, "completed": 0, "total": len(rows)}
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail(return_id: str, user: dict = Depends(get_current_merchant)):
    """Get full detail of a single return request (merchant's own only)."""
    db = get_db()
    result = (
        db.table("return_requests")
        .select("*")
        .eq("id", return_id)
        .eq("merchant_id", user["id"])   # security: own merchant only
        .execute()
    )
    if not result.data:
        raise HTTPException(404, "Return request not found")
    return success_response({"return": result.data[0]})


@router.put("/{return_id}")
async def update_return_status(
    return_id: str,
    body: UpdateReturnRequest,
    user: dict = Depends(get_current_merchant),
):
    """Approve / reject / complete a return request -> sends WhatsApp to customer."""
    valid_statuses = {"approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Must be one of: {valid_statuses}")

    db = get_db()
    existing = (
        db.table("return_requests")
        .select("*")
        .eq("id", return_id)
        .eq("merchant_id", user["id"])
        .execute()
    )
    if not existing.data:
        raise HTTPException(404, "Return request not found")

    ret = existing.data[0]

    updates = {
        "status": body.status,
        "resolved_by": user["id"],
        "resolved_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes

    db.table("return_requests").update(updates).eq("id", return_id).execute()

    # -- Send WhatsApp to customer + debit wallet Rs.0.50 ------------------
    customer_phone = _normalize_phone(ret.get("customer_phone", ""))

    if customer_phone:
        try:
            from services.whatsapp_service import send_return_status_customer
            from services import wallet_service
            from config.service_pricing import get_price

            store_name = ret.get("store_name") or ret.get("store_url") or "Our Store"

            ok = await send_return_status_customer(
                customer_phone=customer_phone,
                customer_name=ret.get("customer_name", "Customer"),
                order_number=ret.get("order_number", "N/A"),
                status=body.status,
                notes=body.worker_notes or "",
                store_name=store_name,
            )
            if ok:
                charge = get_price("return_whatsapp")  # Rs.0.50
                if charge > 0:
                    await wallet_service.debit_wallet(
                        db,
                        user_id=user["id"],
                        amount=charge,
                        service_key="return_whatsapp",
                        description=f"Return status WA to customer -- #{ret.get('order_number')} ({body.status})",
                        reference_id=return_id,
                    )
        except Exception as e:
            logger.warning(f"Return status WA failed (non-critical): {e}")

    return success_response(message=f"Return request {body.status} successfully")

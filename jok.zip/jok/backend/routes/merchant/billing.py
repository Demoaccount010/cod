from fastapi import APIRouter, Depends, HTTPException, Request
from config.database import get_db
from middleware.auth import get_current_merchant
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/merchant/billing", tags=["Merchant Billing"])


@router.get("/current")
async def get_billing_current(user: dict = Depends(get_current_merchant)):
    """
    Contract-based billing overview.
    Returns current active contract/subscription details instead of wallet.
    """
    db = get_db()
    
    # Get active/pending contract
    contract_res = db.table("contracts").select("*").eq("user_id", user["id"]).in_("status", ["active", "pending"]).order("created_at", desc=True).limit(1).execute()
    contract = contract_res.data[0] if contract_res.data else None

    # Get service subscription metrics (quota)
    sub_res = db.table("service_subscriptions").select("*").eq("user_id", user["id"]).execute()
    sub = sub_res.data[0] if sub_res.data else {"used_quota": 0, "monthly_quota": 500} # Default free tier

    # Get recent invoices
    invoices_res = db.table("invoices").select("*").eq("user_id", user["id"]).order("created_at", desc=True).limit(5).execute()
    
    billing_model = "contract" if contract else "pay_as_you_go"

    return success_response({
        "billing_model": billing_model,
        "contract": contract,
        "subscription": sub,
        "recent_invoices": invoices_res.data or [],
        # Legacy fields for backward compatibility to prevent frontend crashes initially
        "wallet_balance": 0,
        "currency": contract.get("currency", "INR") if contract else "INR",
        "orders_remaining": max(0, sub.get("monthly_quota", 0) - sub.get("used_quota", 0)),
    })


@router.get("/wallet")
async def get_wallet(user: dict = Depends(get_current_merchant)):
    """Legacy alias, forwards to current contract view"""
    return await get_billing_current(user)


@router.get("/transactions")
async def transactions(page: int = 1, limit: int = 20, user: dict = Depends(get_current_merchant)):
    """Fetch invoice/contract payment history"""
    db = get_db()
    offset, limit = paginate_params(page, limit)
    result = db.table("invoices").select("*", count="exact").eq("user_id", user["id"]).order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"transactions": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit), "type": "invoices"})


@router.get("/usage")
async def usage_stats(period: str = "30d", user: dict = Depends(get_current_merchant)):
    """Get usage breakdown for the period."""
    db = get_db()
    from datetime import datetime, timezone, timedelta

    days = int(period.replace("d", "")) if "d" in period else 30
    start_date = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    orders = db.table("orders").select("created_at, verification_status").eq("user_id", user["id"]).gte("created_at", start_date).order("created_at").execute()

    total_orders = len(orders.data or [])
    confirmed    = sum(1 for o in (orders.data or []) if o.get("verification_status") in ("confirmed", "manual_confirmed"))
    cancelled    = sum(1 for o in (orders.data or []) if o.get("verification_status") in ("cancelled", "manual_cancelled"))

    return success_response({
        "period": period,
        "total_orders": total_orders,
        "confirmed": confirmed,
        "cancelled": cancelled,
        "confirmation_rate": round((confirmed / total_orders * 100), 1) if total_orders > 0 else 0,
    })

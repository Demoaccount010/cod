from fastapi import APIRouter, Depends
from config.database import get_db
from middleware.auth import get_current_merchant
from services.notification_service import get_unread_count, mark_as_read, mark_all_read
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/merchant/notifications", tags=["Merchant Notifications"])


@router.get("")
async def list_notifications(
    page: int = 1, limit: int = 20, unread_only: bool = False,
    user: dict = Depends(get_current_merchant)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("notifications").select("*", count="exact").eq("user_id", user["id"])
    if unread_only:
        query = query.eq("is_read", False)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({
        "notifications": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit)
    })


# ⚠️ Static routes MUST be before /{notification_id} — otherwise FastAPI matches "read-all" as an ID

@router.get("/unread-count")
async def unread_count(user: dict = Depends(get_current_merchant)):
    count = await get_unread_count(user["id"])
    return success_response({"count": count})


@router.put("/read-all")
async def read_all(user: dict = Depends(get_current_merchant)):
    await mark_all_read(user["id"])
    return success_response(message="All notifications marked as read")


@router.put("/{notification_id}/read")
async def read_notification(notification_id: str, user: dict = Depends(get_current_merchant)):
    await mark_as_read(notification_id, user["id"])
    return success_response(message="Notification marked as read")

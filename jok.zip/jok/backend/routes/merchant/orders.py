from fastapi import APIRouter, Depends, HTTPException, Query
from config.database import get_db
from middleware.auth import get_current_merchant
from models.merchant import ManualOrderUpdate, OrderEditRequest
from utils.helpers import success_response, paginate_params, pagination_meta
from services.order_processing import update_store_order
from services.notification_service import create_notification
from datetime import datetime, timezone
import json, io, csv
from fastapi.responses import StreamingResponse

router = APIRouter(prefix="/api/v1/merchant/orders", tags=["Merchant Orders"])


@router.get("")
async def list_orders(
    page: int = 1, limit: int = 20, status: str = None, search: str = None,
    date_from: str = None, date_to: str = None, store_id: str = None,
    order_type: str = None,
    sort_by: str = "created_at", sort_order: str = "desc",
    user: dict = Depends(get_current_merchant)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("orders").select("*", count="exact").eq("user_id", user["id"])
    if status:
        query = query.eq("verification_status", status)
    if store_id:
        query = query.eq("store_id", store_id)
    if order_type:
        query = query.eq("order_type", order_type)
    if date_from:
        query = query.gte("created_at", date_from)
    if date_to:
        query = query.lte("created_at", date_to)
    if search:
        query = query.or_(f"customer_name.ilike.%{search}%,order_number.ilike.%{search}%,customer_phone.ilike.%{search}%,tracking_number.ilike.%{search}%")

    desc = sort_order == "desc"
    query = query.order(sort_by, desc=desc).range(offset, offset + limit - 1)
    result = query.execute()

    return success_response({
        "orders": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.get("/export")
async def export_orders(
    format: str = "csv", status: str = None, date_from: str = None, date_to: str = None,
    user: dict = Depends(get_current_merchant)
):
    db = get_db()
    query = db.table("orders").select("*").eq("user_id", user["id"])
    if status:
        query = query.eq("verification_status", status)
    if date_from:
        query = query.gte("created_at", date_from)
    if date_to:
        query = query.lte("created_at", date_to)
    result = query.order("created_at", desc=True).execute()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Order Number", "Order Type", "Customer", "Phone", "Amount", "Currency", "Status", "Response",
                      "Delivery Status", "Tracking Number", "Tracking Company", "Payment Method", "Created At"])
    for o in (result.data or []):
        writer.writerow([
            o.get("order_number", ""), o.get("order_type", ""), o.get("customer_name", ""),
            o.get("customer_phone", ""), o.get("order_amount", ""), o.get("currency", ""),
            o.get("verification_status", ""), o.get("customer_response", ""),
            o.get("delivery_status", ""), o.get("tracking_number", ""),
            o.get("tracking_company", ""), o.get("payment_method", ""),
            o.get("created_at", ""),
        ])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=orders_export.csv"})


@router.get("/{order_id}")
async def get_order(order_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    order = db.table("orders").select("*").eq("id", order_id).eq("user_id", user["id"]).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")

    messages = db.table("messages").select("*").eq("order_id", order_id).order("created_at").execute()
    customer = None
    try:
        phone_normalized = order.data[0].get("customer_phone_normalized")
        if phone_normalized:
            from utils.phone_utils import hash_phone
            p_hash = hash_phone(phone_normalized)
            customer_result = db.table("customers_directory").select("*").eq("phone_number_hash", p_hash).execute()
            customer = customer_result.data[0] if customer_result.data else None
    except Exception:
        pass

    return success_response({
        "order": order.data[0],
        "messages": messages.data or [],
        "customer_history": customer,
    })


@router.post("/{order_id}/resend")
async def resend_verification(order_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    order = db.table("orders").select("*").eq("id", order_id).eq("user_id", user["id"]).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.data[0].get("verification_status") in ("confirmed", "cancelled", "manual_confirmed", "manual_cancelled"):
        raise HTTPException(status_code=400, detail="Cannot resend for finalized orders")
    if order.data[0].get("retry_count", 0) >= order.data[0].get("max_retries", 3):
        raise HTTPException(status_code=400, detail="Max retries reached")

    db.table("orders").update({
        "verification_status": "pending",
        "retry_count": order.data[0].get("retry_count", 0) + 1,
        "scheduled_send_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", order_id).execute()

    return success_response(message="Verification message will be resent shortly")


@router.put("/{order_id}/edit")
async def edit_order(order_id: str, body: OrderEditRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    order = db.table("orders").select("*").eq("id", order_id).eq("user_id", user["id"]).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")

    updates = {}
    for field in [
        "customer_name", "customer_phone", "customer_email", "order_amount",
        "order_type", "payment_method", "delivery_status",
        "tracking_number", "tracking_company", "tracking_url",
        "notes", "tags", "shipping_address_json",
    ]:
        val = getattr(body, field, None)
        if val is not None:
            updates[field] = val

    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    updates["updated_at"] = datetime.now(timezone.utc).isoformat()
    db.table("orders").update(updates).eq("id", order_id).execute()

    updated = db.table("orders").select("*").eq("id", order_id).execute()
    return success_response(data={"order": updated.data[0] if updated.data else None}, message="Order updated successfully")


@router.put("/{order_id}/manual-update")
async def manual_update(order_id: str, body: ManualOrderUpdate, user: dict = Depends(get_current_merchant)):
    db = get_db()
    order = db.table("orders").select("*").eq("id", order_id).eq("user_id", user["id"]).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")

    new_status = f"manual_{body.status}"
    updates = {
        "verification_status": new_status,
        "customer_response": body.status,
        "response_received_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.note:
        updates["notes"] = (order.data[0].get("notes") or "") + f"\n[Manual] {body.note}"

    db.table("orders").update(updates).eq("id", order_id).execute()
    await update_store_order(order.data[0], body.status)

    return success_response(message=f"Order manually {body.status}")


@router.put("/{order_id}/cancel")
async def cancel_order(order_id: str, user: dict = Depends(get_current_merchant)):
    """Cancel an order from dashboard — sets status to cancelled and tags Shopify."""
    db = get_db()
    order = db.table("orders").select("*").eq("id", order_id).eq("user_id", user["id"]).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")

    db.table("orders").update({
        "verification_status": "cancelled",
        "delivery_status": "cancelled",
        "customer_response": "cancelled",
        "response_received_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", order_id).execute()

    # Tag Shopify order with CODVerify-Cancelled
    await update_store_order(order.data[0], "cancelled")

    await create_notification(
        user["id"],
        "Order Cancelled",
        f"Order #{order.data[0].get('order_number', order_id)} cancelled manually.",
        "warning", "orders", f"/dashboard/orders/{order_id}"
    )

    return success_response(message="Order cancelled successfully")

from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_merchant
from models.merchant import CreateTicketRequest, TicketReplyRequest
from utils.helpers import success_response, generate_ticket_number, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/merchant/support", tags=["Merchant Support"])


@router.get("/tickets")
async def list_tickets(status: str = None, page: int = 1, limit: int = 20, user: dict = Depends(get_current_merchant)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("support_tickets").select("*", count="exact").eq("user_id", user["id"])
    if status:
        query = query.eq("status", status)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"tickets": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.post("/tickets")
async def create_ticket(body: CreateTicketRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    data = {
        "user_id": user["id"],
        "ticket_number": generate_ticket_number(),
        "subject": body.subject,
        "description": body.description,
        "priority": body.priority.value,
        "category": body.category,
    }
    result = db.table("support_tickets").insert(data).execute()
    return success_response(result.data[0], "Ticket created")


@router.get("/tickets/{ticket_id}")
async def get_ticket(ticket_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    ticket = db.table("support_tickets").select("*").eq("id", ticket_id).eq("user_id", user["id"]).execute()
    if not ticket.data:
        raise HTTPException(status_code=404, detail="Ticket not found")
    replies = db.table("support_ticket_replies").select("*").eq("ticket_id", ticket_id).order("created_at").execute()
    return success_response({"ticket": ticket.data[0], "replies": replies.data or []})


@router.post("/tickets/{ticket_id}/reply")
async def reply_ticket(ticket_id: str, body: TicketReplyRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    ticket = db.table("support_tickets").select("id").eq("id", ticket_id).eq("user_id", user["id"]).execute()
    if not ticket.data:
        raise HTTPException(status_code=404, detail="Ticket not found")
    result = db.table("support_ticket_replies").insert({
        "ticket_id": ticket_id, "user_id": user["id"], "message": body.message, "is_admin_reply": False,
    }).execute()
    db.table("support_tickets").update({"status": "open"}).eq("id", ticket_id).execute()
    return success_response(result.data[0], "Reply sent")

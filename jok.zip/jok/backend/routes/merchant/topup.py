"""
Merchant Wallet Top-Up via Razorpay.
Min: ₹2,000 | Max: ₹50,000
Flow: create order → Razorpay checkout → verify payment → credit wallet
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from config.database import get_db
from config.settings import settings
from middleware.auth import get_current_merchant
from utils.helpers import success_response
from services import wallet_service
from loguru import logger
import hmac
import hashlib

router = APIRouter(prefix="/api/v1/merchant/wallet", tags=["Merchant Wallet Top-Up"])

TOPUP_MIN = 2000.0   # ₹2,000
TOPUP_MAX = 50000.0  # ₹50,000


class TopupCreateBody(BaseModel):
    amount: float   # Amount in INR (e.g. 5000 = ₹5,000)


class TopupVerifyBody(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    amount: float   # Same amount as create


@router.post("/topup/create")
async def create_topup_order(body: TopupCreateBody, user: dict = Depends(get_current_merchant)):
    """
    Create a Razorpay order for wallet top-up.
    Returns razorpay_order_id + key for frontend checkout.
    """
    if body.amount < TOPUP_MIN:
        raise HTTPException(400, f"Minimum top-up amount is ₹{TOPUP_MIN:,.0f}")
    if body.amount > TOPUP_MAX:
        raise HTTPException(400, f"Maximum top-up amount is ₹{TOPUP_MAX:,.0f}")

    # Create Razorpay order
    try:
        from services.payment_service import create_razorpay_order
        amount_paise = int(body.amount * 100)
        order = await create_razorpay_order(
            amount_paise=amount_paise,
            currency="INR",
            receipt=f"wallet_topup_{user['id'][:8]}",
            notes={
                "user_id": user["id"],
                "type": "wallet_topup",
                "amount_inr": str(body.amount),
            },
        )
    except Exception as e:
        logger.error(f"Razorpay order creation failed: {e}")
        raise HTTPException(502, "Payment gateway error. Please try again.")

    if not order:
        raise HTTPException(502, "Failed to create payment order. Check Razorpay credentials.")

    return success_response({
        "razorpay_order_id": order["id"],
        "razorpay_key": settings.RAZORPAY_KEY_ID,
        "amount": body.amount,
        "amount_paise": int(body.amount * 100),
        "currency": "INR",
        "description": f"Wallet Top-Up — ₹{body.amount:,.0f}",
    })


@router.post("/topup/verify")
async def verify_topup_payment(body: TopupVerifyBody, user: dict = Depends(get_current_merchant)):
    """
    Verify Razorpay payment signature and credit wallet.
    Called from frontend after Razorpay checkout success.
    """
    # Verify Razorpay signature
    key_secret = getattr(settings, "RAZORPAY_KEY_SECRET", "") or ""
    if not key_secret:
        raise HTTPException(500, "Payment gateway not configured")

    expected_sig = hmac.new(
        key_secret.encode("utf-8"),
        f"{body.razorpay_order_id}|{body.razorpay_payment_id}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, body.razorpay_signature):
        logger.warning(f"Invalid Razorpay signature for user {user['id']}")
        raise HTTPException(400, "Payment verification failed. Invalid signature.")

    if body.amount < TOPUP_MIN or body.amount > TOPUP_MAX:
        raise HTTPException(400, "Invalid top-up amount")

    db = get_db()

    # Credit wallet
    try:
        updated_wallet = await wallet_service.credit_wallet(
            db,
            user_id=user["id"],
            amount=body.amount,
            description=f"Wallet Top-Up — Razorpay {body.razorpay_payment_id}",
            reference_id=body.razorpay_payment_id,
            service_key="topup",
        )
        logger.info(f"✅ Wallet top-up: ₹{body.amount} credited to user {user['id']} | payment={body.razorpay_payment_id}")
        return success_response({
            "wallet": updated_wallet,
            "payment_id": body.razorpay_payment_id,
            "amount_credited": body.amount,
        }, f"₹{body.amount:,.0f} added to your wallet!")
    except Exception as e:
        logger.error(f"Wallet credit failed after payment: {e}")
        raise HTTPException(500, "Payment received but wallet credit failed. Contact support with payment ID.")

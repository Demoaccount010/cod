"""Merchant contract endpoints — view, accept, pay via Razorpay."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from datetime import datetime, timezone, timedelta
from dateutil.relativedelta import relativedelta
from config.database import get_db
from config.settings import settings
from middleware.auth import get_current_merchant
from utils.helpers import success_response
from services import razorpay_service
from services.email_service import send_activation_invoice_email
from services.whatsapp_service import send_contract_activation_whatsapp
import uuid

router = APIRouter(prefix="/api/v1/merchant/contracts", tags=["Merchant Contracts"])


def gen_invoice_number():
    now = datetime.now()
    return f"INV-{now.strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"


# ── GET MY ACTIVE/PENDING CONTRACT ───────────────────────────────────
@router.get("/active")
async def get_active_contract(user: dict = Depends(get_current_merchant)):
    db = get_db()
    # Get latest contract (pending or active)
    contract = db.table("contracts").select("*").eq("user_id", user["id"]).in_("status", ["pending", "active"]).order("created_at", desc=True).limit(1).execute()

    if not contract.data:
        return success_response({"contract": None, "has_contract": False})

    c = contract.data[0]
    # Get invoices for this contract
    invoices = db.table("invoices").select("*").eq("contract_id", c["id"]).order("created_at", desc=True).execute()

    return success_response({
        "contract": c,
        "invoices": invoices.data or [],
        "has_contract": True,
        "razorpay_key": settings.RAZORPAY_KEY_ID,
    })


# ── GET ALL MY CONTRACTS (history) ───────────────────────────────────
@router.get("/history")
async def get_contract_history(user: dict = Depends(get_current_merchant)):
    db = get_db()
    contracts = db.table("contracts").select("*").eq("user_id", user["id"]).order("created_at", desc=True).execute()
    return success_response({"contracts": contracts.data or []})


# ── ACCEPT CONTRACT ──────────────────────────────────────────────────
@router.post("/{contract_id}/accept")
async def accept_contract(contract_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()

    # Verify contract belongs to user and is pending
    contract = db.table("contracts").select("*").eq("id", contract_id).eq("user_id", user["id"]).eq("status", "pending").single().execute()
    if not contract.data:
        raise HTTPException(404, "Contract not found or already accepted")

    c = contract.data
    pay_amount = c["advance_amount"] if c["type"] == "contract" else c["monthly_amount"]

    if pay_amount <= 0:
        # Free activation — directly activate
        now = datetime.now(timezone.utc)
        end = now + relativedelta(months=c["duration_months"])
        db.table("contracts").update({
            "status": "active",
            "accepted_at": now.isoformat(),
            "paid_at": now.isoformat(),
            "start_date": now.isoformat(),
            "end_date": end.isoformat(),
            "updated_at": now.isoformat(),
        }).eq("id", contract_id).execute()
        db.table("users").update({"account_status": "active"}).eq("id", user["id"]).execute()
        # Activate chatbot if the contract includes one
        chatbot_tier = c.get("chatbot_tier") or "none"
        if chatbot_tier != "none":
            db.table("merchant_chatbot_config").upsert({
                "merchant_id": user["id"],
                "is_enabled": True,
                "chatbot_tier": chatbot_tier,
            }, on_conflict="merchant_id").execute()
        # Send activation email
        user_info = db.table("users").select("email, name, phone, company_name").eq("id", user["id"]).single().execute()
        if user_info.data:
            updated = db.table("contracts").select("*").eq("id", contract_id).single().execute()
            activated_c = updated.data or c
            await send_activation_invoice_email(
                user_info.data["email"],
                user_info.data.get("name", ""),
                activated_c,
            )
            merchant_phone = user_info.data.get("phone", "")
            if merchant_phone:
                await send_contract_activation_whatsapp(
                    merchant_phone=merchant_phone,
                    merchant_name=user_info.data.get("name", ""),
                    store_name=user_info.data.get("company_name") or user_info.data.get("name", ""),
                    contract_number=activated_c.get("contract_number", ""),
                    paid_amount=0.0,
                    pending_amount=0.0,
                    currency=activated_c.get("currency", "INR"),
                )
        return success_response({"activated": True, "message": "Contract activated (no payment required)"})

    # Create Razorpay order for the pay_amount
    amount_paise = int(pay_amount * 100)
    rz_order = razorpay_service.create_order(
        amount_paise=amount_paise,
        currency=c.get("currency", "INR"),
        receipt=f"contract-{contract_id[:8]}",
        notes={"contract_id": contract_id, "user_id": user["id"]},
    )

    # Create invoice record
    invoice_data = {
        "contract_id": contract_id,
        "user_id": user["id"],
        "invoice_number": gen_invoice_number(),
        "type": "advance" if c["type"] == "contract" else "monthly",
        "status": "pending",
        "amount": pay_amount,
        "currency": c.get("currency", "INR"),
        "description": f"{'Advance payment' if c['type'] == 'contract' else 'Monthly payment'} — {c.get('contract_number', '')}",
        "razorpay_order_id": rz_order["id"],
    }
    db.table("invoices").insert(invoice_data).execute()

    # Mark contract as accepted (but not yet active — needs payment)
    db.table("contracts").update({
        "accepted_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", contract_id).execute()

    return success_response({
        "razorpay_order_id": rz_order["id"],
        "razorpay_key": settings.RAZORPAY_KEY_ID,
        "amount": amount_paise,
        "currency": c.get("currency", "INR"),
        "contract_number": c.get("contract_number", ""),
    })


# ── VERIFY PAYMENT — called after Razorpay checkout success ──────────
class PaymentVerify(BaseModel):
    contract_id: str
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


@router.post("/verify-payment")
async def verify_payment(body: PaymentVerify, user: dict = Depends(get_current_merchant)):
    db = get_db()

    # Verify signature
    is_valid = razorpay_service.verify_payment(body.razorpay_order_id, body.razorpay_payment_id, body.razorpay_signature)
    if not is_valid:
        raise HTTPException(400, "Payment verification failed — invalid signature")

    # Verify contract belongs to user
    contract = db.table("contracts").select("*").eq("id", body.contract_id).eq("user_id", user["id"]).single().execute()
    if not contract.data:
        raise HTTPException(404, "Contract not found")

    c = contract.data
    now = datetime.now(timezone.utc)
    end = now + relativedelta(months=c["duration_months"])

    # Update invoice — mark paid
    db.table("invoices").update({
        "status": "paid",
        "razorpay_payment_id": body.razorpay_payment_id,
        "razorpay_signature": body.razorpay_signature,
        "paid_at": now.isoformat(),
    }).eq("razorpay_order_id", body.razorpay_order_id).execute()

    # Activate contract
    db.table("contracts").update({
        "status": "active",
        "paid_at": now.isoformat(),
        "start_date": now.isoformat(),
        "end_date": end.isoformat(),
        "updated_at": now.isoformat(),
    }).eq("id", body.contract_id).execute()

    # Activate user account
    db.table("users").update({"account_status": "active"}).eq("id", user["id"]).execute()

    # Activate chatbot service based on contract tier
    chatbot_tier = c.get("chatbot_tier") or "none"
    if chatbot_tier != "none":
        db.table("merchant_chatbot_config").upsert({
            "merchant_id": user["id"],
            "is_enabled": True,
            "chatbot_tier": chatbot_tier,
        }, on_conflict="merchant_id").execute()

    # Create pending invoice for remaining balance (contract type only)
    if c["type"] == "contract":
        advance = float(c.get("advance_amount") or 0)
        total = float(c.get("total_amount") or 0)
        remaining = round(total - advance, 2)
        if remaining > 0:
            db.table("invoices").insert({
                "contract_id": body.contract_id,
                "user_id": user["id"],
                "invoice_number": gen_invoice_number(),
                "type": "one_time",
                "status": "pending",
                "amount": remaining,
                "currency": c.get("currency", "INR"),
                "description": f"Remaining balance — {c.get('contract_number', '')}",
            }).execute()

    # Send activation invoice email + WhatsApp
    user_info = db.table("users").select("email, name, phone, company_name").eq("id", user["id"]).single().execute()
    if user_info.data:
        updated = db.table("contracts").select("*").eq("id", body.contract_id).single().execute()
        activated_c = updated.data or c
        await send_activation_invoice_email(
            user_info.data["email"],
            user_info.data.get("name", ""),
            activated_c,
        )
        merchant_phone = user_info.data.get("phone", "")
        if merchant_phone:
            advance = float(c.get("advance_amount") or 0)
            total = float(c.get("total_amount") or 0)
            pending_wa = round(total - advance, 2) if c["type"] == "contract" and total > advance else 0.0
            await send_contract_activation_whatsapp(
                merchant_phone=merchant_phone,
                merchant_name=user_info.data.get("name", ""),
                store_name=user_info.data.get("company_name") or user_info.data.get("name", ""),
                contract_number=activated_c.get("contract_number", ""),
                paid_amount=float(c.get("advance_amount") or c.get("monthly_amount") or 0),
                pending_amount=pending_wa,
                currency=activated_c.get("currency", "INR"),
            )

    return success_response({
        "activated": True,
        "message": "Payment verified! Your account is now active.",
        "contract_start": now.isoformat(),
        "contract_end": end.isoformat(),
    })


# ── GET BILLING STATEMENTS ───────────────────────────────────────────
@router.get("/billing/statements")
async def get_billing_statements(user: dict = Depends(get_current_merchant)):
    db = get_db()
    invoices = db.table("invoices").select("*, contracts(contract_number, type, services)").eq("user_id", user["id"]).order("created_at", desc=True).execute()
    
    # Compute totals
    all_inv = invoices.data or []
    total_paid = sum(float(i["amount"]) for i in all_inv if i["status"] == "paid")
    total_pending = sum(float(i["amount"]) for i in all_inv if i["status"] == "pending")

    return success_response({
        "invoices": all_inv,
        "summary": {
            "total_paid": total_paid,
            "total_pending": total_pending,
            "total_invoices": len(all_inv),
        }
    })


# ── DISABLE AUTO-PAYMENT (triggers instant blacklist) ─────────────────
@router.post("/{contract_id}/disable-auto-payment")
async def disable_auto_payment(contract_id: str, user: dict = Depends(get_current_merchant)):
    """
    Disable auto-payment for a contract.
    Consequence: Merchant is instantly blacklisted.
    This prevents payment fraud and ensures contract compliance.
    """
    db = get_db()

    # Verify contract belongs to user
    contract = db.table("contracts").select("*").eq("id", contract_id).eq("user_id", user["id"]).single().execute()
    if not contract.data:
        raise HTTPException(404, "Contract not found")

    c = contract.data
    
    # Disable auto-payment flag on contract
    db.table("contracts").update({
        "auto_payment_enabled": False,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", contract_id).execute()

    # Blacklist merchant
    now = datetime.now(timezone.utc)
    db.table("users").update({
        "blacklist_status": "blacklisted",
        "blacklist_reason": "auto_payment_disabled",
        "blacklist_date": now.isoformat(),
    }).eq("id", user["id"]).execute()

    # Log blacklist event
    db.table("contract_blacklist").insert({
        "merchant_id": user["id"],
        "reason": "auto_payment_disabled",
        "notes": f"Merchant {user['id']} disabled auto-payment on contract {c.get('contract_number')}",
        "created_at": now.isoformat(),
    }).execute()

    return success_response({
        "message": "Auto-payment has been disabled. Your account is now blacklisted per contract terms. Please contact support to restore access.",
        "blacklist_date": now.isoformat(),
    })


# ── ENABLE AUTO-PAYMENT ────────────────────────────────────────────────
@router.post("/{contract_id}/enable-auto-payment")
async def enable_auto_payment(contract_id: str, user: dict = Depends(get_current_merchant)):
    """Enable auto-payment for a contract."""
    db = get_db()
    contract = db.table("contracts").select("*").eq("id", contract_id).eq("user_id", user["id"]).single().execute()
    if not contract.data:
        raise HTTPException(404, "Contract not found")

    db.table("contracts").update({
        "auto_payment_enabled": True,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", contract_id).execute()

    return success_response({"message": "Auto-payment enabled successfully.", "auto_payment_enabled": True})

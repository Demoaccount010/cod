import math
import uuid
from datetime import datetime, timezone


def generate_ticket_number() -> str:
    now = datetime.now(timezone.utc)
    return f"TK-{now.strftime('%y%m%d')}-{uuid.uuid4().hex[:5].upper()}"


def generate_invoice_number() -> str:
    now = datetime.now(timezone.utc)
    return f"INV-{now.strftime('%Y%m')}-{uuid.uuid4().hex[:6].upper()}"


def calculate_reading_time(content: str) -> int:
    words = len(content.split())
    return max(1, math.ceil(words / 200))


def slugify(text: str) -> str:
    import re
    slug = text.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    return slug.strip("-")


def paginate_params(page: int = 1, limit: int = 20) -> tuple[int, int]:
    page = max(1, page)
    limit = min(100, max(1, limit))
    offset = (page - 1) * limit
    return offset, limit


def pagination_meta(total: int, page: int, limit: int) -> dict:
    total_pages = max(1, math.ceil(total / limit))
    return {
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": total_pages,
        "has_next": page < total_pages,
        "has_prev": page > 1,
    }


def success_response(data=None, message: str = "Success"):
    return {"success": True, "data": data, "message": message, "errors": []}


def error_response(message: str = "Error", errors: list = None, data=None):
    return {"success": False, "data": data, "message": message, "errors": errors or []}

from pydantic import BaseModel, Field
from typing import Optional, List, Any


class AdminMerchantStatusUpdate(BaseModel):
    status: str
    reason: Optional[str] = None


class AdminMerchantPlanUpdate(BaseModel):
    plan_type: str
    monthly_quota: Optional[int] = None
    end_date: Optional[str] = None


class AdminAddCredits(BaseModel):
    extra_quota: int = Field(..., gt=0)
    reason: Optional[str] = None


class AdminManualCredit(BaseModel):
    merchant_id: str
    amount: float
    type: str = Field(..., pattern="^(credit|refund)$")
    description: Optional[str] = None


class AdminWalletCredit(BaseModel):
    merchant_id: str
    amount: float = Field(..., gt=0)
    reason: Optional[str] = None


class AdminUpdatePricing(BaseModel):
    per_order_rate: float = Field(..., gt=0)
    description: Optional[str] = None


class CreatePartnerRequest(BaseModel):
    partner_name: str = Field(..., min_length=2)
    partner_logo_url: Optional[str] = None
    partner_website_url: Optional[str] = None
    short_description: Optional[str] = None
    full_description: Optional[str] = None
    category: Optional[str] = None
    is_active: bool = True
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    meta_keywords: Optional[str] = None


class UpdatePartnerRequest(BaseModel):
    partner_name: Optional[str] = None
    partner_logo_url: Optional[str] = None
    partner_website_url: Optional[str] = None
    short_description: Optional[str] = None
    full_description: Optional[str] = None
    category: Optional[str] = None
    is_active: Optional[bool] = None
    display_order: Optional[int] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    meta_keywords: Optional[str] = None


class ReorderPartnersRequest(BaseModel):
    items: List[dict]


class CreateBlogPostRequest(BaseModel):
    title: str = Field(..., min_length=3)
    content: str = Field(..., min_length=10)
    excerpt: Optional[str] = None
    featured_image_url: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    meta_keywords: Optional[str] = None
    is_published: bool = False
    is_featured: bool = False


class UpdateBlogPostRequest(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    excerpt: Optional[str] = None
    featured_image_url: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    meta_keywords: Optional[str] = None
    is_published: Optional[bool] = None
    is_featured: Optional[bool] = None


class AdminTicketUpdate(BaseModel):
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[str] = None


class AdminSettingsUpdate(BaseModel):
    settings: List[dict]


class AdminBlacklistRequest(BaseModel):
    phone_number: str
    reason: Optional[str] = None


class ContactFormRequest(BaseModel):
    name: str = Field(..., min_length=2)
    email: str
    phone: Optional[str] = None
    company: Optional[str] = None
    message: str = Field(..., min_length=10)


class CreateReviewRequest(BaseModel):
    author_name: str = Field(..., min_length=2, max_length=255)
    author_company: Optional[str] = None
    author_role: Optional[str] = None
    rating: int = Field(..., ge=1, le=5)
    title: Optional[str] = Field(None, max_length=500)
    body: str = Field(..., min_length=10)


class UpdateReviewRequest(BaseModel):
    author_name: Optional[str] = None
    author_company: Optional[str] = None
    author_role: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)
    title: Optional[str] = None
    body: Optional[str] = None
    is_approved: Optional[bool] = None
    is_featured: Optional[bool] = None
    is_visible: Optional[bool] = None
    admin_note: Optional[str] = None

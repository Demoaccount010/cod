/**
 * CODVerify Chatbot Widget v5.1 — Bug Fixes
 * Conversational callback flow + premium message design.
 *
 * Usage:
 *   <script src="https://api.codverify.tech/static/chatbot-widget.js?v=5"
 *           data-codverify-key="ck_YOUR_KEY"
 *           data-codverify-api="https://api.codverify.tech"></script>
 */
(function () {
  'use strict';

  var script = document.currentScript || (function () {
    var s = document.getElementsByTagName('script');
    return s[s.length - 1];
  })();
  var API_KEY  = (script.getAttribute('data-codverify-key')  || '').trim();
  var API_BASE = (script.getAttribute('data-codverify-api')  || 'https://api.codverify.tech').replace(/\/$/, '');

  if (!API_KEY) { console.warn('[CODVerify] data-codverify-key is required'); return; }

  // ── State ──────────────────────────────────────────────────────────────────
  var S = {
    open:      false,
    inited:    false,
    sessionId: null,
    status:    'idle',
    tier:      'chatbot_basic',
    config:    null,
    pollTimer: null,
    msgCount:  0,
    // Conversational callback state
    cb: {
      active: false,   // currently collecting callback info
      step:   0,       // 0=name, 1=phone, 2=email, 3=reason, 4=done
      data:   {},      // collected fields
    },
    botName:   'Support',
    botIni:    'SB',
  };

  // ── Network ────────────────────────────────────────────────────────────────
  function get(path, cb) {
    fetch(API_BASE + path, { headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }
  function post(path, body, cb) {
    fetch(API_BASE + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }

  // ── CSS ────────────────────────────────────────────────────────────────────
  function buildCSS(c, theme) {
    var grad   = 'linear-gradient(135deg,' + c + ' 0%,#7c3aed 100%)';
    var isDark = (theme !== 'light');

    // Colour tokens
    var winBg   = isDark ? 'linear-gradient(160deg,#0d0d1a 0%,#12122a 100%)' : '#f8fafc';
    var winBor  = isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.1)';
    var winShad = isDark ? '0 28px 90px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.05)' : '0 20px 60px rgba(0,0,0,.18)';
    var bodyBg  = isDark ? 'transparent' : '#f0f2f8';
    var scrollT = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.12)';
    var sLblClr = isDark ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.4)';
    var tsClr   = isDark ? 'rgba(255,255,255,.22)' : 'rgba(0,0,0,.28)';

    // Bot bubbles
    var bBubBg  = isDark ? 'rgba(255,255,255,.08)' : '#ffffff';
    var bBubClr = isDark ? 'rgba(255,255,255,.9)'  : '#1e293b';
    var bBubBor = isDark ? '1px solid rgba(255,255,255,.09)' : '1px solid #e2e8f0';
    var bBubShd = isDark ? 'none' : '0 1px 4px rgba(0,0,0,.07)';

    // Worker bubbles
    var wBubBg  = isDark ? 'rgba(52,211,153,.12)' : '#f0fdf4';
    var wBubClr = isDark ? '#6ee7b7' : '#166534';
    var wBubBor = isDark ? '1px solid rgba(52,211,153,.18)' : '1px solid #bbf7d0';

    // Visitor bubbles (always gradient)
    var vBubShd = '0 4px 18px rgba(99,102,241,.35)';

    // System
    var sysClr  = isDark ? 'rgba(255,255,255,.35)' : '#94a3b8';
    var sysBg   = isDark ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.04)';

    // Typing
    var typBg   = isDark ? 'rgba(255,255,255,.08)' : '#ffffff';
    var typBor  = isDark ? '1px solid rgba(255,255,255,.07)' : '1px solid #e2e8f0';
    var typDot  = isDark ? 'rgba(255,255,255,.35)' : '#94a3b8';

    // Quick buttons
    var qBg     = isDark ? 'rgba(255,255,255,.06)' : '#ffffff';
    var qBor    = isDark ? '1.5px solid rgba(255,255,255,.1)' : '1.5px solid #e2e8f0';
    var qClr    = isDark ? 'rgba(255,255,255,.78)' : '#374151';

    // Input
    var footBg  = isDark ? 'rgba(0,0,0,.2)' : '#f8fafc';
    var footBor = isDark ? '1px solid rgba(255,255,255,.06)' : '1px solid #e2e8f0';
    var inpBg   = isDark ? 'rgba(255,255,255,.07)' : '#ffffff';
    var inpBor  = isDark ? '1.5px solid rgba(255,255,255,.09)' : '1.5px solid #e2e8f0';
    var inpClr  = isDark ? 'rgba(255,255,255,.9)' : '#1e293b';
    var inpPh   = isDark ? 'rgba(255,255,255,.28)' : '#9ca3af';

    // Callback strip
    var cbbBg   = isDark ? 'rgba(255,255,255,.04)' : '#f1f5f9';
    var cbbBor  = isDark ? '1.5px solid rgba(255,255,255,.09)' : '1.5px solid #e2e8f0';
    var cbbClr  = isDark ? 'rgba(255,255,255,.55)' : '#64748b';

    // Branding
    var brdBg   = isDark ? 'rgba(255,255,255,.02)' : '#f1f5f9';
    var brdBor  = isDark ? '1px solid rgba(255,255,255,.05)' : '1px solid #e2e8f0';
    var brdClr  = isDark ? 'rgba(255,255,255,.22)' : '#94a3b8';
    var brdLink = isDark ? 'rgba(255,255,255,.55)'  : c;

    // Bot avatar (inside messages)
    var avMsgBg = isDark ? 'rgba(255,255,255,.1)' : 'rgba(99,102,241,.12)';
    var avMsgCl = isDark ? 'rgba(255,255,255,.7)' : c;

    return [
      '@import url(\'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap\');',
      '#cvw *{box-sizing:border-box;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;margin:0;padding:0}',

      // ── Launch bubble
      '#cvw-btn{position:fixed;bottom:24px;right:24px;z-index:2147483646;width:58px;height:58px;border-radius:50%;background:' + grad + ';box-shadow:0 8px 32px rgba(99,102,241,.5),0 2px 8px rgba(0,0,0,.25);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .22s}',
      '#cvw-btn:hover{transform:scale(1.12);box-shadow:0 12px 40px rgba(99,102,241,.6)}',
      '#cvw-btn svg{width:26px;height:26px;fill:#fff}',
      '#cvw-badge{position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;min-width:18px;height:18px;border-radius:9px;padding:0 5px;display:none;align-items:center;justify-content:center;pointer-events:none;box-shadow:0 2px 6px rgba(239,68,68,.5)}',
      '#cvw-btn::before{content:"";position:absolute;inset:-5px;border-radius:50%;border:2px solid rgba(99,102,241,.4);animation:cvwring 2.8s ease-out infinite}',
      '@keyframes cvwring{0%{transform:scale(1);opacity:.6}70%{transform:scale(1.35);opacity:0}100%{transform:scale(1.35);opacity:0}}',

      // ── Window
      '#cvw-win{position:fixed;bottom:96px;right:24px;z-index:2147483645;width:375px;height:600px;border-radius:24px;background:' + winBg + ';border:1px solid ' + winBor + ';box-shadow:' + winShad + ';display:flex;flex-direction:column;overflow:hidden;transform:translateY(22px) scale(.93);transform-origin:bottom right;opacity:0;pointer-events:none;transition:transform .32s cubic-bezier(.34,1.56,.64,1),opacity .22s ease}',
      '#cvw-win.on{transform:translateY(0) scale(1);opacity:1;pointer-events:all}',

      // ── Header
      '#cvw-head{background:' + grad + ';padding:14px 18px;display:flex;align-items:center;gap:12px;flex-shrink:0;position:relative;overflow:hidden}',
      '#cvw-head::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.1) 0%,transparent 100%);pointer-events:none}',
      '#cvw-av{width:42px;height:42px;border-radius:13px;background:rgba(255,255,255,.2);backdrop-filter:blur(10px);border:1.5px solid rgba(255,255,255,.3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:#fff;flex-shrink:0;box-shadow:0 4px 14px rgba(0,0,0,.2)}',
      '#cvw-hi{flex:1;min-width:0}',
      '#cvw-hn{font-size:14px;font-weight:700;color:#fff;letter-spacing:.01em;line-height:1.3}',
      '#cvw-hs{font-size:11px;color:rgba(255,255,255,.75);display:flex;align-items:center;gap:5px;margin-top:2px;font-weight:500}',
      '.cvw-dot{width:7px;height:7px;border-radius:50%;background:#4ade80;flex-shrink:0;box-shadow:0 0 0 2px rgba(74,222,128,.2);animation:cvwpulse 2.2s ease-in-out infinite}',
      '@keyframes cvwpulse{0%,100%{box-shadow:0 0 0 2px rgba(74,222,128,.2)}50%{box-shadow:0 0 0 6px rgba(74,222,128,.06)}}',
      '#cvw-x{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);cursor:pointer;padding:7px;border-radius:10px;display:flex;flex-shrink:0;transition:background .18s,transform .18s;margin-left:auto}',
      '#cvw-x:hover{background:rgba(255,255,255,.26);transform:scale(1.06)}',

      // ── Messages area
      '#cvw-body{flex:1;overflow-y:auto;padding:16px 14px 8px;display:flex;flex-direction:column;gap:2px;scroll-behavior:smooth;background:' + bodyBg + '}',
      '#cvw-body::-webkit-scrollbar{width:3px}',
      '#cvw-body::-webkit-scrollbar-track{background:transparent}',
      '#cvw-body::-webkit-scrollbar-thumb{background:' + scrollT + ';border-radius:3px}',

      // ── Message row (wraps avatar + bubble + timestamp)
      '.cw{display:flex;flex-direction:column;margin-bottom:4px;width:100%;animation:cvwfade .26s cubic-bezier(.22,1,.36,1)}',
      '@keyframes cvwfade{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}',
      '.cw.r{align-items:flex-end}',

      // ── Row inner (avatar + bubble side by side)
      '.cw-row{display:flex;align-items:flex-end;gap:8px;max-width:86%}',
      '.cw.r .cw-row{flex-direction:row-reverse;justify-content:flex-end;margin-left:auto}',

      // ── Mini avatar beside bot/worker messages
      '.cmav{width:26px;height:26px;border-radius:8px;background:' + avMsgBg + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.1)' : 'rgba(99,102,241,.15)') + ';display:flex;align-items:center;justify-content:center;font-weight:700;font-size:9px;color:' + avMsgCl + ';flex-shrink:0;margin-bottom:2px}',
      '.cw.r .cmav{display:none}',   // no avatar on visitor side

      // ── Sender label (above bubble)
      '.cs{font-size:10px;color:' + sLblClr + ';padding:0 4px;font-weight:600;margin-bottom:3px;letter-spacing:.03em}',
      '.cw.r .cs{text-align:right}',

      // ── Bubble
      '.cm{max-width:100%;padding:10px 14px;border-radius:17px;font-size:13.5px;line-height:1.65;word-break:break-word;white-space:pre-wrap;font-weight:400}',
      '.cm.b{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-bottom-left-radius:4px;box-shadow:' + bBubShd + '}',
      '.cm.a{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-bottom-left-radius:4px;box-shadow:' + bBubShd + '}',
      '.cm.w{background:' + wBubBg + ';color:' + wBubClr + ';border:' + wBubBor + ';border-bottom-left-radius:4px}',
      '.cm.v{background:' + grad + ';color:#fff;border-bottom-right-radius:4px;box-shadow:' + vBubShd + '}',
      '.cm.s{background:' + sysBg + ';color:' + sysClr + ';font-size:11px;align-self:center;text-align:center;padding:5px 14px;max-width:100%;border:none;border-radius:20px;font-style:italic;margin:6px 0}',

      // ── Timestamp + ticks row
      '.cts{font-size:10px;color:' + tsClr + ';padding:2px 4px 0;display:flex;align-items:center;gap:4px}',
      '.cw.r .cts{justify-content:flex-end}',
      '.cvw-tick{display:inline-flex;align-items:center;opacity:.6}',

      // ── Typing indicator
      '.ctyp{display:flex;gap:5px;align-items:center;padding:10px 14px;background:' + typBg + ';border-radius:17px;border-bottom-left-radius:4px;width:max-content;border:' + typBor + ';margin-bottom:4px}',
      '.ctyp span{width:7px;height:7px;background:' + typDot + ';border-radius:50%;animation:ctb .95s infinite ease-in-out}',
      '.ctyp span:nth-child(2){animation-delay:.16s}.ctyp span:nth-child(3){animation-delay:.32s}',
      '@keyframes ctb{0%,60%,100%{transform:translateY(0);opacity:.4}30%{transform:translateY(-6px);opacity:1}}',

      // ── Quick buttons
      '.cqb{display:inline-block;margin:3px 4px 3px 0;padding:8px 15px;background:' + qBg + ';border:' + qBor + ';color:' + qClr + ';border-radius:22px;font-size:12.5px;cursor:pointer;transition:all .2s;white-space:nowrap;font-weight:500}',
      '.cqb:hover{background:rgba(99,102,241,.1);border-color:' + c + ';color:' + c + ';transform:translateY(-1px)}',

      // ── Input footer
      '#cvw-foot{padding:10px 14px 12px;border-top:' + footBor + ';display:flex;gap:9px;align-items:flex-end;flex-shrink:0;background:' + footBg + '}',
      '#cvw-inp{flex:1;padding:10px 14px;background:' + inpBg + ';border:' + inpBor + ';border-radius:14px;font-size:13.5px;outline:none;resize:none;max-height:80px;min-height:42px;line-height:1.55;color:' + inpClr + ';transition:border-color .2s;font-family:inherit}',
      '#cvw-inp::placeholder{color:' + inpPh + '}',
      '#cvw-inp:focus{border-color:' + c + '}',
      '#cvw-snd{background:' + grad + ';border:none;border-radius:13px;width:42px;height:42px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .18s;box-shadow:0 4px 18px rgba(99,102,241,.38);position:relative;overflow:hidden}',
      '#cvw-snd::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.15),transparent);border-radius:inherit}',
      '#cvw-snd:hover{transform:scale(1.1);box-shadow:0 6px 22px rgba(99,102,241,.55)}',
      '#cvw-snd:active{transform:scale(.95)}',
      '#cvw-snd svg{width:18px;height:18px;fill:#fff;position:relative}',

      // ── Callback strip button
      '#cvw-cbb{padding:0 14px 10px;flex-shrink:0}',
      '#cvw-cbb button{width:100%;padding:9px 16px;background:' + cbbBg + ';border:' + cbbBor + ';border-radius:13px;font-size:12.5px;color:' + cbbClr + ';cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:7px;font-family:inherit;font-weight:500;letter-spacing:.01em}',
      '#cvw-cbb button:hover{border-color:' + c + ';color:' + c + '}',

      // ── Skip / cancel buttons inside chat (callback flow)
      '.cvw-skip{display:inline-block;margin:4px 4px 4px 0;padding:7px 16px;background:transparent;border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.12)' : '#e2e8f0') + ';color:' + (isDark ? 'rgba(255,255,255,.5)' : '#94a3b8') + ';border-radius:20px;font-size:12.5px;cursor:pointer;transition:all .18s;font-family:inherit;font-weight:500}',
      '.cvw-skip:hover{border-color:' + c + ';color:' + c + '}',
      '.cvw-cbcancel{display:inline-block;margin:4px 4px 4px 0;padding:7px 16px;background:rgba(239,68,68,.08);border:1.5px solid rgba(239,68,68,.2);color:#f87171;border-radius:20px;font-size:12.5px;cursor:pointer;transition:all .18s;font-family:inherit;font-weight:500}',
      '.cvw-cbcancel:hover{background:rgba(239,68,68,.15)}',

      // ── Branding footer
      '#cvw-brd{padding:6px 16px;border-top:' + brdBor + ';background:' + brdBg + ';display:flex;align-items:center;justify-content:center;gap:5px;flex-shrink:0}',
      '#cvw-brd span{font-size:10px;color:' + brdClr + ';font-weight:500}',
      '#cvw-brd a{font-size:10px;font-weight:700;color:' + brdLink + ';text-decoration:none;transition:opacity .15s}',
      '#cvw-brd a:hover{opacity:.7}',

      // ── Mobile
      '@media(max-width:420px){#cvw-win{width:calc(100vw - 12px);right:6px;border-radius:24px 24px 0 0;bottom:0;height:90vh}#cvw-btn{bottom:20px;right:16px}}',
    ].join('\n');
  }

  // ── Build DOM ──────────────────────────────────────────────────────────────
  function build(cfg) {
    var c     = cfg.primary_color || '#6366f1';
    var nm    = cfg.bot_name      || 'Support';
    var theme = cfg.widget_theme  || 'dark';
    var ini   = nm.split(' ').map(function (w) { return w[0] || ''; }).join('').slice(0, 2).toUpperCase();

    S.botName = nm;
    S.botIni  = ini;

    var style = document.createElement('style');
    style.textContent = buildCSS(c, theme);
    document.head.appendChild(style);

    var root = document.createElement('div');
    root.id = 'cvw';
    root.innerHTML = [
      // Launch bubble
      '<button id="cvw-btn" aria-label="Open chat">',
      '  <div id="cvw-badge">1</div>',
      '  <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
      '</button>',
      // Chat window
      '<div id="cvw-win" role="dialog" aria-label="Chat support">',
      '  <div id="cvw-head">',
      '    <div id="cvw-av">' + esc(ini) + '</div>',
      '    <div id="cvw-hi">',
      '      <div id="cvw-hn">' + esc(nm) + '</div>',
      '      <div id="cvw-hs"><span class="cvw-dot"></span>&nbsp;Online</div>',
      '    </div>',
      '    <button id="cvw-x" aria-label="Close"><svg viewBox="0 0 24 24" width="16" height="16" fill="white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-body"></div>',
      '  <div id="cvw-cbb"><button id="cvw-cbb-btn">',
      '    <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>',
      '    Request a Callback',
      '  </button></div>',
      '  <div id="cvw-foot">',
      '    <textarea id="cvw-inp" rows="1" placeholder="Type a message..." maxlength="2000"></textarea>',
      '    <button id="cvw-snd" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-brd">',
      '    <span>Powered by</span>',
      '    <a href="https://codverify.tech" target="_blank" rel="noopener">⚡ CODVerify</a>',
      '  </div>',
      '</div>',
    ].join('');
    document.body.appendChild(root);

    // Events
    q('#cvw-btn').addEventListener('click', toggle);
    q('#cvw-x').addEventListener('click', function () { setOpen(false); });
    q('#cvw-snd').addEventListener('click', onSend);
    q('#cvw-cbb-btn').addEventListener('click', startCallbackFlow);
    q('#cvw-inp').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); }
      autoH(this);
    });
    q('#cvw-inp').addEventListener('input', function () { autoH(this); });
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  function q(s)     { return document.querySelector(s); }
  function esc(s)   { return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function tr(v)    { return (v || '').trim(); }
  function autoH(e) { e.style.height = 'auto'; e.style.height = Math.min(e.scrollHeight, 80) + 'px'; }
  function scrl()   { var b = q('#cvw-body'); if (b) setTimeout(function () { b.scrollTop = b.scrollHeight; }, 30); }
  function now()    { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

  // ── Open / Close ──────────────────────────────────────────────────────────
  function toggle() { setOpen(!S.open); }
  function setOpen(v) {
    S.open = v;
    var win = q('#cvw-win');
    if (v) {
      win.classList.add('on');
      q('#cvw-badge').style.display = 'none';
      if (!S.inited) init();
      setTimeout(function () { var i = q('#cvw-inp'); if (i && !S.cb.active) i.focus(); }, 280);
    } else {
      win.classList.remove('on');
    }
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    S.inited = true;
    var cfg  = S.config;
    S.tier   = cfg.chatbot_tier || 'chatbot_basic';

    addBubble('b', cfg.welcome_message || 'Hi! 👋 How can I help you today?');

    // Quick-option buttons
    var opts = cfg.menu_options || [];
    if (opts.length) {
      var body = q('#cvw-body');
      var wrap = document.createElement('div');
      wrap.id = 'cvw-opts';
      wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;padding:4px 0 8px';
      opts.forEach(function (o) {
        var btn = document.createElement('button');
        btn.className = 'cqb';
        btn.textContent = o.label;
        btn.addEventListener('click', function () {
          wrap.remove();
          addBubble('v', o.label);
          setTimeout(function () {
            addBubble('b', o.answer);
          }, 600);
          if (!S.sessionId) startSession(o.label, true);
        });
        wrap.appendChild(btn);
      });
      body.appendChild(wrap);
      scrl();
    }

    // Basic tier — check worker availability
    if (S.tier === 'chatbot_basic') {
      get('/api/v1/merchant-chat/workers-status?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
        if (!err && res && res.data && !res.data.workers_online) {
          updStatus('away');
        }
      });
    }
  }

  // ── Status helpers ────────────────────────────────────────────────────────
  function updStatus(k) {
    var hs = q('#cvw-hs');
    if (!hs) return;
    if (k === 'away') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#f59e0b;display:inline-block;flex-shrink:0;box-shadow:0 0 0 2px rgba(245,158,11,.2)"></span>&nbsp;Away';
    } else if (k === 'agent') {
      hs.innerHTML = '<span class="cvw-dot"></span>&nbsp;Agent connected';
    } else if (k === 'offline') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#ef4444;display:inline-block;flex-shrink:0"></span>&nbsp;No agents online';
    }
  }

  // ── Message bubble ────────────────────────────────────────────────────────
  function addBubble(type, text, label) {
    var body = q('#cvw-body');
    if (!body) return;

    var isUser = (type === 'v');
    var wrap   = document.createElement('div');
    wrap.className = 'cw' + (isUser ? ' r' : '');

    // Sender label (only for worker)
    if (label) {
      var sl = document.createElement('div');
      sl.className = 'cs';
      sl.textContent = label;
      wrap.appendChild(sl);
    }

    // Row: avatar + bubble
    var row = document.createElement('div');
    row.className = 'cw-row';

    // Mini avatar for bot/worker/ai (not user)
    if (!isUser) {
      var av = document.createElement('div');
      av.className = 'cmav';
      av.textContent = (type === 'w') ? (label ? label[0].toUpperCase() : 'A') : S.botIni;
      row.appendChild(av);
    }

    // Bubble
    var bbl = document.createElement('div');
    bbl.className = 'cm ' + type;
    bbl.textContent = text;
    row.appendChild(bbl);

    wrap.appendChild(row);

    // Timestamp + ticks
    var ts = document.createElement('div');
    ts.className = 'cts';
    var tick = isUser
      ? ' <span class="cvw-tick"><svg viewBox="0 0 16 10" width="13" height="13" fill="currentColor" style="opacity:.7"><path d="M1 5l4 4L15 1M6 9L5 8"/><path d="M5 9l4-4"/></svg></span>'
      : '';
    ts.innerHTML = now() + tick;
    wrap.appendChild(ts);

    body.appendChild(wrap);
    scrl();
  }

  function sys(text) {
    var body = q('#cvw-body');
    if (!body) return;
    var el = document.createElement('div');
    el.className = 'cm s';
    el.textContent = text;
    body.appendChild(el);
    scrl();
  }

  function showTyping() {
    var body = q('#cvw-body');
    if (!body || q('#cvw-typ')) return;
    var wrap = document.createElement('div');
    wrap.className = 'cw';
    // mini avatar beside typing
    var row = document.createElement('div');
    row.className = 'cw-row';
    var av = document.createElement('div');
    av.className = 'cmav';
    av.textContent = S.botIni;
    row.appendChild(av);
    var el = document.createElement('div');
    el.id = 'cvw-typ'; el.className = 'ctyp';
    el.innerHTML = '<span></span><span></span><span></span>';
    row.appendChild(el);
    wrap.appendChild(row);
    body.appendChild(wrap);
    scrl();
  }
  function removeTyping() {
    var e = q('#cvw-typ');
    if (e) { var p = e.closest('.cw') || e.parentElement.closest('.cw') || e.parentElement; p.remove(); }
  }

  // ── Quick inline buttons (for callback flow choices) ──────────────────────
  function addChoiceButtons(choices) {
    var body = q('#cvw-body');
    if (!body) return;
    var wrap = document.createElement('div');
    wrap.id = 'cvw-choices';
    wrap.className = 'cw';
    wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;padding:4px 0 6px';
    choices.forEach(function (ch) {
      var btn = document.createElement('button');
      btn.className = ch.skip ? 'cvw-skip' : (ch.cancel ? 'cvw-cbcancel' : 'cqb');
      btn.textContent = ch.label;
      btn.addEventListener('click', function () {
        wrap.remove();
        ch.action();
      });
      wrap.appendChild(btn);
    });
    body.appendChild(wrap);
    scrl();
  }
  function removeChoices() {
    var c = q('#cvw-choices');
    if (c) c.remove();
  }

  // ── Conversational Callback Flow ──────────────────────────────────────────
  function startCallbackFlow() {
    if (S.cb.active) return;
    S.cb = { active: true, step: 0, data: {} };
    // Disable normal input area during callback flow
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Reply here...'; }

    sys('📞 Callback Request');
    setTimeout(function () {
      botSay('Sure! Let me collect a few details. What\'s your **name**?', cbStep0Choices);
    }, 400);
  }

  // Helper: bot says something then optionally shows choice buttons
  function botSay(text, choicesFn, delay) {
    showTyping();
    setTimeout(function () {
      removeTyping();
      // strip markdown bold for display
      addBubble('b', text.replace(/\*\*/g, ''));
      if (choicesFn) choicesFn();
      var inp = q('#cvw-inp');
      if (inp) { inp.focus(); }
    }, delay || 700);
  }

  // Step 0 — ask for name
  function cbStep0Choices() {
    addChoiceButtons([
      { label: '❌ Cancel', cancel: true, action: cancelCallback }
    ]);
    // Override send to intercept callback input
    S.cb.step = 0;
  }

  // Step 1 — ask for phone
  function cbStep1() {
    botSay('Got it, ' + S.cb.data.name + '! 👍 What\'s your **phone number** so we can call you?', function () {
      addChoiceButtons([
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 1;
    });
  }

  // Step 2 — ask for email (optional)
  function cbStep2() {
    botSay('Perfect! Your **email address**? (optional)', function () {
      addChoiceButtons([
        { label: '⏭️ Skip', skip: true, action: function () { S.cb.data.email = ''; cbStep3(); } },
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 2;
    });
  }

  // Step 3 — ask reason (optional)
  function cbStep3() {
    botSay('Almost done! Briefly, what\'s the **reason** for the callback? (optional)', function () {
      addChoiceButtons([
        { label: '⏭️ Skip', skip: true, action: function () { S.cb.data.reason = ''; doSubmitCallback(); } },
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 3;
    });
  }

  // Handle user text input during callback flow
  function handleCallbackInput(msg) {
    removeChoices();
    addBubble('v', msg);
    var step = S.cb.step;

    if (step === 0) {
      // Name
      if (!msg || msg.length < 2) {
        botSay('Please enter a valid name (at least 2 characters).', cbStep0Choices);
        return;
      }
      S.cb.data.name = msg;
      cbStep1();
    } else if (step === 1) {
      // Phone — basic validation
      var digits = msg.replace(/\D/g, '');
      if (digits.length < 7) {
        botSay('Please enter a valid phone number.', function () {
          addChoiceButtons([{ label: '❌ Cancel', cancel: true, action: cancelCallback }]);
          S.cb.step = 1;
        });
        return;
      }
      S.cb.data.phone = msg;
      cbStep2();
    } else if (step === 2) {
      // Email
      S.cb.data.email = msg;
      cbStep3();
    } else if (step === 3) {
      // Reason
      S.cb.data.reason = msg;
      doSubmitCallback();
    }
  }

  function doSubmitCallback() {
    removeChoices();
    showTyping();
    var ep = (S.status === 'offline')
      ? '/api/v1/merchant-chat/offline-callback'
      : '/api/v1/merchant-chat/callback-request';

    post(ep, {
      api_key:       API_KEY,
      visitor_name:  S.cb.data.name,
      visitor_phone: S.cb.data.phone,
      visitor_email: S.cb.data.email  || null,
      reason:        S.cb.data.reason || 'Callback request via chat widget',
    }, function (err, res) {
      removeTyping();
      S.cb.active = false;
      S.status = 'callback_sent';
      var msg = (res && res.data && res.data.message)
        ? res.data.message
        : 'Your callback request has been submitted!';
      addBubble('b', '✅ ' + msg + ' Our team will call you shortly at ' + S.cb.data.phone + '.');
      // Reset input placeholder
      var inp = q('#cvw-inp');
      if (inp) inp.placeholder = 'Type a message...';
    });
  }

  function cancelCallback() {
    S.cb.active = false;
    S.cb = { active: false, step: 0, data: {} };
    removeChoices();
    addBubble('b', 'No problem! Callback request cancelled. Feel free to ask me anything. 😊');
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Type a message...'; inp.focus(); }
  }

  // ── onSend — routes to callback flow or normal chat ───────────────────────
  function onSend() {
    var inp = q('#cvw-inp');
    var msg = tr(inp && inp.value);
    if (!msg) return;
    inp.value = '';
    inp.style.height = 'auto';

    // If in callback flow, intercept
    if (S.cb.active) {
      handleCallbackInput(msg);
      return;
    }

    // Normal chat flow
    sendMsg(msg);
  }

  // ── Normal chat ───────────────────────────────────────────────────────────
  function sendMsg(msg) {
    addBubble('v', msg);

    if (!S.sessionId) {
      startSession(msg, false);
      return;
    }

    showTyping();
    post('/api/v1/merchant-chat/message/' + S.sessionId, {
      api_key: API_KEY,
      message: msg,
    }, function (err, res) {
      removeTyping();
      if (err || !res || !res.success) return;
      var d = res.data;
      if (d.ai_response) addBubble('a', d.ai_response);
      if (d.handoff_requested || d.status === 'waiting_human') {
        sys('🔔 Connecting you with a support agent...');
        S.status = 'waiting_human';
        startPoll();
      }
    });
  }

  // ── Start session ─────────────────────────────────────────────────────────
  function startSession(msg, silent) {
    showTyping();
    post('/api/v1/merchant-chat/start', {
      api_key:       API_KEY,
      visitor_name:  'Visitor',
      visitor_email: null,
      message:       msg,
    }, function (err, res) {
      removeTyping();

      if (err || !res) {
        if (!silent) sys('Connection error. Please try again.');
        return;
      }

      if (!res.success) {
        var d = res.data || {};
        if (d.no_workers_available) {
          S.status = 'offline';
          updStatus('offline');
          sys(d.offline_message || 'Our team is currently unavailable.');
          // Auto-start callback flow
          setTimeout(function () { startCallbackFlow(); }, 600);
        } else {
          if (!silent) sys(res.detail || 'Unable to connect. Please try again.');
        }
        return;
      }

      var data = res.data;

      if (data.no_workers_available) {
        S.status = 'offline';
        updStatus('offline');
        sys(data.offline_message || 'Our team is not available right now.');
        setTimeout(function () { startCallbackFlow(); }, 600);
        return;
      }

      S.sessionId = data.session_id;
      S.status    = data.status || 'ai_active';

      if (data.ai_response) addBubble('a', data.ai_response);

      if (data.handoff_requested || data.status === 'waiting_human') {
        sys('🔔 Connecting you with a support agent...');
        startPoll();
      }
    });
  }

  // ── Polling ───────────────────────────────────────────────────────────────
  function startPoll() {
    if (S.pollTimer) return;
    S.pollTimer = setInterval(poll, 3000);
  }
  function stopPoll() {
    if (S.pollTimer) clearInterval(S.pollTimer);
    S.pollTimer = null;
  }
  function poll() {
    if (!S.sessionId) return;
    get('/api/v1/merchant-chat/messages/' + S.sessionId + '?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) return;
      var d    = res.data;
      var msgs = d.messages || [];

      if (msgs.length > S.msgCount) {
        msgs.slice(S.msgCount).forEach(function (m) {
          if (m.sender_type === 'worker') addBubble('w', m.message, d.worker_name || 'Agent');
          else if (m.sender_type === 'system') sys(m.message);
        });
        S.msgCount = msgs.length;
        if (!S.open) { q('#cvw-badge').style.display = 'flex'; }
      }

      if (d.session_status === 'human_active') {
        S.status = 'human_active';
        updStatus('agent');
        stopPoll();
        startPoll();
      } else if (d.session_status === 'closed') {
        sys('👋 Chat ended. Thank you for reaching out!');
        stopPoll();
        S.sessionId = null;
      }
    });
  }

  // ── Bootstrap ─────────────────────────────────────────────────────────────
  function bootstrap() {
    get('/api/v1/merchant-chat/config/' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) {
        console.warn('[CODVerify] Failed to load chatbot config:', err);
        return;
      }
      S.config = res.data;
      build(res.data);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }

})();

/**
 * CODVerify Chatbot Widget v1.0
 * ─────────────────────────────
 * Self-contained embeddable chat widget.
 * Usage:
 *   <script src="https://api.codverify.tech/static/chatbot-widget.js"
 *           data-codverify-key="ck_YOUR_KEY"
 *           data-codverify-api="https://api.codverify.tech">
 *   </script>
 *
 * OR via JS loader (from embed-code endpoint):
 *   var s = document.createElement('script');
 *   s.src = '...chatbot-widget.js';
 *   s.setAttribute('data-codverify-key', 'ck_XXX');
 *   s.setAttribute('data-codverify-api', 'https://api.codverify.tech');
 *   document.head.appendChild(s);
 */
(function () {
  'use strict';

  // ── Config from script tag ─────────────────────────────────────────────
  var script = document.currentScript ||
    (function () {
      var scripts = document.getElementsByTagName('script');
      return scripts[scripts.length - 1];
    })();

  var API_KEY = script.getAttribute('data-codverify-key') || '';
  var API_BASE = (script.getAttribute('data-codverify-api') || 'https://api.codverify.tech').replace(/\/$/, '');

  if (!API_KEY) {
    console.warn('[CODVerify] data-codverify-key is required');
    return;
  }

  // ── State ───────────────────────────────────────────────────────────────
  var state = {
    open: false,
    sessionId: null,
    config: null,
    messages: [],
    status: 'idle',       // idle | ai_active | waiting_human | human_active | offline | callback_sent
    pollTimer: null,
    lastMsgCount: 0,
    visitorName: '',
    visitorEmail: '',
    inited: false,
  };

  // ── API Helpers ────────────────────────────────────────────────────────
  function apiGet(path, cb) {
    fetch(API_BASE + path, { method: 'GET', headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }

  function apiPost(path, body, cb) {
    fetch(API_BASE + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
      .then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }

  // ── Styles ─────────────────────────────────────────────────────────────
  function injectStyles(primaryColor) {
    var c = primaryColor || '#6366f1';
    var css = [
      '#cvw-root *{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;margin:0;padding:0}',
      '#cvw-bubble{position:fixed;bottom:24px;right:24px;z-index:999999;width:56px;height:56px;border-radius:50%;background:' + c + ';box-shadow:0 4px 16px rgba(0,0,0,.25);cursor:pointer;display:flex;align-items:center;justify-content:center;border:none;transition:transform .2s}',
      '#cvw-bubble:hover{transform:scale(1.1)}',
      '#cvw-bubble svg{width:28px;height:28px;fill:#fff}',
      '#cvw-badge{position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;display:none}',
      '#cvw-window{position:fixed;bottom:94px;right:24px;z-index:999998;width:360px;height:520px;border-radius:16px;background:#fff;box-shadow:0 8px 40px rgba(0,0,0,.18);display:flex;flex-direction:column;overflow:hidden;transform:scale(0);transform-origin:bottom right;transition:transform .25s cubic-bezier(.34,1.56,.64,1),opacity .25s;opacity:0;pointer-events:none}',
      '#cvw-window.open{transform:scale(1);opacity:1;pointer-events:all}',
      '#cvw-header{background:' + c + ';color:#fff;padding:14px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0}',
      '#cvw-avatar{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;flex-shrink:0}',
      '#cvw-hinfo{flex:1}',
      '#cvw-hname{font-size:14px;font-weight:600}',
      '#cvw-hstatus{font-size:11px;opacity:.85}',
      '#cvw-close{background:none;border:none;color:#fff;cursor:pointer;opacity:.8;padding:4px;border-radius:4px;display:flex}',
      '#cvw-close:hover{opacity:1}',
      '#cvw-body{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;scroll-behavior:smooth}',
      '#cvw-body::-webkit-scrollbar{width:4px}',
      '#cvw-body::-webkit-scrollbar-thumb{background:#e5e7eb;border-radius:2px}',
      '.cvw-msg{max-width:80%;padding:9px 12px;border-radius:12px;font-size:13px;line-height:1.5;word-break:break-word}',
      '.cvw-msg.visitor{background:' + c + ';color:#fff;margin-left:auto;border-bottom-right-radius:3px}',
      '.cvw-msg.bot,.cvw-msg.ai{background:#f3f4f6;color:#111827;margin-right:auto;border-bottom-left-radius:3px}',
      '.cvw-msg.worker{background:#ecfdf5;color:#065f46;margin-right:auto;border-bottom-left-radius:3px;border:1px solid #d1fae5}',
      '.cvw-msg.system{background:transparent;color:#9ca3af;font-size:11px;align-self:center;text-align:center;font-style:italic;max-width:100%}',
      '.cvw-sender{font-size:10px;color:#9ca3af;margin-bottom:2px}',
      '.cvw-typing{display:flex;gap:4px;align-items:center;padding:9px 12px;background:#f3f4f6;border-radius:12px;width:fit-content}',
      '.cvw-typing span{width:7px;height:7px;background:#9ca3af;border-radius:50%;display:inline-block;animation:cvw-bounce .9s infinite}',
      '.cvw-typing span:nth-child(2){animation-delay:.15s}',
      '.cvw-typing span:nth-child(3){animation-delay:.3s}',
      '@keyframes cvw-bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}',
      '#cvw-intro{padding:20px 16px;display:flex;flex-direction:column;gap:12px}',
      '#cvw-intro p{font-size:13px;color:#6b7280;line-height:1.5}',
      '#cvw-intro input{width:100%;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:13px;outline:none;transition:border-color .2s}',
      '#cvw-intro input:focus{border-color:' + c + '}',
      '#cvw-intro textarea{width:100%;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:13px;outline:none;resize:none;height:72px;transition:border-color .2s}',
      '#cvw-intro textarea:focus{border-color:' + c + '}',
      '.cvw-btn{width:100%;padding:11px;background:' + c + ';color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;transition:opacity .2s}',
      '.cvw-btn:hover{opacity:.9}',
      '.cvw-btn:disabled{opacity:.5;cursor:not-allowed}',
      '#cvw-menu{padding:0 12px 8px}',
      '#cvw-menu p{font-size:11px;color:#9ca3af;margin-bottom:6px;text-align:center}',
      '.cvw-menu-btn{width:100%;padding:8px 12px;background:#fff;border:1.5px solid #e5e7eb;color:#374151;border-radius:8px;font-size:13px;text-align:left;cursor:pointer;margin-bottom:5px;transition:all .2s}',
      '.cvw-menu-btn:hover{border-color:' + c + ';color:' + c + '}',
      '#cvw-footer{padding:10px 12px;border-top:1px solid #f3f4f6;display:flex;gap:8px;align-items:flex-end;flex-shrink:0}',
      '#cvw-input{flex:1;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:10px;font-size:13px;outline:none;resize:none;max-height:80px;transition:border-color .2s;line-height:1.4}',
      '#cvw-input:focus{border-color:' + c + '}',
      '#cvw-send{background:' + c + ';border:none;border-radius:8px;width:36px;height:36px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:opacity .2s}',
      '#cvw-send:hover{opacity:.9}',
      '#cvw-send svg{width:18px;height:18px;fill:#fff}',
      '#cvw-callback{padding:16px;display:flex;flex-direction:column;gap:10px}',
      '#cvw-callback h3{font-size:14px;font-weight:600;color:#111827}',
      '#cvw-callback p{font-size:12px;color:#6b7280}',
      '#cvw-callback input{width:100%;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:13px;outline:none}'
    ].join('\n');

    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  // ── DOM Builder ────────────────────────────────────────────────────────
  function buildWidget(config) {
    var c = config.primary_color || '#6366f1';
    var botName = config.bot_name || 'Support Bot';
    var initials = botName.split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();

    var root = document.createElement('div');
    root.id = 'cvw-root';
    root.innerHTML = [
      // Bubble button
      '<button id="cvw-bubble" aria-label="Open chat">',
      '  <div id="cvw-badge">1</div>',
      '  <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
      '</button>',
      // Chat window
      '<div id="cvw-window" role="dialog" aria-label="Chat window">',
      '  <div id="cvw-header">',
      '    <div id="cvw-avatar">' + initials + '</div>',
      '    <div id="cvw-hinfo">',
      '      <div id="cvw-hname">' + botName + '</div>',
      '      <div id="cvw-hstatus">● Online</div>',
      '    </div>',
      '    <button id="cvw-close" aria-label="Close chat">',
      '      <svg viewBox="0 0 24 24" width="20" height="20" fill="white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
      '    </button>',
      '  </div>',
      '  <div id="cvw-body"></div>',
      '  <div id="cvw-footer" style="display:none">',
      '    <textarea id="cvw-input" rows="1" placeholder="Type a message..." maxlength="1000"></textarea>',
      '    <button id="cvw-send">',
      '      <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
      '    </button>',
      '  </div>',
      '</div>',
    ].join('');

    document.body.appendChild(root);

    // Events
    document.getElementById('cvw-bubble').addEventListener('click', toggleWidget);
    document.getElementById('cvw-close').addEventListener('click', function () { setOpen(false); });
    document.getElementById('cvw-send').addEventListener('click', sendMessage);
    document.getElementById('cvw-input').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
      autoResize(this);
    });
    document.getElementById('cvw-input').addEventListener('input', function () { autoResize(this); });
  }

  function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 80) + 'px';
  }

  // ── Widget Open/Close ──────────────────────────────────────────────────
  function toggleWidget() {
    setOpen(!state.open);
  }

  function setOpen(open) {
    state.open = open;
    var win = document.getElementById('cvw-window');
    if (open) {
      win.classList.add('open');
      document.getElementById('cvw-badge').style.display = 'none';
      if (!state.inited) initChat();
    } else {
      win.classList.remove('open');
    }
  }

  // ── Init Chat ──────────────────────────────────────────────────────────
  function initChat() {
    state.inited = true;
    var config = state.config;
    var body = document.getElementById('cvw-body');

    // Welcome message
    addMessage('bot', config.welcome_message || 'Hi! 👋 How can I help you today?');

    // Menu options
    if (config.menu_options && config.menu_options.length > 0) {
      var menuDiv = document.createElement('div');
      menuDiv.id = 'cvw-menu';
      menuDiv.innerHTML = '<p>Quick options:</p>';
      config.menu_options.forEach(function (opt) {
        var btn = document.createElement('button');
        btn.className = 'cvw-menu-btn';
        btn.textContent = opt.label;
        btn.addEventListener('click', function () {
          menuDiv.remove();
          addMessage('visitor', opt.label);
          addMessage('bot', opt.answer);
        });
        menuDiv.appendChild(btn);
      });
      body.appendChild(menuDiv);
      scrollBottom();
    }

    // Show intro form
    showIntroForm();
  }

  function showIntroForm() {
    var body = document.getElementById('cvw-body');
    var div = document.createElement('div');
    div.id = 'cvw-intro';
    div.innerHTML = [
      '<p>Please introduce yourself to get started:</p>',
      '<input id="cvw-vname" type="text" placeholder="Your name *" required>',
      '<input id="cvw-vemail" type="email" placeholder="Email (optional)">',
      '<textarea id="cvw-vmsg" placeholder="Your message *" required></textarea>',
      '<button class="cvw-btn" id="cvw-start-btn">Start Chat</button>',
    ].join('');
    body.appendChild(div);
    scrollBottom();

    document.getElementById('cvw-start-btn').addEventListener('click', startChat);
  }

  function startChat() {
    var name = (document.getElementById('cvw-vname').value || '').trim();
    var email = (document.getElementById('cvw-vemail').value || '').trim();
    var msg = (document.getElementById('cvw-vmsg').value || '').trim();

    if (!name) { alert('Please enter your name'); return; }
    if (!msg) { alert('Please enter a message'); return; }

    state.visitorName = name;
    state.visitorEmail = email;

    var btn = document.getElementById('cvw-start-btn');
    btn.disabled = true;
    btn.textContent = 'Starting...';

    var introDiv = document.getElementById('cvw-intro');
    var menuDiv = document.getElementById('cvw-menu');
    if (introDiv) introDiv.remove();
    if (menuDiv) menuDiv.remove();

    addMessage('visitor', msg);
    showTyping();

    apiPost('/api/v1/merchant-chat/start', {
      api_key: API_KEY,
      visitor_name: name,
      visitor_email: email || null,
      message: msg,
    }, function (err, res) {
      removeTyping();

      if (err || !res || !res.success) {
        if (res && res.data && res.data.no_workers_available) {
          state.status = 'offline';
          addMessage('system', res.data.offline_message || 'No agents available right now.');
          showCallbackForm();
        } else {
          addMessage('system', 'Failed to start chat. Please try again.');
        }
        return;
      }

      var data = res.data;

      if (data.no_workers_available) {
        state.status = 'offline';
        addMessage('system', data.offline_message || 'No agents available right now.');
        showCallbackForm();
        return;
      }

      state.sessionId = data.session_id;
      state.status = data.status;

      if (data.ai_response) addMessage('ai', data.ai_response);
      if (data.handoff_requested || data.status === 'waiting_human') {
        addMessage('system', '🔔 Connecting you with a support agent...');
        startPolling();
      } else if (data.status === 'ai_active') {
        // AI mode — show input
        showFooter();
      }

      showFooter();
    });
  }

  // ── Messaging ──────────────────────────────────────────────────────────
  function sendMessage() {
    if (!state.sessionId) return;
    var input = document.getElementById('cvw-input');
    var msg = (input.value || '').trim();
    if (!msg) return;

    input.value = '';
    input.style.height = 'auto';
    addMessage('visitor', msg);
    showTyping();

    apiPost('/api/v1/merchant-chat/message/' + state.sessionId, {
      api_key: API_KEY,
      message: msg,
    }, function (err, res) {
      removeTyping();
      if (err || !res || !res.success) return;

      var data = res.data;
      if (data.ai_response) addMessage('ai', data.ai_response);
      if (data.handoff_requested || data.status === 'waiting_human') {
        addMessage('system', '🔔 Connecting you with a support agent...');
        state.status = 'waiting_human';
        startPolling();
      }
    });
  }

  // ── Polling for human messages ─────────────────────────────────────────
  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(pollMessages, 3000);
  }

  function stopPolling() {
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  function pollMessages() {
    if (!state.sessionId) return;
    apiGet('/api/v1/merchant-chat/messages/' + state.sessionId + '?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) return;

      var data = res.data;
      var msgs = data.messages || [];

      if (msgs.length > state.lastMsgCount) {
        var newMsgs = msgs.slice(state.lastMsgCount);
        newMsgs.forEach(function (m) {
          if (m.sender_type === 'worker') {
            var wName = data.worker_name || 'Agent';
            addMessage('worker', m.message, wName);
          } else if (m.sender_type === 'system') {
            addMessage('system', m.message);
          }
          // visitor and ai already shown
        });
        state.lastMsgCount = msgs.length;

        // Notify if window closed
        if (!state.open) {
          var badge = document.getElementById('cvw-badge');
          badge.style.display = 'flex';
        }
      }

      if (data.session_status === 'human_active') {
        state.status = 'human_active';
        document.getElementById('cvw-hstatus').textContent = '● Agent connected';
        showFooter();
      } else if (data.session_status === 'closed') {
        addMessage('system', 'Chat ended. Thank you!');
        stopPolling();
        state.sessionId = null;
      }
    });
  }

  // ── Callback Form (offline) ────────────────────────────────────────────
  function showCallbackForm() {
    var body = document.getElementById('cvw-body');
    var div = document.createElement('div');
    div.id = 'cvw-callback';
    div.innerHTML = [
      '<h3>📞 Request a Callback</h3>',
      '<p>Leave your details and we\'ll call you back shortly.</p>',
      '<input id="cvw-cb-name" type="text" placeholder="Your name *" value="' + (state.visitorName || '') + '">',
      '<input id="cvw-cb-phone" type="tel" placeholder="Phone number *">',
      '<input id="cvw-cb-email" type="email" placeholder="Email (optional)" value="' + (state.visitorEmail || '') + '">',
      '<button class="cvw-btn" id="cvw-cb-btn">Request Callback</button>',
    ].join('');
    body.appendChild(div);
    scrollBottom();

    document.getElementById('cvw-cb-btn').addEventListener('click', submitCallback);
  }

  function submitCallback() {
    var name = (document.getElementById('cvw-cb-name').value || '').trim();
    var phone = (document.getElementById('cvw-cb-phone').value || '').trim();
    var email = (document.getElementById('cvw-cb-email').value || '').trim();

    if (!name || !phone) { alert('Name and phone are required'); return; }

    var btn = document.getElementById('cvw-cb-btn');
    btn.disabled = true;
    btn.textContent = 'Sending...';

    apiPost('/api/v1/merchant-chat/offline-callback', {
      api_key: API_KEY,
      visitor_name: name,
      visitor_phone: phone,
      visitor_email: email,
    }, function (err, res) {
      var cbDiv = document.getElementById('cvw-callback');
      if (cbDiv) cbDiv.remove();
      state.status = 'callback_sent';
      addMessage('system', '✅ ' + ((res && res.data && res.data.message) || 'Callback request sent! We\'ll call you back shortly.'));
    });
  }

  // ── UI Helpers ─────────────────────────────────────────────────────────
  function addMessage(type, text, label) {
    var body = document.getElementById('cvw-body');
    var wrap = document.createElement('div');
    wrap.style.display = 'flex';
    wrap.style.flexDirection = 'column';
    if (type === 'visitor') wrap.style.alignItems = 'flex-end';

    if (label) {
      var sender = document.createElement('div');
      sender.className = 'cvw-sender';
      sender.textContent = label;
      if (type === 'visitor') sender.style.textAlign = 'right';
      wrap.appendChild(sender);
    }

    var bubble = document.createElement('div');
    bubble.className = 'cvw-msg ' + type;
    bubble.textContent = text;
    wrap.appendChild(bubble);
    body.appendChild(wrap);

    state.messages.push({ type: type, text: text });
    scrollBottom();
  }

  function showTyping() {
    var body = document.getElementById('cvw-body');
    var el = document.createElement('div');
    el.id = 'cvw-typing';
    el.className = 'cvw-typing';
    el.innerHTML = '<span></span><span></span><span></span>';
    body.appendChild(el);
    scrollBottom();
  }

  function removeTyping() {
    var el = document.getElementById('cvw-typing');
    if (el) el.remove();
  }

  function showFooter() {
    var footer = document.getElementById('cvw-footer');
    footer.style.display = 'flex';
    document.getElementById('cvw-input').focus();
  }

  function scrollBottom() {
    var body = document.getElementById('cvw-body');
    body.scrollTop = body.scrollHeight;
  }

  // ── Bootstrap ──────────────────────────────────────────────────────────
  function init() {
    apiGet('/api/v1/merchant-chat/config/' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) {
        console.warn('[CODVerify] Failed to load chatbot config:', err);
        return;
      }

      state.config = res.data;
      injectStyles(res.data.primary_color);
      buildWidget(res.data);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

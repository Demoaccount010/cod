-- ============================================================
-- SERVICE PRICING TABLE — Run this once in Supabase SQL Editor
-- After running, admin panel price editing will work instantly.
-- ============================================================

CREATE TABLE IF NOT EXISTS service_pricing (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    service_key     TEXT UNIQUE NOT NULL,
    label           TEXT NOT NULL,
    icon            TEXT DEFAULT '💬',
    amount          NUMERIC(10, 4) DEFAULT 0.00,
    currency        TEXT DEFAULT 'INR',
    notes           TEXT DEFAULT '',
    active          BOOLEAN DEFAULT TRUE,
    display_order   INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ⚠️ CRITICAL FIX: Disable RLS + grant permissions
-- Supabase by default enables RLS on new tables.
-- Even the service_role key gets blocked without this.
-- Run this EVEN IF table already exists.
-- ============================================================
ALTER TABLE service_pricing DISABLE ROW LEVEL SECURITY;

GRANT ALL ON service_pricing TO service_role;
GRANT SELECT ON service_pricing TO anon;
GRANT ALL ON service_pricing TO authenticated;

-- ============================================================
-- Seed all service prices (skips if already exists)
-- ============================================================
INSERT INTO service_pricing (service_key, label, icon, amount, currency, notes, active, display_order)
VALUES
    ('whatsapp_cod_verification', 'WhatsApp COD Verification',          '💬', 0.50, 'INR', 'per message',   TRUE, 1),
    ('call_verification',         'Call Verification (confirm/cancel)', '📞', 7.00, 'INR', 'per call',      TRUE, 2),
    ('call_not_picked',           'Call Not Picked / Callback',         '📵', 0.00, 'INR', 'Free',          TRUE, 3),
    ('ai_chatbot',                'AI Chatbot',                         '🤖', 0.00, 'INR', 'Unlimited',     TRUE, 4),
    ('human_agent_chat',          'Human Agent Chat',                   '👤', 5.00, 'INR', 'per session',   TRUE, 5),
    ('return_whatsapp',           'Return / Exchange WA Notifications', '🔄', 0.50, 'INR', 'per message',   TRUE, 6),
    ('delivery_notification',     'Delivery Status WA Notifications',   '📦', 0.50, 'INR', 'per message (shipped / out-for-delivery / delivered)', TRUE, 7),
    ('return_new_request_wa',     'New Return Request WA (Customer)',   '↩️', 0.50, 'INR', 'per message',   TRUE, 8),
    ('return_merchant_alert_wa',  'New Return Alert WA (Merchant)',     '🔔', 0.50, 'INR', 'per message',   TRUE, 9),
    ('clarification_wa',          'Order Clarification WA (Re-send)',   '🔁', 0.50, 'INR', 'per message',   TRUE, 10)
ON CONFLICT (service_key) DO NOTHING;

-- Optional: auto-update updated_at on row change
CREATE OR REPLACE FUNCTION update_service_pricing_ts()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_service_pricing_updated ON service_pricing;
CREATE TRIGGER trg_service_pricing_updated
    BEFORE UPDATE ON service_pricing
    FOR EACH ROW EXECUTE FUNCTION update_service_pricing_ts();

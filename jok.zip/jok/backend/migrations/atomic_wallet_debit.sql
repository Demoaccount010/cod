-- ══════════════════════════════════════════════════════════════════
-- Atomic wallet debit RPC — prevents race conditions
-- Run this in Supabase SQL Editor ONCE
-- ══════════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION debit_wallet_atomic(
    p_user_id     UUID,
    p_amount      NUMERIC,
    p_allow_negative BOOLEAN DEFAULT FALSE
)
RETURNS TABLE(
    success       BOOLEAN,
    new_balance   NUMERIC,
    error_code    TEXT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_current_balance NUMERIC;
    v_new_balance     NUMERIC;
BEGIN
    -- Lock the row for this user — prevents concurrent debits
    SELECT balance INTO v_current_balance
    FROM merchant_wallets
    WHERE user_id = p_user_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 0::NUMERIC, 'WALLET_NOT_FOUND';
        RETURN;
    END IF;

    v_new_balance := v_current_balance - p_amount;

    -- Check if balance would go negative and we don't allow it
    IF v_new_balance < 0 AND NOT p_allow_negative THEN
        RETURN QUERY SELECT FALSE, v_current_balance, 'INSUFFICIENT_BALANCE';
        RETURN;
    END IF;

    -- Apply debit atomically
    UPDATE merchant_wallets
    SET
        balance       = ROUND(v_new_balance, 2),
        total_debited = COALESCE(total_debited, 0) + p_amount,
        updated_at    = NOW()
    WHERE user_id = p_user_id;

    RETURN QUERY SELECT TRUE, ROUND(v_new_balance, 2), NULL::TEXT;
END;
$$;

-- Grant execute to authenticated/service role
GRANT EXECUTE ON FUNCTION debit_wallet_atomic(UUID, NUMERIC, BOOLEAN) TO service_role;
GRANT EXECUTE ON FUNCTION debit_wallet_atomic(UUID, NUMERIC, BOOLEAN) TO authenticated;

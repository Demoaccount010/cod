"""
Service Pricing — Dynamic DB-backed pricing engine
Admin dashboard se prices update honge, yahan se sab kuch read hoga.
Cache: 60-second in-memory cache (TTL) to avoid hitting DB on every wallet debit.
"""
from loguru import logger
from functools import lru_cache
import time

# ── In-memory cache ───────────────────────────────────────────────────────────
_pricing_cache: dict = {}       # {service_key: amount}
_cache_ts: float = 0.0          # Unix timestamp of last refresh
_CACHE_TTL: int = 60            # seconds


# ── Hardcoded fallback (used if DB unavailable) ───────────────────────────────
_FALLBACK_PRICING: dict = {
    "whatsapp_verification": {
        "amount": 0.50,
        "label": "WhatsApp COD Verification",
        "icon": "💬",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 1,
    },
    "call_verification": {
        "amount": 7.00,
        "label": "Call Verification",
        "icon": "📞",
        "notes": "per call",
        "active": True,
        "currency": "INR",
        "display_order": 2,
    },
    "call_no_answer": {
        "amount": 0.00,
        "label": "Call Not Answered / No Response",
        "icon": "📵",
        "notes": "Free",
        "active": True,
        "currency": "INR",
        "display_order": 3,
    },
    "ai_chatbot": {
        "amount": 0.00,
        "label": "AI Chatbot",
        "icon": "🤖",
        "notes": "Unlimited",
        "active": True,
        "currency": "INR",
        "display_order": 4,
    },
    "human_agent": {
        "amount": 5.00,
        "label": "Human Agent Chat",
        "icon": "👤",
        "notes": "per session",
        "active": True,
        "currency": "INR",
        "display_order": 5,
    },
    "return_wa_notification": {
        "amount": 0.50,
        "label": "Return / Exchange WA Notification",
        "icon": "🔄",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 6,
    },
    "return_merchant_alert": {
        "amount": 0.50,
        "label": "New Return Alert (Merchant)",
        "icon": "🔔",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 7,
    },
    "return_status_update": {
        "amount": 0.50,
        "label": "Return Status Update (Customer)",
        "icon": "↩️",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 8,
    },
    "order_shipped": {
        "amount": 0.50,
        "label": "Order Shipped Notification",
        "icon": "🚚",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 9,
    },
    "order_delivered": {
        "amount": 0.50,
        "label": "Order Delivered Notification",
        "icon": "📦",
        "notes": "per message",
        "active": True,
        "currency": "INR",
        "display_order": 10,
    },
    "email_weekly_summary": {
        "amount": 0.00,
        "label": "Weekly Email Summary",
        "icon": "📧",
        "notes": "Free",
        "active": True,
        "currency": "INR",
        "display_order": 11,
    },
}


def _refresh_cache() -> None:
    """Load all pricing from DB into _pricing_cache."""
    global _pricing_cache, _cache_ts
    try:
        from config.database import get_db
        db = get_db()
        rows = db.table("service_pricing").select("*").order("display_order").execute()
        if rows.data:
            _pricing_cache = {
                r["service_key"]: {
                    "amount": float(r.get("amount") or 0),
                    "label": r.get("label", ""),
                    "icon": r.get("icon", "💬"),
                    "notes": r.get("notes", ""),
                    "active": r.get("active", True),
                    "currency": r.get("currency", "INR"),
                    "display_order": r.get("display_order", 0),
                }
                for r in rows.data
            }
            _cache_ts = time.time()
            logger.debug(f"Service pricing cache refreshed — {len(_pricing_cache)} services loaded")
    except Exception as e:
        logger.warning(f"Could not refresh pricing cache from DB: {e}. Using fallback.")


def _get_cache() -> dict:
    """Return cached pricing, refreshing if stale."""
    global _cache_ts
    if not _pricing_cache or (time.time() - _cache_ts) > _CACHE_TTL:
        _refresh_cache()
    return _pricing_cache if _pricing_cache else {}


def get_price(service_key: str) -> float:
    """Get price for a service_key. Returns 0.0 if not found or inactive."""
    cache = _get_cache()
    if cache:
        entry = cache.get(service_key)
        if entry is None:
            return 0.0
        if not entry.get("active", True):
            return 0.0
        return float(entry.get("amount", 0))
    # Fallback to hardcoded
    fallback = _FALLBACK_PRICING.get(service_key, {})
    if not fallback.get("active", True):
        return 0.0
    return float(fallback.get("amount", 0))


def get_all_pricing() -> list:
    """Return all pricing entries as list (for admin API and merchant display)."""
    cache = _get_cache()
    if cache:
        return sorted(cache.values(), key=lambda x: x.get("display_order", 0))
    # Fallback
    return [
        {**v, "service_key": k}
        for k, v in _FALLBACK_PRICING.items()
    ]


def get_all_pricing_with_keys() -> list:
    """Return pricing list with service_key included (for admin management)."""
    cache = _get_cache()
    if cache:
        return sorted(
            [{"service_key": k, **v} for k, v in cache.items()],
            key=lambda x: x.get("display_order", 0),
        )
    return [
        {"service_key": k, **v}
        for k, v in _FALLBACK_PRICING.items()
    ]


def invalidate_cache() -> None:
    """Force cache invalidation — call after admin updates pricing."""
    global _pricing_cache, _cache_ts
    _pricing_cache = {}
    _cache_ts = 0.0
    logger.info("Service pricing cache invalidated")

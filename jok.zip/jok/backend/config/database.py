from supabase import create_client, Client
from config.settings import settings
from loguru import logger

_client: Client | None = None


def get_supabase() -> Client:
    global _client
    if _client is None:
        try:
            _client = create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_KEY)
            logger.info("Supabase client initialized")
        except Exception as e:
            logger.error(f"Supabase connection failed: {e}")
            raise
    return _client


def reset_db():
    """Reset DB client — called if connection becomes stale."""
    global _client
    _client = None
    logger.info("Supabase client reset")


def get_db() -> Client:
    return get_supabase()

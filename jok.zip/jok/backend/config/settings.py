from pydantic_settings import BaseSettings
from typing import List
import os
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseSettings):
    # Supabase (Database — unchanged across deployments)
    SUPABASE_URL: str = ""
    SUPABASE_KEY: str = ""
    SUPABASE_SERVICE_KEY: str = ""

    # JWT
    JWT_SECRET: str = "change-me-in-production"
    JWT_REFRESH_SECRET: str = "change-me-refresh-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # External Services
    RESEND_API_KEY: str = ""
    RAZORPAY_KEY_ID: str = ""
    RAZORPAY_KEY_SECRET: str = ""
    RAZORPAY_PAYOUT_ACCOUNT: str = ""  # Razorpay X account number for influencer payouts

    # Stripe (International payments)
    STRIPE_SECRET_KEY: str = ""
    STRIPE_PUBLISHABLE_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""

    # Internal security
    INTERNAL_API_TOKEN: str = "change-me-internal-token"  # Shopify plugin → backend auth

    # Backend public URL (used in webhook URL generation)
    # Set this to your AWS/DigitalOcean domain — e.g. https://api.codverify.tech
    BACKEND_URL: str = "http://localhost:8000"

    # Server port — override via env var or docker-compose (default 8000)
    PORT: int = 8000

    # Groq AI Chatbot
    GROQ_API_KEY: str = ""
    GROQ_MODEL: str = "llama-3.3-70b-versatile"
    GROQ_TEMPERATURE: float = 0.3

    # Email — supports both Google Apps Script webhook and direct SMTP
    # On AWS/DigitalOcean both options work (no DNS restrictions like HuggingFace)
    EMAIL_WEBHOOK_URL: str = ""   # Option A: Google Apps Script web app URL

    # SMTP Email (Option B — recommended for AWS with SES or any SMTP)
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = ""
    SMTP_FROM_NAME: str = "CODVerify"

    # WhatsApp (Centralized - Platform owner's credentials)
    WHATSAPP_PHONE_NUMBER_ID: str = ""
    WHATSAPP_ACCESS_TOKEN: str = ""
    WHATSAPP_VERIFY_TOKEN: str = "codverify_webhook_token_2024"
    WHATSAPP_APP_SECRET: str = ""
    # WHATSAPP_API_PROXY_URL: Only needed on HuggingFace (DNS restrictions).
    # On AWS/DigitalOcean/EC2 — leave EMPTY, direct API calls work fine.
    WHATSAPP_API_PROXY_URL: str = ""

    # App
    ALLOWED_ORIGINS: str = "http://localhost:5173,https://codverify.tech,https://www.codverify.tech"
    ENVIRONMENT: str = "development"
    DEFAULT_ADMIN_EMAIL: str = "admin@codverify.tech"
    FRONTEND_URL: str = "https://codverify.tech"
    SHOPIFY_DASHBOARD_URL: str = "https://codverify.tech/dashboard"
    SHOPIFY_PLUGIN_URL: str = ""  # e.g. https://shopify.codverify.tech

    # Encryption
    ENCRYPTION_KEY: str = "change-me-32-byte-key-for-prod!!"

    @property
    def allowed_origins_list(self) -> List[str]:
        return [o.strip() for o in self.ALLOWED_ORIGINS.split(",")]

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"

    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"


settings = Settings()

#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════
# CODVerify — Deploy / Update Script
# ══════════════════════════════════════════════════════════════════════════
# Run this every time you want to deploy updates to the server.
# Works on AWS EC2, DigitalOcean, any Linux VPS.
#
# Usage:
#   ssh ubuntu@YOUR_EC2_IP
#   cd /opt/codverify
#   ./deploy/deploy.sh
# ══════════════════════════════════════════════════════════════════════════

set -e

APP_DIR="/opt/codverify"
cd $APP_DIR

echo "╔══════════════════════════════════════╗"
echo "║  CODVerify — Deploying Update        ║"
echo "╚══════════════════════════════════════╝"

# ── Pull latest code ──────────────────────────────────────────────────────
echo "📥 Pulling latest code from Git..."
git pull origin main

# ── Rebuild and restart services (zero downtime for nginx) ────────────────
echo "🐳 Rebuilding Docker images..."
docker compose build --no-cache backend shopify

echo "🔄 Restarting services (backend first, then shopify, nginx stays up)..."
docker compose up -d --no-deps backend
sleep 5  # Wait for backend to be healthy

# Check backend health before continuing
echo "❤️  Checking backend health..."
MAX_RETRIES=10
COUNT=0
until curl -sf http://localhost:8000/health > /dev/null; do
    COUNT=$((COUNT+1))
    if [ $COUNT -ge $MAX_RETRIES ]; then
        echo "❌ Backend failed health check after $MAX_RETRIES attempts. Rolling back..."
        docker compose logs --tail=50 backend
        exit 1
    fi
    echo "   Waiting for backend... ($COUNT/$MAX_RETRIES)"
    sleep 5
done
echo "✅ Backend is healthy!"

docker compose up -d --no-deps shopify
docker compose up -d --no-deps nginx

# ── Clean up old images ───────────────────────────────────────────────────
echo "🧹 Cleaning up unused Docker images..."
docker image prune -f

# ── Show status ───────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════╗"
echo "║  Deployment Complete!                ║"
echo "╚══════════════════════════════════════╝"
docker compose ps

echo ""
echo "📊 Logs (last 20 lines of backend):"
docker compose logs --tail=20 backend

#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════
# CODVerify — EC2 / VPS One-Time Setup Script
# ══════════════════════════════════════════════════════════════════════════
# Run this ONCE on a fresh AWS EC2 t3.small (Amazon Linux 2023 or Ubuntu 22.04)
# OR on DigitalOcean Droplet / any Linux VPS
#
# Usage:
#   ssh ubuntu@YOUR_EC2_IP
#   wget https://raw.githubusercontent.com/YOUR_ORG/codverify/main/deploy/setup-ec2.sh
#   chmod +x setup-ec2.sh && sudo ./setup-ec2.sh
# ══════════════════════════════════════════════════════════════════════════

set -e  # Exit on any error

echo "╔══════════════════════════════════════╗"
echo "║  CODVerify — Server Setup            ║"
echo "╚══════════════════════════════════════╝"

# ── Detect OS ─────────────────────────────────────────────────────────────
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
fi

echo "👉 Detected OS: $OS"

# ── Update System ─────────────────────────────────────────────────────────
echo "📦 Updating system packages..."
if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
    apt-get update -y && apt-get upgrade -y
    apt-get install -y curl wget git unzip software-properties-common
elif [[ "$OS" == "amzn" || "$OS" == "rhel" || "$OS" == "centos" ]]; then
    yum update -y
    yum install -y curl wget git unzip
fi

# ── Install Docker ────────────────────────────────────────────────────────
echo "🐳 Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    # Add current user to docker group (no need for sudo)
    usermod -aG docker $SUDO_USER || usermod -aG docker ubuntu || true
    echo "✅ Docker installed"
else
    echo "✅ Docker already installed: $(docker --version)"
fi

# ── Install Docker Compose v2 ──────────────────────────────────────────────
echo "📦 Installing Docker Compose v2..."
if ! docker compose version &> /dev/null; then
    mkdir -p /usr/local/lib/docker/cli-plugins
    COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep '"tag_name"' | cut -d '"' -f 4)
    curl -SL "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-linux-x86_64" \
        -o /usr/local/lib/docker/cli-plugins/docker-compose
    chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
    echo "✅ Docker Compose installed: $(docker compose version)"
else
    echo "✅ Docker Compose already installed: $(docker compose version)"
fi

# ── Install Certbot (Let's Encrypt SSL) ───────────────────────────────────
echo "🔒 Installing Certbot..."
if ! command -v certbot &> /dev/null; then
    if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
        apt-get install -y certbot
    elif [[ "$OS" == "amzn" ]]; then
        pip3 install certbot
    fi
    echo "✅ Certbot installed"
else
    echo "✅ Certbot already installed"
fi

# ── Create app directory ───────────────────────────────────────────────────
APP_DIR="/opt/codverify"
echo "📁 Creating app directory: $APP_DIR"
mkdir -p $APP_DIR
cd $APP_DIR

# ── Configure Firewall ─────────────────────────────────────────────────────
echo "🔥 Configuring firewall..."
if command -v ufw &> /dev/null; then
    ufw allow 22/tcp   # SSH
    ufw allow 80/tcp   # HTTP
    ufw allow 443/tcp  # HTTPS
    ufw --force enable
    echo "✅ UFW firewall configured"
fi
# For AWS: configure Security Group in AWS Console:
#   Inbound: 22 (SSH), 80 (HTTP), 443 (HTTPS) from 0.0.0.0/0
#   Outbound: All traffic

# ── Clone Repository ──────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════╗"
echo "║  Setup Complete!                     ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo ""
echo "1. Clone your repo:"
echo "   cd /opt/codverify"
echo "   git clone https://github.com/YOUR_ORG/codverify.git ."
echo ""
echo "2. Set up environment files:"
echo "   cp backend/.env.aws.example backend/.env"
echo "   nano backend/.env  # Fill in all values"
echo "   cp plugins/codverify-shopify/.env.example plugins/codverify-shopify/.env"
echo "   nano plugins/codverify-shopify/.env  # Fill in all values"
echo ""
echo "3. Start services:"
echo "   cd /opt/codverify"
echo "   docker compose up -d --build"
echo ""
echo "4. Get SSL certificate (Certbot) — SKIP if using AWS ALB for SSL:"
echo "   # Stop nginx temporarily"
echo "   docker compose stop nginx"
echo "   certbot certonly --standalone -d api.codverify.tech -d shopify.codverify.tech"
echo "   # Uncomment HTTPS block in nginx/nginx.conf"
echo "   docker compose up -d nginx"
echo ""
echo "5. Verify:"
echo "   curl http://YOUR_EC2_IP/health"
echo "   # Expected: {\"status\":\"healthy\",...}"
echo ""
echo "📌 For server switching (DigitalOcean etc.):"
echo "   Just run this script on the new server + copy your .env files"

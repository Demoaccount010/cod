# CODVerify — Fresh Deployment Guide

## Prerequisites (Server pe ek baar)
```bash
# Docker install
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker ubuntu
# Docker Compose
sudo apt install docker-compose-plugin -y
```

---

## Step 1 — Files Upload
```bash
# Local PC se zip upload karo (Git Bash / PowerShell):
scp -i your-key.pem "Your Smile.zip" ubuntu@YOUR_SERVER_IP:/home/ubuntu/

# Server pe:
cd /home/ubuntu
unzip "Your Smile.zip" -d cod
cd cod/jok   # ya jo folder ho
ls           # docker-compose.yml dikhna chahiye
```

---

## Step 2 — Backend .env
```bash
cp backend/.env.aws.example backend/.env
nano backend/.env
```

Fill karo:
```env
SUPABASE_URL=https://XXXX.supabase.co
SUPABASE_KEY=your_service_role_key
ENCRYPTION_KEY=your_32_char_key_here
JWT_SECRET=your_jwt_secret
INTERNAL_API_TOKEN=your_internal_token
SENDGRID_API_KEY=SG.xxx (ya EMAIL credentials)
WHATSAPP_ACCESS_TOKEN=your_whatsapp_token
WHATSAPP_PHONE_NUMBER_ID=your_phone_id
WHATSAPP_BUSINESS_ACCOUNT_ID=your_business_id
```

---

## Step 3 — Plugin .env
```bash
nano plugins/codverify-shopify/.env
```

Fill karo:
```env
# Multi-app support — add each merchant's Shopify app here
SHOPIFY_APPS=[{"key":"APP1_API_KEY","secret":"APP1_SECRET","label":"Merchant1"},{"key":"APP2_API_KEY","secret":"APP2_SECRET","label":"Merchant2"}]

SHOPIFY_SCOPES=read_orders,write_orders,wriet_script_tags
HOST=https://shopify.codverify.tech
PORT=3000
CODVERIFY_BACKEND_URL=http://backend:8000
INTERNAL_API_TOKEN=your_internal_token   # SAME as backend
CODVERIFY_DASHBOARD_URL=https://codverify.tech/dashboard
```

---

## Step 4 — SSL Certificate
```bash
# Domain DNS already pointing ho to:
sudo apt install certbot -y
sudo certbot certonly --standalone -d codverify.tech -d shopify.codverify.tech -d api.codverify.tech
# Certs: /etc/letsencrypt/live/codverify.tech/
```

---

## Step 5 — Build & Start
```bash
cd /home/ubuntu/cod/jok
docker compose up -d --build
docker compose ps          # sab Running hona chahiye
```

---

## Step 6 — Verify Running
```bash
docker logs codverify-backend --tail 20
docker logs codverify-shopify --tail 20
docker logs codverify-nginx --tail 10

# Health check:
curl https://codverify.tech/health
curl https://shopify.codverify.tech/health
```

---

## Step 7 — Naya Merchant Add Karna

1. **Shopify Partners** → New Custom App → Copy API Key + Secret
2. **Plugin .env edit:**
   ```bash
   nano /home/ubuntu/cod/jok/plugins/codverify-shopify/.env
   # SHOPIFY_APPS array mein new entry add karo
   ```
3. **Rebuild plugin:**
   ```bash
   docker compose up -d --build shopify
   ```
4. **Merchant install link:**
   ```
   # Default merchant ke liye:
https://shopify.codverify.tech/auth?shop=MERCHANT_STORE.myshopify.com&app=0

# Merchant2 ke liye:
https://shopify.codverify.tech/auth?shop=MERCHANT_STORE.myshopify.com&app=1

# Merchant3 ke liye:
https://shopify.codverify.tech/auth?shop=MERCHANT_STORE.myshopify.com&app=2

   ```
   *(INDEX = array mein position, 0 se start)*

---

## Shopify Partners App Setup (Ek Baar)

| Field | Value |
|-------|-------|
| App URL | `https://shopify.codverify.tech/auth` |
| Redirect URL | `https://shopify.codverify.tech/auth/callback` |

---

## Common Commands

```bash
# Sab restart
docker compose restart

# Sirf backend restart
docker compose restart backend

# Full rebuild (code change ke baad)
docker compose up -d --build

# Logs dekhna
docker logs codverify-backend --tail 50 -f
docker logs codverify-shopify --tail 50 -f

# Stop sab
docker compose down

# Supabase DB column add (ek baar):
# merchant_settings: ADD COLUMN cod_verification_enabled boolean DEFAULT true
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Port already in use | `docker compose down && docker compose up -d --build` |
| HMAC fail | Check `SHOPIFY_APPS` secret correct hai |
| Orders nahi aa rahe | Check backend logs + subscription active in Supabase |
| Cancel nahi ho raha | Check access_token_encrypted in stores table |
